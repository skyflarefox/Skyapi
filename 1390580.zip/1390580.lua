-- Lua provided by SkyAPI 
-- Game: Curse Lsland
addappid(1390580)
addappid(1390581, 1, "18b0910ac4c030cd72f52e0be92b7873b0e0741a8d71181c059920f7bd6e4a45")
