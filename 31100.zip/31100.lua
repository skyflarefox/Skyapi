-- Lua provided by SkyAPI 
-- Game: Wallace & Gromit’s Grand Adventures
addappid(31100)
addappid(31101, 1, "f7f4133e91a013cfe62739a4a98f2532af39e7f651980aa4b2b3a59d63e9304c")
