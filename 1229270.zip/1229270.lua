-- Lua provided by SkyAPI 
-- Game: AppID 1229270
addappid(1229270)
addappid(1229271, 1, "a52d45a993058f3cf2e5300bef20957689ee7823ca38f6fc5f31020927c4da2d")
