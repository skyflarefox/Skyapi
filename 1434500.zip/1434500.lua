-- Lua provided by SkyAPI 
-- Game: AppID 1434500
addappid(1434500)
addappid(1434501, 1, "38552a4866cbbb7fe8897a4958b532d06c6b8042050c7a463a607f950f315066")
