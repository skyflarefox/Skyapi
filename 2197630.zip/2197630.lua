-- Lua provided by SkyAPI 
-- Game: Art Reborn: Painting Connoisseur Demo
addappid(2197630)
addappid(2197631, 1, "74e4691a50a4da7b911f4db70f2d266a81045becb7ea94fa76959f2fc736f957")
