-- Lua provided by SkyAPI 
-- Game: AppID 1537540
addappid(1537540)
addappid(1537541, 1, "5119c7077728fa646917d05271a8938f0ef17d4fa1b92579fb6beb642841499e")
