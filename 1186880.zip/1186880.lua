-- Lua provided by SkyAPI 
-- Game: OctoFurry
addappid(1186880)
addappid(1186881, 1, "01d527238fd539cccf2eabb87c47c3f2fc09ebdac6827964f6eaeb168690bf46")
addappid(1186882, 1, "47a226b196dacd0260d6971232beee2cf1ca1c8df93e12ad365f2040d19f3a0e")
addappid(1186883, 1, "e16c673ba16fa6c46f161a16483e3227ff9c20db6a122cb1b1960969ddf20c88")
addappid(1192920, 0, "6eed81c8dd11ba8ad8f0555d92aa1ae82e092f8d4ee1ccc349fbe4410ea7ee2f")
