-- Lua provided by SkyAPI 
-- Game: OctoFurry
addappid(1186880)
addappid(1186881, 1, "01d527238fd539cccf2eabb87c47c3f2fc09ebdac6827964f6eaeb168690bf46")
addappid(1192920, 0, "6eed81c8dd11ba8ad8f0555d92aa1ae82e092f8d4ee1ccc349fbe4410ea7ee2f")
