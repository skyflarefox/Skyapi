-- Lua provided by SkyAPI 
-- Game: Embr
addappid(1062830)
addappid(1062831, 1, "b67bf65058bab34ac1aec469651b75032e1bff85cdd58cb2e28d51f107d29776")
addappid(1363500)
addappid(1518080)
addappid(1843280)
