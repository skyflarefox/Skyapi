-- Lua provided by SkyAPI 
-- Game: AppID 2466890
addappid(2466890)
addappid(2466891, 1, "1fec422e2694f6cdb335d0d337c5e41bba2241562869823cea6bc374289a351a")
