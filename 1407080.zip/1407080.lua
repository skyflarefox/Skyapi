-- Lua provided by SkyAPI 
-- Game: Fisti-Fluffs
addappid(1407080)
addappid(1407081, 1, "9769abbae02783b449a3dd6e5c6fb7b76fa5792d94f4a08f0ed68cd5ca56ee71")
