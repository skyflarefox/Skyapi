-- Lua provided by SkyAPI 
-- Game: start;again
addappid(1927140)
addappid(1927141, 1, "55a176426253881a11278ca8fda3fd6a4e8df32fa26dbc2ef5cd1e75a62d0c69")
