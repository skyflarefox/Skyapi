-- Lua provided by SkyAPI 
-- Game: MeiQi 2023
addappid(2180430)
addappid(2180431, 1, "94ab8fd69a0267675c3d5df4003e54dc33e3bd3035e18097e7c64d39bb0134e7")
