-- Lua provided by SkyAPI 
-- Game: Reign Of Kings
addappid(344760)
addappid(344761, 1, "552f512e7952332484cee4970163dcca1f753b50d718397558f532af5d4c7a11")
