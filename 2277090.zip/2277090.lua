-- Lua provided by SkyAPI 
-- Game: DAEMON MASQUERADE
addappid(2277090)
addappid(2277091, 1, "4ba9c2038eafdc96aca0289a17244f4ae5347b09c1f9359c9beca3d3a11d716f")
