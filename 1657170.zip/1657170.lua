-- Lua provided by SkyAPI 
-- Game: Suspicious Downpour
addappid(1657170)
addappid(1657171, 1, "030ba35999ece9b62a23acf872a17b9b0b640ee53338fcb3e9c0ed5448f6e0dc")
