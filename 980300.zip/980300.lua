-- Lua provided by SkyAPI 
-- Game: One Finger Death Punch 2
addappid(980300)
addappid(980301, 1, "d4caf6e62301b386a22a2a4a519a5299fe3a1d1df7d699670988e8c4daca9d61")
