-- Lua provided by SkyAPI 
-- Game: AppID 763030
addappid(763030)
addappid(763031, 1, "b8831ca0f934defa24c412a335db7b9e417ca1047053aa2ac3b46c2ff16e0948")
