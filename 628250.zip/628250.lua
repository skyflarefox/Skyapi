-- Lua provided by SkyAPI 
-- Game: AppID 628250
addappid(628250)
addappid(628251, 1, "017f6690629fb78a6a8e9178d606639401c79ff1d3e7bfbf16d6070cdbd4258a")
