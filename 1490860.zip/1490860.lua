-- Lua provided by SkyAPI 
-- Game: Til Nord
addappid(1490860)
addappid(1490861, 1, "68f223df541d84358725331bee5bf816f85a84e0926c15fd8d321ee47892d8a0")
