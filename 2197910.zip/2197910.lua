-- Lua provided by SkyAPI 
-- Game: Dawnlands
addappid(2197910)
addappid(2197911, 1, "02572a3398cac8a3d34a536c6dea329f205da67420f70b54c95c5d277bd6b8b9")
