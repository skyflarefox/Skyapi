-- Lua provided by SkyAPI 
-- Game: stein.world
addappid(1049660)
addappid(1049661, 1, "55cc9aa0ae0a982659fb766ddc1dd5d6f0669deb5b12e14d9ae68d13f80c70b3")
