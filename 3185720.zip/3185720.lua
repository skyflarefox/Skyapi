-- Lua provided by SkyAPI 
-- Game: 像素旅人-Pixel Traveler
addappid(3185720)
addappid(3185721, 1, "60e1d6496df4061c829dd3f469277d399d7214c69cca6ea84608f81818feea34")
