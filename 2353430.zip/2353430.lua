-- Lua provided by SkyAPI 
-- Game: AppID 2353430
addappid(2353430)
addappid(2353431, 1, "b3d32739fa28c3a6f7c83c6911526c2f801fb871e7c6209f59d8f0b4457ca3dd")
