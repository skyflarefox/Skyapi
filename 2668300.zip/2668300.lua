-- Lua provided by SkyAPI 
-- Game: Sakura Segment 1.0
addappid(2668300)
addappid(2668301, 1, "5631200e24b6ddad73cdbcce58d3356c56181caf1f931a3b815c5f376afb8853")
