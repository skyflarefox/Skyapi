-- Lua provided by SkyAPI 
-- Game: Health Insurance Claim Denier
addappid(3451060)
addappid(3451061, 1, "0609a62e8a8c3591d3e877c7069c60da5db90dc72b2b804c36807502b7c19865")
