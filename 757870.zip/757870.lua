-- Lua provided by SkyAPI 
-- Game: Australian trip
addappid(757870)
addappid(757871, 1, "19812b28f9bc33219b73665b08c92ec73a5603a9c81064323df39e2ef6cf23a6")
addappid(774111, 0, "0d7bb7bbc273bf765cf96aff74c4597bad88f647922c570473260e5c73f7d055")
