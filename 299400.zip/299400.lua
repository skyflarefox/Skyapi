-- Lua provided by SkyAPI 
-- Game: XING: The Land Beyond
addappid(299400)
addappid(299401, 1, "f6aa243a527dbdea4642d8094bd4268c3f3b3aa7606cd9bc3264fe9518518a57")
