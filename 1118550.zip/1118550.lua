-- Lua provided by SkyAPI 
-- Game: AppID 1118550
addappid(1118550)
addappid(1118551, 1, "29aebf7a697d06d3fddd5c2652da9d70f6c77561aa5ab2bb74e605052d4aee0c")
