-- Lua provided by SkyAPI 
-- Game: HO-HOP! - Christmas Board Game
addappid(3339600)
addappid(3339601, 1, "b2fc1c24d94180b7a3e621214e6cce4f8ba981f06005c2918f8cb19800715467")
