-- Lua provided by SkyAPI 
-- Game: Contraband Police: Prologue
addappid(1396240)
addappid(1396241, 1, "c49f850a8ed604c11ed85e7e6279f7b1ebac6f9bddc9b03b73c47431820437c9")
