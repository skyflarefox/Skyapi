-- Lua provided by SkyAPI 
-- Game: AppID 940520
addappid(940520)
addappid(940521, 1, "7ffe27143ea6feceb66302bf2a01a5dfb30d6b6485098d72732d0657a3cee1e6")
addappid(943870, 0, "2ea1e792f15cb5c176856485ea55a824ac427a75bea395139cdb3904ecf8712a")
addappid(943871, 0, "1c65133bc317e8c12dacdcfbe8c9f6d98e2d76dfbc0e73690dfe4c4e58f7db63")
