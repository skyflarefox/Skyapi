-- Lua provided by SkyAPI 
-- Game: NiGHTS Into Dreams
addappid(219950)
addappid(219951, 1, "c0fd424e8a1a95a16118e829b811263cb79a8f66510826fedba3eadab9cf6daa")
