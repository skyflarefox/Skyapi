-- Lua provided by SkyAPI 
-- Game: OBSCURIA
addappid(2756780)
addappid(2756781, 1, "3fdbb343b5ab2a89c8ac805d6f03a55906ea951591e8e04b41b350edf2727030")
addappid(3492080)
