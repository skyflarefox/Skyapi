-- Lua provided by SkyAPI 
-- Game: Disgaea 4 Complete+
addappid(1233880)
addappid(1233881, 1, "61c99a12f757f3bd4d8e69503c05e32e1184b97a184c79eec397860b1fdb578f")
addappid(1342160, 0, "62982db0fc7f2531b1d0de0ae7dc139e94500fcfbaf74c68e0b61d11a04824d2")
