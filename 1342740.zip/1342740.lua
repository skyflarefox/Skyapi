-- Lua provided by SkyAPI 
-- Game: AppID 1342740
addappid(1342740)
addappid(1342741, 1, "3f44acda3a2db385455f2af36c16e55c4cd7557a838920d47df3b62f40f8a3c3")
