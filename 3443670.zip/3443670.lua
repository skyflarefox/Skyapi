-- Lua provided by SkyAPI 
-- Game: 赤ずきんちゃんのお見舞い
addappid(3443670)
addappid(3443671, 1, "d4af0513ebdd72229f2bdaac01a0b615f847229b544ac180ed010e60fa97eb61")
