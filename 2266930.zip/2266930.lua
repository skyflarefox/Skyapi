-- Lua provided by SkyAPI 
-- Game: RUSLICSTAN INVADES
addappid(2266930)
addappid(2266931, 1, "b5dbd6a3aec432f7b0fad20c481860a8fb173bd496251d12164fc24b1d92d591")
