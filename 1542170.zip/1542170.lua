-- Lua provided by SkyAPI 
-- Game: vissekom
addappid(1542170)
addappid(1542171, 1, "06289f07b2ceeaf8b86d037b91ae3bfe34c80278776262526dbb48a3cc2c3b3a")
addappid(1542172, 1, "cb87fc159b7ec91885611e53bd77298e1f709917419c933b870f0fa7b15dbd4e")
