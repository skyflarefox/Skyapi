-- Lua provided by SkyAPI 
-- Game: Survive The Dark
addappid(1558670)
addappid(1558671, 1, "448e1673c4e2ac7b2a338d57149286383053012268f29efe78dda8612203c456")
