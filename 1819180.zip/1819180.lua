-- Lua provided by SkyAPI 
-- Game: Oxide Room 104
addappid(1819180)
addappid(1819181, 1, "dce5c642fcde8cd5cc49f778ecfb3de40c212dc011d2e3244cad46739801c2c2")
