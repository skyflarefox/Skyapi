-- Lua provided by SkyAPI 
-- Game: Daiichi Dash
addappid(1285600)
addappid(1285601, 1, "09f683b8497aa1c3f9ff282726c133356aa8da2282289780d9a8d62327e5782a")
