-- Lua provided by SkyAPI 
-- Game: AppID 2135900
addappid(2135900)
addappid(2135901, 1, "5ea8b248ac0fa6eac04c52ad85afe0951c30220d79f28b72efa1827d017f34a3")
