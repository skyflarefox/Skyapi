-- Lua provided by SkyAPI 
-- Game: Pixel Gladiator
addappid(542400)
addappid(542401, 1, "0b1f2970edb076b03a61fec3d1a9bcd4474e43fb318da25e6317488e84bc09f6")
addappid(566760)
