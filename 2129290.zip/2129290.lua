-- Lua provided by SkyAPI 
-- Game: Scary School Simulator
addappid(2129290)
addappid(2129291, 1, "239f26336c07ba572f962ed9961893b30530316b9b41cdc164a4ed366c7d0455")
