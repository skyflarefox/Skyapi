-- Lua provided by SkyAPI 
-- Game: AppID 2887050
addappid(2887050)
addappid(2887051, 1, "619dfe46f900ed90ded83d40460b2ae3946d60a48ca82dc26ebb3d747c745ffe")
