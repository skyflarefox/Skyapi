-- Lua provided by SkyAPI 
-- Game: AppID 593150
addappid(593150)
addappid(593151, 1, "b4ee0611fdd059f6a536960846241bc2622e51d5008c36dd5dab63506661a200")
