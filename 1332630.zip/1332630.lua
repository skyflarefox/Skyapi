-- Lua provided by SkyAPI 
-- Game: Zombeer: Delivery Mission
addappid(1332630)
addappid(1332631, 1, "1735db0223970c36f257e1d0445552be6fc9e8d427a2ebbfece83649695c8dbd")
