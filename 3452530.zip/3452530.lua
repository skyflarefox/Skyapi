-- Lua provided by SkyAPI 
-- Game: Run-Sprint-Parkour!
addappid(3452530)
addappid(3452531, 1, "43f2c92eca8e99aab0f2af65884a66b021d9efd35b4e484f1ca48b48379000c1")
