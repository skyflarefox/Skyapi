-- Lua provided by SkyAPI 
-- Game: MEMORIAPOLIS
addappid(2228280)
addappid(2228281, 1, "43ae0c2c71df2d5cfb0d270b8568580b99b626f5ebaa5d6115aefe84f3cd901a")
