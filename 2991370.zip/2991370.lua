-- Lua provided by SkyAPI 
-- Game: AppID 2991370
addappid(2991370)
addappid(2991371, 1, "27ecbe23f4043341d31e4660772c367410e89e717f9648444e7e5b91c744860a")
