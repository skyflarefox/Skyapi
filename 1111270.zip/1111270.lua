-- Lua provided by SkyAPI 
-- Game: AppID 1111270
addappid(1111270)
addappid(1111271, 1, "ba2b31c67eb03f4c07966b72fea45a307f8172b298585afcbfe6603593bfecaf")
