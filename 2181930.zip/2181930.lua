-- Lua provided by SkyAPI 
-- Game: AppID 2181930
addappid(2181930)
addappid(2181931, 1, "855fed2de6c56315ee1e987c549bad7917ae168dc87c075ef656e185eae595b1")
