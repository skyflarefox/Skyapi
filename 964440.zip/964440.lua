-- Lua provided by SkyAPI 
-- Game: Hell is Others
addappid(964440)
addappid(964441, 1, "203b89acdccfef4597d6693196f8bf70f383f015a7f545da663e4a229775a3bb")
