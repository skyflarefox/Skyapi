-- Lua provided by SkyAPI 
-- Game: Royal Legends: Raised in Exile Collector's Edition
addappid(1986630)
addappid(1986631, 1, "4c5d652d86d9248e29f8870d2a0994171496db429134b57cc4de51eb4b496f30")
