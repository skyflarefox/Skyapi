-- Lua provided by SkyAPI 
-- Game: GHOST HUNTER
addappid(2327840)
addappid(2327841, 1, "d451b26adf7c5ddd761261c6f8dd83cc30f0920d4b3cabb2a6974f6e839e1f8d")
