-- Lua provided by SkyAPI 
-- Game: AppID 2107140
addappid(2107140)
addappid(2107141, 1, "2dd8b39297785b06a4b8689406422feb676e652ea205b8b76ffb62c07de85087")
