-- Lua provided by SkyAPI 
-- Game: Erophone:Re
addappid(1832740)
addappid(1832741, 1, "b2c9133f2d1656b538e57486ea7ca57b6358b15649c1ac6793fd62bd4af2ca55")
