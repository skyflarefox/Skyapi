-- Lua provided by SkyAPI 
-- Game: Nine Heavens
addappid(3252190)
addappid(3252191, 1, "a07131d960f75800930bb903ec36c5175bfacc459a75d26026fd6543df72984d")
