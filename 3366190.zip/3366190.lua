-- Lua provided by SkyAPI 
-- Game: AppID 3366190
addappid(3366190)
addappid(3366191, 1, "c7420f83a845017ed34900821f00363eb8e78db6b046915a08c7070946bc34f3")
