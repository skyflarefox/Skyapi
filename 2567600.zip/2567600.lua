-- Lua provided by SkyAPI 
-- Game: Scare Girl 2
addappid(2567600)
addappid(2567601, 1, "0f48c9d09c592ab75eb495e8fc6ba953dcdd6f15ab876d64907a6facf46a72ae")
