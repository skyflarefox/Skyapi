-- Lua provided by SkyAPI 
-- Game: AppID 1009270
addappid(1009270)
addappid(1009271, 1, "2c85f5d4149d6989c7e9bd8934b5913fece33736e782d9bfbf3d71a24887f6be")
