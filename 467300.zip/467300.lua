-- Lua provided by SkyAPI 
-- Game: AppID 467300
addappid(467300)
addappid(467301, 1, "a5362ebb010126d49d81d4d7d381f31555103f3aaccdc29b3212fc8900f548c2")
addappid(467302, 1, "ffe5f6d0653e0acd3ca28bac409b039b674df88593a93a1a0e824357ef66021d")
