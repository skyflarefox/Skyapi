-- Lua provided by SkyAPI 
-- Game: Demons Rise Up!
addappid(1701660)
addappid(1701661, 1, "2007d019abf7b60003497fd33e81fdecca2b23725d8324457ccf360bfe90882b")
