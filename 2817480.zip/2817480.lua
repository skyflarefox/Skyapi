-- Lua provided by SkyAPI 
-- Game: Eternal end
addappid(2817480)
addappid(2817481, 1, "c34451d893febd505eeac975935af1af14a35273050ef5a7ade3d5fc091a4672")
