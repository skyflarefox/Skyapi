-- Lua provided by SkyAPI 
-- Game: AppID 1263740
addappid(1263740)
addappid(1263741, 1, "d7c25a558c01020d8bbcdc4e2c481bb240ef8ce7668359786560c027ad721242")
