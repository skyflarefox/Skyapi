-- Lua provided by SkyAPI 
-- Game: Math Climber
addappid(3561510)
addappid(3561511, 1, "d5915a04ff7a4da342d9b861d4a1854b54838ac90779c9245ff1f4051bbcecbf")
