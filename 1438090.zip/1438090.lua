-- Lua provided by SkyAPI 
-- Game: Hobo Cat Adventures
addappid(1438090)
addappid(1438091, 1, "3580b50900edd85fa3dbdad5fb2a3398e112ed3e8ccd580df3fdc39489b34ee1")
