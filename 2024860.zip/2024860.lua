-- Lua provided by SkyAPI 
-- Game: Barista: Take Away
addappid(2024860)
addappid(2024861, 1, "a92277e85f5d186fc59f8f6d7475cc441d308c7f14875e7d052fa41e9e1166dd")
