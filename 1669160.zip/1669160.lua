-- Lua provided by SkyAPI 
-- Game: ENDLESS BECOMING - APARTMENT
addappid(1669160)
addappid(1669161, 1, "d708e15cb4184ee5b6942c3490af438e86ded2de77678327750bb7d26196f2b0")
