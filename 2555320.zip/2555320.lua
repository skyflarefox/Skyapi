-- Lua provided by SkyAPI 
-- Game: Summon
addappid(2555320)
addappid(2555321, 1, "87ac54e6035b1667b18054e619f46f1fce93611de2b69c7fe452a02afc314674")
