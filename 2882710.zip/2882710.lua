-- Lua provided by SkyAPI 
-- Game: Sword and Shield Idle
addappid(2882710)
addappid(2882711, 1, "b723be8a80c85650fc4e2ad26e08a24cb64210f5db3fe7bbca8ad5fefab51888")
