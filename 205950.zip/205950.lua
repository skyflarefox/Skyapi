-- Lua provided by SkyAPI 
-- Game: AppID 205950
addappid(205950)
addappid(205951, 1, "312f275b9df5617d29920993de70d6e5cbbffe3e7ac8fbd8a9b19deb7f68fe25")
addappid(229000)
