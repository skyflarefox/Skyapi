-- Lua provided by SkyAPI 
-- Game: Lolita Expedition
addappid(1687940)
addappid(1687941, 1, "f1f88e08bb0b4eb82388368df11526be432535faedbb68960b1ca0fa62a77e18")
addappid(2259430, 0, "f2cc6a901b6aa1f0318e97fc4fc8ae5350787b458dadbb6497240dd6a42d7d13")
addappid(2317350, 0, "a6e956810d3c410f84da62016b952aaf185d4ccfeda0256386c76d3208cc832b")
addappid(2317360, 0, "0bb1a07f7e12a08c9c52c7b704ea22f28a8cc923b5fda1240fa7b661ac3ab000")
