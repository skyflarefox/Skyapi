-- Lua provided by SkyAPI 
-- Game: AppID 501380
addappid(501380)
addappid(501381, 1, "0f8e470451b99d647fc43e62f4e1897210f89d8b6f09581a8a7bf344aaad0a4c")
