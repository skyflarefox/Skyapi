-- Lua provided by SkyAPI 
-- Game: AppID 2720950
addappid(2720950)
addappid(2720951, 1, "4da596c43247b7cfad598477ab22ba008605f5c503cfef3780e28b5b29951185")
