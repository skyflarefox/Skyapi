-- Lua provided by SkyAPI 
-- Game: DRIFT ISLAND Playtest
addappid(3116850)
addappid(3116851, 1, "40b04f3e5fa7a13766061718bd55f1489d2143ab96b0f0ec29d2fd7ebd7063f1")
