-- Lua provided by SkyAPI 
-- Game: EVERSLAUGHT
addappid(1530750)
addappid(1530751, 1, "ac2be9130379ebe103f94c96ef11bd267df681fdee0e73f2079bcbd53ee331a5")
