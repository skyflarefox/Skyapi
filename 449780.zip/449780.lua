-- Lua provided by SkyAPI 
-- Game: Jacob
addappid(449780)
addappid(449781, 1, "38a68407db3b8234edbf7fbd97b633d89da9b3d561f0c1f45242082a254459a2")
