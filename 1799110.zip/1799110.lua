-- Lua provided by SkyAPI 
-- Game: Jumper
addappid(1799110)
addappid(1799111, 1, "033289fcf3e9e67040a88b25d5f4055e53db6185f96f8b8ba11d55ff466b0792")
