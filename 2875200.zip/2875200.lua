-- Lua provided by SkyAPI 
-- Game: Max Mustard Soundtrack
addappid(2875200)
addappid(2875201, 1, "4899c61b27b351a8369ef90eaf94e4244ce6a6e172512f1dae7d7d6511ca927f")
