-- Lua provided by SkyAPI 
-- Game: What a Shitty Job
addappid(3278480)
addappid(3278481, 1, "13ddd42a7207f4891f82966867b31df96c67c66caa2d6b733c4425086c57ddc1")
