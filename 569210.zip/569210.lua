-- Lua provided by SkyAPI 
-- Game: AppID 569210
addappid(569210)
addappid(569211, 1, "59de8afb0b07b7b88c8dbe1092f87101ac5f781b0458552450bbe295d83c07bb")
addappid(611950, 0, "796e6beb065a2baa25385bd8e55829ab9a187890720902ec7d7b09d4b2b1d024")
