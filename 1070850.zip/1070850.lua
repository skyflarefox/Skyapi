-- Lua provided by SkyAPI 
-- Game: Today Is My Birthday
addappid(1070850)
addappid(1070851, 1, "23130a4258a5f1d2f80b25f4ae53dd64e194139a6402023a1545f71bfc6c1d6d")
