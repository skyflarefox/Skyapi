-- Lua provided by SkyAPI 
-- Game: Keng's Little Universe
addappid(1725860)
addappid(1725861, 1, "bf39fba06434b862cb651702ca72b145424f4680411f2655712781639e64987c")
