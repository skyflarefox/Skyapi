-- Lua provided by SkyAPI 
-- Game: My Furry Dictator Demo
addappid(1771870)
addappid(1771871, 1, "3ff9e7208264d82b2009c5b767888f6f7102358ed132ef51d0766582baa65b25")
