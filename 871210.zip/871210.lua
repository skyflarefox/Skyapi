-- Lua provided by SkyAPI 
-- Game: Lamp Chronicle
addappid(871210)
addappid(871211, 1, "bb95d73b302c82eb8d64ee34f0f6c2cad01c839e2e49e9d07d2cebd1933ed115")
