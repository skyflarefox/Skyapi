-- Lua provided by SkyAPI 
-- Game: PROJEKT GODHAND
addappid(2978440)
addappid(2978441, 1, "004dc9e4d6f18cb965014e1f1b513fd2a0dd0d6ceaec09cc09c06c3cf35d880f")
addappid(3807110)
addappid(3906880)
