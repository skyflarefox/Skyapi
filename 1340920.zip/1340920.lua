-- Lua provided by SkyAPI 
-- Game: AppID 1340920
addappid(1340920)
addappid(1340921, 1, "4909aa6d93be798749bae0493c9387e351f8029da646a1aff246770380942237")
