-- Lua provided by SkyAPI 
-- Game: Cardfight!! Vanguard Dear Days 2
addappid(2457540)
addappid(2457541, 1, "5195261e7ca5f37ebc06fd9599b9b8cbc1b172ea54cec4096d3e60b8f176643e")
