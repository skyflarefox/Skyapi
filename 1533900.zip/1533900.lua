-- Lua provided by SkyAPI 
-- Game: MAMIYA Demo
addappid(1533900)
addappid(1533901, 1, "63b2eb064f3f0bd3daa620885bf6fd9ca9c8babeea5bc8b012ec0246490a22b4")
