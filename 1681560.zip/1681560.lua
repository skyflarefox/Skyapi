-- Lua provided by SkyAPI 
-- Game: Hungry Bunny
addappid(1681560)
addappid(1681561, 1, "3b04a5d24aaf3295a9e5e3780fe2fe6fd7f36759e3fa4bad03ca4561cd0cfda4")
