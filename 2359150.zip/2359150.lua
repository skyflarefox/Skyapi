-- Lua provided by SkyAPI 
-- Game: Ultimate Blackball
addappid(2359150)
addappid(2359151, 1, "ade1bc7e0f37d71d4f9744ed613cd0a32f4a5be160417b2f26d2d56a99faefc0")
