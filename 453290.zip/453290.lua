-- Lua provided by SkyAPI 
-- Game: Awareness Rooms
addappid(453290)
addappid(453291, 1, "40a1d011ebc135c4c26c18fda3118ea1052d296e04d35c9580d6d1512624b7b7")
addappid(453292, 1, "746cd9b062b053be1297c15c7ec706b909e6e09c93756108e3116ab06fe7e977")
