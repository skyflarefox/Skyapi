-- Lua provided by SkyAPI 
-- Game: Orb Flight
addappid(2406540)
addappid(2406541, 1, "3cd841d0dc1bb59a18b47e7a849584f3486307e3c4fdb22de8a738fe7959d1a2")
