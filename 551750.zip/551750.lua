-- Lua provided by SkyAPI 
-- Game: Survival VR
addappid(551750)
addappid(551751, 1, "6b9e7bc052cd59c62dbb1953aa4d45fed4dc237e5d9d799e44f6e837adfc1884")
