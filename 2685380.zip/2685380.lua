-- Lua provided by SkyAPI 
-- Game: CHAIRS
addappid(2685380)
addappid(2685381, 1, "c5d0f22c5af35714c77cd514e499344b9298e5c4f54960f2d9a656a79e9f0269")
