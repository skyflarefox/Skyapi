-- Lua provided by SkyAPI 
-- Game: Apartment Story
addappid(3069870)
addappid(3069871, 1, "bbce455ce6bc471a73d563ed6d2b2f8386340b8207afdd02cd6a6b031d9c9ff7")
