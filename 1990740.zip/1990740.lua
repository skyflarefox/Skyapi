-- Lua provided by SkyAPI 
-- Game: Barro GT
addappid(1990740)
addappid(1990741, 1, "84fa5dd4ee0cd89e37c3ed1f89656a8a614bbcc1ec42668205e2f8c638c458fb")
