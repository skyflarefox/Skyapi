-- Lua provided by SkyAPI 
-- Game: AppID 227700
addappid(227700)
addappid(227701, 1, "dfd265efd149b5faf48f88bb7f1162f802ace723ff0c734c2f943bfee80d5111")
addappid(228982)
addappid(228985)
addappid(228990)
addappid(229000)
addappid(310090)
addappid(310091)
