-- Lua provided by SkyAPI 
-- Game: FLATHEAD
addappid(2840480)
addappid(2840481, 1, "6179b8bc5b13f8586375cfdd8d642b3d6ed4a7954435cd1192bee1e8716a0329")
