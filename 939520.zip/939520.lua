-- Lua provided by SkyAPI 
-- Game: AppID 939520
addappid(939520)
addappid(939521, 1, "34937eb8cf3adfaa70161d9ed569145b90f8dd53dd571ac6fd85f0777a67f3f1")
