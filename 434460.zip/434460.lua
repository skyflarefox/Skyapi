-- Lua provided by SkyAPI 
-- Game: Rock of Ages 2: Bigger & Boulder™
addappid(434460)
addappid(434461, 1, "3a02fbf8f2b8f47ee3ba37a0e4fa6e8f4b9e794dd2d95abd4cbf41c71c5721cd")
addappid(434462, 1, "ff41ed9ac0228ce19c30fc6ae2aa20cdb4dc3bbc185c510910fdb5ee01227e64")
addappid(434463, 1, "f77c2bb98646e339a89a460e92088ca71a430d3bb7478951b27905181a2bae5c")
addappid(645970)
