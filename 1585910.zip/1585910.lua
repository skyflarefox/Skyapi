-- Lua provided by SkyAPI 
-- Game: Roll
addappid(1585910)
addappid(1585911, 1, "a1607e661dfd48f06ea11c17573e67452c6f2efd277926e042dd1656047f61c4")
