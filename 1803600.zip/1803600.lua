-- Lua provided by SkyAPI 
-- Game: Gone Rogue
addappid(1803600)
addappid(1803601, 1, "fd56d425cad20c0a3a0a0a11590a52b9cf9898c942d6d94a5718c76e8ea5bfeb")
