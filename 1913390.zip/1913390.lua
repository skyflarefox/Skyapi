-- Lua provided by SkyAPI 
-- Game: AppID 1913390
addappid(1913390)
addappid(1913391, 1, "6e70276aff7f63f4f647a9675147ccf19be144ee9a80f3e7509844c469ce2fcd")
