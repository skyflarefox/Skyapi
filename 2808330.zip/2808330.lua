-- Lua provided by SkyAPI 
-- Game: Kill A Million Rats Demo
addappid(2808330)
addappid(2808331, 1, "b11013d4e17206d2eb3ab0eea4616058c3f5f399d5b6fac5dd81ac53a664efa2")
