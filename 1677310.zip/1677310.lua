-- Lua provided by SkyAPI 
-- Game: In Stars And Time
addappid(1677310)
addappid(1677311, 1, "5c168975657d2ce4b6970aabbee571b7c0a4d43d48184092896c8fbbb4bd8d4f")
