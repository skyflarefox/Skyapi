-- Lua provided by SkyAPI 
-- Game: Othercide - Soundtrack
addappid(1330380)
addappid(1330381, 1, "618618561970af797e6b1bbc2936c5ff2a8442766d2c6f0cde394a92ef65d7a9")
