-- Lua provided by SkyAPI 
-- Game: The Serpent Rogue
addappid(1453790)
addappid(1453791, 1, "e50f8591f16215ab7dbfc6506a8aec9d8efe46f87446145ea631f73ea2d7cfb6")
