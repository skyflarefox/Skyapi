-- Lua provided by SkyAPI 
-- Game: AppID 1626640
addappid(1626640)
addappid(1626641, 1, "9f88a2613b6224bd4f1afe81e6a533f43da3e3da23fb1e74cccfaac40a4d7f39")
addappid(1626720)
addappid(1715610, 0, "b4c7e011fe618943d34523c2019339f02ec7de67f5589e8fe0dc84898d8a7539")
