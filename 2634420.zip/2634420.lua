-- Lua provided by SkyAPI 
-- Game: Haunted Things
addappid(2634420)
addappid(2634421, 1, "2aa19bc8c63ee4771d6464d55e1faa18ecce1f250174c4b6ada2b4cb68acb6b6")
