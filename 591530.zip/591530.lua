-- Lua provided by SkyAPI 
-- Game: AppID 591530
addappid(591530)
addappid(591531, 1, "a5fbd6a50e5715132dcaaf578e24b2b4a954f1e92bcaab735ec61d60d06c2206")
