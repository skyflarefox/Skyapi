-- Lua provided by SkyAPI 
-- Game: Satellite Odyssey: Prologue
addappid(2579270)
addappid(2579271, 1, "3db4ef776544a3a8b8ac0484d0e56993e37d895b65a9396324ceb6efddd56a7e")
