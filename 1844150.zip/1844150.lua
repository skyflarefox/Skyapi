-- Lua provided by SkyAPI 
-- Game: Panzer Girls
addappid(1844150)
addappid(1844151, 1, "914062bc0d4a3f5afe0f69ea451b69ea695b7fc130863d69f7f1b1c2639c15b1")
