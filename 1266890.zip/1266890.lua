-- Lua provided by SkyAPI 
-- Game: AppID 1266890
addappid(1266890)
addappid(1266891, 1, "7b89eb28b0c51144d1a155fcef485476354332cff4e8a6bbc9aa4297b260e041")
