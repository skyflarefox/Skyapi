-- Lua provided by SkyAPI 
-- Game: AppID 766090
addappid(766090)
addappid(766091, 1, "e0cb827064fb2a33323679ff137122a4b1275a6b4748896b35533d63270432ec")
