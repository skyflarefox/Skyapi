-- Lua provided by SkyAPI 
-- Game: War Cube
addappid(527800)
addappid(527801, 1, "8a1040a0cef27167626717adab9cf292e99cd1b4c3f58da1d829a9a1c86328a8")
