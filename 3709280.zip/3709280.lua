-- Lua provided by SkyAPI 
-- Game: The Dark Crown: Genesis Demake
addappid(3709280)
addappid(3709281, 1, "23eedab7bb63a747e2b54e9f30e9ec9c5c716f0459f19d291d9e50fb1223414d")
