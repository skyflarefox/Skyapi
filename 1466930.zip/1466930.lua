-- Lua provided by SkyAPI 
-- Game: AppID 1466930
addappid(1466930)
addappid(1466931, 1, "93dbb20b59ae6175f8861b9891b5e160f7334a5d012337595b720a465b000bb7")
