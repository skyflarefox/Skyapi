-- Lua provided by SkyAPI 
-- Game: Frame of Mind
addappid(1485250)
addappid(1485251, 1, "691548217cfd998c1c6b236b649ca3b484c4dde3488108c7ce7d5891b4469184")
