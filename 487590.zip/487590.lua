-- Lua provided by SkyAPI 
-- Game: Pepe Porcupine
addappid(487590)
addappid(487591, 1, "54efb45fdcd64e825d637179d7fc0cf4cb8b8777c8458fee503c45d75f0b0074")
