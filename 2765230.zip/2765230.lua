-- Lua provided by SkyAPI 
-- Game: 东方：平野孤鸿 Demo版
addappid(2765230)
addappid(2765231, 1, "5323f370667db77edadc1cbf4de300d89990bc9b72f0550491e92a87d882ee53")
