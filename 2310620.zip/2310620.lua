-- Lua provided by SkyAPI 
-- Game: Ballooni - balloon homunculus
addappid(2310620)
addappid(2310621, 1, "4c9e1ba724318ef7d1146b5660a659825a6fc1445375092db5b7070ed957dd98")
