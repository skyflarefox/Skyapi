-- Lua provided by SkyAPI 
-- Game: Alvo VR
addappid(2000590)
addappid(2000591, 1, "1d5e28d260cabd22ed878fb158ff1a2067c5c111f22cee5278165593277992bc")
