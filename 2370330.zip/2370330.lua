-- Lua provided by SkyAPI 
-- Game: Linia Stripes
addappid(2370330)
addappid(2370331, 1, "2bfc1f2b0b844b09cdc6e01e48799c7640d73abf806559f0c8995a0c4853a6a8")
