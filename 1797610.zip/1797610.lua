-- Lua provided by SkyAPI 
-- Game: Barro 22
addappid(1797610)
addappid(1797611, 1, "64e96c0120134f5f264cc3b8cfd515e5a6ebc5c500d81d22c04be84198d221ed")
