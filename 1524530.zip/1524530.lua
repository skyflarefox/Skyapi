-- Lua provided by SkyAPI 
-- Game: Fantasy Town Regional Manager
addappid(1524530)
addappid(1524531, 1, "656bb913ac6eb8211149f1dd51306c075ea438962bb8384ab1454b852a0134c7")
addappid(1524532, 1, "b73202d1e059078612f9dd0637d64bf1cdefdcabee070be57e0aea0be7aa4742")
addappid(1524533, 1, "5bc5ebbdd2ea3249b855b74da081390f31e7d3b3dc6be14f05c05ecadaf6d235")
