-- Lua provided by SkyAPI 
-- Game: AppID 12550
addappid(12550)
addappid(12551, 1, "1523470d6ded0bfc42e6712f53efa36aecf04a2b8068915b0b5c986d6aa941fd")
