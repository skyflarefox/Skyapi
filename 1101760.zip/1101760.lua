-- Lua provided by SkyAPI 
-- Game: CRAZY DRIVER
addappid(1101760)
addappid(1101761, 1, "0032fcd60ba0df86641d30a022d85596a5b4a111f0a3b6c7fc5199ae59a4b473")
addappid(1101762, 1, "4d6cf25232f9a2c68904381de1a9cec7e3db1f7100bfe1d144528f6083bcbba1")
addappid(1101763, 1, "bb1af7f4fd47fe952e7258eddb7747683af942ddcd8ad9e9847b872f7644a15c")
