-- Lua provided by SkyAPI 
-- Game: Pushing POPO
addappid(2141100)
addappid(2141101, 1, "bcd399cd3de8e812d9c62a660da6df1aeac9724bd8a2592fe945a20d3c808ff7")
