-- Lua provided by SkyAPI 
-- Game: S.W.I.N.E. HD Remaster
addappid(944010)
addappid(944011, 1, "b8f4c5498fbfc24b4b5c7d713bcef7de3b433e72bbae2b4488df7b516a347e72")
