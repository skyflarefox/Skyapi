-- Lua provided by SkyAPI 
-- Game: AppID 3400150
addappid(3400150)
addappid(3400151, 1, "a65e819d34e0189e00520ca8f97feee223652a12744b20476dbde980b6ce847b")
