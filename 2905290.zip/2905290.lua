-- Lua provided by SkyAPI 
-- Game: Easy Breezy Drive
addappid(2905290)
addappid(2905291, 1, "4e24708d4384161d73f84b67b42f3d4f44c7c5fabd76faf771fde5ed78beff01")
