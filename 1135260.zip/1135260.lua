-- Lua provided by SkyAPI 
-- Game: AppID 1135260
addappid(1135260)
addappid(1135261, 1, "c19bb6d1c7ec099597fcc92bc6d90c41f61d7130b01b7ca4593d149e00369da2")
