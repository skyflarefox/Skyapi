-- Lua provided by SkyAPI 
-- Game: AppID 46420
addappid(46420)
addappid(46421, 1, "54c46cce28b45e868447c614ff28b2b73ebd74a4f300e3691418451d02c05c34")
