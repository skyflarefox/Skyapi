-- Lua provided by SkyAPI 
-- Game: Bullet Noir Soundtrack
addappid(3693390)
addappid(3693391, 1, "a4ac97ac0504d754be35839aa0a9a8b99e0f8ea8c8f401f626bb5b716b7a9031")
