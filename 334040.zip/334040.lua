-- Lua provided by SkyAPI 
-- Game: Down To One
addappid(334040)
addappid(334041, 1, "e96d0a2a1fd77f3b140e7b128779c8e31ca32463b590bd5cc6e1df00bf6c794c")
