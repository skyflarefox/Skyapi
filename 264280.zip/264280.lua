-- Lua provided by SkyAPI 
-- Game: 99 Levels To Hell
addappid(264280)
addappid(264281, 1, "bd0804c00f11dce8944fe2e58e539479733cd3e71ce537f533f504bab3123d49")
addappid(264282, 1, "195663b396085f7279408c53992cb51950496c973bb31ccf4cbb6c6ad04ec9c3")
addappid(264283, 1, "306b9756dab78d93caebbad732a416eeebc9409aa688f02c410a7f25d0da4577")
addappid(275050)
