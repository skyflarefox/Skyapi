-- Lua provided by SkyAPI 
-- Game: AppID 3231760
addappid(3231760)
addappid(3231761, 1, "119d38faeb5e5001237a70acf521688fd11c482fced976ef2b5fd2723bb2767a")
