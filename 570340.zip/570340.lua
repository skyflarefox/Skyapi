-- Lua provided by SkyAPI 
-- Game: GoWings Safari
addappid(570340)
addappid(570341, 1, "bd7452631fcb4e368c37e0c09342802139e0acd4cf4c04b888561341503cb92c")
