-- Lua provided by SkyAPI 
-- Game: Scroll Of Life
addappid(1807250)
addappid(1807251, 1, "c35a3c5ca5d06b8d7be10e501c1dade028b775a11eda76f613c1ad19172a4a88")
