-- Lua provided by SkyAPI 
-- Game: Trails
addappid(3605120)
addappid(3605121, 1, "0d0838710fdf1b4eaf0f38202ad31bc2f7aa60391cb7c37e531e4004381d589c")
