-- Lua provided by SkyAPI 
-- Game: Raw Data
addappid(436320)
addappid(436321, 1, "9e019b8c077cfb79c936631e7efb043b7f680de505d7ef543f456916d7dc005b")
