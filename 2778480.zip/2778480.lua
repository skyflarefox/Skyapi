-- Lua provided by SkyAPI 
-- Game: AppID 2778480
addappid(2778480)
addappid(2778481, 1, "9bc705e6feeb8bfdded7956c5fad10039f2193433e132ce005c3c1ac604bf91d")
