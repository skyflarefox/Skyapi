-- Lua provided by SkyAPI 
-- Game: Tayutama: Kiss on my Deity
addappid(3430300)
addappid(3430301, 1, "49f55dfa1e0fe61db960b070c933655967af6c5784b392999810aaefbe47dae2")
