-- Lua provided by SkyAPI 
-- Game: AppID 2789660
addappid(2789660)
addappid(2789661, 1, "98c9265abb23b82895cff3ece834f529d7fd23158749bc296bb3216bfd840ce8")
