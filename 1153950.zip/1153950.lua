-- Lua provided by SkyAPI 
-- Game: USAGIRI
addappid(1153950)
addappid(1153951, 1, "b4b012c4740e29c26b2615986bc90f6573a4e9ea82db3683427b301be8aa68ab")
