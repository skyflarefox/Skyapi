-- Lua provided by SkyAPI 
-- Game: AppID 1158470
addappid(1158470)
addappid(1158471, 1, "e40e50eecc497833f93b4bfb0bc45de97143f9af1c4c7296c42b740b68f28045")
