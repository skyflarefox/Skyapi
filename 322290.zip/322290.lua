-- Lua provided by SkyAPI 
-- Game: Gurumin: A Monstrous Adventure
addappid(322290)
addappid(322291, 1, "43b1c0d3d24d21f3747d85aab8b97e7659495b00cbee44cc7c3e84ac68d8268a")
