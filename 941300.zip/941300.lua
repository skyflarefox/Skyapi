-- Lua provided by SkyAPI 
-- Game: AppID 941300
addappid(941300)
addappid(941301, 1, "14fd6a797d6c5f3ce8a1944820378308c36bfc5cb053ab0711f70cacdc4d60ca")
