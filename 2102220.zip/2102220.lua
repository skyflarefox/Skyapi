-- Lua provided by SkyAPI 
-- Game: Memory Puzzle - Futanari Boss
addappid(2102220)
addappid(2102221, 1, "4162d96e50a924f230d8101b87377f87149ab425bef7b255720277bfd8b19303")
