-- Lua provided by SkyAPI 
-- Game: AppID 1175390
addappid(1175390)
addappid(1175391, 1, "7c7c4728ad40a2a34cae37bd8d2f2f4df925d98ffa4fe0d04a19d86334074b26")
