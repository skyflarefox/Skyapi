-- Lua provided by SkyAPI 
-- Game: AppID 1894230
addappid(1894230)
addappid(1894231, 1, "bb8c02c4411e5aea9675913ee5eae4ef64bf9dd695c32ad385c49f6c1bfe166f")
