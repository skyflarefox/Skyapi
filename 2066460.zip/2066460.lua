-- Lua provided by SkyAPI 
-- Game: 灵魂筹码:契约
addappid(2066460)
addappid(2066461, 1, "902482db2b25bd0f7250fd4333d88b7a56991523b06771a88d0fcb2580270076")
