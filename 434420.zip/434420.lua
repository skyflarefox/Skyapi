-- Lua provided by SkyAPI 
-- Game: The Chosen RPG
addappid(434420)
addappid(434421, 1, "193ce930b2fc99a52fd0d67bac780b40cd83c3d0adbb94ec2e67b4aba54c28c4")
