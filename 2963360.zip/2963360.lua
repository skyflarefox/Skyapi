-- Lua provided by SkyAPI 
-- Game: Chicken Game
addappid(2963360)
addappid(2963361, 1, "0ad13300f9d07787db0ef31e5c675830bc930f7036da8f94c412efa793b7e865")
