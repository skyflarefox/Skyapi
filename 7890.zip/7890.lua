-- Lua provided by SkyAPI 
-- Game: Men of War™ Demo
addappid(7890)
addappid(7891, 1, "3aa2c8544fb40797813a1528a5183c3ee54b99a18fc8b3b65ddd2baaa60b0284")
