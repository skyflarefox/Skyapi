-- Lua provided by SkyAPI 
-- Game: AppID 2576240
addappid(2576240)
addappid(2576241, 1, "ad955a1e0347e84ba4691a45d642a33adbb1bf77d203dc8de75d494ff1787891")
