-- Lua provided by SkyAPI 
-- Game: Eastwind Adventures: Chapter 1
addappid(1656870)
addappid(1656871, 1, "50c61d2e2278fa0548db03fedcba6fa542b30719e6671c217ac27cfed742d655")
