-- Lua provided by SkyAPI 
-- Game: Ship Graveyard Simulator 2: Prologue
addappid(2295920)
addappid(2295921, 1, "f3f7cfc31f45fad416301b11a3eb84cf994c718ef861b99cd61a6bc8e09bba46")
