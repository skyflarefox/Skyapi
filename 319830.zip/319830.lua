-- Lua provided by SkyAPI 
-- Game: AX:EL - Air XenoDawn
addappid(319830)
addappid(319831, 1, "3a0e5cb2b83269f10df2a5e660731f45a9a13cd45330af26feca8f429ee11fb1")
