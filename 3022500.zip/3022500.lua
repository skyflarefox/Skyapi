-- Lua provided by SkyAPI 
-- Game: Sakura Alien 3
addappid(3022500)
addappid(3022501, 1, "aba8dcd345e6eb188bd36de1e1e1037e2f92589aeb975b48b7a7e065d6249546")
