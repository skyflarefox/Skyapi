-- Lua provided by SkyAPI 
-- Game: Bits n Bullets
addappid(730180)
addappid(730181, 1, "1e0600d5760fc421dd9f6c755aa4f6e71054ea4df72b425efea0d5115f871892")
