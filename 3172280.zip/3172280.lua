-- Lua provided by SkyAPI 
-- Game: SEX Amnesia - Lover Sim 🔞
addappid(3172280)
addappid(3172281, 1, "1646a77a092a374a2be5cbe417ef498dbd02bd3ea4567fb3d6907e14b46bb04e")
