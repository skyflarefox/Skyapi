-- Lua provided by SkyAPI 
-- Game: Hidden Town
addappid(1778470)
addappid(1778471, 1, "c1a1a55c520b6ebbca18e196b9bf69c2798a66e4df7cfd7be3640827a801f0ac")
