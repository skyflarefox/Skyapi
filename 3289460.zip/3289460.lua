-- Lua provided by SkyAPI 
-- Game: AppID 3289460
addappid(3289460)
addappid(3289461, 1, "c626b1489cd125f9024b2e801e5bfd478c101fa6874e3dd14c824bdb91afc877")
