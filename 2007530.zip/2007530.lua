-- Lua provided by SkyAPI 
-- Game: Spellbook Demonslayers
addappid(2007530)
addappid(2007531, 1, "3b14c44abae033b08e0106204baa1d68b9331044d2ba08a53c3423f79e811871")
addappid(2201670)
