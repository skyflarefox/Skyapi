-- Lua provided by SkyAPI 
-- Game: AppID 2906960
addappid(2906960)
addappid(2906961, 1, "a061b3200303313e50ddf2d27ec5a8d836f7cd443be99e526679046b176a0b75")
