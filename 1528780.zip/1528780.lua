-- Lua provided by SkyAPI 
-- Game: ABERRATION TOWN
addappid(1528780)
addappid(1528781, 1, "345ac6bee1141214e4119f6d2e7fbc2db67e0d1ffe9b52529b6f5a8cae61bef2")
