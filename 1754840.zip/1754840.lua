-- Lua provided by SkyAPI 
-- Game: Hacker Simulator
addappid(1754840)
addappid(1754841, 1, "a712e4d1bec4f811a9996e477ce6a964372106b3970ce86a38153fef3d12619d")
