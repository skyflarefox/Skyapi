-- Lua provided by SkyAPI 
-- Game: AppID 885030
addappid(885030)
addappid(885031, 1, "cbd06e08081cefe3fda86f4b36d9d4e079c26e863ea405c1f8623a3ef96a13bd")
