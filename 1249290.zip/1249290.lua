-- Lua provided by SkyAPI 
-- Game: The Curse of Zigoris
addappid(1249290)
addappid(1249291, 1, "4f98d9082bdbccda8513dba36bc5f07374073448f031b437d3821f9faae77a39")
