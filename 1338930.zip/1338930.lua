-- Lua provided by SkyAPI 
-- Game: Invaliens
addappid(1338930)
addappid(1338931, 1, "0f31e13929eb195c44dd889149080de96b558c94f08d5ba71a011b3fcc13e3d4")
