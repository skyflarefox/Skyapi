-- Lua provided by SkyAPI 
-- Game: AppID 3098700
addappid(3098700)
addappid(3098701, 1, "9fca6230f1704ba6822911358921cdd0296a3598e66475458ca0c81860bd4a7f")
