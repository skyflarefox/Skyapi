-- Lua provided by SkyAPI 
-- Game: Immortal Heritage
addappid(2082520)
addappid(2082521, 1, "b3e1e50cc6b767988465d85f8b0e68afd48d3fe9d3a44b9d6d94399d2ba9b5c0")
