-- Lua provided by SkyAPI 
-- Game: AppID 3393570
addappid(3393570)
addappid(3393571, 1, "c571fa4c65c9da76c39a4d5b19ebe15a34b95a38f3bbb0faf5c2ec7261367f64")
