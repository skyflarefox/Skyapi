-- Lua provided by SkyAPI 
-- Game: Affogato
addappid(1983970)
addappid(1983971, 1, "b7795d7254e20ba6ea12b707e751aadbf228356882c15f02e74e0b7b6b6ccfcb")
