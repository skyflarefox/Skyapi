-- Lua provided by SkyAPI 
-- Game: Solitairica
addappid(463980)
addappid(463981, 1, "3954e7a9a1ba1fd47cd583b901164192a859ce7dd63360791353b77afc44ab00")
