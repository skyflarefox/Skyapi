-- Lua provided by SkyAPI 
-- Game: AppID 1504720
addappid(1504720)
addappid(1504721, 1, "31ca0f9d9b91f02448f30ff93a00470baec16a94ecb33cd66331062bd2290560")
