-- Lua provided by SkyAPI 
-- Game: Supplice
addappid(1693280)
addappid(1693281, 1, "770718c10d551ffca5eb8b63fc2d1f94a628025b07f50764765e79e6a486daab")
