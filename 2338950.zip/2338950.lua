-- Lua provided by SkyAPI 
-- Game: Dream Ploy Will
addappid(2338950)
addappid(2338951, 1, "25c032e8eb6074cd485a26db99535e3cd46883f299784fe9fc85e05d691e73f7")
