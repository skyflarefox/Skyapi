-- Lua provided by SkyAPI 
-- Game: Rush Rally Origins Demo
addappid(1995970)
addappid(1995971, 1, "3f66300277de7ed9f227b06ce9f599ea1c8e06288cf57d339b9193e52a7230fc")
