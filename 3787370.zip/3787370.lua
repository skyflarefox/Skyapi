-- Lua provided by SkyAPI 
-- Game: Wholesome - Out and About Playtest
addappid(3787370)
addappid(3787371, 1, "efd64f1593218c3ec17724b1f470dcaab38675290a409e2df61208d41c19d1a6")
