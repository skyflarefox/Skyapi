-- Lua provided by SkyAPI 
-- Game: Ranch Farm and Store Simulator
addappid(3706960)
addappid(3706961, 1, "a1a4f83bc536c658071ce64e3c7693d17ed422982ef1da9b0fa7e579f9f347c0")
