-- Lua provided by SkyAPI 
-- Game: Elf World Adventure 2
addappid(2928820)
addappid(2928821, 1, "12864c0237763b184e907b846d02b70883675abe07ab8ba637c331e558bb9404")
