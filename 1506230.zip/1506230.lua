-- Lua provided by SkyAPI 
-- Game: Bigfoot Forest
addappid(1506230)
addappid(1506231, 1, "2f672697c8cef9ffb65446a9909ba3906038a9cd84a808d53347594b12e9f35f")
