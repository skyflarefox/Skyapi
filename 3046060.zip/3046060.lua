-- Lua provided by SkyAPI 
-- Game: Under The Crisis: Dárlia Island Remaster
addappid(3046060)
addappid(3046061, 1, "b10edcf7cfe46d77474fcfa4971dc7a638b78df6f61d93f27cb957283f83924c")
