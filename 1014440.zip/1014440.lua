-- Lua provided by SkyAPI 
-- Game: AppID 1014440
addappid(1014440)
addappid(1014441, 1, "9ea3bf28b6e7567e8637fc48d5d1c9e3adc7bfcf19c8f107699246f6d9aa136b")
