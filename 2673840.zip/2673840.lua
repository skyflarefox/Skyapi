-- Lua provided by SkyAPI 
-- Game: AppID 2673840
addappid(2673840)
addappid(2673841, 1, "85a6e9d6dde8ff5edec70094e22b46fb9880029c469f00b6463f50d7b977303f")
