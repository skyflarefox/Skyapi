-- Lua provided by SkyAPI 
-- Game: Forgotten Places: Lost Circus
addappid(818440)
addappid(818441, 1, "e8f3ef2dd5226afbd977950bd0682ab812cd3a3074d12438588470406a3a214c")
