-- Lua provided by SkyAPI 
-- Game: AppID 1149430
addappid(1149430)
addappid(1149431, 1, "c96ca7b14d851697db0dc603fbaa3679fc6ec9c710ebd7d7f575c212b62d73b1")
