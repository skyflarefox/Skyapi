-- Lua provided by SkyAPI 
-- Game: Decent Checkers
addappid(2150170)
addappid(2150171, 1, "8c4e126eaddf89439aa222ff3192250bd8d723c9cebcff05723406dd7ea915ca")
