-- Lua provided by SkyAPI 
-- Game: Desktop Dungeons: Rewind
addappid(1976950)
addappid(1976951, 1, "1041e494078aa552868d49a5425f0e5daa7f08d0ee901c5c0859f575f5530f5f")
