-- Lua provided by SkyAPI 
-- Game: Un Pas Fragile
addappid(1093520)
addappid(1093521, 1, "6e8606e946946a24d9b934c80524c77dd77db090337a49aeb08099fa12429486")
addappid(1093522, 1, "6cab0f3390f048cdee154658eba5145efa44e84f3f264ce12daae7d8c383dae6")
