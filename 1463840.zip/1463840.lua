-- Lua provided by SkyAPI 
-- Game: Warp Out
addappid(1463840)
addappid(1463841, 1, "8ad8d593e9844e7d6c2e550fbc5cc5ed4764cc00d6a3e9834154b78c7f4b0dae")
