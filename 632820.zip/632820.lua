-- Lua provided by SkyAPI 
-- Game: Ricky Raccoon
addappid(632820)
addappid(632821, 1, "4b0b2f22255ebe99f0c91126c2a816ad138ce78835e8de9ce6c0fcdf733234cf")
addappid(632822, 1, "7a027d50967557c4eb8da7d685e8c8b34f1a9f88a04e2079a6b85c1b873bd38e")
addappid(632823, 1, "73b4167edfcf24e6a5a3e818fff50dbee6fbdc62b14a596696afcaff212c0678")
