-- Lua provided by SkyAPI 
-- Game: AppID 1162560
addappid(1162560)
addappid(1162561, 1, "b9c1011039ece640ff9997da88fb3b93c5b773e8b00a6d6b6b6fa9d95deb71e3")
