-- Lua provided by SkyAPI 
-- Game: Sand:box
addappid(2179380)
addappid(2179381, 1, "10b809f70c8adf5799fe29f42c4ed7511820978209c5d4adfee2b37e3baa181b")
