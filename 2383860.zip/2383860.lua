-- Lua provided by SkyAPI 
-- Game: Octodad (Student Edition)
addappid(2383860)
addappid(2383861, 1, "301d77547524e561d525f814becce947e3cd0978cff7641c3ff32a0e16eb66fe")
