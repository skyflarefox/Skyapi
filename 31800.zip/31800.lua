-- Lua provided by SkyAPI 
-- Game: Nancy Drew®: Danger by Design
addappid(31800)
addappid(31801, 1, "e9f5b88c9158caa2c36a4e3d4baf392f3ad99236502fb2e7514b4a87ba6a48fd")
