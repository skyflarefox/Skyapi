-- Lua provided by SkyAPI 
-- Game: Farmer Toon
addappid(1848910)
addappid(1848911, 1, "90b487af072e906cc5b0c11b81b4a616397b809dc23cf1fc7b53fadbc7f7a201")
