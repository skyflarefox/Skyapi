-- Lua provided by SkyAPI 
-- Game: Tomb Raider I-III Remastered Starring Lara Croft
addappid(2478970)
addappid(2478971, 1, "d618662f8f002c8bbbe623996f63415e1a4f843bce5608ec23b390a7ea5798ee")
