-- Lua provided by SkyAPI 
-- Game: AppID 2002810
addappid(2002810)
addappid(2002811, 1, "80c03e7d29610153d6cd68e1cd1f08d8ecd5a97df8ac490088218cc91a8ce270")
