-- Lua provided by SkyAPI 
-- Game: Chimpact 1 - Chuck's Adventure
addappid(518120)
addappid(518121, 1, "612db50fe85727ebf2aa22df44ce973c446ffd4f63e5d6b0bf83f21b6d97c4cf")
