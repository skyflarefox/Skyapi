-- Lua provided by SkyAPI 
-- Game: Outpost
addappid(2339690)
addappid(2339691, 1, "22930e068f59492053235a661562f39cad65b59e27439d5f3f6506487dc9f2fb")
