-- Lua provided by SkyAPI 
-- Game: AppID 2556890
addappid(2556890)
addappid(2556891, 1, "ac1985a39fde4ee439ae862ac8032ce72044d706b4406eb226a24d3abd8932d9")
