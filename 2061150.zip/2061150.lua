-- Lua provided by SkyAPI 
-- Game: Ikki Unite
addappid(2061150)
addappid(2061151, 1, "6aaa6e3712d222513afed01427dae51e155b92c182899a607f31abf3b6129dd3")
