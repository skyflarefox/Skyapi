-- Main AppID
addappid(3765010)

-- Main Depots
addappid(3765011, 1, "862296624beb296f31c01dfabcf03e1cd32a053be26dfb9d894a0ff8a084435c")
setManifestid(3765011, "8273910239294745927", 14509810634)

-- DLC's (with depot keys)
-- Forensics: Crime Scene Detective Demo (AppID: 4753480)
addappid(4753480)
addappid(4753481, 1, "31001d812e53f40ec08e274d8039203220248e7a77a196135e074fdc1a7195db")
setManifestid(4753481, "6664278521427128305", 6255149689)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
