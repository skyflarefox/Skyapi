-- Lua provided by SkyAPI 
-- Game: AppID 2134310
addappid(2134310)
addappid(2134311, 1, "b00adf693705bc9ec0839f760e178f8d805ba92a2a1b281b5880ee947f084d36")
