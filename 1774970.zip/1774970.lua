-- Lua provided by SkyAPI 
-- Game: Machine Ruin Self-Destruction Masturbation Life of the Sky Temple
addappid(1774970)
addappid(1774971, 1, "919a8e1d5ea260eb0bb3c4c1d5174ad8b6350131ce18990c944041bbeaa2d106")
