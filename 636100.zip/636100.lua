-- Lua provided by SkyAPI 
-- Game: Tesla vs Lovecraft
addappid(636100)
addappid(636101, 1, "ae49cc673b8c6dfe79f678b6dd3f8edf06a691ff77301badbe6390b4cf1564aa")
addappid(636102, 1, "efc18e56a4e1b82c329c524817586420ee2e207391bd4b61e66ea5100c1f7465")
addappid(636103, 1, "a60e532ad0e83d4157c38180cee27f4898cc8d5d8d6ee42a8425a73ecfd98eb0")
