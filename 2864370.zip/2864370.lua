-- Lua provided by SkyAPI 
-- Game: Fully Dogomatic
addappid(2864370)
addappid(2864371, 1, "6cfbf31f2f512019547ad0a65ed1adc2009a986c43ec4c2884bb30d98b04e410")
