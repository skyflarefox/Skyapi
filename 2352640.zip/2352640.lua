-- Lua provided by SkyAPI 
-- Game: You are Peter Shorts
addappid(2352640)
addappid(2352641, 1, "9c122e303321fa53a6ff3ef3d8278d84b15654aeb128fb409e7c4e000a2cfbb1")
