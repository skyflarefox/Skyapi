-- Lua provided by SkyAPI 
-- Game: Excidio The Kaiju Simulator
addappid(1594130)
addappid(1594131, 1, "0a0d5250bcb4b6d42cf9418cce12612a9b2e29876899d2c742d132422aee9868")
