-- Lua provided by SkyAPI 
-- Game: My Lovely Wife
addappid(1251930)
addappid(1251931, 1, "d02641eef3fd80971830fd998697652beca320a9f00e93040ccf9d1c7c9c22b7")
addappid(1861080, 0, "84c7febab902f23de3a79acfc55a85a568844cf1dab15e761211b4d1c863e0c8")
