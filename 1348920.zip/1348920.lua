-- Lua provided by SkyAPI 
-- Game: Wind Peaks
addappid(1348920)
addappid(1348921, 1, "ac3b5e3c8367dd5ed81b7c05e30f479db11feeec903d363ec6a900729f997bf1")
