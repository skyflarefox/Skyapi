-- Lua provided by SkyAPI 
-- Game: The Smurfs - Mission Vileaf
addappid(1502560)
addappid(1502561, 1, "92924d4fced70d09d84c8558800903f84e5e65a36fee94b5bb50d1708a42a660")
addappid(1709890)
