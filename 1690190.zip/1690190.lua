-- Lua provided by SkyAPI 
-- Game: Portal Walk
addappid(1690190)
addappid(1690191, 1, "2fa62f07e6821e70652363a03a7ca882345e63c55604f409e049a40d9fbafc35")
