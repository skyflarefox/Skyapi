-- Lua provided by SkyAPI 
-- Game: Hollowbody
addappid(2123640)
addappid(2123641, 1, "cd95e2d279a5f19b799660720b650fd9db4b26c546f0503e6dbe56674a3ff94d")
