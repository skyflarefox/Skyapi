-- Lua provided by SkyAPI 
-- Game: Kong: Survivor Instinct
addappid(2769080)
addappid(2769081, 1, "6843b35550304f6170532750c039efeddc8b13c3e0a610a0c4e7a102813b1edf")
