-- Lua provided by SkyAPI 
-- Game: Teku
addappid(2660750)
addappid(2660751, 1, "12916283fd1eb75e3cd6f0851c24e90543786653a848986f1691a7ff6c6dc99d")
