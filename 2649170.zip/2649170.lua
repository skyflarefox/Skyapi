-- Lua provided by SkyAPI 
-- Game: Buried Shards
addappid(2649170)
addappid(2649171, 1, "1bdad37cc6bebe2c32a2ba4fa8d255e8c0cecde82657892bc502e29b10f2dfbc")
