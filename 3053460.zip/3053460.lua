-- Lua provided by SkyAPI 
-- Game: Evil Corporation Demo
addappid(3053460)
addappid(3053461, 1, "2c713255c25425efc67aac9d58e781081de9bb9799a0252388ffa900152b2a94")
