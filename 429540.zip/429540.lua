-- Lua provided by SkyAPI 
-- Game: AppID 429540
addappid(429540)
addappid(429541, 1, "7395c23b869ac2af12685a3474e948e5a78498c9d02082ed9676b2fda3517b7a")
