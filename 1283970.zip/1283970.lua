-- Lua provided by SkyAPI 
-- Game: YoloMouse - Cursor Changer
addappid(1283970)
addappid(1283971, 1, "cc3e8638081fb7bb6f0a2b461db9232fa3521c984d47cb33aed0f59c8eadd303")
