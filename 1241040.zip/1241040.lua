-- Lua provided by SkyAPI 
-- Game: Deep Despair
addappid(1241040)
addappid(1241041, 1, "8f578f4eede85b6086ce4f4ff77bc8d244efdbdca38969bd36392c4940baae43")
