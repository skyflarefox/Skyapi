-- Lua provided by SkyAPI 
-- Game: Project Speed
addappid(1201940)
addappid(1201941, 1, "6a8a4c5699c91529f2c12e994d9e28cfe4be1d72cfe2aa0e1c7ed57064262485")
