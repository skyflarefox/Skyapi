-- Lua provided by SkyAPI 
-- Game: Backmooms
addappid(3857770)
addappid(3857771, 1, "2b3ad5b6decdb78986132b46ade471f1db5663545506ffbb7ef7b6a1545e935f")
