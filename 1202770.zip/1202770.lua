-- Lua provided by SkyAPI 
-- Game: kirakira stars idol project AI
addappid(1202770)
addappid(1202771, 1, "9734ff3ef6977eb156fd3020fc7d8274c397018093819b9bf4cf191ad1a24234")
