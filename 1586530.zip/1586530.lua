-- Lua provided by SkyAPI 
-- Game: AppID 1586530
addappid(1586530)
addappid(1586531, 1, "826779aa0a6534c6bcf768e8dc64c0c57a1acfd8a510066e31c3021d0bdf8f2a")
