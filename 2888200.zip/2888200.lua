-- Lua provided by SkyAPI 
-- Game: Same Room Same Day
addappid(2888200)
addappid(2888201, 1, "a55aab1c25d4b066eca972989d2cb2e710d40ae803422fd9611c659b384547ec")
