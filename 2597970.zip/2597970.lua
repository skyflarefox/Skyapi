-- Lua provided by SkyAPI 
-- Game: Finding Frankie
addappid(2597970)
addappid(2597971, 1, "bcc51d89a45d304706c7741701fbf0d6b3ad9de2efbfecbc9a990d9ced20f2a6")
