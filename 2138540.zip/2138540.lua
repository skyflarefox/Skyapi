-- Lua provided by SkyAPI 
-- Game: BicycleSim Demo
addappid(2138540)
addappid(2138541, 1, "9bf9a50e62513210645afaecf927a022a1ad71b6a916fdb239eeae48bf3fa4ec")
