-- Lua provided by SkyAPI 
-- Game: Cursed 3
addappid(2110460)
addappid(2110461, 1, "a05783bca002a2a24e0cf75f17ecba9c8242446d270d94c692b37274d31e5c2c")
