-- Lua provided by SkyAPI 
-- Game: Beauty and the Beast: Hidden Objects
addappid(892550)
addappid(892551, 1, "9e060933259652dc8e164ee867cdd6bb007b8112021264c3bd6558309617d102")
