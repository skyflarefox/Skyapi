-- Lua provided by SkyAPI 
-- Game: TERRACOTTA
addappid(748020)
addappid(748021, 1, "48995a58a33cf885636eb3b4e86125437df0d5810333194c6262436dd5f52fef")
