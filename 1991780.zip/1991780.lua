-- Lua provided by SkyAPI 
-- Game: MIRADOR
addappid(1991780)
addappid(1991781, 1, "98d1ac7b2dc3d9d7b7918f07c8f55e740af053bd3dec493f29a78949f5111023")
