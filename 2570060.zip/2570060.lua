-- Lua provided by SkyAPI 
-- Game: AppID 2570060
addappid(2570060)
addappid(2570061, 1, "4d66c85b050a1e1a63f86be905b8139f972cb4516ba8064c03b751892ca7246e")
