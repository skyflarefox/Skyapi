-- Lua provided by SkyAPI 
-- Game: DatavizVR Demo
addappid(551960)
addappid(551961, 1, "c6d94d5658f113c192ede82a8c6d245f405e4cb0c49ec9991de58b47fdfb386b")
