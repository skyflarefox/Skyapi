-- Lua provided by SkyAPI 
-- Game: Car Physics Simulator
addappid(1675090)
addappid(1675091, 1, "415efa404a1118e75a30f2ecf124a9e20da1c377624002b252186b91065e6064")
