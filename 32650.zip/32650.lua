-- Lua provided by SkyAPI 
-- Game: AppID 32650
addappid(32650)
addappid(32651, 1, "50c9f1ec00bb05cd151f46b9ac2805031e36e78f001b09e20019ab3ad3c34d74")
