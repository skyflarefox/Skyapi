-- Lua provided by SkyAPI 
-- Game: A Chair in a Room : Greenwater
addappid(427760)
addappid(427761, 1, "2cbf2206b75fdd30edfd9f02ca3cfae22a0bc987cb8373b23499bddbca39f042")
addappid(975930, 0, "861cd7811cae3cd82debda49f44c446fb1a27d1185b47acb4f0d26d5ad7fa705")
