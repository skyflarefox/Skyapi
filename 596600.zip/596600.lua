-- Lua provided by SkyAPI 
-- Game: AppID 596600
addappid(596600)
addappid(596601, 1, "cf9e37a63df2e10f0990fedee7e5338d7f60e3252fe67629c4a29aaac033d2bc")
