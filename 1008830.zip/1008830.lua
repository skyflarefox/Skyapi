-- Lua provided by SkyAPI 
-- Game: AppID 1008830
addappid(1008830)
addappid(1008831, 1, "db7f89199eee529e1d5fdf41230ff258d45950a1198598b63c0fac73c23fe107")
