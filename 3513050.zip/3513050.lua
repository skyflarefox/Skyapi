-- Lua provided by SkyAPI 
-- Game: Last Town
addappid(3513050)
addappid(3513051, 1, "c18017f5494e3624c7da11995cbcde25a144a78e054e5f23ba906f562b0a4544")
