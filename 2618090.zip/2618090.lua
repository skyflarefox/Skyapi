-- Lua provided by SkyAPI 
-- Game: Mistward
addappid(2618090)
addappid(2618091, 1, "18ac2a4b2883e039ee352a3ede91d68ac1979f0f6efcccac442b1703d14cb3db")
