-- Lua provided by SkyAPI 
-- Game: JongRo 3_Street
addappid(2752770)
addappid(2752771, 1, "19a4fc312f4a0809386e7aaece6d2f62de78a2c8c824b557b7ec1861ed109e3c")
