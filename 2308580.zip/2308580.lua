-- Lua provided by SkyAPI 
-- Game: Disaster Detective Saiga: An Indescribable Mystery
addappid(2308580)
addappid(2308581, 1, "2901cf519b3f805b99db29bf0f95eafa731bc217797f29ccbb903f4daf70008c")
