-- Lua provided by SkyAPI 
-- Game: Touring Karts
addappid(1088950)
addappid(1088951, 1, "38879ca07dabf8150370342f1961605ba35f42ddf5dca66a6aeadb62a2f93dba")
