-- Lua provided by SkyAPI 
-- Game: Entropy Architects
addappid(3538850)
addappid(3538851, 1, "5cb71da33edf6b1ff204be66e1f739b7e3b23a607f794008b9b79cc11c1b58d1")
