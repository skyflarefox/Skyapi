-- Lua provided by SkyAPI 
-- Game: Little Witch in the Woods
addappid(1594940)
addappid(1594941, 1, "04285d12a3e6cdfeb5449292b53174aa1205b0c8330cc8e237d7b73e8bc2b63a")
