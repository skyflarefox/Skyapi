-- Lua provided by SkyAPI 
-- Game: Help! I'm Turning Into A Mermaid!
addappid(4115180)
addappid(4115181, 1, "0ed021d5740889497a6c34f603ffbbb663ab786ca26cee2df4a0cfb23ba90a15")
