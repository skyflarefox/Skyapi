-- Lua provided by SkyAPI 
-- Game: Generation Zero®
addappid(704270)
addappid(704271, 1, "bec34bd7a4b8b9e13563f62a6dab312a919c164703f0739da3f138a71e64db7c")
