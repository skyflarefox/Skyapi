-- Lua provided by SkyAPI 
-- Game: LuckLand
addappid(2516820)
addappid(2516821, 1, "a839e4be0006698b006dde5b4acc6183519a3df6b6507abf0102e249c99016d3")
