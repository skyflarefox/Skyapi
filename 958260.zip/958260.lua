-- Lua provided by SkyAPI 
-- Game: AppID 958260
addappid(958260)
addappid(958261, 1, "47a7073965d982c132fbec7844f17a3acf0ec4133cd86f8f39ab239ae4942718")
