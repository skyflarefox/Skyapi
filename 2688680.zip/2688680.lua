-- Lua provided by SkyAPI 
-- Game: Girls of The Tower
addappid(2688680)
addappid(2688681, 1, "ac1d0bebb6bb797c85f3e0f3b1de659db587290ebb828f9194ef70ff4c123e5d")
addappid(2884730, 0, "2a6039323271cad88718693f4baca73fcefac0a70ac6e330ce0c5694b777a9c0")
