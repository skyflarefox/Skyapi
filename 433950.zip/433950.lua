-- Lua provided by SkyAPI 
-- Game: Bit Blaster XL
addappid(433950)
addappid(433951, 1, "a481c6f695652788d14e8b14afac69fa5d1144b1f781cb1bfdea29a69cceddf8")
addappid(433952, 1, "bd0917e30df0f9a3ae426fe9c6be014b409aed298c59e6f8ef2247b3e9482ff3")
addappid(433953, 1, "8e8be5a425ace70334d5b3ff4bfeef843f1dda0f6e18ff780bae29cb09fa76e0")
addappid(548700, 0, "80957c0db01a9438481fe456823d25deafc0a9cdbce3a15d76c7da553dc220e0")
