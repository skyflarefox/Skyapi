-- Lua provided by SkyAPI 
-- Game: Plague: London 1665
addappid(2225010)
addappid(2225011, 1, "c8f2ddb034b6e44e0b71fcae91fa3fe917f00a153fdc62d623f90cdb1850d1fa")
