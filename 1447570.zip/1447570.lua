-- Lua provided by SkyAPI 
-- Game: Monkey King vs Transformers
addappid(1447570)
addappid(1447571, 1, "fc4ab2878bab4c143be6d1f03ffd9ed1912e014ce05374c4244a6cb3ec12853f")
