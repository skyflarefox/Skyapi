-- Lua provided by SkyAPI 
-- Game: AppID 2126110
addappid(2126110)
addappid(2126111, 1, "65a7e36b0c30fdc06cbfaebb46a035bdf0427e1c613a5b0a69a29da41eb2de94")
