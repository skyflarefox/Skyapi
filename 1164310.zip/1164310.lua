-- Lua provided by SkyAPI 
-- Game: Fairytale Solitaire. Witch Charms
addappid(1164310)
addappid(1164311, 1, "b46f1e06d8a9d09af82b59d513a01931b73954e8e619f6316a800f5075009e63")
addappid(1164314, 1, "5a146d25d61b4073774f5666884fd80060f39e0b1f09cc05e9c929ebe48bec2c")
