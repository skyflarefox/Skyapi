-- Lua provided by SkyAPI 
-- Game: Kill The Crows
addappid(2441270)
addappid(2441271, 1, "30030b0018f2e8952c734aed1819cd43acffb26c0b4eb27c344d6fdfa16686ae")
