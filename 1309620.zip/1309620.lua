-- Lua provided by SkyAPI 
-- Game: AppID 1309620
addappid(1309620)
addappid(1309621, 1, "5d61dec4e6d97c716529e5d329421d1b4722b365e810d2f5df55f7b000f083ab")
