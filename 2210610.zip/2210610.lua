-- Lua provided by SkyAPI 
-- Game: JUNK! A Demo About Robots Playtest
addappid(2210610)
addappid(2210611, 1, "ce80c7ed8478a51e22971c04e15ff9d90c4a7758e4b6446a595be414029229ab")
