-- Lua provided by SkyAPI 
-- Game: Stock Market Tycoon: Challenge
addappid(3296800)
addappid(3296801, 1, "276527398cee5ae75a21e2a010daadd8b10987f2e7030c1c3a4726f09413c501")
