-- Lua provided by SkyAPI 
-- Game: AppID 524440
addappid(524440)
addappid(524441, 1, "4ba8bddafecd319346c3d718b6cb381392e145aaa169f032072857fc2d6bedc7")
