-- Lua provided by SkyAPI 
-- Game: AppID 788630
addappid(788630)
addappid(788631, 1, "4a0bca301314bfe912ba761211d51a78d46bdc7fac7c54900375228fe3ad5c5c")
