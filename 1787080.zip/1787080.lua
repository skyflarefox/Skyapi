-- Lua provided by SkyAPI 
-- Game: Office No.41: Prototype Edition
addappid(1787080)
addappid(1787081, 1, "33717e9eace141149757901b5dad5f81e8e54a1b269b2a0b5e6b39e054515dc2")
