-- Lua provided by SkyAPI 
-- Game: Bedtime:turn off the life
addappid(2847310)
addappid(2847311, 1, "47568abd687ca85dcdb8e4baf7ab8d32a56f78cccd973e6b3e4bc1d6429644b3")
