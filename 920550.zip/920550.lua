-- Lua provided by SkyAPI 
-- Game: AppID 920550
addappid(920550)
addappid(920551, 1, "8b4e2cec33255bde2c33ef8a4c927e32a7e109dd13bec58d5381285a8fc6c353")
