-- Lua provided by SkyAPI 
-- Game: Tower Dominion
addappid(3226530)
addappid(3226531, 1, "bce32f7a7225638f1c114345d97f78d3462114031739e05859e0b3a07a1eb408")
