-- Lua provided by SkyAPI 
-- Game: Sumerian Six
addappid(1429850)
addappid(1429851, 1, "18e46f478f70bf5822eed7efb533a1d5753cb4e200f1267014be704869fa3342")
