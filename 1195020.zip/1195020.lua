-- Lua provided by SkyAPI 
-- Game: Guardians of the Ashes
addappid(1195020)
addappid(1195021, 1, "f09129cec70e04532a511a18f8efd3ac4d1e9891756a91aab42f93940ce7e72a")
addappid(1251870)
