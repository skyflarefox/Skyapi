-- Lua provided by SkyAPI 
-- Game: Survival Horror #8,436 (DISCONTINUED)
addappid(1565290)
addappid(1565291, 1, "fb6d45926591ba66ccf403d0a091a4230968eac736b20c848aad466cf9a1b141")
