-- Lua provided by SkyAPI 
-- Game: Ski Jump Challenge 2024
addappid(2736230)
addappid(2736231, 1, "a52b66b46b96919746cb592d71d06845af48cb94d37f531b29e75f4dd5bf6f6a")
