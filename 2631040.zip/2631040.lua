-- Lua provided by SkyAPI 
-- Game: Cloak Hero Demo
addappid(2631040)
addappid(2631041, 1, "98f1bf57547c543f0673f0c55a809482518a99f5594885674dd9c1981e0066f4")
