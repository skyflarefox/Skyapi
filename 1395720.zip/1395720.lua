-- Lua provided by SkyAPI 
-- Game: AppID 1395720
addappid(1395720)
addappid(1395721, 1, "a6bfc4d74a6b15f279bec20e552c895ecfebd3f65a195154a4578ce0dc9b2629")
addappid(1395722, 1, "bea02899e5127d712b7455da964dfc474fde00323b4894acddc2232d139dd192")
