-- Lua provided by SkyAPI 
-- Game: AppID 1376590
addappid(1376590)
addappid(1376591, 1, "d0cd152542b4db52297763d4674d11af9b5c77dea7307301a9d4f284a988d313")
