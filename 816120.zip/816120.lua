-- Lua provided by SkyAPI 
-- Game: AppID 816120
addappid(816120)
addappid(816121, 1, "42f1b0b4824bfb4aa11998b87a5875fd677c6c968433683dad139726f3cb2409")
