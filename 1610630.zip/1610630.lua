-- Lua provided by SkyAPI 
-- Game: AppID 1610630
addappid(1610630)
addappid(1610631, 1, "692975372fe5ac06c75cd3d1f221110d55eeab32cc27f413a35f49e49adf1c21")
