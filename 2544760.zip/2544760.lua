-- Lua provided by SkyAPI 
-- Game: AppID 2544760
addappid(2544760)
addappid(2544761, 1, "682c7601460a705d5841320d68100eb63eb6f0d4eb0259069fafbbad144ca4fb")
