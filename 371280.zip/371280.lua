-- Lua provided by SkyAPI 
-- Game: AppID 371280
addappid(371280)
addappid(371281, 1, "ff088b67d6946b277dbc824250b96f8d043958d5567ed9fe9af1b46fa43ee251")
