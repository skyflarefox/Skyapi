-- Lua provided by SkyAPI 
-- Game: Neon Blood
addappid(2067310)
addappid(2067311, 1, "250ca541652dc67026fe0060efa93ad7cafce6a026c62aca851a85902771c927")
