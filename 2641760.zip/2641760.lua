-- Lua provided by SkyAPI 
-- Game: AppID 2641760
addappid(2641760)
addappid(2641761, 1, "fa1cc09d464a6158a93e45211b93d1ca665f0f040bd859aaa55ae41c5717ad6e")
