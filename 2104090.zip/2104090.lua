-- Lua provided by SkyAPI 
-- Game: AppID 2104090
addappid(2104090)
addappid(2104091, 1, "4f10da91c61a70050d24c77dd77c441ae2443cb5318a667ceb5de23b179d6ec2")
