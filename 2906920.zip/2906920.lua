-- Lua provided by SkyAPI 
-- Game: Eternal Fate: A Journey Begins
addappid(2906920)
addappid(2906921, 1, "bc41d8a61ef1dd40270d57447bc90660bf2b2eda179ed67becdffcea8e959f34")
