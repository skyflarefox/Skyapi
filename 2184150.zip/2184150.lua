-- Lua provided by SkyAPI 
-- Game: Dead Matter
addappid(2184150)
addappid(2184151, 1, "7fcf86a407ed2bf3dc7d0191e036bd4d5da63afbdf4eb27eef04177d249b932c")
