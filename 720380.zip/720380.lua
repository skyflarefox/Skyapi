-- Lua provided by SkyAPI 
-- Game: Ancestors Legacy Free Peasant Edition
addappid(720380)
addappid(720381, 1, "d8227ba7326156ae22e315f734ecddaf47b8c57c2193045875e20dcd0a3af0b0")
