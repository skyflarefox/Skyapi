-- Lua provided by SkyAPI 
-- Game: Invasion Vill
addappid(1442750)
addappid(1442751, 1, "da3172dae1c5e29664856e56a81c677ba53b647075d443e9db5d7826b1a2ba00")
