-- Lua provided by SkyAPI 
-- Game: The Village
addappid(1637540)
addappid(1637541, 1, "dd6867355d3e348520b83e52dbc2baf6799626fcfa980d8d20437bfb7ea8a7ed")
