-- Lua provided by SkyAPI 
-- Game: AppID 241560
addappid(241560)
addappid(241561, 1, "1be1e7dac5110de350ec4e8bef5adeb9f3462a7b97b0816158c163a30a634e8b")
addappid(241562, 1, "8aadd8a2edf897c35e27b15ad03ef8b4eab7b060324519e59988e290391dcafc")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
