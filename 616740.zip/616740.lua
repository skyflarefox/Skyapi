-- Lua provided by SkyAPI 
-- Game: 克莉丝的炎之信仰 Cryste: the Faith of Fire Vol.1
addappid(616740)
addappid(616741, 1, "0c0d16e8cb9bdeec845f92119574bb211983f81ace4427c4988629557e151f46")
addappid(616742, 1, "f4f20b0da54e25e9d208deba5afa2e6e7464814cd5559c15bbecb3b43907d736")
addappid(616743, 1, "314c2a2f576e307a1977699024832f20545379ff682090fe9fd399a4921f357b")
