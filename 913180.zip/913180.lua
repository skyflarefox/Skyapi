-- Lua provided by SkyAPI 
-- Game: Battle royale simulator
addappid(913180)
addappid(913181, 1, "dc847f375bad2f0ee3730825a7860376e511f96cd2dd2d05fcfbbfbb8cab8414")
