-- Lua provided by SkyAPI 
-- Game: AppID 1079430
addappid(1079430)
addappid(1079431, 1, "65e82c4b08622b94c0b0dc0cdb60032378c855b09a353f6ae0ca2c9d79a24011")
