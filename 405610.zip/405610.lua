-- Lua provided by SkyAPI 
-- Game: AppID 405610
addappid(405610)
addappid(405611, 1, "26e2cba2383f79bd72b8d3e84ce74fbedfca5a88aa5665f44da43d3903ee4189")
addappid(405612, 1, "62722d4d63c7ffa3cc2d34df70c33dcd3272ddc211a395b5fd635d0d0f0982a8")
addappid(405613, 1, "5d18ecdad4c82a5a6b59a4ae7616434761c449b01e56ee5e61a087f93bd41da0")
