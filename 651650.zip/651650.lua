-- Lua provided by SkyAPI 
-- Game: AppID 651650
addappid(651650)
addappid(651651, 1, "b35d19273a685abcef6d3a51335b87a77a9af569369bf0f2c7ce6dd4e440aa8f")
