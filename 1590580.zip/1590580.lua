-- Lua provided by SkyAPI 
-- Game: MELTY BLOOD ARCHIVES
addappid(1590580)
addappid(1590581, 1, "436fa82f9d7f9bffc15db902c75faa6562cbf24ba1bbc9b1125841e2e7f00826")
