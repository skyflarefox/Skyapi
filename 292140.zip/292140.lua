-- Lua provided by SkyAPI 
-- Game: AppID 292140
addappid(292140)
addappid(292141, 1, "549a471e372538d6e666807a2c77be950ad2fe1c6f2023fa8351a8a16942e913")
addappid(292142, 1, "9dc2e5803adb867ad7ab36d54856c4746af9d8f61a6ddfe1fffe1441e50380d7")
