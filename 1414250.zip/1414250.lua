-- Lua provided by SkyAPI 
-- Game: CORPSE FACTORY
addappid(1414250)
addappid(1414251, 1, "327a05a39e762f86e6d7c7a20318cf99820be17d6eb8956427583f1cac1287a4")
