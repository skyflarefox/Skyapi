-- Lua provided by SkyAPI 
-- Game: Minimon
addappid(308520)
addappid(308521, 1, "609d91195748560f0cac100702af911ee47a2032c5039b094d1c140ebbac536b")
addappid(308522, 1, "5dc4adb88ebf3aebdc5bd3c0156c7826faf983d8b84f3eadec521da89d08e371")
addappid(308523, 1, "da990ed7854be2ec97f2ffdf06945b7856023c33a4ccd163c76ad1f0fe7e8161")
