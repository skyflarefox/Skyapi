-- Lua provided by SkyAPI 
-- Game: Teenage Mutant Ninja Turtles: The Cowabunga Collection
addappid(1659600)
addappid(1659601, 1, "5023f9ba2117c0ff8e49a8f0db2c1cee99a49f811f9d4d7de07b833f45df831c")
