-- Lua provided by SkyAPI 
-- Game: Cast Cats
addappid(3118450)
addappid(3118451, 1, "35e3dd9ebd4841dcf8607883fafd8e26362fa4086cb1080cf131ac1684337e52")
