-- Lua provided by SkyAPI 
-- Game: Ornament Express
addappid(2163140)
addappid(2163141, 1, "76afa288bc23498357db6e724d67cb8f2b2564bccb594c682d6173336c151958")
