-- Lua provided by SkyAPI 
-- Game: AppID 1368010
addappid(1368010)
addappid(1368011, 1, "bf979df2d347fc8c141990a74a53a9bb993a5fb2cb7f4973b9fe1797610fa3b1")
