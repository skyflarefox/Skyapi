-- Lua provided by SkyAPI 
-- Game: Zerowood
addappid(1276300)
addappid(1276301, 1, "8a5277f32756118c8bede809d4f3c1648fb9393ecfd53a32a5e3d3fb905e6524")
