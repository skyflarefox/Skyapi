-- Lua provided by SkyAPI 
-- Game: AppID 2642190
addappid(2642190)
addappid(2642191, 1, "f05ad4d82f2f3af218bdfbb477347ac2f0b34bc70e873ae87cdea956d7e610a5")
