-- Lua provided by SkyAPI 
-- Game: DeltaBlade 2700
addappid(1143450)
addappid(1143451, 1, "061fa43e48434eb5e2ee18242051e2c42bc220d27f8e48d993e4f10b78cb2898")
