-- Lua provided by SkyAPI 
-- Game: Earth Muncher
addappid(809460)
addappid(809461, 1, "6b14b52b27b666625dcebbb7751beecdec2f320370b468ee3a0de95f32cf46a7")
