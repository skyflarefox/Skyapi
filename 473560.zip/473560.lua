-- Lua provided by SkyAPI 
-- Game: AppID 473560
addappid(473560)
addappid(473561, 1, "09c7438823cc9c11c9e6d23b481861da839244d2096fa9b6eb69c9f05bd960a4")
