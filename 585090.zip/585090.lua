-- Lua provided by SkyAPI 
-- Game: Black River
addappid(585090)
addappid(585091, 1, "2c4778cea28004edde256a42959b22e1d130bec61339c1bd71042eaa048262aa")
