-- Lua provided by SkyAPI 
-- Game: 101 Cats in India
addappid(3127270)
addappid(3127271, 1, "bc08607921e5436a664283702442ed6cdc1ed8a0759fa561059f012e98c90951")
