-- Lua provided by SkyAPI 
-- Game: I Believe in Capybara Supremacy!
addappid(2424680)
addappid(2424681, 1, "78b62de675c6eff5acd8ed3a13075fb10775f31fbf795974c73fd28667f4a331")
