-- Lua provided by SkyAPI 
-- Game: 夏末白夜
addappid(2538910)
addappid(2538911, 1, "88a23f519e2bde9d21e81bdcd30dc4975ca8fdb0743d60360487cf45f7d53539")
