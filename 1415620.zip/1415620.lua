-- Lua provided by SkyAPI 
-- Game: Sudoku Forever
addappid(1415620)
addappid(1415621, 1, "0ce57630fc059d9e36436af33d6b6862c4e063f0dc88ad3bb3207ddabc905977")
