-- Lua provided by SkyAPI 
-- Game: Haunted House Renovator Demo
addappid(2402140)
addappid(2402141, 1, "5555714192764101efe5f49db98bc341fa4feb920e72bdcf2c1bdfcab95b5253")
