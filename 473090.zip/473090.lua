-- Lua provided by SkyAPI 
-- Game: Shoppe Keep - Original Soundtrack
addappid(473090)
addappid(473091, 1, "b80d4cd0f67f27ce6e09fc77641aa0f908a583c1078dd5b8929c5616dc1ad72c")
