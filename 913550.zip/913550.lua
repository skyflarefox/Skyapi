-- Lua provided by SkyAPI 
-- Game: I wanna be the Creator
addappid(913550)
addappid(913551, 1, "ef5cdb61edb59dbe1344d9f7f63bc6c86958de192c8c211927e7cfcd1c553b74")
