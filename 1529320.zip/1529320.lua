-- Lua provided by SkyAPI 
-- Game: Sword of the Necromancer Soundtrack
addappid(1529320)
addappid(1529321, 1, "b18820c4410b17ac1cab717105fbc8218b4bccc2b6d2b8d82bc38ee60d60067d")
addappid(1529322, 1, "760fd3e307138003eb4b82da5331c0e2671c946e6084049aa30a96d0b4311f43")
