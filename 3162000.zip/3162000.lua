-- Lua provided by SkyAPI 
-- Game: The Backrooms: Expedition
addappid(3162000)
addappid(3162001, 1, "667d1450e1e7243815f31972c2e791ad614e5b603b222f7e12716b81ae26290b")
