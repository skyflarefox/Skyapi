-- Lua provided by SkyAPI 
-- Game: Hidden Series 1
addappid(2473950)
addappid(2473951, 1, "631881f6c2eff8636725f491e150ac0e06e1b860689408ff28daa32812552ed6")
