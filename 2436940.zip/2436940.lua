-- Lua provided by SkyAPI 
-- Game: Sephiria
addappid(2436940)
addappid(2436941, 1, "65e59b412db2d2909f33ac5755b0d55df645935df94bfd26610fd4f3ee60bb21")
