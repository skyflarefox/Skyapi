-- Lua provided by SkyAPI 
-- Game: Ruff Night At The Gallery
addappid(1463470)
addappid(1463471, 1, "12872a4e628040531059dac56f89413fa67d14eb65bc8404c9ec9e17e1cb5eb7")
