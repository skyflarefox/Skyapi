-- Lua provided by SkyAPI 
-- Game: Only Me
addappid(1674490)
addappid(1674491, 1, "6ab70cceab259d9ff7eb8cbbc70e88bc81f01457a5ab4892c9723047a3d11ee2")
