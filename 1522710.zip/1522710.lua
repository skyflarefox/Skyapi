-- Lua provided by SkyAPI 
-- Game: LX Patterns
addappid(1522710)
addappid(1522711, 1, "50bbcaf8c061844c04dbd74f2aa93c7c33298f5e766e78ce42834fae0293593f")
addappid(1522712, 1, "b2bf2c14c1dc0164102621691e15d67d32b7ed7730771245f24add3fc2f96168")
