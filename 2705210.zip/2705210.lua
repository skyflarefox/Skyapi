-- Lua provided by SkyAPI 
-- Game: Good Kill!
addappid(2705210)
addappid(2705211, 1, "cd5dff7b8ed88730a8513ec1b773d101ea477e6c637b0d5644ca19afa32f3c45")
