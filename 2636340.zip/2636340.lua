-- Lua provided by SkyAPI 
-- Game: SEEING THINGS
addappid(2636340)
addappid(2636341, 1, "903745aabe84d59f328bff88d2030f068574d1d0852b7c2201ea7d209658f868")
