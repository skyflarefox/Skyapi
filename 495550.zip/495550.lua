-- Lua provided by SkyAPI 
-- Game: AppID 495550
addappid(495550)
addappid(495551, 1, "4152023f8a16f3b761c47ec1d017b22bdc18a2e1062600e2684a6aa47005bc3e")
