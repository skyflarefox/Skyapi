-- Lua provided by SkyAPI 
-- Game: AppID 1082380
addappid(1082380)
addappid(1082381, 1, "b820344d00a73ec90b81ff9ae871502beb8cea40547cf067c7b318d0b3ae6b9e")
