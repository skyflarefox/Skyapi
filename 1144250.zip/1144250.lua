-- Lua provided by SkyAPI 
-- Game: AppID 1144250
addappid(1144250)
addappid(1144251, 1, "9ae7c9da4425e1e017fb087c6553980c44d994bcc1e970a0b3c6c952f7ccc79c")
