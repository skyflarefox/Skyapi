-- Lua provided by SkyAPI 
-- Game: Penumbra: Black Plague Gold Edition
addappid(22120)
addappid(22121, 1, "4013caf9b7f78fe37ec931fe8098ec53ec7749b9e89e5bdd0b3e365d052d7bf3")
addappid(22122, 1, "4f5b9ad17c85e63d273799b4b12edccb67037f6a223891c274473cb25baf3177")
addappid(22123, 1, "edd461b992dc609085478c191bbff11d8d2086888459974226df94e6e612f572")
addappid(22124, 1, "ee6eba290e92806ea9f806dd36b22c93f65d07f21350f22db61af5d0b9f31428")
addappid(22125, 1, "389c98a1e2b28251d9ac8ae8a9f1843186d31176c5bbcd90bd5670a765b33ff3")
addappid(229020)
