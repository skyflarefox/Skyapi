-- Lua provided by SkyAPI 
-- Game: Adult Education
addappid(3426930)
addappid(3426931, 1, "881f90d84860112c8e525911a0d050c05ac90354e8dcb494f857250038f4cb35")
