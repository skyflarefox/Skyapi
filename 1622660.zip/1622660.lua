-- Lua provided by SkyAPI 
-- Game: Stream Skate
addappid(1622660)
addappid(1622661, 1, "830939ea87484c941e8fa780e40b85fbdf94c8d2bb74665203570a3c49af260a")
