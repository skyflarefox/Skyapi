-- Lua provided by SkyAPI 
-- Game: TELEFORUM
addappid(2186570)
addappid(2186571, 1, "0ce7f4b462c6a8f7e1c0d707230e4655fe286eca8f40c4fc6e14a897bb378ea6")
