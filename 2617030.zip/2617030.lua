-- Lua provided by SkyAPI 
-- Game: Pond Scum: A Gothic Swamp Tale
addappid(2617030)
addappid(2617031, 1, "82c2f53aea80d55ca725d81b4651a0f7449bf2bbf4da6f654037a00022b63d27")
