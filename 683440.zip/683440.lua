-- Lua provided by SkyAPI 
-- Game: BootyBuns & 21
addappid(683440)
addappid(683441, 1, "3aa00e287fdc832f95b06a6a1e92eef65d0f03523b9c7c3ec63eee744bf9a0e3")
