-- Lua provided by SkyAPI 
-- Game: AppID 1356530
addappid(1356530)
addappid(1356531, 1, "c98aa70c3532f772bba153280467b43d5251ec3aa2e76684e67a73b33ee55173")
