-- Lua provided by SkyAPI 
-- Game: Fatal Stormer
addappid(818220)
addappid(818221, 1, "8a853d519a5bcafcb48653211680d171409b2dfa347f9f468065d9015c44f92e")
