-- Lua provided by SkyAPI 
-- Game: Curse of Anabelle
addappid(1122180)
addappid(1122181, 1, "675c7ad936714c922fdb751b46ecfb808707660902c9a676d0c4a67b5c9103c4")
