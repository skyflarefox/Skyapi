-- Lua provided by SkyAPI 
-- Game: aMAZE Christmas
addappid(986990)
addappid(986991, 1, "8e6d1677b8ad60617f16cf6c34aefdd1b04421ddb7bf40a3f7b01ee6c7dc8a26")
