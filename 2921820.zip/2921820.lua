-- Lua provided by SkyAPI 
-- Game: Undead Tower Defense
addappid(2921820)
addappid(2921821, 1, "de5eda661f42de65887194139c18ad7d8b3338c02878de63bcc98443801b9edb")
