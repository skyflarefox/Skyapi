-- Lua provided by SkyAPI 
-- Game: Titanic: Fall Of A Legend
addappid(1835200)
addappid(1835201, 1, "e581a4fd48939a0b9e4520e131327451f578cb8335f1625ddc640e5be1fe7009")
