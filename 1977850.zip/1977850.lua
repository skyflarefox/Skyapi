-- Lua provided by SkyAPI 
-- Game: Escape From Zombie U:reloaded Demo
addappid(1977850)
addappid(1977851, 1, "a5be1cc00c5e79583d30351653a06321640ca64a1d09eb8ec8eabaa8e36be5ab")
