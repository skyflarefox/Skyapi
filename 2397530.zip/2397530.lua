-- Lua provided by SkyAPI 
-- Game: AppID 2397530
addappid(2397530)
addappid(2397531, 1, "835b2815c9e723529d226c00b98d3bc7f96706aecc7da6e139c9bde182e4615f")
