-- Lua provided by SkyAPI 
-- Game: Chill X
addappid(1482580)
addappid(1482581, 1, "7723fc34db33e3b804fdbf34d02754d8b1e398385c32b75baf2477fddda01557")
