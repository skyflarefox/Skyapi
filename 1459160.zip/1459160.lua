-- Lua provided by SkyAPI 
-- Game: Dark Cave
addappid(1459160)
addappid(1459161, 1, "ed05af14413abb6f8f28f5e3f2d6688180a0c781d5e82c76925c2791935f2128")
