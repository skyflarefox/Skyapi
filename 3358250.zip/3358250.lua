-- Lua provided by SkyAPI 
-- Game: Loot of Baal
addappid(3358250)
addappid(3358251, 1, "f68c49dc4bd554c9dbf396aae940daa371d8deae4986edff7244a6f2040680b8")
addappid(3801620, 0, "8ad5d631ee36729ff67cc7a0a7754e5ff4e5ac0441400a181c0a6ab2de8e39a8")
