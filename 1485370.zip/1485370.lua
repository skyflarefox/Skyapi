-- Lua provided by SkyAPI 
-- Game: AppID 1485370
addappid(1485370)
addappid(1485371, 1, "6e72ec786d629d413b28996a371ccc2f8f3cc3a6798c689ca2f88744534d811e")
