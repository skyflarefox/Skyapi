-- Lua provided by SkyAPI 
-- Game: Bulletrooms - Backrooms Shooter Game
addappid(3085730)
addappid(3085731, 1, "a2df9a2d4ba66762557ab66f963bf55053b2565df8c7a67e01a17b5405f2f687")
