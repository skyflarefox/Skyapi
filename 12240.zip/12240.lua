-- Lua provided by SkyAPI 
-- Game: AppID 12240
addappid(12240)
addappid(12241, 1, "bb4d23d8dc1d3e85aee63c422d283cd86a6434a81709ea2f8edcb4fa2e6b2599")
