-- Lua provided by SkyAPI 
-- Game: AppID 2957300
addappid(2957300)
addappid(2957301, 1, "439416fbea18c1e09e42b80f9d496b1eac02f18f63fe1355ae10c35dca219395")
