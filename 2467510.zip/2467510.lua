-- Lua provided by SkyAPI 
-- Game: Dark Ride Simulator
addappid(2467510)
addappid(2467511, 1, "3902d1446bff70be50b4666fed7a6de53f9bda70132df3d806e0007ba0b3682c")
