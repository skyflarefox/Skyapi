-- Lua provided by SkyAPI 
-- Game: Dark Forest Project
addappid(1693360)
addappid(1693361, 1, "1e9dbeebe9d363d396eb29aad0e5c31305c3b0155c5c8fe1cb263826f8ca54c8")
