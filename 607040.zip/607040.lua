-- Lua provided by SkyAPI 
-- Game: Grimoire Chronicles
addappid(607040)
addappid(607041, 1, "966032434b6d53d6a7a5b253f25259af7eae556c7679e5c024dacb6e08c611f2")
