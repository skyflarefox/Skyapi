-- Lua provided by SkyAPI 
-- Game: Dominatrix Simulator: Threshold
addappid(953270)
addappid(953271, 1, "ec29e3f325783c2846416bde359e2c9b6e9736c1249fab7434d6a4c7e48cf5a4")
