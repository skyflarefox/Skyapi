-- Lua provided by SkyAPI 
-- Game: AppID 822550
addappid(822550)
addappid(822551, 1, "9782f1d36fb6ac0b59b9407b29669f3706366841cc0d491c0148d126228b3df5")
