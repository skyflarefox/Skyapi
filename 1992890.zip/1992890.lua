-- Lua provided by SkyAPI 
-- Game: 欢乐金蟾捕鱼
addappid(1992890)
addappid(1992891, 1, "7cd6a6f374836e54f2191c76ef0f4cfb3047041580ba86225e23ff713e061a9f")
