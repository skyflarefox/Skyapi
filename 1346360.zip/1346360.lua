-- Lua provided by SkyAPI 
-- Game: Old Skies
addappid(1346360)
addappid(1346361, 1, "55dab47b8a95f7c4d5559003459e91432708c60cf269461bf68280da24ffb5e3")
