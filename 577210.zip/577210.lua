-- Lua provided by SkyAPI 
-- Game: Q.U.I.R.K.™
addappid(577210)
addappid(577211, 1, "1daca42905fb75cddcae8de71b3167458fa1517ace4c1ece3900b70ebf9afbf5")
addappid(577212, 1, "8d7d2a7fe99c8347708b1df6fd22cb17d5d79f3336c12d999507823ff05ddcc9")
