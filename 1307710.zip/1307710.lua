-- Lua provided by SkyAPI 
-- Game: GRID Legends
addappid(1307710)
addappid(1307711, 1, "60b113c0bab9f60878b8f651772e080a6b1f3ec17ab744fc73bd6231333bd405")
