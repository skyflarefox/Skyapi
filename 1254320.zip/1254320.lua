-- Lua provided by SkyAPI 
-- Game: Surviving the Abyss
addappid(1254320)
addappid(1254321, 1, "529b5ecbb6ac0fce55c4ea0e3af1a72db9db655aa65a79414b56c2e69375766b")
