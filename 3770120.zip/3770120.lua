-- Lua provided by SkyAPI 
-- Game: AppID 3770120
addappid(3770120)
addappid(3770121, 1, "00301242ae83652b183f5c159d46bb5db80078f6e8c7b832e15bb9fd47dac1a1")
