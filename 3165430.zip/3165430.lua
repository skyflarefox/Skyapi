-- Lua provided by SkyAPI 
-- Game: Dead Metro Playtest
addappid(3165430)
addappid(3165431, 1, "10e97504e0a7bac196b867b9f6519c4b1207e21fc1a3d7b1248baf4d65653177")
