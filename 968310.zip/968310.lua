-- Lua provided by SkyAPI 
-- Game: Breathe Peace World
addappid(968310)
addappid(968311, 1, "3b82dcb667d7a435b43a3f3c444dd58598a531ec7f0b4fa6dac4e7a238b8ad49")
