-- Lua provided by SkyAPI 
-- Game: AppID 2615240
addappid(2615240)
addappid(2615241, 1, "84a4bef3de493c661ae1c8bee7cceb688f42d34d74ab15a88c0883f1c10d8308")
