-- Lua provided by SkyAPI 
-- Game: Combat Evolved 2D
addappid(3007630)
addappid(3007631, 1, "18d9cd742325566a57d5b76b9fa56d95dffc16315a86c7555e7d181c7abb3ba6")
