-- Lua provided by SkyAPI 
-- Game: AppID 1401920
addappid(1401920)
addappid(1401921, 1, "98e88d09bcb6bd817f3ee16fa7559e872e5a550ec8b4230b4623205e6ea3ac2b")
