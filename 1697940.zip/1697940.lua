-- Lua provided by SkyAPI 
-- Game: The Whisperer
addappid(1697940)
addappid(1697941, 1, "fa906f159d6ffd086e834437f80684536cf0033e7b42a3c3e140f8900d603259")
