-- Lua provided by SkyAPI 
-- Game: AppID 772610
addappid(772610)
addappid(772611, 1, "81913eb3c6b2ea9cc7a9fd33492fa42bf342a3de79f08e75233d3d74ad488b1a")
