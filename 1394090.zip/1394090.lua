-- Lua provided by SkyAPI 
-- Game: Power of Ten - Demo
addappid(1394090)
addappid(1394091, 1, "bc82174dd0617d49874c3d7190011f7bac3cc4b1c334a2670ed257b9b8305148")
