-- Lua provided by SkyAPI 
-- Game: 4 Elements
addappid(47000)
addappid(47001, 1, "6ff843b689aee294b80e56d3db6e850dc5dec67f036579e5f70404a756a4545a")
