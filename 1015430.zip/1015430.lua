-- Lua provided by SkyAPI 
-- Game: AppID 1015430
addappid(1015430)
addappid(1015431, 1, "0cdf13134af24377289d91b832b2706352c40a7df3a7e4cc9985acde654e8058")
addappid(1015432, 1, "b4e6405c1d689df2dd6758ffc08ea985ec93c5eab6d43e3427a32c7c9da62f69")
