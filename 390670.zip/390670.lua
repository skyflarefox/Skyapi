-- Lua provided by SkyAPI 
-- Game: Steel Ocean
addappid(390670)
addappid(390671, 1, "9c719c87c078d0509d51d104fd52203226ca4e56a8e2a504117b9521b2430b95")
addappid(398310, 0, "b129b90a83c642f6bfd8a67a1c78795f9beed9aa1d4cf7c1eb3753217b9beee7")
addappid(430110)
addappid(430120)
addappid(460240)
addappid(546880)
addappid(546890)
addappid(557350)
addappid(557380)
