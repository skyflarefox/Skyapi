-- Lua provided by SkyAPI 
-- Game: Unearth
addappid(2487930)
addappid(2487931, 1, "50ab85563ae5cb17cd6b8dbf58371f34f57618e279b85aab1a97641910ed1e82")
