-- Lua provided by SkyAPI 
-- Game: AppID 494460
addappid(494460)
addappid(494461, 1, "fac375e09e5fc527478329c369529d3706eac0033231288aa36a7c03046adc50")
