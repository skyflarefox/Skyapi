-- Lua provided by SkyAPI 
-- Game: AppID 1140440
addappid(1140440)
addappid(1140441, 1, "5543534b8abadbdbafa82b1ce1812ec8a80cd8da2f1b123e30bfd0bac2426cdb")
