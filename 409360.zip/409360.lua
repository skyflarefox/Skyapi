-- Lua provided by SkyAPI 
-- Game: Faron's Fate
addappid(409360)
addappid(409361, 1, "22f230f5358c30890d33b2e401fadc1b5d1ba80b171d80bb802ec9e5c5877866")
addappid(410260)
