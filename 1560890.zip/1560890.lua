-- Lua provided by SkyAPI 
-- Game: Morkredd Prøve (Demo)
addappid(1560890)
addappid(1560891, 1, "cd84316513299bca80ec5b4702a0277a42384c3ab990d18d02d7f813f033b845")
