-- Lua provided by SkyAPI 
-- Game: AppID 2269330
addappid(2269330)
addappid(2269331, 1, "5419b22b02c344b4b6f2a55de4ec1089260dbac9c58512d593132d9a08e18a18")
