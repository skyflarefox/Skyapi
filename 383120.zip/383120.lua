-- Lua provided by SkyAPI 
-- Game: Empyrion - Galactic Survival
addappid(383120)
addappid(383121, 1, "34c1757941c6a2a64511d2d07327a24569014d7bd684b4259ec76f37f7aedc55")
addappid(2765930)
