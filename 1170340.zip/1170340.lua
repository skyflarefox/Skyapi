-- Lua provided by SkyAPI 
-- Game: Hentai Jigsaw Puzzle 2
addappid(1170340)
addappid(1170341, 1, "10d8a3b8a99b0e7948b3771cabb2bdc68fc62cee5f82b6f0cc9a58d268801fba")
addappid(1182270)
