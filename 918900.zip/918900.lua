-- Lua provided by SkyAPI 
-- Game: AppID 918900
addappid(918900)
addappid(918901, 1, "a509b4209c9ab188c8a6f08a6e040a6ea4a8e69bd197a0d2b79bcedcac618ccc")
