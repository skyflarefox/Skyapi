-- Lua provided by SkyAPI 
-- Game: AppID 1240530
addappid(1240530)
addappid(1240531, 1, "ff658b6d6365210427d69487494528cb0fa71864fab08b37957faced3eed8918")
