-- Lua provided by SkyAPI 
-- Game: Carmen Sandiego
addappid(2475300)
addappid(2475301, 1, "f473cf38e3fd909e56fc7299424141d710b4d6bac319dabc2933aed73bba21ac")
addappid(3311640)
