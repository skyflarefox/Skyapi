-- Lua provided by SkyAPI 
-- Game: AppID 886440
addappid(886440)
addappid(886441, 1, "0d015ac444ae1fd7136af346367b24a65cec57de9fa709b4129fcf7ee5173a87")
addappid(886443, 1, "ce0e1f5e6e226e5795811ad4343e2e8c04a00428c8341196442cf11af86f51ee")
