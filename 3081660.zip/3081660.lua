-- Lua provided by SkyAPI 
-- Game: AppID 3081660
addappid(3081660)
addappid(3081661, 1, "b875575c9f9e6498e5346fef5829ba4a2cfa60e47db761bfa312b2c3fd24a366")
