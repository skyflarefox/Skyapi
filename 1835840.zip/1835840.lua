-- Lua provided by SkyAPI 
-- Game: Quarantineer
addappid(1835840)
addappid(1835841, 1, "c83da66a20cb09a24a003e5e1665d038da0583b9015a4307e06e9d3ce8a6b5dc")
