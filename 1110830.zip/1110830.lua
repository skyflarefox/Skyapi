-- Lua provided by SkyAPI 
-- Game: AppID 1110830
addappid(1110830)
addappid(1110831, 1, "123a6781a6dd383ed38afcd4cc440d788423a6576b15c23f701fa4eb10bb9f14")
addappid(1141720)
