-- Lua provided by SkyAPI 
-- Game: Crescent Quest
addappid(2421510)
addappid(2421511, 1, "f3728c3b05f8b26648b84187c0eccb67706f9629b4180994a8402e75e2808f49")
