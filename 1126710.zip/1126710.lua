-- Lua provided by SkyAPI 
-- Game: AppID 1126710
addappid(1126710)
addappid(1126711, 1, "42e2c79af26531a8ae144c630fa77e3f2ae9433f58e532b4b75eecbe6ebd4dda")
