-- Lua provided by SkyAPI 
-- Game: Silly Polly Beast Demo
addappid(3261690)
addappid(3261691, 1, "0b086432f7029e05f31cd46e0d180f4aa302bbefc4f3ee3718689a04f2194107")
