-- Lua provided by SkyAPI 
-- Game: Deep Space
addappid(1453940)
addappid(1453941, 1, "b0cd930e3b49c4384ab47aced4e1d89894922454215a010de920753f87d7b615")
