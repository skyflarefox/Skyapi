-- Lua provided by SkyAPI 
-- Game: Dead Alliance™
addappid(626200)
addappid(626201, 1, "099b355afb049ed50ba0e398abf8e73420160ee7b420a9a6f6d45abc78a4efd4")
