-- Lua provided by SkyAPI 
-- Game: BEAMS
addappid(2710420)
addappid(2710421, 1, "fa13904b76319626e8c3861de721cec7347157b033a57dd71cda7a49a6abc2a6")
