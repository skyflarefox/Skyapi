-- Lua provided by SkyAPI 
-- Game: AppID 1597630
addappid(1597630)
addappid(1597631, 1, "3f46fd89624711f7b6ff979be31a2d71270b2e33c0f8d0ce5656e2dc34c595da")
