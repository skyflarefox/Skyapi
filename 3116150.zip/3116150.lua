-- Lua provided by SkyAPI 
-- Game: Butterfly Dream Demo
addappid(3116150)
addappid(3116151, 1, "e6c48dd4bf110a83368a755eb82574d662594cd6741f75cb1c664f343b75c864")
