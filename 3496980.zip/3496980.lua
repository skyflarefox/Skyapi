-- Lua provided by SkyAPI 
-- Game: Greenhouse: Schism
addappid(3496980)
addappid(3496981, 1, "72765af3f5eea22697b91b94af6fa303fa6997920b318ffd2daf9f57d0fb15bd")
