-- Lua provided by SkyAPI 
-- Game: Crime Simulator: Playgrounds
addappid(2928280)
addappid(2928281, 1, "420803afcfa6aad0d49ab5c933d63f73a2a541bd6d20c1e2030c53113c844006")
