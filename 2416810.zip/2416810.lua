-- Lua provided by SkyAPI 
-- Game: AppID 2416810
addappid(2416810)
addappid(2416811, 1, "9f2fbd6506e7a7f2e50f71436270489245caae28c40054f0229407447d17a2b5")
