-- Lua provided by SkyAPI 
-- Game: HexoJago
addappid(1866220)
addappid(1866221, 1, "b3233aa787da6c15173d402b9bb65aecbe29e02f0eff19c8f239b96e1dd28ca5")
addappid(1870560)
