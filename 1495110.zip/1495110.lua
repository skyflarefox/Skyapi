-- Lua provided by SkyAPI 
-- Game: Fairytale Mosaics Beauty And The Beast 2
addappid(1495110)
addappid(1495111, 1, "919183eebaca730d4a43f1c281beed497d4bed3e3a20ac7e984f78dcd07a8386")
addappid(1495112, 1, "9abb885e848902dc9c88e4205b6b651148b5ee07b0fc7cf7f931967eaa6257e7")
addappid(1495113, 1, "5afb96e724a6cb4b5fbe3ce02b47dbbaf3575e6364230c94e824034929bfe695")
addappid(1495114, 1, "e599b968af392d689aab10323fcb300e6c46ab089953a594ec4aa3a1b53e7f94")
