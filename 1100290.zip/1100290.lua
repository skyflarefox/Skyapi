-- Lua provided by SkyAPI 
-- Game: AppID 1100290
addappid(1100290)
addappid(1100291, 1, "3f1ad119aad2738e42f53621028dcd70992e2b33fe2185785cb6cfb5d82bfcd9")
