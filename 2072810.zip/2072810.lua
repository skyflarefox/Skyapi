-- Lua provided by SkyAPI 
-- Game: AppID 2072810
addappid(2072810)
addappid(2072811, 1, "b3ceafec30308c9eaaf544ad1695238cf961050b5b801a6adc3e451ceac4c7f7")
