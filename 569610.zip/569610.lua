-- Lua provided by SkyAPI 
-- Game: Distant Space
addappid(569610)
addappid(569611, 1, "a7527fd2068cac97c3a7772ca98930fed680114645e7439cbdc777e48f38d4f2")
