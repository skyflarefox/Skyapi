-- Lua provided by SkyAPI 
-- Game: World of Fate
addappid(2241860)
addappid(2241861, 1, "2c6ba16f74465c25c6166a6ad3286576b45623a2af1b8b08195b96fe74db81fe")
