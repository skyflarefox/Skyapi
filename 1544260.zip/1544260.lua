-- Lua provided by SkyAPI 
-- Game: Meor Playtest
addappid(1544260)
addappid(1544261, 1, "70b01d08a30db72bcee5a75db27ec4a16c227a9b46aa13b11eb46e416fb20fb4")
