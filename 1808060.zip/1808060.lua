-- Lua provided by SkyAPI 
-- Game: Obama Maze
addappid(1808060)
addappid(1808061, 1, "e6e8c895c84a062d9a8ded59cd523f9a9af1554e429da4c197ee94d7e2e66d7c")
addappid(2107240)
