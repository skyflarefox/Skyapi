-- Lua provided by SkyAPI 
-- Game: OVR Locomotion Effect Demo
addappid(1429050)
addappid(1429051, 1, "acd19a61da5761becd96c39b1ecef1c299d0fbbc59dd907a01e1cd56ab17aff9")
