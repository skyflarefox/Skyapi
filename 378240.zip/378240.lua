-- Lua provided by SkyAPI 
-- Game: The Mors
addappid(378240)
addappid(378241, 1, "0a0711dab14c20ee698bcc19d1602cda866c98fd4df63098b5f2051bd87dc412")
