-- Lua provided by SkyAPI 
-- Game: AppID 812190
addappid(812190)
addappid(812191, 1, "7a1325f90bad258a3c07565e59e58fa4da04272a8917bef56c3fbf5f169d8c07")
addappid(1151850, 0, "30d3277f3c442350c96e3a1cd00728abcb005e4596692e9f481607ce185776fc")
