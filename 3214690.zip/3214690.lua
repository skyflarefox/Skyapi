-- Lua provided by SkyAPI 
-- Game: Chronicles of Delights: Isekai Adventure
addappid(3214690)
addappid(3214691, 1, "c5b966679c899c3d1c8c2f134608174603966690e3ad92659f781101c0a3edd2")
