-- Lua provided by SkyAPI 
-- Game: Wandering in Space VR
addappid(1971770)
addappid(1971771, 1, "4b1c85b1e298cc34f21894e7746f336f79c9c7e469ed03da52526a02704040ce")
