-- Lua provided by SkyAPI 
-- Game: Rolling in the Maze
addappid(1899400)
addappid(1899401, 1, "629bdf244ecfcab1c289082c0c3231f452a92267d80c64a968da7269a5e026e6")
addappid(1908590, 0, "94874b40ab6f5cb089d7df33ef54a6747737e89f6b7e7c872ceb4d5d7857f4e5")
