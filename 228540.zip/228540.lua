-- Lua provided by SkyAPI 
-- Game: AppID 228540
addappid(228540)
addappid(228541, 1, "c57ad715ebf2622c929f2c5a8b4737d7edd73c656ab04eb8df079408819040d4")
addappid(228542, 1, "94ba035019fbfe6effb17f944191b5fe04829a99bf49b1dbf6ec3797db09eb10")
addappid(228543, 1, "35b1527b38d22c286d91edfb5ef414eda366bbb2c1c47407aae35605cc1a6d2f")
