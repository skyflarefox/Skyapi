-- Lua provided by SkyAPI 
-- Game: STHELL
addappid(1604280)
addappid(1604281, 1, "8d6956d46d0da9138ffcdd65bae685548fd07818f1167e43d661e17a4aeea9d0")
