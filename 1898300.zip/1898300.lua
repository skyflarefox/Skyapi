-- Lua provided by SkyAPI 
-- Game: AppID 1898300
addappid(1898300)
addappid(1898301, 1, "32c13d15c0ef56699f2d009163b995a3a06463310ea381191d1d19e332af2f6c")
