-- Lua provided by SkyAPI 
-- Game: The Mutineer
addappid(1385670)
addappid(1385671, 1, "2555ca65c7c041d8705a67d8d26c7297862f9b0b56a7aeae87288f072a6dd867")
