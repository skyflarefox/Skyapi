-- Lua provided by SkyAPI 
-- Game: Kraken Academy!!
addappid(1158220)
addappid(1158221, 1, "e8a2c35cdcf7fd2aa3a8950dbefb70813019caa7ee29d8e22dae31af88212e82")
addappid(1158222, 1, "24814ce60441daca9ec093ac026df0cfaccde29fae1baeffc587669a1bbca4c0")
addappid(1158223, 1, "dc0747ce2223eea269d355e4126d8573f61e8485c4135d7cd77d1f2ae7681d5b")
