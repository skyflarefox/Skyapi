-- Lua provided by SkyAPI 
-- Game: Milo and the Christmas Gift
addappid(2716140)
addappid(2716141, 1, "d3b87712169c9aa7d73d65617f02ca26f7361b4dc51f24584cd1c9c9576c71f6")
