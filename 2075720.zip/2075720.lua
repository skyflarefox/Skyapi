-- Lua provided by SkyAPI 
-- Game: 9 Days
addappid(2075720)
addappid(2075721, 1, "6075ff50d6af9b4e3ee0b83bfaa817c49e920604c04e60014156c95331112e8c")
