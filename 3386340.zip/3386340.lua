-- Lua provided by SkyAPI 
-- Game: AppID 3386340
addappid(3386340)
addappid(3386341, 1, "1a72d970dbdc9b98a40c5f0ef08fd2c3563cf1687935f1d82f72b3ec9a1d7e78")
