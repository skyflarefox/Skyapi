-- Lua provided by SkyAPI 
-- Game: AppID 1830960
addappid(1830960)
addappid(1830961, 1, "cdae1daf96a020fd17011000dcfb1fbc316667507ab605fcb20376bffa9d1fa6")
