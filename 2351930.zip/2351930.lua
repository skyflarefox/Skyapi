-- Lua provided by SkyAPI 
-- Game: Swarm Survivor
addappid(2351930)
addappid(2351931, 1, "fc69873e402927d31e38d195e94e7a92d7b52edeff142bdd804412a163860c7d")
