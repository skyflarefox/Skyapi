-- Lua provided by SkyAPI 
-- Game: AppID 1700770
addappid(1700770)
addappid(1700771, 1, "8881c09a325805931b6b94ed76c19c28d08606127dbe2fbb454b1be63dbf6184")
