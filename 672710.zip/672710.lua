-- Lua provided by SkyAPI 
-- Game: Traffic Giant
addappid(672710)
addappid(672711, 1, "96581bd2457ea99bfbd591a92d8f7cc0c8cda4b85bdbe3d6d998786fc7f6d516")
addappid(672712, 1, "79e0cb1aea414805a5909c4edd2ed5a7071f6068135825212cbb6ac84414176e")
addappid(672713, 1, "23c52f210cc12e1b0df4d98f89e727fa7b0e6530bfeeee7f258a8936e886a7c2")
addappid(672714, 1, "2a11dd5f35dd73bce0f9d98eb130e77631f31356886c2ddd1252bc76834fd1a3")
