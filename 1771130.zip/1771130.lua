-- Lua provided by SkyAPI 
-- Game: OPEN DOOR
addappid(1771130)
addappid(1771131, 1, "a51b0fbf51aa8990d0fff0c57f234211c4e21a391ad24dd9190aad690b8b260a")
