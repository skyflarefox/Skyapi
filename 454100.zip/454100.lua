-- Lua provided by SkyAPI 
-- Game: Dungeon Escape
addappid(454100)
addappid(454101, 1, "37709ba8f29ea4fce083fa35a3d6f01196604f4ec9fa859bd71bdc0dea5d79d9")
addappid(454102, 1, "b6660ed3b740e0a293f0908c8cbf796a28f3460c3529539cfb89588b2c3bdde8")
addappid(454103, 1, "898bc25cbf6bd4974afb3ccf2da64497aa89b9a39f85041ae5e65debebc456fa")
