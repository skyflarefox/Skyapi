-- Lua provided by SkyAPI 
-- Game: Love Rhythm
addappid(1185520)
addappid(1185521, 1, "009d40c71a1854e44104cdae6e526f0b13c06541a5862755b17fc065fefba3c5")
