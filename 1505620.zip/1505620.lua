-- Lua provided by SkyAPI 
-- Game: Waifu Secret
addappid(1505620)
addappid(1505621, 1, "fdd6d5be1779b792ce08474667b77cd650e25945eab468ddbc38509703b08f97")
