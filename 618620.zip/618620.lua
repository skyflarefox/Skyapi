-- Lua provided by SkyAPI 
-- Game: Naval Armada: Fleet Battle
addappid(618620)
addappid(618621, 1, "74982e67496cc11bfafe6e993a0596ade18c77bb40fa985bb329a796f7385050")
addappid(618622, 1, "ae1b0f774bca73cc757a58ee07c7eeecb2c344aa1cb43b31fe1efdf589e3414d")
addappid(618623, 1, "794670f12223036e6c97d9cc831f1b6217efa2a5bbcad66df2332586d3300e8a")
