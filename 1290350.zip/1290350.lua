-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1290350)
addappid(1290351,0,"134611c7730fc89bd8a3ba25c2aafbfe87ae630b7b007637ec6833a522b6ec03")
setManifestid(1290351,"2873792185401635081")
addappid(1290352)
addappid(1290353)