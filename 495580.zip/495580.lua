-- Lua provided by SkyAPI 
-- Game: Divided We Fall: Play For Free
addappid(495580)
addappid(495581, 1, "d05072a13b52baba974b70a3c51d6bfdc19482b36bd9abd82392ea21722ac6bd")
addappid(495582, 1, "89916a28ab2161446227ea778f93883dd4eb5391d59040a4a2ae991ee0e6ac8e")
addappid(495583, 1, "b8b1a0d9f335eb6499c11ab85c4e7ca24c56c70fc29109cc89ba47214d3c5c48")
addappid(862760)
