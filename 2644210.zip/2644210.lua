-- Lua provided by SkyAPI 
-- Game: Margarita (Berkeley's Maid: Remake Edition)
addappid(2644210)
addappid(2644211, 1, "fed9415b636fe2e0a81ac3ee813bbf79a3cb1afa6ca089b0242817567d1c8943")
addappid(3311500, 0, "5e0668e0b08cc28a87e3a72a316a550e7de73f8a60832f59b57e29a52c14f3fb")
