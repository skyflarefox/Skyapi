-- Lua provided by SkyAPI 
-- Game: Once Upon a Jester
addappid(1668190)
addappid(1668191, 1, "24f1729c7e9013206efae8b4b71f5c6e16159ed7b8231d06c8371ccd568c6f95")
