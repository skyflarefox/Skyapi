-- Lua provided by SkyAPI 
-- Game: Captain Blood
addappid(3040220)
addappid(3040221, 1, "4e420c4703c98612bdd32e142ab68e49de39d49835b722b523ddede7ae026a17")
