-- Lua provided by SkyAPI 
-- Game: Paper Dolls 2 纸人贰
addappid(1334040)
addappid(1334041, 1, "597e814feb7f6fd2584d5f51e05f08b325ab4c0325e79ec83dbafb1b61568937")
addappid(1453650, 0, "205f3bfd33dab5bd606c4959fa858e6046c33db2a1b86ec84ff73d62c6b6d6da")
