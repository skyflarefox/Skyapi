-- Lua provided by SkyAPI 
-- Game: Haunted Hotel: The Axiom Butcher Collector's Edition
addappid(1762450)
addappid(1762451, 1, "c00ae681fd14b4b9a7175dfee927dba6de73e3c38fa2ccb4ecd42c384bfb6844")
