-- Lua provided by SkyAPI 
-- Game: AppID 2389310
addappid(2389310)
addappid(2389311, 1, "c4eb8d37bada04f97694177cb57bb7854319e8316e9bcc34510801799fd25bf9")
