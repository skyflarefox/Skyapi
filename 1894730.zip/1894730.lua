-- Lua provided by SkyAPI 
-- Game: Asterix & Obelix XXXL : The Ram From Hibernia
addappid(1894730)
addappid(1894731, 1, "9df8b240dfe169146c5d5a08f52d17c7e0de597bd5904ce17e52dfd2d2e95d83")
