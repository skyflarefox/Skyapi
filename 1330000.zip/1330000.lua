-- Lua provided by SkyAPI 
-- Game: AppID 1330000
addappid(1330000)
addappid(1330001, 1, "2f6104a763da7d625fe6284c3b52beca5787775c77574a842799f5be1fd5e43f")
addappid(1330002, 1, "ce6ee02092ba2ffcb8d5da8b9a5a3b1a32791ec290787b6986bd3f08f42193c7")
