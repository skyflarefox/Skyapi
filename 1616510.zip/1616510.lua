-- Lua provided by SkyAPI 
-- Game: AppID 1616510
addappid(1616510)
addappid(1616511, 1, "67b704678fc9b8b87b94038b1e3c3266bf2b4b43cb5fc9cc851e6388991cbe9e")
