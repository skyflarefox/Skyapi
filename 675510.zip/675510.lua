-- Lua provided by SkyAPI 
-- Game: Kingdom City Drowning Episode 1 - The Champion
addappid(675510)
addappid(675511, 1, "b8f7202567791f5ed6a5f7e3fada18aed17e0801ee710ecc448fad2360062798")
