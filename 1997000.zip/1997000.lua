-- Lua provided by SkyAPI 
-- Game: AppID 1997000
addappid(1997000)
addappid(1997001, 1, "53b0517121a75e7a931ab186440d8a8779e3523f42511ed07ce5e32a3128726a")
