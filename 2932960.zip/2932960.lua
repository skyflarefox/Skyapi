-- Lua provided by SkyAPI 
-- Game: A Merchant's Promise
addappid(2932960)
addappid(2932961, 1, "968615d7322f18dda5a36a70f8da86d8fbf504465b02572a7386febe2fc7ba8b")
