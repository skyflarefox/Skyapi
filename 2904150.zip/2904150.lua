-- Lua provided by SkyAPI 
-- Game: AppID 2904150
addappid(2904150)
addappid(2904151, 1, "da9ade9221dc4e7c73d98164f578ce7a8f6454bef5ba322175316bae39147288")
