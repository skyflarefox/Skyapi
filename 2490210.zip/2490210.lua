-- Lua provided by SkyAPI 
-- Game: Blitz Runner
addappid(2490210)
addappid(2490211, 1, "c2b31f77b9453ea7a336ac062a1fd8a8402b18061ca0bac9b97d8c6fbe3272a5")
