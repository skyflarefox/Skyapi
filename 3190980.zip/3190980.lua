-- Lua provided by SkyAPI 
-- Game: AppID 3190980
addappid(3190980)
addappid(3190981, 1, "79fd247371c1344289aad350206a0eb03908b04c3db9def610af297babe74d4f")
