-- Lua provided by SkyAPI 
-- Game: PuppetShow: Porcelain Smile Collector's Edition
addappid(1038380)
addappid(1038381, 1, "4151f151171c361c06dee890b02675290ffd0e6e0728fc3dcfab25f07d33e53d")
