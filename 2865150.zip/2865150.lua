-- Lua provided by SkyAPI 
-- Game: 后室：彼阳的晚意-Backrooms:Beyond one year Demo
addappid(2865150)
addappid(2865151, 1, "b9ed1d10f15e81eed3e7df7d39626c6ed1e91b70a3c4224e23bb3678e40f0bb9")
