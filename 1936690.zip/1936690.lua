-- Lua provided by SkyAPI 
-- Game: Gladiator Playtest
addappid(1936690)
addappid(1936691, 1, "aedb4232e1ea1fef3f8aca03f558a098376a0136be3afe3a25069d8f0cd3c295")
