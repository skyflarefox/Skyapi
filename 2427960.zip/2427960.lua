-- Lua provided by SkyAPI 
-- Game: Calcium Contract
addappid(2427960)
addappid(2427961, 1, "32dfc84d29e1ae4dfd5fee8afffbf3b297c1cbb95bff674dc0079c98ef4062db")
