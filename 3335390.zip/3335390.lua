-- Lua provided by SkyAPI 
-- Game: Sexbot Lab
addappid(3335390)
addappid(3335391, 1, "86796f8d9a5c441c5418280519a7d55cd5669a57e7f940ea9d0e9a2c64fd8b20")
