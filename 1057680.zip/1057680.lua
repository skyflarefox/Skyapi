-- Lua provided by SkyAPI 
-- Game: 人间 The Lost We Lost
addappid(1057680)
addappid(1057681, 1, "6fdc6b60b7f397e3130ad16adcd80e6aabe854e6f95a7a384122330fb7515996")
addappid(1088450, 0, "6bad4c5cf73c8610426614c19bbc3fe39cd11d98af5c459e2e5ebcf87050e8aa")
