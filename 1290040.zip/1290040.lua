-- Lua provided by SkyAPI 
-- Game: AppID 1290040
addappid(1290040)
addappid(1290041, 1, "6c4b5dab73a2024072e05d83edc17670d60f8d7d389fd713713d825417360e61")
