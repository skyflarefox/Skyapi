-- Lua provided by SkyAPI 
-- Game: The Darkest Island
addappid(1363390)
addappid(1363391, 1, "7eb2f92a3743e251d9a9062aa9eeadbad17a0d4692277caa018e8dde3736200d")
