-- Lua provided by SkyAPI 
-- Game: AppID 1177720
addappid(1177720)
addappid(1177721, 1, "e36c2d595f48ca926faf1e0854dce7603ab4fa9bcdf0b7acfe3417a7b60635ca")
