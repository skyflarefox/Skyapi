-- Lua provided by SkyAPI 
-- Game: Greedland
addappid(2218400)
addappid(2218401, 1, "50ce9e04af153be16d359d90ff3f2cc322ab4f88e8407139c48e34e6d6477091")
