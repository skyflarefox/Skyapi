-- Lua provided by SkyAPI 
-- Game: Fragment's Moonrise
addappid(1297660)
addappid(1297661, 1, "189bd4f0cd81206ffdfe0f930f6edb2b1c8513ecdbaa0a3f0b05e4836aed03c4")
