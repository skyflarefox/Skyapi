-- Lua provided by SkyAPI 
-- Game: All of Us Are Dead... Demo
addappid(2273620)
addappid(2273621, 1, "f9a59ee41c898d82c277e600f5a4ef99f7150186afcc0ada334c2797f83069dd")
