-- Lua provided by SkyAPI 
-- Game: AppID 915810
addappid(915810)
addappid(915811, 1, "d7b9540b9686b8d615fa43442db4e31e903d7770c28306479c875f17e92ed930")
