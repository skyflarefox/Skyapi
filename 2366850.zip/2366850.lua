-- Lua provided by SkyAPI 
-- Game: DAIR
addappid(2366850)
addappid(2366851, 1, "dc56068ba70fcc724d4383eb7160871db6dc98b9b8d99c4216a28c3e07099f18")
