-- Lua provided by SkyAPI 
-- Game: NO, THANK YOU!!!
addappid(975000)
addappid(975001, 1, "9575ffd3affe3782c0912278c17e21e2ea2475d82d5f5e4fe20d7219de852844")
