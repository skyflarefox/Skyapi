-- Lua provided by SkyAPI 
-- Game: Suits: Absolute Power
addappid(1210230)
addappid(1210231, 1, "97a7cf8114b33ce0ea492ba412e43c69dfc4ddbf5932fdaa33e44af63929df97")
