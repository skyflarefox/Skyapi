-- Lua provided by SkyAPI 
-- Game: AppID 1310080
addappid(1310080)
addappid(1310081, 1, "c0079c42938cec168675356ab15c03b0aff09e1355079a3578f7b7100d3336cf")
