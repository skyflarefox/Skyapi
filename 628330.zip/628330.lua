-- Lua provided by SkyAPI 
-- Game: AppID 628330
addappid(628330)
addappid(628331, 1, "ae3c1b9099ab0f6ddf3b44e7d59ae08384ecdbeeddd8e87186b30886c539cf9d")
addappid(628333, 1, "12bb6c0949de6c006e4cf832db3a2f0efa079175d145eca61ae802c5358139aa")
