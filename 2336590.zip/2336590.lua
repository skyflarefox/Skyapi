-- Lua provided by SkyAPI 
-- Game: AppID 2336590
addappid(2336590)
addappid(2336591, 1, "6c0d76d334187b2c7ef32b0b13f2164cd7a9ec262009d4d83b2be9b32bbcf2b6")
