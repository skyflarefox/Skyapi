-- Lua provided by SkyAPI 
-- Game: CyberBlocker Complete Edition
addappid(2123390)
addappid(2123391, 1, "cbde53535f57a2035bd25a31cd44843db8afd59fc9cb7d274e8e7154a7ee949d")
