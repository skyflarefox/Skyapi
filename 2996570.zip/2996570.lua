-- Lua provided by SkyAPI 
-- Game: AppID 2996570
addappid(2996570)
addappid(2996571, 1, "22d28241bbf5981e0adf5312e88b3d5d29eae805069166112feb915c7c7dd90f")
