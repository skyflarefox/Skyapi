-- Lua provided by SkyAPI 
-- Game: THE_ABYSS_HAS_WALLS
addappid(1916630)
addappid(1916631, 1, "32b71dfc47e29c8716a35ee389998b2771e2578474751a85610c4729dd2229df")
addappid(1922660)
