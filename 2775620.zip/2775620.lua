-- Lua provided by SkyAPI 
-- Game: AppID 2775620
addappid(2775620)
addappid(2775621, 1, "d7709f4773075afb9d53149458eb314b3931a487f1cb9a00cb7075b4b660585e")
