-- Lua provided by SkyAPI 
-- Game: Dead Herring VR
addappid(1498490)
addappid(1498491, 1, "6f12c4b00d6c058302f543b4f833184689028086dc9d6db7122be492e66ded10")
