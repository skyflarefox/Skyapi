-- Lua provided by SkyAPI 
-- Game: Grimstar: Prequel
addappid(1631250)
addappid(1631251, 1, "55d5ebd07ecaf0b81857ac7a47f496aef40ecc0bc1e535b198c0569cc6b7c5aa")
