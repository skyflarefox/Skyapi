-- Lua provided by SkyAPI 
-- Game: Avadon 3: The Warborn
addappid(460780)
addappid(460781, 1, "24c1c715187d619d8a68db0349dd0baf414f0d2ca6ab4142cc70e8f3e2b6caab")
addappid(460782, 1, "8b8d944c3446b2a0b7fad4f0855171ff16c0d6aa46fba1a34dda18e6659f5278")
addappid(518630, 0, "03bf96649b54be70b81bae73c8f73e5be453443083725f9befb3329eeccc0059")
