-- Lua provided by SkyAPI 
-- Game: Wild Bastards
addappid(1660840)
addappid(1660841, 1, "0408c5cf14dd89f80d031a9880eca5777d24d2b82d49c91b7569a34556eae74e")
