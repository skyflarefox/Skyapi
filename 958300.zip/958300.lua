-- Lua provided by SkyAPI 
-- Game: AppID 958300
addappid(958300)
addappid(958301, 1, "bfef5c183ba68925e51b6cd66d48944bcf8670e0b06a05da4f3eb62b7aa83cdb")
