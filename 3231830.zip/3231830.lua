-- Lua provided by SkyAPI 
-- Game: AppID 3231830
addappid(3231830)
addappid(3231831, 1, "3bd0037818f86fd3557112832c05884e2bf7f746ab132aa7c23ed8f0df892131")
