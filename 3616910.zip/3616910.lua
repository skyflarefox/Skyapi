-- Lua provided by SkyAPI 
-- Game: BACKROOMS: We Escape Forever
addappid(3616910)
addappid(3616911, 1, "51025fbf15fd39032d10f162d9e460b4f89c06365e6699638a2d65aba62919bb")
