-- Lua provided by SkyAPI 
-- Game: BioCrisis
addappid(1448800)
addappid(1448801, 1, "7ecf5d7f489149bfd672bd1d2d4c76cae2ae8d2a8cc993262374d492e9f6b37d")
