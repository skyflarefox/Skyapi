-- Lua provided by SkyAPI 
-- Game: AppID 1909290
addappid(1909290)
addappid(1909291, 1, "1e277bf0eae74994ddaba84daf5ebf8ce0c17ab5e26795740d08a9e8a2e60ec3")
