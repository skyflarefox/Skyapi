-- Lua provided by SkyAPI 
-- Game: 101 Cats in Prague
addappid(3806550)
addappid(3806551, 1, "611dd4ede68a998b6e911da5ca7c5c04c68353031886c0027d685d7691da1cd1")
