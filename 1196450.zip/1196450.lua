-- Lua provided by SkyAPI 
-- Game: Stop Sign VR Tools
addappid(1196450)
addappid(1196451, 1, "7d4e3e375f97176e1f7c69e9c5d545972d3f21862cd162b48c223802382fe9cd")
