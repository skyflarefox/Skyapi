-- Lua provided by SkyAPI 
-- Game: AppID 888680
addappid(888680)
addappid(888681, 1, "d4e91323927227086d2e441bf497aeaf334e64b20045abb40621fa48836d2b31")
