-- Lua provided by SkyAPI 
-- Game: GAZOLINAS
addappid(2230740)
addappid(2230741, 1, "f0092552ccb81062a8857640707d40f0ae417adcc4571b0bf10b171d102e986d")
