-- Lua provided by SkyAPI 
-- Game: Mech Armada
addappid(1389360)
addappid(1389361, 1, "6a09cd3ce1b5b608ba93a86a4520829825c02abdaed6b935477f94a49c422d57")
