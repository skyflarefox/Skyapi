-- Lua provided by SkyAPI 
-- Game: AppID 1515200
addappid(1515200)
addappid(1515201, 1, "da1aff41e5dc354e9d956adb05562d2cf21918dbda8a2820656720a1a4e57368")
