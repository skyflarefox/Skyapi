-- Lua provided by SkyAPI 
-- Game: Idle Monkeylogy
addappid(1690690)
addappid(1690691, 1, "29e8b06cf34c8012930b10f2c1239cf9257f7a06cf95c9dc9b9b4f2ef4459776")
