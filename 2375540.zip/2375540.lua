-- Lua provided by SkyAPI 
-- Game: Hentai Casual Jigsaw - Witches
addappid(2375540)
addappid(2375541, 1, "8cbcf7fa739780b247fd54b62dc4cd65e712777ee3402206ab1805560cfd640f")
