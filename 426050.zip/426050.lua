-- Lua provided by SkyAPI 
-- Game: LEGIE
addappid(426050)
addappid(426051, 1, "58070d6a51131ba5e203cbfd58081dffa8948d48487bfa42ee396e972f13c1c5")
