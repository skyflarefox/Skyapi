-- Lua provided by SkyAPI 
-- Game: AppID 1711960
addappid(1711960)
addappid(1711961, 1, "93c709e283e5156320915276c61b17e2462092f2da1081c68d6aca433ee174f0")
