-- Lua provided by SkyAPI 
-- Game: AppID 1293430
addappid(1293430)
addappid(1293431, 1, "eb0d53e530e3d781dc7f31449e7f73270ed8aa06d70179e5574fc9a1d61c83f2")
