-- Lua provided by SkyAPI 
-- Game: Paralines The Last paladin
addappid(813110)
addappid(813111, 1, "adc1d16be742a56af52241bd08d9080ec54487a31e2a36d57d5e7b2221db2609")
addappid(889000)
