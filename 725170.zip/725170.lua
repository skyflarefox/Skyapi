-- Lua provided by SkyAPI 
-- Game: AppID 725170
addappid(725170)
addappid(725171, 1, "b94788e6c16f0b35a17a7b2bb1876ad6b65359cba34f1f3fd73add444ba83f36")
