-- Lua provided by SkyAPI 
-- Game: No More Future
addappid(2091790)
addappid(2091791, 1, "ca97ec9ab959d7ac87d977770d94466f0f9c06f95b333fa3e159c2ac9e88e074")
