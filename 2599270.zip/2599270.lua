-- Lua provided by SkyAPI 
-- Game: Gem Defender: Soyjak Survivors
addappid(2599270)
addappid(2599271, 1, "8a4c41a27743be952f2eaf6351d79d84f8b610090b2a6f17b22d77d1353e5c76")
