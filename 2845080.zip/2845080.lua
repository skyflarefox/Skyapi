-- Lua provided by SkyAPI 
-- Game: SHARK SIEGE - TOGETHER SURVIVAL
addappid(2845080)
addappid(2845081, 1, "2989e0e3ea0d4ab6f390d46ed35904bc48235c5ccf60c755abf64039f6925dbd")
