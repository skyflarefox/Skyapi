-- Lua provided by SkyAPI 
-- Game: AppID 651670
addappid(651670)
addappid(651671, 1, "c9769e55ff211d10b6956bc0034942ca40a6f0e9310416e0bcbacd709094d7ab")
addappid(1379330, 0, "83362e34b4f192c64a1a63b047f7de7bb27b2af39775b932a24b4e3bece259a4")
