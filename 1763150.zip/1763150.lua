-- Lua provided by SkyAPI 
-- Game: Everglow
addappid(1763150)
addappid(1763151, 1, "2713610fb8a9321772b44273289e5f7274f90fee319e93536d8eb940c3ece8c4")
