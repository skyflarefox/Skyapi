-- Lua provided by SkyAPI 
-- Game: Supercow
addappid(1883570)
addappid(1883571, 1, "3d09785d2b6f0b0bc5fcfab832af7eb346af796e4bf3eceb4fa141f5feafd5b4")
