-- Lua provided by SkyAPI 
-- Game: Gomo
addappid(265330)
addappid(265331, 1, "5f5c00b4fab7d2cfd30d22b271ca1694bb95bd983cd597b4d2bbdd2059ab787d")
addappid(265332, 1, "0f2b929c02ef44605c711578c9bf2bec126ecb49687ea338a09fc921356ca508")
