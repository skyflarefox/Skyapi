-- Lua provided by SkyAPI 
-- Game: AppID 1085520
addappid(1085520)
addappid(1085521, 1, "5d53a66f698a1ca8f2aaa71e791612522e0138850bac6ae7b018a6677525f0db")
