-- Lua provided by SkyAPI 
-- Game: AppID 1205960
addappid(1205960)
addappid(1205961, 1, "2339c53c9ab59f2ff148e5c7f8776dc9a95bc66d203edf553cbbf02aa539d0be")
addappid(1211940, 0, "b1d323fe179c5f5a0387615ba97c9ad74a94f7ad9266c61fb709189d891be150")
