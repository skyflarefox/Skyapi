-- Lua provided by SkyAPI 
-- Game: AppID 2196860
addappid(2196860)
addappid(2196861, 1, "00c6e6e6aff8b5ca4c2086da3bdb0add41033932412ee08356bc7e55610237d9")
