-- Lua provided by SkyAPI 
-- Game: Fortified
addappid(334210)
addappid(334211, 1, "6533b5eeca9b49bf0a98b33b27271d5e675a17e604711f83095331148f5e94dd")
