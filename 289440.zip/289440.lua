-- Lua provided by SkyAPI 
-- Game: AppID 289440
addappid(289440)
addappid(289441, 1, "1b7f79bdb323dc9795ec23a768fed7279de2c58dc955bdd436243defc887e4c5")
addappid(289442, 1, "de29a552989e6e93cd1691c34fad97ba3f23a364cf4dd2636975a9cf61c4b810")
