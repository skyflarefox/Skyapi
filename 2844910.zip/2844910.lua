-- Lua provided by SkyAPI 
-- Game: Interior Designer
addappid(2844910)
addappid(2844911, 1, "27d50a2fca09dc3649747b3c66557722495294ccbc3a7fb7afe0fa50b6515009")
