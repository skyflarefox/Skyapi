-- Lua provided by SkyAPI 
-- Game: Planes, Bullets and Vodka
addappid(562360)
addappid(562361, 1, "3c5fd1049f7ca23079ab9df85498734da3feee520728f75e8a83fbdeb76bf16f")
addappid(562362, 1, "94d4db00277ba51a56982c682f7fbaf4b8e8d26ec4c5e0cf646c3740be5c3362")
addappid(577020, 0, "53e209fb393de4a413d5c70b1bf4878c3c920aaf0ae6a14118f6094ba6863468")
