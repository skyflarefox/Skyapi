-- Lua provided by SkyAPI 
-- Game: AppID 924750
addappid(924750)
addappid(924751, 1, "359880727545a3c0e5860966d978f6abd66b895cfa201b4038426894a3f0616f")
