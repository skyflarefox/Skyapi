-- Lua provided by SkyAPI 
-- Game: Escape Floor Zero
addappid(2760600)
addappid(2760601, 1, "2b53aba9f4ea2ce6c51e142f0d183ad2cfad67cc22b1db5a4f67b3fa6797d974")
