-- Lua provided by SkyAPI 
-- Game: AppID 568070
addappid(568070)
addappid(568071, 1, "484ef4f1fceeccb04686b089413c2ab28343d9013ea0ed3bf9fd03e25e3c0191")
