-- Lua provided by SkyAPI 
-- Game: Lust Galaxy 🪐 🔞
addappid(3073370)
addappid(3073371, 1, "f144b0b2031ae79fb5959f8c86d35dba74ae77d796a9cc2d0b588158dfde3bbb")
