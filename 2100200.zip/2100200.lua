-- Lua provided by SkyAPI 
-- Game: Idle Zombies Clicker
addappid(2100200)
addappid(2100201, 1, "52cde4d8a4a2abe84ce16eeaf266b774e0d20425cfab197d978565b872e8c6d6")
