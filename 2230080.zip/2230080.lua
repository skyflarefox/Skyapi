-- Lua provided by SkyAPI 
-- Game: AppID 2230080
addappid(2230080)
addappid(2230081, 1, "ffa9a93f4f294990192c0084c192954430a485dd415d23fdba6bcd3de4f53cb2")
