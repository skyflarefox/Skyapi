-- Lua provided by SkyAPI 
-- Game: AppID 283330
addappid(283330)
addappid(283331, 1, "28c64897fda8cb0e156f21c683e18777d649a768d78d34fc168663013cc83a09")
