-- Lua provided by SkyAPI 
-- Game: Ring of Pain
addappid(998740)
addappid(998741, 1, "3d93e1b7aa260a0821a5fe689926f87387ed2742e5dfa4ad7a6fc01b52019a9b")
