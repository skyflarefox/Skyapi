-- Lua provided by SkyAPI 
-- Game: Unstoppable Gorg
addappid(18120)
addappid(18121, 1, "08366eb616de551149002ede78471fb96ee03bda61a96405fa2a719986039629")
addappid(18122, 1, "17e87d9934005b83a3a271c6460afe1b6236e2178ae26481ded25b130a60c409")
