-- Lua provided by SkyAPI 
-- Game: The Other Half
addappid(917920)
addappid(917921, 1, "55241f70ed9c06087771b7563f145b192e49dde01dc1024209d1be66d6a3d9ae")
addappid(917922, 1, "5d0269baed5cefebca5744f03d5c6fb5032a9eac42835a0e22f24fd6c43039e1")
addappid(917923, 1, "e6f9ad273f51b70ea47dfee5b4de5d6c465f471fafbf2e02eae1ae1ea112de90")
addappid(976650)
