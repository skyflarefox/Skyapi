-- Lua provided by SkyAPI 
-- Game: Flipper Frenzy
addappid(3305770)
addappid(3305771, 1, "afd311e4972d48ff3a65f7af20c00f6a603f596400f67c792723937e325ff0b8")
