-- Lua provided by SkyAPI 
-- Game: Evan's Remains
addappid(1110050)
addappid(1110051, 1, "e01360fdc6a038042ded8b24cb6ebbd7ab474ad3b414b60e078cca46128f7f93")
addappid(1110052, 1, "871c10832f2cb12b86d8e5e872efce5007128756b849891385d641305753e379")
