-- Lua provided by SkyAPI 
-- Game: Paper Bride 3 Unresolved Love
addappid(1939790)
addappid(1939791, 1, "7de0aae77c62ef479e8b577947fc7456f4463c385e974d8a3f5ea9bb933580a4")
addappid(2144700, 0, "212ee8551f9ba98b74155ccd2bb6648a1c8fcd454650eecede6a9862e4003b23")
addappid(2144710, 0, "e16400d3b44b76110b075670d0520d1895064a22a6f2e299dcef6136f46ad13a")
