-- Lua provided by SkyAPI 
-- Game: Crash Drive 3
addappid(346820)
addappid(346821, 1, "a0e81db4dfb4e5e0e573528d581d4e20edb52a953a2764ca98a1a5412cf1d681")
addappid(346822, 1, "a9487bf19e70dbf45eb99ea49fd6e9fd94a4787a55a51e970766901d9abf145d")
addappid(346823, 1, "68936c99af15b0ff5537fcd0b74d698e8fbca6acc4981ce6073770c3f6bd1108")
