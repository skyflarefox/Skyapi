-- Lua provided by SkyAPI 
-- Game: Streetoir
addappid(2639980)
addappid(2639981, 1, "c65753b357d9dd047c8cf613660d55c1a11a614ad0093e758ec9d6c519338ff0")
