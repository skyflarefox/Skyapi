-- Lua provided by SkyAPI 
-- Game: The Boba Teashop
addappid(3461920)
addappid(3461921, 1, "be49622c16cf04591bbdb523169e72248065c5fb1da12c4868c780e4dd8e131b")
