-- Lua provided by SkyAPI 
-- Game: AppID 797400
addappid(797400)
addappid(797401, 1, "8ceaa95b6b38e4c1e7bbd01fdaacd757e44d43b25f66af6f828ff510b2d6532b")
addappid(1192650, 0, "b13819d702599c3b1ae4c59c4c2e13e36502f20436e352e24713e17043ce3cec")
