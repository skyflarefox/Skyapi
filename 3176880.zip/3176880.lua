-- Lua provided by SkyAPI 
-- Game: Let's play Cards Solitaire
addappid(3176880)
addappid(3176881, 1, "04458ab8eb9fb8b11f2c8b7721848b25c0ca805d785dc930d61c06a90e57b57b")
