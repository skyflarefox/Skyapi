-- Lua provided by SkyAPI 
-- Game: Frip and Froop's Logical Labyrinth DX
addappid(2499740)
addappid(2499741, 1, "b1e63a87a0d58df3e2757b459e166dc8f3a5bdb29d9a09783e2e315c27f67cd8")
