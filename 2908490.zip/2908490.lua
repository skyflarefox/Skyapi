-- Lua provided by SkyAPI 
-- Game: FORGE SIMULATOR
addappid(2908490)
addappid(2908491, 1, "3feb9e2e70e9b1704477eab764cbc25af7a70ca23143f0f0940403b208577ba8")
