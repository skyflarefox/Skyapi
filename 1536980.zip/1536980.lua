-- Lua provided by SkyAPI 
-- Game: Glass Masquerade 3: Honeylines
addappid(1536980)
addappid(1536981, 1, "79d44fbaab425191d7d4dae87062773e4021c88156b2bd41d6c2e3c6d750458e")
