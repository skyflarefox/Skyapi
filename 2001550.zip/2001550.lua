-- Lua provided by SkyAPI 
-- Game: Spirittea Demo
addappid(2001550)
addappid(2001551, 1, "f726e44b3ca7193516cecb79a7d5b590f9d56dd6fef1d271ce6530552ec16a45")
