-- Lua provided by SkyAPI 
-- Game: ♞ The Tactics of War ♞
addappid(937780)
addappid(937781, 1, "84b8ea0b643aeb1fb7e1044498d10c4886754a01f13ad62aeb64c73051a72a3c")
