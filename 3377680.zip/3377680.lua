-- Lua provided by SkyAPI 
-- Game: Atonement
addappid(3377680)
addappid(3377681, 1, "f624665fd47fdeb6c06977ec7feda4004b311a2b342be403d476d6d2f4e13498")
