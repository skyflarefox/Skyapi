-- Lua provided by SkyAPI 
-- Game: Underminer
addappid(2735870)
addappid(2735871, 1, "c2eee8e9da2baf286a5cad2beef939bfe8f512b604306be1e54a3a9efad492bb")
