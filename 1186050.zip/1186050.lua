-- Lua provided by SkyAPI 
-- Game: AppID 1186050
addappid(1186050)
addappid(1186051, 1, "9d671d25c325174ba5082c7a0df21f2d05a7aebde47b8f9edda79d7217ea1fbf")
