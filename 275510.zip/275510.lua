-- Lua provided by SkyAPI 
-- Game: AppID 275510
addappid(275510)
addappid(275511, 1, "af48820ac14f05b81096b95899d691d7a62603ac6dad7268039d67792c3e3912")
