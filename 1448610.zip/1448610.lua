-- Lua provided by SkyAPI 
-- Game: NIRO
addappid(1448610)
addappid(1448611, 1, "276be4ec19b60090beea9ea2eb387d5a70adb99d220be49de2dfe6af814d512e")
