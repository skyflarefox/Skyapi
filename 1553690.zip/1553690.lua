-- Lua provided by SkyAPI 
-- Game: How does it work!?
addappid(1553690)
addappid(1553691, 1, "430d33722ce7952d1cff3f0c7cf7c9ea81771c2549c8e0cc146307d78d4d4a1c")
