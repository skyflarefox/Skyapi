-- Lua provided by SkyAPI 
-- Game: Cardeneer
addappid(2307260)
addappid(2307261, 1, "6c5b5180afd66c09d08ce1c523d9c48976140b969dd9d3a4f264affb461f539d")
addappid(2600940)
