-- Lua provided by SkyAPI 
-- Game: Ghostist
addappid(1552760)
addappid(1552761, 1, "2f4e3307147fe791927f30556ef363097dff4d56d72d8adc1b23fb8c1282e15f")
