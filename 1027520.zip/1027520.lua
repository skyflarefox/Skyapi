-- Lua provided by SkyAPI 
-- Game: Hentai Waifu Vol.1
addappid(1027520)
addappid(1027521, 1, "c5950ca705cc953af9085daf9fe4e87f9741dc59b35cd28afa0ef27b330422e1")
addappid(1036770, 0, "35b9abb1dfe83c441479d2d1bbd3c15e66407c45ccb6243c36c6bac2dfe55b77")
addappid(1036771, 0, "ff2e09b019eb9e83895f459787277623fd6438aa879dc5e65c7b39ed5f2c9dde")
