-- Lua provided by SkyAPI 
-- Game: AppID 619310
addappid(619310)
addappid(619311, 1, "5a309ef4154a266b6b2f0495f0863e37da9278b0b70fb4a1fb97b016405f21a1")
