-- Lua provided by SkyAPI 
-- Game: JEF
addappid(1188760)
addappid(1188761, 1, "81065d05cbf7f132456f9541b4ff1b89bfc12e15b942726a1173fd20d08f2817")
