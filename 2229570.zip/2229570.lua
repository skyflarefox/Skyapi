-- Lua provided by SkyAPI 
-- Game: AppID 2229570
addappid(2229570)
addappid(2229571, 1, "a66c621de508834ec995e7409feed3001cf57f7d6e31b74075408236e865ee19")
