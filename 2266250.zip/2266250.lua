-- Lua provided by SkyAPI 
-- Game: AppID 2266250
addappid(2266250)
addappid(2266251, 1, "90f44907ac903750542896e03ff15ddc24aef4af6e9bcc22de5b6a4064f2d9f9")
