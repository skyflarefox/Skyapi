-- Lua provided by SkyAPI 
-- Game: Warriors Of Titus - F2P
addappid(1513740)
addappid(1513741, 1, "95066f62434335e852ed8dfdf7474ea75afb410244160507ce7ec45aaa0539a8")
