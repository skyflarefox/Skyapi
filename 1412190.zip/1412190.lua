-- Lua provided by SkyAPI 
-- Game: BEACHED
addappid(1412190)
addappid(1412191, 1, "da0b4719a1aa78f03cb7398087b28a4698ded296de9e89f4f38149aceed5b4de")
