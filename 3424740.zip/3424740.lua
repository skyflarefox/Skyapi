-- Lua provided by SkyAPI 
-- Game: Firework War
addappid(3424740)
addappid(3424741, 1, "013638a60d0bcf7c1ca3379f8fdc23dea7a4a484d359ec2d4be704023e68daeb")
addappid(3466780)
