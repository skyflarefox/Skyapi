-- Lua provided by SkyAPI 
-- Game: AppID 1353950
addappid(1353950)
addappid(1353951, 1, "be1cf95ea0dbe40357a1ec0ef4c90f51c97942633c1953d0557c3a0d60ffd994")
addappid(1353952, 1, "32781b875f5055aafd5c7c463f02b182467671ac7dec69f648177d57f4ef432a")
