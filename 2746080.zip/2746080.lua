-- Lua provided by SkyAPI 
-- Game: AppID 2746080
addappid(2746080)
addappid(2746081, 1, "7d2771daad794485bd58ea9ee4fb8d6425825bead3fde569271c1290be560fcd")
