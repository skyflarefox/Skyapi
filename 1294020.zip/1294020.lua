-- Lua provided by SkyAPI 
-- Game: Space Mercenary Shooter : Episode 2
addappid(1294020)
addappid(1294021, 1, "6fea00951e686950179c797e1da8d1b3353c63e0b79c6fd91a5b44adb8e79ca1")
