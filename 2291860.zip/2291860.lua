-- Lua provided by SkyAPI 
-- Game: Moonlight Pulse Demo
addappid(2291860)
addappid(2291861, 1, "7981d392ae74911cac67aef9603eb1103aff6b4c71f15c7355959af7b9a0669f")
