-- Lua provided by SkyAPI 
-- Game: AppID 3160750
addappid(3160750)
addappid(3160751, 1, "799712c4e602be888a8b6d54ac31e855f95c327da0c06ded4b8bb77da06cc727")
