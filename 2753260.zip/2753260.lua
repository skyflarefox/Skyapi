-- Lua provided by SkyAPI 
-- Game: Voyeur Villa - Harem Manager
addappid(2753260)
addappid(2753261, 1, "0d36166c538c77da617a7706fa2a7e95e7ab2a74559ec5574df17f750f98cf6a")
