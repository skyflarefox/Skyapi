-- Lua provided by SkyAPI 
-- Game: AppID 1159290
addappid(1159290)
addappid(1159291, 1, "76e3cc8dd03421623d2c8f64513c49d675e0eea185c1bf6795bf9263c8f93535")
