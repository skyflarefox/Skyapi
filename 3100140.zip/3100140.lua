-- Lua provided by SkyAPI 
-- Game: AppID 3100140
addappid(3100140)
addappid(3100141, 1, "1f9d18ed72dc45ef49997c701e605372bc4f7728d3bab76328077de133346bae")
