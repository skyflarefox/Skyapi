-- Lua provided by SkyAPI 
-- Game: Nexagon: Deathmatch
addappid(1329810)
addappid(1329811, 1, "75ea8a79b67a9eea89ccad807589ed0ee64b7890cae20cd1d759bda91d7ee2ef")
