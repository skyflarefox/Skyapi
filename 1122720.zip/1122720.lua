-- Lua provided by SkyAPI 
-- Game: Sayonara Wild Hearts
addappid(1122720)
addappid(1122721, 1, "ddec2e074f84dd8a0ae6a7e28b59e730bec7b9bbebe6ada7d16d8e58d979c11c")
