-- Lua provided by SkyAPI 
-- Game: Wild Dogs
addappid(1752060)
addappid(1752061, 1, "68880fb4aae249aa6d4a77f67a4c199c96a0099a48fc4850d163b66f08df8c17")
