-- Lua provided by SkyAPI 
-- Game: New Gundam Breaker
addappid(738530)
addappid(738531, 1, "280c135e5a7484d58e9ae159cd748af9e5d1e858346bf15a0b968d0a7a3b58a5")
addappid(874321, 0, "dcc4dce00d21f701c8a02b487c43d770473d0631e1a96294ce740d04a0f2b370")
