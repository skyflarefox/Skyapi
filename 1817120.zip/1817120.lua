-- Lua provided by SkyAPI 
-- Game: Combat Troops VR
addappid(1817120)
addappid(1817121, 1, "14175d23fb5038c691e05ced71725059587243125c2acf353728a9f0a2ac8463")
