-- Lua provided by SkyAPI 
-- Game: Beastiarium
addappid(545150)
addappid(545151, 1, "e452a66e5f98b3d9871d1702e6df284f23d48116cb35b2aa0a334f0abfb6e122")
