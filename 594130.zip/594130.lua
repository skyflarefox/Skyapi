-- Lua provided by SkyAPI 
-- Game: AppID 594130
addappid(594130)
addappid(594131, 1, "c82c530f08fd0be11082d47e0f7295b8083a6273eea87b720d15b0059f8dcacb")
