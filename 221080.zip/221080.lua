-- Lua provided by SkyAPI 
-- Game: AppID 221080
addappid(221080)
addappid(221081, 1, "0e0c3e12e69cec3d28c16e1570344c6f68b8d79e67c82027fac1fb6982fb33cd")
