-- Lua provided by SkyAPI 
-- Game: In Sink Demo
addappid(2009810)
addappid(2009811, 1, "216319f15a2cc4747fd3eea1ab6b1f2a08546b46b1977ee086b344615d708b3f")
