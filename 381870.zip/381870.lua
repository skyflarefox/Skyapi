-- Lua provided by SkyAPI 
-- Game: Koala Kids
addappid(381870)
addappid(381871, 1, "e267195aa7153d57bc8c2f591b3da2d1732cf515bbcb58e856644841563b7da8")
