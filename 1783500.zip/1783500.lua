-- Lua provided by SkyAPI 
-- Game: DaVinCo
addappid(1783500)
addappid(1783501, 1, "3c9544503213796f11a1ff76c4c5cafbd51c7a5f95b2739f29d45532e96a4319")
