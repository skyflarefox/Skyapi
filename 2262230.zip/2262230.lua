-- Lua provided by SkyAPI 
-- Game: Bargain Toader
addappid(2262230)
addappid(2262231, 1, "127b03b64c18b94e15c31f625289ea364451b7168c513468e05e870f6aa25244")
