-- Lua provided by SkyAPI 
-- Game: Bloons Card Storm
addappid(2876550)
addappid(2876551, 1, "7cf0a60ce56e6ecb737f6b56521db63d4b96beefe8272bf52170647f7eaf42fb")
