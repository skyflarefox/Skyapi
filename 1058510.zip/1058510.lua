-- Lua provided by SkyAPI 
-- Game: AppID 1058510
addappid(1058510)
addappid(1058511, 1, "72921e265aa8a53df9e871a489ad954b1dcedbe3f0a0b3e0fc157a81a204aea9")
