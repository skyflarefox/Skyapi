-- Lua provided by SkyAPI 
-- Game: Dog Man: Mission Impawsible Demo
addappid(3118020)
addappid(3118021, 1, "167c32874056d33e7092d42b4fa532e389a0c131731e739b1a8ccfe225a5f2b5")
