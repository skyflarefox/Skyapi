-- Lua provided by SkyAPI 
-- Game: AppID 572730
addappid(572730)
addappid(572731, 1, "c9a69a388a75131dca4cd70c27315f95a1eba94378f185a0bbbc6d334d070317")
