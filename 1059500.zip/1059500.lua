-- Lua provided by SkyAPI 
-- Game: PUZZLE: OCEAN
addappid(1059500)
addappid(1059501, 1, "9e91886921c32dc7acbc87fdd39c1ffacd8a51f54ac53774a0ab34e2b50c7bb4")
addappid(1108530)
