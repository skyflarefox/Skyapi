-- Lua provided by SkyAPI 
-- Game: Street Legal Racing: Redline v2.3.1
addappid(497180)
addappid(497181, 1, "ceb30eb975ede265200a888dd305c54baf42d6e273df05c51934f65ee75d3206")
addappid(513500, 0, "906cd0846a0a94ee8145811be685e638b21ccd227cfc06d7302efafc81bb636a")
