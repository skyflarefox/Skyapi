-- Lua provided by SkyAPI 
-- Game: D.N.A: Do Not Answer
addappid(3043290)
addappid(3043291, 1, "c0c41280259a3854d7185925f331a6fa040951e639c007659b05d1b972d9d429")
