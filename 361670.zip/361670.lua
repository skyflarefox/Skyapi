-- Lua provided by SkyAPI 
-- Game: AppID 361670
addappid(361670)
addappid(361671, 1, "4c55d4e0ed1c0a9d2e872cd0175cbedef581d3465d65737dd234319fe863790b")
