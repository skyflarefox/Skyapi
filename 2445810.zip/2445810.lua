-- Lua provided by SkyAPI 
-- Game: Decarnation Soundtrack - Cauchemar
addappid(2445810)
addappid(2445811, 1, "992684896eb0a071d40f8ad30ed55a170f99dbd289336e19669a7508e3daf744")
