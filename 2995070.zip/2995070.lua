-- Lua provided by SkyAPI 
-- Game: Liminal Void Demo
addappid(2995070)
addappid(2995071, 1, "1b8326bd2ac352ab47e94fb3297739976f54908dfb76cf504f1f66e5b12b940d")
