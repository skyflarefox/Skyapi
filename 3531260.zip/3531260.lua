-- Lua provided by SkyAPI 
-- Game: Superhero Simulator
addappid(3531260)
addappid(3531261, 1, "6cf09b48c7c2655fbd5292a138ecf7905fc1316e5f4c3a5c3a4beff3458a97e6")
