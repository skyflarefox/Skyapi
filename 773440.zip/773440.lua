-- Lua provided by SkyAPI 
-- Game: Primal Pursuit
addappid(773440)
addappid(773441, 1, "3e1ef28b0e7848c8e2f5f235d11e9c50e4ce645814591fae35e3850587eb7f07")
