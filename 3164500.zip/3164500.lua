-- Lua provided by SkyAPI 
-- Game: Schedule I
addappid(3164500)
addappid(3164501, 1, "81d0de07788de885787b0519b9dabf51618be6cba9124497decf572ac96624f4")
