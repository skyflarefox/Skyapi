-- Lua provided by SkyAPI 
-- Game: AppID 663000
addappid(663000)
addappid(663001, 1, "d3fdfe4bee847952e88552d47fb1b1ee904ebf4e9f2493fe0a581eca6497a04b")
