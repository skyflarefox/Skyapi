-- Lua provided by SkyAPI 
-- Game: AppID 632080
addappid(632080)
addappid(632081, 1, "9ff12774115808f49f9b5c4c957c131abbca36b00efa3bb16f9073ff5afec5b2")
