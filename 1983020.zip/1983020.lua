-- Lua provided by SkyAPI 
-- Game: Caterpillar
addappid(1983020)
addappid(1983021, 1, "edebd2224f6464aed24a7db90bf7e410dfe698aea3dd4ef7fb45e521bde8e73b")
