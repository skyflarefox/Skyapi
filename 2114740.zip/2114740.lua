-- Lua provided by SkyAPI 
-- Game: Blasphemous 2
addappid(2114740)
addappid(2114741, 1, "bfa23044329db73bff7359d046baad4e5d546333e7c34042a0065de17eb5350e")
addappid(2500160, 0, "503b5732abefe07001d4c001350558da4747a61c52562da4882858a9e2be2235")
addappid(2879370)
