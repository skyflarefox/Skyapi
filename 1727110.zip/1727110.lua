-- Lua provided by SkyAPI 
-- Game: March! March! Demo
addappid(1727110)
addappid(1727111, 1, "0c63dcb6cd155983ed73b1d7af6a4d91c8e216102f9f776eea0bad430dee63f6")
