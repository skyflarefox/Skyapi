-- Lua provided by SkyAPI 
-- Game: AppID 1090760
addappid(1090760)
addappid(1090761, 1, "6f8986130f228bd276577c6bae3d2fa677971fd31b3d06ed352a51fb4e677603")
