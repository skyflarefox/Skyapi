-- Lua provided by SkyAPI 
-- Game: AppID 1257880
addappid(1257880)
addappid(1257881, 1, "28a745d0c093593823fb0d816037f782a214ac3539db3a91fd7050d184a1122e")
