-- Lua provided by SkyAPI 
-- Game: AppID 1113730
addappid(1113730)
addappid(1113731, 1, "4e0c722310e8d101e8f81f543baca587135af7822f87c23cddf313e2fe793f7b")
