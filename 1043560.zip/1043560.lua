-- Lua provided by SkyAPI 
-- Game: Static
addappid(1043560)
addappid(1043561, 1, "290c730b76c318e1a491d5cc4aec58c216b489d351317b918a0960941648b1ac")
