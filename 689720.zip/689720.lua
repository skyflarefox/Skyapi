-- Lua provided by SkyAPI 
-- Game: Gangsta Underground : The Poker
addappid(689720)
addappid(689721, 1, "f17e5c9f4261a4e9608cb7b9381da5935252289fb2f6d72f1d82a937846b7a71")
