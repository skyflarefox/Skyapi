-- Lua provided by SkyAPI 
-- Game: LocoMotion
addappid(2123510)
addappid(2123511, 1, "76b110102e36d45a0d5b10611062c36226644959148bdacd2394da447b02dd36")
