-- Lua provided by SkyAPI 
-- Game: Infected City
addappid(1640670)
addappid(1640671, 1, "80e970d4a3178d0323c6c68f45c683a6dba37e2ce3da8672ae4dda2ffe5c3c0d")
