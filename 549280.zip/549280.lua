-- Lua provided by SkyAPI 
-- Game: AppID 549280
addappid(549280)
addappid(549281, 1, "484357e5c51e9a4e5905eadd5f88c0fafc3885f02dd6f2987cdc6be14562b3c2")
