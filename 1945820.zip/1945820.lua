-- Lua provided by SkyAPI 
-- Game: Boxel Golf
addappid(1945820)
addappid(1945821, 1, "b9f00a8ca3a7817978506153fef08922c0a881e80fd1e4b27672245f29d2eae2")
