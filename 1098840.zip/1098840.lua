-- Lua provided by SkyAPI 
-- Game: AppID 1098840
addappid(1098840)
addappid(1098841, 1, "12214f0979c7e04813af92293b722d9f5efe2a422b4e3aa36f969d0f36774fc6")
