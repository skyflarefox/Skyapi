-- Lua provided by SkyAPI 
-- Game: AppID 336060
addappid(336060)
addappid(336061, 1, "1cd4d39fda66c2aad61218e6b59582266387da6476a850644536baa098f4ded9")
