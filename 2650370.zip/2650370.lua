-- Lua provided by SkyAPI 
-- Game: Jennifer's Fragments Demo
addappid(2650370)
addappid(2650371, 1, "aa0344814b220b79b672a1f748403eef6140fb14f73c0dd26ddf4eac0e678f12")
