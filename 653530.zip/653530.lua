-- Lua provided by SkyAPI 
-- Game: AppID 653530
addappid(653530)
addappid(653531, 1, "c0c40a798956920fb98fa28013e11b2c58d66ad661f094ba33565bb6a26b5b3a")
addappid(653532, 1, "d835bbd2433114e69479e195e3e09e273753198b49ea9d53aa31fbd5ab7c7b04")
