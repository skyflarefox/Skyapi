-- Lua provided by SkyAPI 
-- Game: Bully: Scholarship Edition
addappid(12200)
addappid(12201, 1, "b02e549a49b9318ee8352042cb5cfe08a4d103eb6a7a3526c27e4e6ec86ed57b")
