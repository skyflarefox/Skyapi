-- Lua provided by SkyAPI 
-- Game: AppID 928410
addappid(928410)
addappid(928411, 1, "d0fe9dbdefd31ea973bb1d477a4b13f4c80ca24751291028147e67fbcda998a9")
