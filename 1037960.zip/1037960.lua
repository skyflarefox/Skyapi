-- Lua provided by SkyAPI 
-- Game: Grand Dude Simulator
addappid(1037960)
addappid(1037961, 1, "58711b4084548280b689693ce7631698e4be9e73c3719d64be7b600007e77445")
