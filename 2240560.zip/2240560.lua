-- Lua provided by SkyAPI 
-- Game: Holstin Playtest
addappid(2240560)
addappid(2240561, 1, "61cd35e9e0891f7234eb6486df34c5cd25f011ea3329da4d2f6ce36a71554203")
