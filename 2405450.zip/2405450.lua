-- Lua provided by SkyAPI 
-- Game: When Night Comes
addappid(2405450)
addappid(2405451, 1, "a18cda454fe9b703823069149ed8906b5a62d991efc9d5cd9c51cc92bf8dd03e")
