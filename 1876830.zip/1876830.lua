-- Lua provided by SkyAPI 
-- Game: Life after Death
addappid(1876830)
addappid(1876831, 1, "bb68305990a2d5f37a6a24baa01b24fc24d3e5c4c0cd5b8e87814144eafa1930")
