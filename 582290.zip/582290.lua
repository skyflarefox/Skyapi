-- Lua provided by SkyAPI 
-- Game: Rest House
addappid(582290)
addappid(582291, 1, "aa14b4d68f8e289f780ca758b739c6f83ac0db820ebcbbf72c7b6c67287970b0")
addappid(737790, 0, "fed826cb44a175c388883cc36fda12b446e25276c70faee361d440d687fd0298")
