-- Lua provided by SkyAPI 
-- Game: Biomydra
addappid(542870)
addappid(542871, 1, "5988eba0a175582c54a445e16a52c1a5d2e490e881d1b549249f672dd37259e8")
