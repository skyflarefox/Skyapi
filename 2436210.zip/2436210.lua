-- Lua provided by SkyAPI 
-- Game: AmazeVR Concerts
addappid(2436210)
addappid(2436211, 1, "7783e42b3ccf94af92391706091b780141fe653626fdba0d40e1f1f5b70d6701")
