-- Lua provided by SkyAPI 
-- Game: AppID 704580
addappid(704580)
addappid(704581, 1, "0a6bded3184fac94ccde352bdf632040f7c6a0d531fbfef83375d9bd6629fca3")
