-- Lua provided by SkyAPI 
-- Game: AppID 457370
addappid(457370)
addappid(457371, 1, "cda18302486bbf3d21fa0f5c122dbc1c7ba24856cd5e3232a6f9b7ed72cc87cf")
