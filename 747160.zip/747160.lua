-- Lua provided by SkyAPI 
-- Game: BAPTISM
addappid(747160)
addappid(747161, 1, "b9e4774214776e408836b6d2a96aa9c5411b8bb80eaa490e20d55ec24c8d71c1")
