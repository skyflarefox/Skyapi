-- Lua provided by SkyAPI 
-- Game: TimeMelters - Challenges
addappid(2058240)
addappid(2058241, 1, "7c6b06592fafb147a806aabf0871a76a62de8532e918bbc74583916391395209")
