-- Lua provided by SkyAPI 
-- Game: AppID 572740
addappid(572740)
addappid(572741, 1, "6e623ec6983106146ac387afe926c6ba5c518a4ccfcc8597db9d66346309f3a4")
