-- Lua provided by SkyAPI 
-- Game: 月夜赞歌 Melody in the moonlight
addappid(1874780)
addappid(1874781, 1, "44c63a1df9edd1b712d008126908d994cc48a4b9b0b2be5a1963d5d29696af6f")
