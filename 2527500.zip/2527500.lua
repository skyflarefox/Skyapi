-- Lua provided by SkyAPI 
-- Game: AppID 2527500
addappid(2527500)
addappid(2527501, 1, "ffef2d1f42cd2438f5b7d029d771a9f941fd224250c3184f595773fb4926e1cd")
