-- Lua provided by SkyAPI 
-- Game: Driver4VR
addappid(1366950)
addappid(1366951, 1, "80d8ed60372562417003680d8dead18e48da889f884e42df6a048b6aeb6baf56")
addappid(1529611)
addappid(2928420, 0, "a9a3a29e85e0e9ab9adc64c7e1f9f298f485b992c0359d5e56393c084c4b0452")
