-- Lua provided by SkyAPI 
-- Game: AppID 2387450
addappid(2387450)
addappid(2387451, 1, "880a7b8957a34f9e6c8565e880226c3a0264d70b72b57d4afda23f4ec9503fc0")
