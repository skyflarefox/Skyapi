-- Lua provided by SkyAPI 
-- Game: KarmaZoo Demo
addappid(2312680)
addappid(2312681, 1, "6633d9204d26ff8aa510a87685b921389afed002ba5833ba773b29b987957ab2")
