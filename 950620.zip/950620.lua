-- Lua provided by SkyAPI 
-- Game: AppID 950620
addappid(950620)
addappid(950621, 1, "f0a967c2d200e58f94b1dc142e07f6c93ca43ca1ff93802cbd015b9005df0717")
