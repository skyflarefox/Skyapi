-- Lua provided by SkyAPI 
-- Game: Phantom Patrol Demo
addappid(3272340)
addappid(3272341, 1, "db0a83e5af3121c6d70bb591725f36935f99582647d7bbe69e60b63db549fe31")
