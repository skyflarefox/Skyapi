-- Lua provided by SkyAPI 
-- Game: No Lights
addappid(682910)
addappid(682911, 1, "bd8c1cf9940096695323c88e8e699f55d548990ad7540258ad734cebf0e96547")
