-- Lua provided by SkyAPI 
-- Game: One Hunt
addappid(894330)
addappid(894331, 1, "0af32bc0cc1103011a961e6bd30e37f8db89ba2eb3f0e30511d61203af1019b3")
