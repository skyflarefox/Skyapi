-- Lua provided by SkyAPI 
-- Game: 創業王 CEO
addappid(2269460)
addappid(2269461, 1, "7259b82704dab129d55a1f39360e7a3c8d2fc43d853d6bb521ce97d647910878")
