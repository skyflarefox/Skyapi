-- Lua provided by SkyAPI 
-- Game: Victory Road
addappid(1002430)
addappid(1002431, 1, "f3c501ffa3812f25dbe49fae69612e11b06dcf978d094740e5f6452049685327")
