-- Lua provided by SkyAPI 
-- Game: Just Skill Shooter 4
addappid(2999790)
addappid(2999791, 1, "74309f5166ce0ba7de4f8f43704c41868becfeca5c9b4176479831b849a999b9")
