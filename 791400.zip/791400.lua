-- Lua provided by SkyAPI 
-- Game: From Village to Empire
addappid(791400)
addappid(791401, 1, "39c94e992a5af63a7f0f8ac9d29244798eff4588dd96fe053397da28f0457420")
addappid(791402, 1, "03493b71ec6799eecefa26f5d148581e0fe889d2e4cb7ae6ee6c75d7d195acaf")
addappid(791403, 1, "a1ab7a647b992fb25ec3bd10496f562c90fd34bc92b74547e2ebfdc21b36a171")
addappid(791404, 1, "5f704bddc2bda2918df4fc6a5127ff845bab11573b1777b31aa2c46896bf2f30")
