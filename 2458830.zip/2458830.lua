-- Lua provided by SkyAPI 
-- Game: Towerborne
addappid(2458830)
addappid(2458831, 1, "2568fc72975f6f7f70842960f59dc2c606ef7c24c2babaed575f688b24bfd26e")
addappid(4174300)
