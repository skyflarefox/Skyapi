-- Lua provided by SkyAPI 
-- Game: Daydream: Forgotten Sorrow Soundtrack
addappid(2423750)
addappid(2423751, 1, "94506a95a9c52a1502b8712f526dc36eccf299bd88ad546ac65af4d491a50519")
