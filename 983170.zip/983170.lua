-- Lua provided by SkyAPI 
-- Game: Infinite Chili Sauce  无尽的辣酱
addappid(983170)
addappid(983171, 1, "342b781c89b494d63af79000cff4f125b8de34e5cec0a1d7e1504b3ca7f202c8")
