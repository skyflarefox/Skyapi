-- Lua provided by SkyAPI 
-- Game: Lucky Night VR
addappid(753060)
addappid(753061, 1, "2c8d200ebbf16fabb37d915977ab7043abd14f631e1e4abae817c8b0030efb82")
