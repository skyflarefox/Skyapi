-- Lua provided by SkyAPI 
-- Game: Fuga: Melodies of Steel (Manga) Vol. 1
addappid(3132540)
addappid(3132541, 1, "cd3e495999f321353088138a8cf9e06764182c642ce8ad1bc3036e2c9e99cc40")
