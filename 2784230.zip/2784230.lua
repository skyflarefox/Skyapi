-- Lua provided by SkyAPI 
-- Game: mischievous
addappid(2784230)
addappid(2784231, 1, "be48273a5687c863d00f8c2d3965b8ce55dff9648fce043510f3bba1b7fde0d9")
