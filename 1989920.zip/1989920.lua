-- Lua provided by SkyAPI 
-- Game: 白娘子
addappid(1989920)
addappid(1989921, 1, "6d6f62dbd1e0b5d971ebdb4463f2675c4bd9e7bebcd1777389701395c6052bc9")
