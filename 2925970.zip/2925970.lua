-- Lua provided by SkyAPI 
-- Game: The Unholy Priest
addappid(2925970)
addappid(2925971, 1, "2516af666d3a9476d2bd66de2549e8549633b1051f2c6bac4dca318725e1b622")
