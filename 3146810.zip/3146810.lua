-- Lua provided by SkyAPI 
-- Game: Look Closer! Demo
addappid(3146810)
addappid(3146811, 1, "44e27e67bdfa19bf37d0b564efdcf8b8769e9f78f40592c9a468eac564f701cd")
