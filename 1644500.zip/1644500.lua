-- Lua provided by SkyAPI 
-- Game: Masterplan Tycoon
addappid(1644500)
addappid(1644501, 1, "0d31ee13f45f3b293549a0ed9ad1733dba3d4b76d9b3e4e5a1639a16dc7693fa")
