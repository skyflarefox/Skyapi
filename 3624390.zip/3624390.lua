-- Lua provided by SkyAPI 
-- Game: Mordeny
addappid(3624390)
addappid(3624391, 1, "59beea265007f3bdb66861fd5e6675e371fc801e527c5c0804aeb66b62a43ad9")
