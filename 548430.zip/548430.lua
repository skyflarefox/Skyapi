-- Lua provided by SkyAPI 
-- Game: Deep Rock Galactic
addappid(548430)
addappid(548431, 1, "73ef10dc344cb7fb34be23aea35b20fbb2b32b0db50650919c7e3d731e759aad")
