-- Lua provided by SkyAPI 
-- Game: Bubble Ghost Remake Soundtrack
addappid(3698950)
addappid(3698951, 1, "c87d10122864c1754a6b4de2cc7a64a392de75cadf72c1e81e89fa29a4c23b18")
