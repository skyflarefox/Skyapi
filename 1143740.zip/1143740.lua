-- Lua provided by SkyAPI 
-- Game: AppID 1143740
addappid(1143740)
addappid(1143741, 1, "d18f1deea4e335dc0ec66b6343d5680c4295dd26ea5596bdca3f9846f50d6271")
