-- Lua provided by SkyAPI 
-- Game: STAaRS
addappid(3186340)
addappid(3186341, 1, "6223be8bd744a8b1bc5b67796dbe7fe2017600cf25545c33742563354b8dae77")
