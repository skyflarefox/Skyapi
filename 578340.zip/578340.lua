-- Lua provided by SkyAPI 
-- Game: Earthfall Soundtrack
addappid(578340)
addappid(578341, 1, "f6f16cfea92c1ba9f375b5a5812332c5c2a31000956e17079663976668263480")
