-- Lua provided by SkyAPI 
-- Game: Dino Trauma
addappid(2149420)
addappid(2149421, 1, "d627bf4dc51c12a79e13020be93e409a4e086a755f43bd26d097a87a2d8fb0e5")
