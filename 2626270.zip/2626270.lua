-- Lua provided by SkyAPI 
-- Game: AppID 2626270
addappid(2626270)
addappid(2626271, 1, "3d736257b04988d0a025549adb7ef33f828e1722b1ed4ac3f6efc03398136d16")
