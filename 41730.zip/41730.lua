-- Lua provided by SkyAPI 
-- Game: Ion Assault
addappid(41730)
addappid(41731, 1, "895fcf12fa93ea0bc2dce5ba443f6018f5263975518af58159e3065eb8fd9e7c")
