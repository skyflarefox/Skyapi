-- Lua provided by SkyAPI 
-- Game: Cursed Feed
addappid(3405400)
addappid(3405401, 1, "6d1a9f5e2206b15156373eab150728b7fca3a48210638568b8a81da16265b532")
