-- Lua provided by SkyAPI 
-- Game: HoPiKo
addappid(437390)
addappid(437391, 1, "2ba535e4f5c048d1985854852190a9942fd0e88820c22ae541b7647dc1fdfca1")
addappid(437392, 1, "0963f63d56c76d835f7f0c30211135aff8edff4822383273e2e0c3b855ed61ba")
addappid(437393, 1, "365d7f64fbae5acc7cbf00049036f325d5fc90548ed4f5deaa9353bd734cf45a")
addappid(520650)
