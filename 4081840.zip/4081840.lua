-- Lua provided by SkyAPI 
-- Game: Escape from Yandere
addappid(4081840)
addappid(4081841, 1, "d7484400be27a04b6ecee36e7cedb34112d26303e4f9778b8a331a0283c8f8c9")
