-- Lua provided by SkyAPI 
-- Game: Neon Inferno Demo
addappid(3509220)
addappid(3509221, 1, "7f09ff787aa0deb5f32e3ac952bdae91a94a2efe169d377bd99f62beefb08c62")
