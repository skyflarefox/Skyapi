-- Lua provided by SkyAPI 
-- Game: Blacksea Odyssey
addappid(369550)
addappid(369551, 1, "015476d31134e81af860a5512a5038a71e5010e0593e93b66b119462adcd22c8")
addappid(369552, 1, "9baac3848d79149d2034472d26171fe883feefd2106c464b9b828b36e7e0902f")
addappid(369553, 1, "408f7fe4af390b1266422b754cbb8c5142f8c922fa78f9209abed8ee6be35f81")
addappid(445660)
addappid(445661)
