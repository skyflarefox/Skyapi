-- Lua provided by SkyAPI 
-- Game: Slice & Dice
addappid(1775490)
addappid(1775491, 1, "28d97678dce1e4792d1d37f29e42d777a0b5ec6b8bbf6ec8357f69cb8688165a")
