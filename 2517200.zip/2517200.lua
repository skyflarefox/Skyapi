-- Lua provided by SkyAPI 
-- Game: Repair this!
addappid(2517200)
addappid(2517201, 1, "ac62a5ddd2d13540516cf4dc9a66b99b829b1a096e33312855c741699c2841fd")
