-- Lua provided by SkyAPI 
-- Game: TEMBO THE BADASS ELEPHANT
addappid(341870)
addappid(341871, 1, "f842648b5645e393c252d0f640da581301c98b7cffa6049b4ca047f27c6835d3")
