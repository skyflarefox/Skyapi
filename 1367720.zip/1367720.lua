-- Lua provided by SkyAPI 
-- Game: General War Memories
addappid(1367720)
addappid(1367721, 1, "873743bc229d8107216478d4d36ae049f5c0dad1033d58b51e119538e5a502f9")
addappid(1367722, 1, "14b2e37cbb97db4b9399d74874018c2ed4cfcdd08a5ac9149717316aef453eb8")
