-- Lua provided by SkyAPI 
-- Game: Memory Puzzle - Bad Girl
addappid(1962440)
addappid(1962441, 1, "ee4d65a94dba1d6c9bf08d886ff7d9c61b1f3c6f65467e545080228ad4086788")
