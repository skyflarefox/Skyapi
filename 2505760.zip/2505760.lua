-- Lua provided by SkyAPI 
-- Game: AppID 2505760
addappid(2505760)
addappid(2505761, 1, "69d1aaea605bf89aae0485bf43a0899c4ad74a9d3acc1c9bc78e817082b87c8e")
