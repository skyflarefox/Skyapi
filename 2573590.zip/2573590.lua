-- Lua provided by SkyAPI 
-- Game: Toytopia
addappid(2573590)
addappid(2573591, 1, "fb3d676ecb2fc50f566fc00935823f3de525d430eac6f3d94a0226a01840fdb1")
