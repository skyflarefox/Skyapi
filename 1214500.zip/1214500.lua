-- Lua provided by SkyAPI 
-- Game: GraFi Lunar
addappid(1214500)
addappid(1214501, 1, "aa7ab065cd2394df700b9f7ab0874ddbba008d1dc85725f5c69621695d5e1054")
