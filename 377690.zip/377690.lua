-- Lua provided by SkyAPI 
-- Game: Starlight Vega
addappid(377690)
addappid(377691, 1, "2a4a4c0304879c557bb36444d86a1dc667f4a87ce1de68c92085a7457340cade")
