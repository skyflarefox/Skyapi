-- Lua provided by SkyAPI 
-- Game: Garden Rescue
addappid(346210)
addappid(346211, 1, "330b281e9b32bd427668bf755428f32bd03297d4c9b853a62ea6034b47d6a0a7")
