-- Lua provided by SkyAPI 
-- Game: HexWind
addappid(2739340)
addappid(2739341, 1, "dade24adef44bd3372dcfb9cee1c6b07b2aef1b84c89a504f454fa783b456457")
