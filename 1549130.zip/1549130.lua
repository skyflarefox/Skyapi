-- Lua provided by SkyAPI 
-- Game: Quick Packer 2
addappid(1549130)
addappid(1549131, 1, "d708f1addee2ae6d51722c07395f1d4fb307c8c3e1447966ab6bdfd67309114f")
