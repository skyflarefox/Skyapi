-- Lua provided by SkyAPI 
-- Game: CASE: Animatronics Demo
addappid(500650)
addappid(500651, 1, "8b262ecb5c76f89d2b08e6c2a8d97f0ba8047651811b2c0c52bd3a0b9425215b")
