-- Lua provided by SkyAPI 
-- Game: Force Reboot
addappid(1766010)
addappid(1766011, 1, "f6c8f85627a10e1dad7b19879686acae1d61e150d63b7a0fdc3edb26b3b93593")
