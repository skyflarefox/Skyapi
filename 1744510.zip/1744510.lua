-- Lua provided by SkyAPI 
-- Game: AppID 1744510
addappid(1744510)
addappid(1744511, 1, "1dee837f9342c46721c12630eed47843b2c19f68b210f859845e277c19e7a89d")
