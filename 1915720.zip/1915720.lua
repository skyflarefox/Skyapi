-- Lua provided by SkyAPI 
-- Game: My Friendly Neighborhood Demo
addappid(1915720)
addappid(1915721, 1, "49e43522d16fed54b8355b379b0ebcdda55ee6cc8660217c2c78b638b7be308d")
