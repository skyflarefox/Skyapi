-- Lua provided by SkyAPI 
-- Game: AppID 795660
addappid(795660)
addappid(795661, 1, "e5edfde92ebaba5c54dc241dc9f36976ee0ef3c9082f23adc1a23a5fed4da40d")
