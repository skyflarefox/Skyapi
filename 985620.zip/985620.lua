-- Lua provided by SkyAPI 
-- Game: Space Captain McCallery - Episode 2: Pilgrims in Purple Moss
addappid(985620)
addappid(985621, 1, "6a7f5dc9b06a35cf0a189f2b45e23e26d2e7bcfd6c92dbcb93523fdb6db5f9d0")
