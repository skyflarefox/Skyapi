-- Lua provided by SkyAPI 
-- Game: Space Pilgrim Episode III: Delta Pavonis
addappid(439250)
addappid(439251, 1, "faae83019e1892f4c720c3586ce3c8cb5ef4ae1ee1e0478544a1059b389a0313")
