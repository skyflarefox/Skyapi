-- Lua provided by SkyAPI 
-- Game: Mist of the Undead
addappid(1373500)
addappid(1373501, 1, "d19968c7b3993cf5dab1d472006bbffe231c6d4451ef14a20ef931912e08aea6")
