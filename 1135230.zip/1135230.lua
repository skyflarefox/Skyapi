-- Lua provided by SkyAPI 
-- Game: AppID 1135230
addappid(1135230)
addappid(1135231, 1, "011afcb4ff95536d7fd9806e3c2b9b08d9dd0f69a69bd7b92076966562010938")
addappid(1135232, 1, "4fb873edabfbd3320be661283c46fdc9dd7d5f9cc7d942b53790673083fe1b66")
