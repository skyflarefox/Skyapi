-- Lua provided by SkyAPI 
-- Game: Starflex-VR
addappid(1802970)
addappid(1802971, 1, "5e6742036794f443e10295755156f676dd7f275a7386a66a09b3ca7b0bc7524a")
