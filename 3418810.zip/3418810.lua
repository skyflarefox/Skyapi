-- Lua provided by SkyAPI 
-- Game: Marmot Fight Club
addappid(3418810)
addappid(3418811, 1, "7c3b55e50e00afe0476a4ae3a8119add403d1734ecde80de2ec1043292b3dc27")
