-- Lua provided by SkyAPI 
-- Game: AppID 2084850
addappid(2084850)
addappid(2084851, 1, "91c56e166c0683974987771fc367c9949a5ce2781e24bce8a4ffa39f86295226")
