-- Lua provided by SkyAPI 
-- Game: AppID 1019420
addappid(1019420)
addappid(1019421, 1, "7732892357924565c6b09283b0b4cb3eaa128a8a42bcf043fc70c6cf4d7cda3e")
