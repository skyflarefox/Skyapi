-- Lua provided by SkyAPI 
-- Game: Phantom Fury
addappid(1733240)
addappid(1733241, 1, "3cfe77c0a8458712950b1f1eb9485e8846e4b1aa4410171c47bdc02eb0c03096")
