-- Lua provided by SkyAPI 
-- Game: Sakura Beach
addappid(377680)
addappid(377681, 1, "33c58c64b3032abe03a66187d21744a56dc75192844e9c0eabd4f499cda8f712")
