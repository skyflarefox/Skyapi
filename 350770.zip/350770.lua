-- Lua provided by SkyAPI 
-- Game: AppID 350770
addappid(350770)
addappid(350771, 1, "0526e4d0783432a908066d057b98cb0ef7a4dc98429b6ae5e969fea399456097")
