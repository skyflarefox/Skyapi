-- Lua provided by SkyAPI 
-- Game: AppID 987410
addappid(987410)
addappid(987411, 1, "e0ee1ddfeb4027f702910072b747bd58b7b7fe5bb47be82691d3fddce52ebe7c")
