-- Lua provided by SkyAPI 
-- Game: Stray
addappid(1332010)
addappid(1332011, 1, "e61bdb7aeaccc075f69345348178ac158f107c1433c9a28743797407dc335e4c")
