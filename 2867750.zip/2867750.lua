-- Lua provided by SkyAPI 
-- Game: Rose and Locket Demo
addappid(2867750)
addappid(2867751, 1, "51e485b1728ea7569ae54837be27245624f51e8a97f0db33e7fcec3f466a0b83")
