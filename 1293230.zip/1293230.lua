-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1293230)
addappid(1293232,0,"2a30361eceb822840c23640579a032a081be57e0623b8898ac06e380f07ff917")
setManifestid(1293232,"4733300517973905610")
addappid(1293234,0,"aaa8c76c47d7d0b678800ec77000d3d4cdb65b05959fea7ecbf0a93baf9d49e7")
setManifestid(1293234,"2898794218713599770")
addappid(1293235,0,"3d6e6e8b094f4fb38e4aeb6091cdbb0e10fc5cf9839dccbdfa8b8c3df5a14ef0")
setManifestid(1293235,"2215339808425818486")
addappid(1293231,0,"5fede50d76486629263a58fb719b922897df1116499af2c49e56983b878b7153")
setManifestid(1293231,"4154911923603011130")