-- Lua provided by SkyAPI 
-- Game: AppID 663190
addappid(663190)
addappid(663191, 1, "e242927e2e9df41d99db4b86721bedd4855692e6489ce57fa3d19172f6f98ce7")
