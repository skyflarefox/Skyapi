-- Lua provided by SkyAPI 
-- Game: AppID 1117000
addappid(1117000)
addappid(1117001, 1, "0802f4f01e53f6b42fae639eade7b3337d1c5abb939f60cb1a7319825e17e306")
