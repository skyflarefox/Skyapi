-- Lua provided by SkyAPI 
-- Game: AppID 1295390
addappid(1295390)
addappid(1295391, 1, "0e6084af2a7cce43f9bdb8209ea46e2c1d661f26456f933a4c964896c6c3c684")
