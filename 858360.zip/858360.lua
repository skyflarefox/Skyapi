-- Lua provided by SkyAPI 
-- Game: AppID 858360
addappid(858360)
addappid(858361, 1, "d725d31fb84e94c13b04c2d6c4a8e477e6fbb19268a49f920ce4032ddbe2e16c")
