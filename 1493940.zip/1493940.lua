-- Lua provided by SkyAPI 
-- Game: Airoheart
addappid(1493940)
addappid(1493941, 1, "98f571290c566a8daaefa8b71c77a8c03435cca71ac0a1dda5906d7f99d8189b")
addappid(2109080)
