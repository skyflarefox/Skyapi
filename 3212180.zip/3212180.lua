-- Lua provided by SkyAPI 
-- Game: Nightmare Shift
addappid(3212180)
addappid(3212181, 1, "09f843e621271d2d260be421e7cce34328ce229c63919f0d0857e25b70016978")
