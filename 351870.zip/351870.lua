-- Lua provided by SkyAPI 
-- Game: AppID 351870
addappid(351870)
addappid(351871, 1, "29bd950e6ab6c65337ab0d9bb5245ab431a3379016b0c1efcfbdf45c8da9b7c7")
addappid(351872, 1, "332adf3e01ce2c4df55a244bf3d54a9297d30cff02f71db9f59fb190a09d8294")
