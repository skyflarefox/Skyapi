-- Lua provided by SkyAPI 
-- Game: AppID 2924640
addappid(2924640)
addappid(2924641, 1, "f3ed6f95af8f704c45e187beaf2f9d14cfc83e2259e2c978db8e95a189f97344")
