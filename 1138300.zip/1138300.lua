-- Lua provided by SkyAPI 
-- Game: AppID 1138300
addappid(1138300)
addappid(1138301, 1, "835bc5fd02ef452b319f9498fbefe237c58273d87a22ce3ccb70b15ab2a5e59a")
