-- Lua provided by SkyAPI 
-- Game: AppID 1820120
addappid(1820120)
addappid(1820121, 1, "44cfeeb8be5c198d4b84c39e01bd2c65d9d925ed104b9ffd840a398e87fe5229")
