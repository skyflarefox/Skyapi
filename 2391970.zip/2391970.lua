-- Lua provided by SkyAPI 
-- Game: AppID 2391970
addappid(2391970)
addappid(2391971, 1, "88b2cae7180fc6df7107002a0f022bf08df40985f247c1198aed4f6bccf92bc7")
