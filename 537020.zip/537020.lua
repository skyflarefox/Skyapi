-- Lua provided by SkyAPI 
-- Game: Legions of Tyrandel
addappid(537020)
addappid(537021, 1, "20b0f2197c48608ff188ecd89c77bff72def65d94a75c61fcdb6534dd5961ddd")
