-- Lua provided by SkyAPI 
-- Game: AppID 1461540
addappid(1461540)
addappid(1461541, 1, "03f1c85d85419d6d06391ced4e70fe79257954891c2c678dc16dc007a86dce27")
