-- Lua provided by SkyAPI 
-- Game: AppID 3391050
addappid(3391050)
addappid(3391051, 1, "30f9dfb6c17340d725b4a5ad647866294907b1131b1711151cbd0b7ff3943eb3")
