-- Lua provided by SkyAPI 
-- Game: Haydee 2
addappid(1444650)
addappid(1444651, 1, "3a127e1d2941df13b43eacabbff7d788a219b66f14e133a7b778745268c36a21")
