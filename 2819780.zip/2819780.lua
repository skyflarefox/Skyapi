-- Lua provided by SkyAPI 
-- Game: Neon Fantasy: Butterflies
addappid(2819780)
addappid(2819781, 1, "e00208e11045baba528fc89bd2117a9333375968ffaa6ecc9ec702720bfbbafb")
