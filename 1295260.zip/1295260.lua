-- Lua provided by SkyAPI 
-- Game: Clockwork Calamity in Mushroom World: What would you do if the time stopped ticking?
addappid(1295260)
addappid(1295261, 1, "b6d34d6e9a5a70cf125f7fff44573f93067e99c0ef9fd691c59554d4bfc0d90d")
addappid(1295262, 1, "48d88bf5503a5622646f57399db2bd3fcb9923a17e66007e5ebe8b02f47fe205")
addappid(1295263, 1, "a00a71c6a8971369bc1593635c21b0172e0cb1ac4c41b2a8e1b5728d79212121")
