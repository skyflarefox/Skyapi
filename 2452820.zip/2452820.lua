-- Lua provided by SkyAPI 
-- Game: Skogdal
addappid(2452820)
addappid(2452821, 1, "351f3f12ca2c2b9bf9570833c0d89ab281f7546b4cf1fb9239dd38e44bd88817")
