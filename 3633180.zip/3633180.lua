-- Lua provided by SkyAPI 
-- Game: Undead Horde: Dark Conqueror
addappid(3633180)
addappid(3633181, 1, "c131906faeb327c72bb2ad71d94102d05c56bf1aa8ce61cee350337bbad66763")
