-- Lua provided by SkyAPI 
-- Game: Aim: Warmup
addappid(1501110)
addappid(1501111, 1, "824c9fd72c8b91d42518300fe94b53a01697c2cbbca58ced6d44171900cc950b")
