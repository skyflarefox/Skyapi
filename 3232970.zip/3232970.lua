-- Lua provided by SkyAPI 
-- Game: AppID 3232970
addappid(3232970)
addappid(3232971, 1, "fed37be9c33e1057be43a1028c1166a19be9606bfbe17731525b040dd636960c")
