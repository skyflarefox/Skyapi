-- Lua provided by SkyAPI 
-- Game: Auto Sale Life: Fresh Start
addappid(2877220)
addappid(2877221, 1, "0e63f29295fca3feaa23179ce564467107c8a88a6859f56f1536f516c8dc7772")
