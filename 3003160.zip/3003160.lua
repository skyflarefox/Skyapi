-- Lua provided by SkyAPI 
-- Game: BLADECHIMERA Demo
addappid(3003160)
addappid(3003161, 1, "c450b1406c4803fe6bd92eb73c67bb63d62524d0c668fb137f2fdcc552ebab85")
