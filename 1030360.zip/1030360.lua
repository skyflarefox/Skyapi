-- Lua provided by SkyAPI 
-- Game: Midnight Evil
addappid(1030360)
addappid(1030361, 1, "2644d0f33765bb2f42a9e1abfecae2cd393b1362a40b9e683da951b75d992545")
