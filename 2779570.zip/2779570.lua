-- Lua provided by SkyAPI 
-- Game: Archons
addappid(2779570)
addappid(2779571, 1, "8841014dc6c7e84abc5540cf428d6541e5356e33b43ceda85af5332e4e1d4be7")
