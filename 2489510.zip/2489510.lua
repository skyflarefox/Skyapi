-- Lua provided by SkyAPI 
-- Game: Jack Holmes : Master of Puppets PROLOGUE
addappid(2489510)
addappid(2489511, 1, "197abaa1c834b2fe67d9aa564e8854def02662ce54b8fbfb6beb0e989e97f5c1")
