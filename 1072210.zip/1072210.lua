-- Lua provided by SkyAPI 
-- Game: AppID 1072210
addappid(1072210)
addappid(1072211, 1, "5cfc03ad969416168b77853de4a4db5dddf20cd5a136094aa7064b25755ccd64")
