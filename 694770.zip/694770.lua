-- Lua provided by SkyAPI 
-- Game: AppID 694770
addappid(694770)
addappid(694771, 1, "55251d18b7825746cde24bd652e7d04f9f179a24a4432eb11a8bf30eb7d52514")
addappid(694772, 1, "9e1a663d482ee23d2f4a0cf51bc30881abb91a3bea8c4ac973cc31e425be8196")
