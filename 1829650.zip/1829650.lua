-- Lua provided by SkyAPI 
-- Game: Sekai to Sekai no Mannaka de
addappid(1829650)
addappid(1829651, 1, "c93bc1619c2ef4531c17857242cf18a6f3b636c85f3637d1e09d0724fbd38d25")
