-- Lua provided by SkyAPI 
-- Game: BLACK DAY
addappid(696650)
addappid(696651, 1, "c5f0e774edd6c4051a09d030b755fff24a1bdb40bb980c20c45a60be63ee5c76")
