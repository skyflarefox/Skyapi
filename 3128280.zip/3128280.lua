-- Lua provided by SkyAPI 
-- Game: Cats & Dice
addappid(3128280)
addappid(3128281, 1, "451a0b83b1eaa8f52e8567032e0c0767b187cfd7787ca5b01b62f1410dd06dff")
