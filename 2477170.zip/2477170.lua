-- Lua provided by SkyAPI 
-- Game: 仙途
addappid(2477170)
addappid(2477171, 1, "443560b092e91792f2f297ccc0d67d510587191f62d4d6423633943da5c04b83")
