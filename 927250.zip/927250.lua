-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(927250)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(927251,0,"ba4a15f7ef47c5d874e4f760635057c9b63834e78d51c2c9cede15ca7331755a")
setManifestid(927251,"7907969020478816061")
addappid(1020880,0,"7c9a7c9e857e2ef331ae8473e69babd2152de1f19ab8c05e44a729d58501cea8")
setManifestid(1020880,"1111007528905647129")