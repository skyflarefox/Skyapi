-- Lua provided by SkyAPI 
-- Game: NERVE Soundtrack
addappid(1529450)
addappid(1529451, 1, "1aafb6d0de1f93ee51bdcc901b85cdf05ed71da9efc49268f19947dd2f28547b")
addappid(1529452, 1, "1ff329a4862c0ed9a5ceb524885791e9547df5a6ef640280b38b84bcb5570af5")
