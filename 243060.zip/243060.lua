-- Lua provided by SkyAPI 
-- Game: Urban Chaos
addappid(243060)
addappid(243061, 1, "b0bde965d6a14e84fc6b2cdb3ef3b95b2101d5878b2cec83285580e045904460")
