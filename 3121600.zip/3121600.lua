-- Lua provided by SkyAPI 
-- Game: Habilis
addappid(3121600)
addappid(3121601, 1, "cd1720fffa4a08d8764acc2b9eba27be3d16155be54379c48e50738dc3aa0870")
