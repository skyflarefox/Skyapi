-- Lua provided by SkyAPI 
-- Game: BDSM VR
addappid(1471610)
addappid(1471611, 1, "adc7d5d80de3374b64edeed7108796a59e8a472ba7165e188e6a89af5570b5a3")
addappid(1471612, 1, "74c2d056e8359eb6a231e707c575b7d82e3ff9f6ace9d5d3f810babd6f35aed5")
addappid(1476700)
