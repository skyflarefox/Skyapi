-- Lua provided by SkyAPI 
-- Game: Diesel Punch
addappid(1321400)
addappid(1321401, 1, "b514bed4db2534e6e90735d9b4723677a1d041c552e968766d8d09ae4144d3fe")
