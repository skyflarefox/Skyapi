-- Lua provided by SkyAPI 
-- Game: Nekomew's Potty Trouble
addappid(774221)
addappid(774222, 1, "51eb680a58a978e84919a7641f0845214214d1595c5b5b2f5559f05038cc9fb9")
addappid(923250)
addappid(923251)
