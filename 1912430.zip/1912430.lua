-- Lua provided by SkyAPI 
-- Game: AppID 1912430
addappid(1912430)
addappid(1912431, 1, "ac2b1868aae600d296ec16f899129823050cea775d14b14ee90414752e40c77a")
