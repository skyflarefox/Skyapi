-- Lua provided by SkyAPI 
-- Game: AppID 908520
addappid(908520)
addappid(908521, 1, "f31cd8224b7d2b7b0fb910eacc838d36e379847e5a43a05737c0bde364d302a2")
