-- Lua provided by SkyAPI 
-- Game: Puppet Play 🎬
addappid(1666890)
addappid(1666891, 1, "ba7c9755b73d8191da3d57ee332621785190325593556f3b2c5588d9ce47928f")
