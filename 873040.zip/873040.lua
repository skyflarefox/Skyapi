-- Lua provided by SkyAPI 
-- Game: AppID 873040
addappid(873040)
addappid(873041, 1, "7a4133cdfbf0457256dc6b5fca33d97a62d4a90ffd795cf5b12f96e589f8ec58")
