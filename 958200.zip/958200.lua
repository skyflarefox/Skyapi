-- Lua provided by SkyAPI 
-- Game: Ralf
addappid(958200)
addappid(958201, 1, "b15136af1673c5870f0a0eaaf453be4c974f9e184a96b05f350d37dbc276f0dd")
