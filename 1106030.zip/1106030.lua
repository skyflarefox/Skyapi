-- Lua provided by SkyAPI 
-- Game: ROAD HOMEWARD 3 underwater world
addappid(1106030)
addappid(1106031, 1, "49e4925d1d412320cad305073ac0180f6fbe0226b600e881932bd93c5a604893")
