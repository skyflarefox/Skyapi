-- Lua provided by SkyAPI 
-- Game: 死寂（Deathly Stillness）
addappid(1727650)
addappid(1727651, 1, "bc8ab7b5b3063d5620446c75d05611a8c3a92584d35351293a7dbca3d8608c63")
