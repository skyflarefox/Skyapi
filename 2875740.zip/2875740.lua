-- Lua provided by SkyAPI 
-- Game: Anime Girl Puzzles
addappid(2875740)
addappid(2875741, 1, "1afdbd813a83cb434dea1a7989e192bee8a9ab135aa547213156aacd687f5e3b")
