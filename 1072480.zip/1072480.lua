-- Lua provided by SkyAPI 
-- Game: The Fisherman - Fishing Planet
addappid(1072480)
addappid(1072481, 1, "b0f39fb0235b910b4afb094392b03e217d652b6ba8b1ef5d2387fcea3289358e")
