-- Lua provided by SkyAPI 
-- Game: REKKR: Sunken Land
addappid(1715690)
addappid(1715691, 1, "b403ddad9aa1edc51237acafff3fa5e9790b642f6fc0b1c99b0d1126086d3b37")
