-- Lua provided by SkyAPI 
-- Game: the fairytale of DEATH
addappid(1054300)
addappid(1054301, 1, "f7feb7d04b4fa6ea9fa1303b1711373fc4d32b02af74ad7ff844e3f0f793e2d6")
