-- Lua provided by SkyAPI 
-- Game: Paint By Numbers
addappid(1605290)
addappid(1605291, 1, "c794b208adce8758fcb5b1fe4b4e80cf7c036e13c4327ba7951e207afa6d7de5")
