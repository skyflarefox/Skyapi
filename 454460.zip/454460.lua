-- Lua provided by SkyAPI 
-- Game: AppID 454460
addappid(454460)
addappid(454461, 1, "49d01440eb1fcf94962a6b41451d866be4a605befcc0a93297ce7953c7db61ca")
addappid(454462, 1, "b24814d739909931250d4bcc5b45172eed3db2509c9cf4eacd33243add2d1322")
