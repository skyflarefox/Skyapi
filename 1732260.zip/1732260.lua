-- Lua provided by SkyAPI 
-- Game: Lucent Bounds
addappid(1732260)
addappid(1732261, 1, "403881448745150ca67e9a9b73df320df65a9f02c3817ddeb8e1c86657f966e6")
