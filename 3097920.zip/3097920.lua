-- Lua provided by SkyAPI 
-- Game: AppID 3097920
addappid(3097920)
addappid(3097921, 1, "5aea4a97542233b3d3ee9357ee68a6cc6e11c35873da3e30fe5dcb1613110d58")
