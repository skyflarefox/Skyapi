-- Lua provided by SkyAPI 
-- Game: AppID 2959030
addappid(2959030)
addappid(2959031, 1, "b833ebdbcc197fb3e8a3c8e40d95eb6df653b4d9b6a0785960250fa8d46eb1fc")
