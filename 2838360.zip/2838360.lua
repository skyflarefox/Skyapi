-- Lua provided by SkyAPI 
-- Game: SINce Memories: Off The Starry Sky
addappid(2838360)
addappid(2838361, 1, "d8abfe0bffa0aa31eed1c96624f7db1f5eb3b43544cbcbcbde2ad951426fbf9a")
