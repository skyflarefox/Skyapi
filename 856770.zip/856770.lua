-- Lua provided by SkyAPI 
-- Game: Hokan: Monster Slayer
addappid(856770)
addappid(856771, 1, "780ff673499a7f650a8afee0deb0e19fb4dc089cb9024738ca5d11f8dfa0f61c")
