-- Lua provided by SkyAPI 
-- Game: ESports Simulator
addappid(3026100)
addappid(3026101, 1, "d1f5c17c120a39dd43d937c2609d3cd11c015df9ddd95356ff668f5ccac4cac9")
