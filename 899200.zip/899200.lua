-- Lua provided by SkyAPI 
-- Game: AppID 899200
addappid(899200)
addappid(899201, 1, "2671e30e5d87783c6e1897b8167225d1ae89be3603b6b1c12c105903b988698a")
