-- Lua provided by SkyAPI 
-- Game: GHARP
addappid(1913980)
addappid(1913981, 1, "62b85bd9e6d569c16519496130dc44877725d040a03fb5532b0406170533b5c4")
