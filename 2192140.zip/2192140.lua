-- Lua provided by SkyAPI 
-- Game: AppID 2192140
addappid(2192140)
addappid(2192141, 1, "6cbc7fd71b25410391d53a8c346c1678158ef9ad8c9c664814e34f91037da566")
