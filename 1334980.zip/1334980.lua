-- Lua provided by SkyAPI 
-- Game: AppID 1334980
addappid(1334980)
addappid(1334981, 1, "38f804f23688ed1192b3aa255acca8fee22bc60464b00d6948d87e15fde01147")
addappid(1334982, 1, "9e323a0fc91e1ab030d0a6abe660a51ca59ce160eb4790ea1159826b9071429a")
