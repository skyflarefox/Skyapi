-- Lua provided by SkyAPI 
-- Game: Volcanoids Modding SDK
addappid(1698830)
addappid(1698831, 1, "8bb517d34b1cca09573e7effbd6a7b59651713d7a0dff17ac4ac9a0218e53430")
