-- Lua provided by SkyAPI 
-- Game: AppID 654070
addappid(654070)
addappid(654071, 1, "5342cb94443cd41e8edae655dea8c8932b5afff16b58f2da810fb5a7b106f22c")
