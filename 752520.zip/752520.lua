-- Lua provided by SkyAPI 
-- Game: AppID 752520
addappid(752520)
addappid(752521, 1, "fecfb7d1fc01c26369732e963220b469e0007b7bb7c1bdff419e03209c8f20a6")
