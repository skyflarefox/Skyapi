-- Lua provided by SkyAPI 
-- Game: Fool's Gold Demo
addappid(2910250)
addappid(2910251, 1, "e3f6fc0a0aedc8f961322e12c337787a5634fdf0a2481a3c764ebacf81425b3e")
