-- Lua provided by SkyAPI 
-- Game: Star Pilot
addappid(1564520)
addappid(1564521, 1, "2c1742c83a9754836f7f4ba705e34ca9807fbfa7142d3626834070ebf1a2a935")
