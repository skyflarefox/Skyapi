-- Lua provided by SkyAPI 
-- Game: 修仙小屋
addappid(2892880)
addappid(2892881, 1, "97371ce20a95049fb3b6aa47ada1b9a21429e2dbc8ca5c1488a31f46fb364900")
