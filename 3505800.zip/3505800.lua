-- Lua provided by SkyAPI 
-- Game: Yurei Hunt
addappid(3505800)
addappid(3505801, 1, "9521415f6188d413f1ceb9f8efa8aa01177dd315142a3d95cd6bd73c320ad8ed")
