-- Lua provided by SkyAPI 
-- Game: AppID 2637120
addappid(2637120)
addappid(2637121, 1, "862ee3885a7400d9c83b5d8a2ebc0034d0b1a3d7cd338d00101201fb35a24525")
