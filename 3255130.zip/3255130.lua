-- Lua provided by SkyAPI 
-- Game: Echoes of Mystralia Playtest
addappid(3255130)
addappid(3255131, 1, "c05626f94981c3016c7167e5e5a66a7bb194232a9ada9614480714247f1aae40")
