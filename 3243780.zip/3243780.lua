-- Lua provided by SkyAPI 
-- Game: Abode: Definitive Edition
addappid(3243780)
addappid(3243781, 1, "3bb8e2211f2c722a6ba245c106feddec1097f3d6308ef1b545f9fcb1a47ddce2")
