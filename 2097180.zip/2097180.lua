-- Lua provided by SkyAPI 
-- Game: OxU
addappid(2097180)
addappid(2097181, 1, "f974ca3478f0c9461ab2f1668f0a858aa2dc8fc54cf4e8cbba39190c36435ab8")
addappid(2146060)
