-- Lua provided by SkyAPI 
-- Game: Pieter Both Village Demo
addappid(3206000)
addappid(3206001, 1, "7f5d08b1f5a145f3ebc8a2966ed36edc6a873c6881fa58ba475c88099b8a2a71")
