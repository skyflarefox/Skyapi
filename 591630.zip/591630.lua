-- Lua provided by SkyAPI 
-- Game: Candleman: The Complete Journey
addappid(591630)
addappid(591631, 1, "eb73a2069f3b4b122dbebd422243366e143ed3516bebe0b3993c801b34166e73")
addappid(591633, 1, "1bc8aa9089bfeacb593696dda5693578dad7fecbd5a5166e0ec565002327477a")
