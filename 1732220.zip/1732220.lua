-- Lua provided by SkyAPI 
-- Game: The Crown of Wu
addappid(1732220)
addappid(1732221, 1, "a67daa6625ee95eda5c3a5ff2532b38e10b5578efce905d5be3de63065858aa5")
