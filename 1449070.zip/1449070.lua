-- Lua provided by SkyAPI 
-- Game: Journey to the West
addappid(1449070)
addappid(1449071, 1, "c456f9618b01e443fe6335403be2cb31891a949eac078764eb206fa5e6a63d79")
