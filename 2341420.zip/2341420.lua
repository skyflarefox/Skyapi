-- Lua provided by SkyAPI 
-- Game: Barrett Foster : Prologue
addappid(2341420)
addappid(2341421, 1, "12ee5367ae67e937adfd3094e47f5752fb3dc2cc7bca16a39950e6ce6ba7b59a")
