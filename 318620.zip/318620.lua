-- Lua provided by SkyAPI 
-- Game: AppID 318620
addappid(318620)
addappid(318621, 1, "1843f3f2f79e211043bcb8b1fc1561ee9ec9f191df952fd68f55eb1d9349fb5b")
