-- Lua provided by SkyAPI 
-- Game: Adorimon : Arena of Ancients
addappid(2767160)
addappid(2767161, 1, "162266d6ce9f0c716128ee910261532fe30a2ab1565a7bc1b4831a5877be13ee")
