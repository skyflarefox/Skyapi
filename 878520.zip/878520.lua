-- Lua provided by SkyAPI 
-- Game: AppID 878520
addappid(878520)
addappid(878521, 1, "69d16135ebb0574fe32e9724fde570f88c37d8e80e082ab08273f32245325aee")
