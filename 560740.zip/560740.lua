-- Lua provided by SkyAPI 
-- Game: Shtriga: Summer Camp
addappid(560740)
addappid(560741, 1, "1d07f7f58bba10de76a68a31a8fc6df1de98bb6db0e6559f62f4e2b67b96c998")
