-- Lua provided by SkyAPI 
-- Game: 完堕ちXギャル母娘 ～ マジ気持ちイイ！アタシたち、アンタの肉オナホにされちゃう ～ Demo
addappid(2989900)
addappid(2989901, 1, "4bf9164eb9754b9a9622330e53eb2a5b346c812fc632c69eaaca5d816e6c1805")
