-- Lua provided by SkyAPI 
-- Game: 欺神弄鬼
addappid(2697490)
addappid(2697491, 1, "4597f45d9ef1e69cfed27b87576d5f3b2b962dfeb9ee469aa7a28738d7069cfb")
