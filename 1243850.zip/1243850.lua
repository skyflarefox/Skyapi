-- Lua provided by SkyAPI 
-- Game: This Bed We Made
addappid(1243850)
addappid(1243851, 1, "86c396a5290b9f8988b07469182701a3545368ce1f1ad107f95c504d73b7094e")
