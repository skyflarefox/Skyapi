-- Lua provided by SkyAPI 
-- Game: Oil Sheik
addappid(2746610)
addappid(2746611, 1, "98b4b29c1bca58dda3500d5c3e6342e54441a5ecd7ad15c190f2c36e7d20f26e")
