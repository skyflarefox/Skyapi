-- Lua provided by SkyAPI 
-- Game: 3D Escape Room: Detective Story
addappid(3411050)
addappid(3411051, 1, "c4600ef021e6ad60a4c455e997994f39bebc3eae442cc334d3475c7aff8371ed")
