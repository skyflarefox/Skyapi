-- Lua provided by SkyAPI 
-- Game: Suzerain
addappid(1207650)
addappid(1207651, 1, "e962f7f3acaa1caae21e3a4b34d2c88979477e1e5c6343007e2b688814031f1b")
addappid(1207652, 1, "eec4a5f35bdeae4e24e087931ce32ca88abc8136a7f68f3fcf2c207145696479")
