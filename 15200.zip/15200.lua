-- Lua provided by SkyAPI 
-- Game: Silent Hunter®: Wolves of the Pacific
addappid(15200)
addappid(15201, 1, "286df1e793647e3ff03e1fca1a8e0886c191c45fb78505a56e0e043eda305155")
addappid(15202, 1, "255487b0d88028b950a32e147ab2f05981d59b8b6f7ed61afc159690019b2a3f")
addappid(15203, 1, "97d2bf1157ff335ef2c205f4a508ebeb2d35d7f2015958f899dc9515f096a31f")
