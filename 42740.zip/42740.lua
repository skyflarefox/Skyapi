-- Lua provided by SkyAPI 
-- Game: AppID 42740
addappid(42740)
addappid(42741, 1, "8f17d1849d419858fd16d3574d61f42263ebc4d480a4c9e0c026738182da33ed")
