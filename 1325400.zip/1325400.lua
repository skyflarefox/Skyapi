-- Lua provided by SkyAPI 
-- Game: VEGAS Pro 18 Edit Steam Edition
addappid(1325400)
addappid(1325401, 1, "d78647a715c6b05690ff1b183cb54d055600c85737c23a8ded663c542382a391")
