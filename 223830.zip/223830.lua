-- Lua provided by SkyAPI 
-- Game: Xenonauts
addappid(223830)
addappid(223831, 1, "cf3e98bc903a8cd79c2867ff15d5ff2639f144f05929ed5e8deee8d7bf043828")
addappid(223833, 1, "d44f862e4e7612556b22f033cb6a791882888d9c89025fb8ddd100a2764b0e7e")
addappid(223835, 1, "32a2d827b7be43c3fc903bf3036d6ec4b7c2e56daafe31d88316c1dbbf0297bb")
addappid(223836, 1, "8b8393e331a2065eb4d3939c74ab1b4ec44aad32cf06850c0efacf3183d1a966")
