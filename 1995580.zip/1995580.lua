-- Lua provided by SkyAPI 
-- Game: Hypnosis Prison
addappid(1995580)
addappid(1995581, 1, "df01623b9d0088b31517dde31dd2bc2223372b06c348b7c0d52045e8a3728864")
