-- Lua provided by SkyAPI 
-- Game: Owl Bounce
addappid(3724540)
addappid(3724541, 1, "32b028d69cab1d800e6b19ac71333bfce9bb4e71084c50f760c6c30c2eff5a2c")
