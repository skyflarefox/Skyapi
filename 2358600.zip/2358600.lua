-- Lua provided by SkyAPI 
-- Game: Death Harvest
addappid(2358600)
addappid(2358601, 1, "8e27f0d052d5ad721acbfd67517592acf6e825d4858064d79e6dc643e108aa40")
