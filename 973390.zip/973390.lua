-- Lua provided by SkyAPI 
-- Game: AppID 973390
addappid(973390)
addappid(973391, 1, "a9e626a5144065b51005aa120ba54ed8eb8149ad1720ea35bcfbeac0e2db893e")
