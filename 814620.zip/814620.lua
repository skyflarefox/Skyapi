-- Lua provided by SkyAPI 
-- Game: AppID 814620
addappid(814620)
addappid(814621, 1, "eb147890cf87bf8f8244967fcc5dc2cb8e91341631677337af11a8f0ebd50f55")
