-- Lua provided by SkyAPI 
-- Game: Hatch
addappid(1730920)
addappid(1730921, 1, "86125b8fac0ce0d6e6764f3c8239b03c2779f08cdc3a080048a918b9f507c893")
