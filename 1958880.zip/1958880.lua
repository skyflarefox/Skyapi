-- Lua provided by SkyAPI 
-- Game: It's a Wrap! Demo
addappid(1958880)
addappid(1958881, 1, "e9681e16c60959fc420d876d7ad9c5c75867019bd0e8f133ef5070385562b421")
