-- Lua provided by SkyAPI 
-- Game: Thriving City: Song
addappid(1956800)
addappid(1956801, 1, "f254dc89cb04fbc2228cbf01e4d818f698f4d45ebfa5761feb4d1c0b59ad6618")
