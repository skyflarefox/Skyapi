-- Lua provided by SkyAPI 
-- Game: Design it, Drive it : Speedboats
addappid(501090)
addappid(501091, 1, "5afa35546b72912206276315d9799b687c425bd149f3154c22bfc0340916c858")
