-- Lua provided by SkyAPI 
-- Game: Neon Warp
addappid(485920)
addappid(485921, 1, "2a8d47833a412f6a4839865a44266e26bccbd2c837cc79f948a99812c80dc910")
