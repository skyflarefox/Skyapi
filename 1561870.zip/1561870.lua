-- Lua provided by SkyAPI 
-- Game: FALCO AXE
addappid(1561870)
addappid(1561871, 1, "8785e6a1d45bb4a2968dc6e75490166c706608251f43ae2c4d205662d4af5125")
