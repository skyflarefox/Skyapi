-- Lua provided by SkyAPI 
-- Game: Microcivilization Demo
addappid(2303100)
addappid(2303101, 1, "cb6292b5cc0682f38919ab7f08b64c20481e9bc2d41a24f0f7b91ca923773fd0")
