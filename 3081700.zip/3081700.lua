-- Lua provided by SkyAPI 
-- Game: Hawk Tuah
addappid(3081700)
addappid(3081701, 1, "16a0ce7720e7659851d604cd591405ca9b6c20a8724fdf220a3a71c65e1af8ad")
