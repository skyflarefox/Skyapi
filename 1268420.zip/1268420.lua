-- Lua provided by SkyAPI 
-- Game: Britannia
addappid(1268420)
addappid(1268421, 1, "6843865cf8352bd7770e2b67f9b2f1fa2ca1b764e74928f076065e3eefb1ffb5")
addappid(1268422, 1, "cb1da5d79719725c49a4db1356776af9964ec21901cc425759befedda38ac943")
