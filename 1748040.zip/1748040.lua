-- Lua provided by SkyAPI 
-- Game: Recolit Demo
addappid(1748040)
addappid(1748041, 1, "30f05d332d07c92c810d00660c5467705467b21b06e25ff126d5ebef05081583")
