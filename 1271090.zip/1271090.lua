-- Lua provided by SkyAPI 
-- Game: Let's Cook Together
addappid(1271090)
addappid(1271091, 1, "639bfda837763e69f630242c49880d575b77f1438106fa2ae99bcd5256411043")
