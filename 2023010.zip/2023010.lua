-- Lua provided by SkyAPI 
-- Game: Truxton 2
addappid(2023010)
addappid(2023011, 1, "4cc8487cc68372aaf1225e96e683ca22ed8fcc3f210e03220e70ba98a691553a")
