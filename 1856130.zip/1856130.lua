-- Lua provided by SkyAPI 
-- Game: Catoise
addappid(1856130)
addappid(1856131, 1, "fa2fdda43a9ef3c2ac357f289e81d5e9cfce0ebd62888655ed5a5f492999ea8a")
