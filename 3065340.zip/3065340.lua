-- Lua provided by SkyAPI 
-- Game: Rogue Tanks Demo
addappid(3065340)
addappid(3065341, 1, "83fb37e5203a8ca5c268600722d370076101c8e3af09b0a19bbd920f615d0ac5")
