-- Lua provided by SkyAPI 
-- Game: Skul: The Hero Slayer Soundtrack
addappid(1525720)
addappid(1525721, 1, "b34b9e0534446e917b200c91ad83d4a33298b14b768dec625e2595a7b6fb17c6")
