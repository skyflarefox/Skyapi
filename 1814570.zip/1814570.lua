-- Lua provided by SkyAPI 
-- Game: Transcendence Legacy - Voidswept
addappid(1814570)
addappid(1814571, 1, "692ab0a2c37856ebbf9fe571c18c27b110c4b266edc5b584a212f5909f7d64e1")
