-- Lua provided by SkyAPI 
-- Game: ImageStriker
addappid(1180790)
addappid(1180791, 1, "704b5c99ca86c953ce290d5b38ac98dd273e7f15d54133e1127f5dbaa4e6ffda")
