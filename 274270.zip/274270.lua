-- Lua provided by SkyAPI 
-- Game: NOT A HERO
addappid(274270)
addappid(274271, 1, "c4997ffc9aabeb46353f96dfea25ea7b1ec5677d271d5713da0bf30fbef54023")
addappid(368520, 0, "3f76a719e56fdd2a1566226c469d3c76559c68ecf0c95bb216f5d0e6effac197")
addappid(380030)
