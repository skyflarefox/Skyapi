-- Lua provided by SkyAPI 
-- Game: Seafrog
addappid(2107540)
addappid(2107541, 1, "364189e481f9d2e792d49c1a002f01fc72527066d1d74cfc5f505b9c6218d831")
