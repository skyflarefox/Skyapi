-- Lua provided by SkyAPI 
-- Game: Monsters of Little Haven
addappid(1101930)
addappid(1101931, 1, "61b5387b1490b36f09619d7dbec1c88b597febd0252ee85f29ccf9ca573bc916")
addappid(1124440, 0, "b1b70b769b434c6985f386f8a3c5c838365d77c8595dd204a9cbba3534b58075")
addappid(1124441, 0, "321de686c8a4199d8def95b32ccface2935d15958920b32e001b73f054391c7e")
