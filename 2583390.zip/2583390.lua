-- Lua provided by SkyAPI 
-- Game: BORE BLASTERS Demo
addappid(2583390)
addappid(2583391, 1, "a4a93577ec438fdc9331da54fcd4e57256acd6d7e4221963459b1866e90ad8a3")
