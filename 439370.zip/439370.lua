-- Lua provided by SkyAPI 
-- Game: Midair
addappid(439370)
addappid(439371, 1, "24212d8e941f457f8eee1b65958bcf5a2ba1f783b22518b12cac2dbf2df0475b")
