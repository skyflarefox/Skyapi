-- Lua provided by SkyAPI 
-- Game: AppID 924070
addappid(924070)
addappid(924071, 1, "fd33abee36f2c391d26de7805ec480da66a6cc16d482790733e26ad3c9075f52")
