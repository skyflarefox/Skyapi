-- Lua provided by SkyAPI 
-- Game: Self Defense Dojo
addappid(2534120)
addappid(2534121, 1, "d59188b9f24874801e3b610eb5ca4e5485098872f5c980e5fb2906d38ec98c7d")
