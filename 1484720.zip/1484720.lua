-- Lua provided by SkyAPI 
-- Game: Dead Estate
addappid(1484720)
addappid(1484721, 1, "b483a8cfd4be1921be8384435068f891b8921a3e71b86b0a281ab6163aac8575")
