-- Lua provided by SkyAPI 
-- Game: AppID 2833530
addappid(2833530)
addappid(2833531, 1, "7fe348d4fc1c1dc740d76a3002366ea2bed4767d84340e515874162059ae911d")
