-- Lua provided by SkyAPI 
-- Game: AppID 3238670
addappid(3238670)
addappid(3238671, 1, "13cd290bb2c0f5a7295e7fb13e3a40c979c54085244db28c2251421edde94157")
