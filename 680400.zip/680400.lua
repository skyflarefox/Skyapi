-- Lua provided by SkyAPI 
-- Game: AppID 680400
addappid(680400)
addappid(680401, 1, "0fdbb0b4bfc2287aafea26c7ab578736261380e11f1cbd2c7684d77e9f993a76")
