-- Lua provided by SkyAPI 
-- Game: AppID 2151580
addappid(2151580)
addappid(2151581, 1, "16787ad2dcf625b58f77222db96e7019da13d96235d1d7576f6b152b3ed2201b")
