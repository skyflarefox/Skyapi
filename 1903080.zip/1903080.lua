-- Lua provided by SkyAPI 
-- Game: Sharing Lights
addappid(1903080)
addappid(1903081, 1, "82a888a9eecefaff0d35ba097d9257219e001d745238e1089fd9a21d542ed37c")
