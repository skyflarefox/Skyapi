-- Lua provided by SkyAPI 
-- Game: Sporadic Spire
addappid(1346240)
addappid(1346241, 1, "6df0eebd3cafc56951ec0c6cb7b89ed88a0eb34f95231b5f9dbfa7444fc5ca4f")
