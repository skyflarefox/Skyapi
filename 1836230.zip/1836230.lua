-- Lua provided by SkyAPI 
-- Game: AppID 1836230
addappid(1836230)
addappid(1836231, 1, "17772a0fae8f8654d73005491306593d7a1dd6dcc76c04a22458d13c117b233c")
