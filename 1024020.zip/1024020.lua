-- Lua provided by SkyAPI 
-- Game: AppID 1024020
addappid(1024020)
addappid(1024021, 1, "0af6eb2f327175bfd4ec84842a87204573c89b6be16e532850ad050293a10499")
addappid(1151710)
