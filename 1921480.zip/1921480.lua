-- Lua provided by SkyAPI 
-- Game: #BLUD
addappid(1921480)
addappid(1921481, 1, "8defbdfe2faf0d810c2e71573a71750d0b0a7a103d39120653107eb84c59978f")
