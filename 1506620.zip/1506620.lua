-- Lua provided by SkyAPI 
-- Game: AppID 1506620
addappid(1506620)
addappid(1506621, 1, "563e6695a12d582e733967c3b56991673f9e376ccf14e8d0006c352709dce962")
