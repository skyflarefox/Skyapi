-- Lua provided by SkyAPI 
-- Game: Find the cubs
addappid(1694180)
addappid(1694181, 1, "4e9770da65cdbeaa49eb2106331eb685b474c19ef474ef17380871c584923ce3")
