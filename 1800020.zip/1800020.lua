-- Lua provided by SkyAPI 
-- Game: Unreal Mashup Playtest
addappid(1800020)
addappid(1800021, 1, "dd32ec027cb51c7f69fe300bc378d7f982b523eeb5699e86e03155a322563476")
