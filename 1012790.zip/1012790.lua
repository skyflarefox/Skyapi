-- Lua provided by SkyAPI 
-- Game: AppID 1012790
addappid(1012790)
addappid(1012791, 1, "569bd7c4d66094271837ea69868e6d849a17ad1d1190f5761f748639ed643f1f")
