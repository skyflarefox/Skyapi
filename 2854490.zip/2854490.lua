-- Lua provided by SkyAPI 
-- Game: Escape The Mad Empire Playtest
addappid(2854490)
addappid(2854491, 1, "e6996e8adf8499558b50cf8a1118bdb847eba49a89749d75d7bacdfdfb9a0ee7")
