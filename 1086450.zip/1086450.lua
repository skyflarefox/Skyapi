-- Lua provided by SkyAPI 
-- Game: AppID 1086450
addappid(1086450)
addappid(1086451, 1, "bbe7ef6d65f5618c154c1c9d24be232642f2e6528f9aaef744f509876f2e7013")
