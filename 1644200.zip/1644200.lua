-- Lua provided by SkyAPI 
-- Game: Now you can't see me
addappid(1644200)
addappid(1644201, 1, "99846c5c28feb8ac67e765dc6d711c05102cd83796844f62229ec75bd91e1cc7")
