-- Lua provided by SkyAPI 
-- Game: AppID 1644960
addappid(1644960)
addappid(1644961, 1, "7bd16fd362dc178163d8afa11b87e3fe72a6c53a23d000d8b4671c601f1c5d95")
