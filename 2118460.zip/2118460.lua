-- Lua provided by SkyAPI 
-- Game: AppID 2118460
addappid(2118460)
addappid(2118461, 1, "301cdfd04824d40f5ec2d48a5db8973f74810eb9ec4969f8f15d94d7c989aa66")
