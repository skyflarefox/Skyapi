-- Lua provided by SkyAPI 
-- Game: RESIDENT EVIL RESISTANCE
addappid(952070)
addappid(952071, 1, "be4c331b420fccf7ed6e4ed528a8f004574c409dfc941ad3e7004fb936679301")
