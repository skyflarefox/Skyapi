-- Lua provided by SkyAPI 
-- Game: Block
addappid(1093870)
addappid(1093871, 1, "7870bb488101ca5ec07d36fc035dd43a8977b3374063455e4f418874be7073e3")
