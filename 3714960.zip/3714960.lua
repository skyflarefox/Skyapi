-- Lua provided by SkyAPI 
-- Game: Bastionforge
addappid(3714960)
addappid(3714961, 1, "2fad353ecc0aa8fd77459404212a1220e50726df4f124482cbe90b1506a8a26d")
