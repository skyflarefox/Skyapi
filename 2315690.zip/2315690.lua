-- Lua provided by SkyAPI 
-- Game: WWE 2K24
addappid(2315690)
addappid(2315691, 1, "23e097a5dcfd505419d23c66434881e466ae025183332849a90469800dd3d074")
