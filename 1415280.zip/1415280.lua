-- Lua provided by SkyAPI 
-- Game: Faerie Afterlight
addappid(1415280)
addappid(1415281, 1, "77f073b0a6a87d3b168e531d00d0037053da7b69d5d3d0302feeab9673e8fb7f")
