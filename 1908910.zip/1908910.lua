-- Lua provided by SkyAPI 
-- Game: 台北大空襲 Demo
addappid(1908910)
addappid(1908911, 1, "f4d1b70873c784e9fcce41728e906567a071090656177e0d824e67c5d2b6ee53")
