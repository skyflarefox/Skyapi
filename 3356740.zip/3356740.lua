-- Lua provided by SkyAPI 
-- Game: Weed Simulator
addappid(3356740)
addappid(3356741, 1, "647cc0706629b5126fd7ba42176e5e61ab0a9a0138ad2a60b7af50f157aeed90")
