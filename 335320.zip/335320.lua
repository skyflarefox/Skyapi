-- Lua provided by SkyAPI 
-- Game: Bet On Soldier
addappid(335320)
addappid(335321, 1, "c651ee2b9a03427fd0dcca8794003a2af8dc47bf5bf2a74af893b0f240704001")
addappid(335322, 1, "1fa1305b1d2f5f3887e877480cfafa4916fa7745c4b4befc82fd4abe4cc42be4")
addappid(335323, 1, "f20a2d2a01d9d95034b06ab318e30853bd0e19595473bcd40de95cbd072583c0")
addappid(335324, 1, "f2139bc1ea8e4b7e5a75ff57ce4ca39f58383eb99135fc9acb15b2617bedacef")
