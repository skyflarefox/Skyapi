-- Lua provided by SkyAPI 
-- Game: Little drift
addappid(1587610)
addappid(1587611, 1, "7a4c49c8c423e5a91a571a3f5382239dab9704579579ab0eda767fa9b5405170")
