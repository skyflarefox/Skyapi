-- Lua provided by SkyAPI 
-- Game: AppID 349980
addappid(349980)
addappid(349981, 1, "c5c2916eb826493f47c23808aa2ff9368e43641c7858e3f0b391ad53158913da")
