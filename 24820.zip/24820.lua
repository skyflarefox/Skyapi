-- Lua provided by SkyAPI 
-- Game: The Godfather
addappid(24820)
addappid(24821, 1, "f8f3488c8009877a9f45aa05b92c34cd41a1fbde33951f53887ffd76d5dcdc3c")
