-- Lua provided by SkyAPI 
-- Game: Oblitus mortis
addappid(3434340)
addappid(3434341, 1, "951d55fb1670c08c94e596f879320377f45817df1df0812ed5fa759ba8c38bb1")
