-- Lua provided by SkyAPI 
-- Game: AppID 962080
addappid(962080)
addappid(962081, 1, "fd8e3dba37fff26dc0e59d12b7ad637f2663cc0563b0a695c83d5442d928b230")
