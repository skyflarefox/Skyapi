-- Lua provided by SkyAPI 
-- Game: Vindictive Drive 2: Maidbot Archive
addappid(2641420)
addappid(2641421, 1, "84b38c5d572f93478ab1c950d2fe23d9205d4b5e6823d70c9c9ee10b26a4d1ee")
