-- Lua provided by SkyAPI 
-- Game: Alchemist's Secret
addappid(2816520)
addappid(2816521, 1, "e2dc882853c695c06b663a4335d4720972d1b2dff9386fed955f3c73bb5f31e4")
