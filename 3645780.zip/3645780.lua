-- Lua provided by SkyAPI 
-- Game: AppID 3645780
addappid(3645780)
addappid(3645781, 1, "0c31936417749b59d05309e53fc5a16ae1ca1ac6e5e86270e6df2474fb59c98e")
