-- Lua provided by SkyAPI 
-- Game: Flopparena
addappid(2115500)
addappid(2115501, 1, "5b8bebd71cb28c5f6bf31b102895d7c91ef4132b14d2f1ccfb75c37c28304df2")
