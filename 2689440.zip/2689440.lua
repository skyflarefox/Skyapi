-- Lua provided by SkyAPI 
-- Game: The Dawning Letters -Sunrise-
addappid(2689440)
addappid(2689441, 1, "bcd08f1c7f74bd975ca879229a3da245555c7e1f349fa892f87a7bcb80c233e6")
