-- Lua provided by SkyAPI 
-- Game: Wave Beta
addappid(453000)
addappid(453001, 1, "c4f0a57952b3b43a00caf110c6f52eb4ecb76151352d87fb320c8a75b10b493f")
