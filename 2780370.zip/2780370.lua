-- Lua provided by SkyAPI 
-- Game: Sex Simulator - Naughty Trainer
addappid(2780370)
addappid(2780371, 1, "bc16e8f5717d1ece49865fe4c190c7c1f022f7341003ff3f24b12ac5a487a5eb")
