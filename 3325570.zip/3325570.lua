-- Lua provided by SkyAPI 
-- Game: Kaodi
addappid(3325570)
addappid(3325571, 1, "d70aee716a0b7c675413abf222e42186d7f182305ca95643aca362740d39021b")
