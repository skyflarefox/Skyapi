-- Lua provided by SkyAPI 
-- Game: Black Reliquary
addappid(2119270)
addappid(2119271, 1, "7b30ef7ab8a2c269f056e00d523676a8325cc946a04ae262877060028e974c3f")
