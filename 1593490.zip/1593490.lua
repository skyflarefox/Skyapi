-- Lua provided by SkyAPI 
-- Game: Rescue Operation
addappid(1593490)
addappid(1593491, 1, "ae0f343e52458b0991ed13cb52c5f9297ad4c191f94119e95973c3955a3b82a6")
