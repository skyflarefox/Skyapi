-- Lua provided by SkyAPI 
-- Game: Hentai Melody
addappid(2355080)
addappid(2355081, 1, "e3e6e1fde91cc1e890b6873911a38d5840f62293ef9005391efae5f8e8080a85")
