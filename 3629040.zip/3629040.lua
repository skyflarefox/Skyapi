-- Lua provided by SkyAPI 
-- Game: Avium Playtest
addappid(3629040)
addappid(3629041, 1, "4fc209b77fc488a3f57057fad3d96b796efdeff1ac0052517a51137c1349f3f6")
