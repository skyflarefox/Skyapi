-- Lua provided by SkyAPI 
-- Game: AppID 1515330
addappid(1515330)
addappid(1515331, 1, "1032bdef2fe72df6c4e59a75103f7c77c7dfaf52c9759da13ffaff19f033e408")
