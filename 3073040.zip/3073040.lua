-- Lua provided by SkyAPI 
-- Game: Seoul Station
addappid(3073040)
addappid(3073041, 1, "d5355408014d53178ac224a6587a056472e7d3606d0ad44ee8c9862920a54b68")
