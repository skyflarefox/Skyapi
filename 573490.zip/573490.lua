-- Lua provided by SkyAPI 
-- Game: AppID 573490
addappid(573490)
addappid(573491, 1, "d48e8280304d1245c19aaf65dc98d9d4518ceed4b55d198994ef2db3d963da7e")
addappid(573492, 1, "d5f15f58c26c6ab547a54bc5d9ff962feba89ab66b264708b76f24cb77e590ac")
