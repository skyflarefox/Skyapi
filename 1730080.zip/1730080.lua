-- Lua provided by SkyAPI 
-- Game: AppID 1730080
addappid(1730080)
addappid(1730081, 1, "2e76d7a2039889adee6effc2fed6882b5f3e83c8fc010d2dc81ddf3811b266f0")
