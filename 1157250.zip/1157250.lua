-- Lua provided by SkyAPI 
-- Game: Anomaly Zone
addappid(1157250)
addappid(1157251, 1, "6b31cae9fddf57e22945cb5dd9162c7d3535c70f57a916b017e0cb59ac0a2ba2")
