-- Lua provided by SkyAPI 
-- Game: AppID 1935010
addappid(1935010)
addappid(1935011, 1, "5f069e1c1cc557d3b688153ac137dadecb6e15292e46060d6cd4f84b5e887575")
