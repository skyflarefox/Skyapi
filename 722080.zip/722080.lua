-- Lua provided by SkyAPI 
-- Game: Blue Snake Adventures
addappid(722080)
addappid(722081, 1, "b4930f568da6c09906f6a05d289bd08900549466b4c733946af477b72fd02a66")
addappid(722090, 0, "5b493f334703a193ac61ca6e3d7c6d04eb1c5f0ffcd9def83dd24954203cdc1e")
