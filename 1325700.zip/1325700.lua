-- Lua provided by SkyAPI 
-- Game: Space Haven Soundtrack
addappid(1325700)
addappid(1325701, 1, "490e6260a9b4b56188885697683e6a6017ee142f13838fd9b0c6af576be10285")
addappid(1325702, 1, "6345a6fc030388a087ef42110b89a928258f455f31a32b3405a198cbdd659ba4")
