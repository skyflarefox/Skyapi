-- Lua provided by SkyAPI 
-- Game: AppID 1081710
addappid(1081710)
addappid(1081711, 1, "5a044f3426ea8290ead2916f80e9fd7b5a0a1ecc3c2636ab79777b90fc194ad8")
