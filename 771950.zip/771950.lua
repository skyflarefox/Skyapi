-- Lua provided by SkyAPI 
-- Game: SUMETRICK
addappid(771950)
addappid(771951, 1, "6a7e66435492716761bf74788f276c6e2fa7f0059dd02e445e897b82487fd966")
addappid(776800, 0, "973440b104ba8292605ff7ea4e7a5c6431e3ab9ced2d36ae0211bb2edcfe1c98")
