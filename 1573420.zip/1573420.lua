-- Lua provided by SkyAPI 
-- Game: AppID 1573420
addappid(1573420)
addappid(1573421, 1, "c7b847a5913e7c293bacd14e75f171ac79164602f5b2924341139e68a3367148")
