-- Lua provided by SkyAPI 
-- Game: Steampunk Jigsaw Puzzles
addappid(2561360)
addappid(2561361, 1, "e624c5cfb77d4788302eb083175b1b1fdd54da12af36d2857aefa404c94f1e6d")
