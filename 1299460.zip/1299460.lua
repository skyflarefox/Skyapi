-- Lua provided by SkyAPI 
-- Game: Wanderstop
addappid(1299460)
addappid(1299461, 1, "d17456022f048ed4e2819c267b7442a6fc81b5a8b031710e23d704f284d251b3")
