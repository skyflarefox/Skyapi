-- Lua provided by SkyAPI 
-- Game: 101 Cats in Tokyo
addappid(3298590)
addappid(3298591, 1, "7b3906b8b2a9ed0ff9af376038b4ec0591b92364c93ac32db531a389ac64cd6f")
