-- Lua provided by SkyAPI 
-- Game: Space Reign
addappid(1762570)
addappid(1762571, 1, "5801a701e02460b48cb05757b53942ea34105ab70ce791d18b04344fb4e5e5d0")
