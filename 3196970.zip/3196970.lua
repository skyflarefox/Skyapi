-- Lua provided by SkyAPI 
-- Game: AppID 3196970
addappid(3196970)
addappid(3196971, 1, "27191398c2b6173d07d18938e75279f46d1f0656734ba23648bf7a2b855219b6")
