-- Lua provided by SkyAPI 
-- Game: AppID 1259840
addappid(1259840)
addappid(1259841, 1, "d861f228c28813fb0f5540e64bee4620ce146056d81198900c06881d6e784eda")
