-- Lua provided by SkyAPI 
-- Game: Irony Curtain: From Matryoshka with Love
addappid(866190)
addappid(866191, 1, "961862d3212ebfa9dd2f03e902112927b436cd835087c478d146a8e786039d8b")
addappid(1078741, 0, "63bdb60b9313c0bd4d6ce4f83d24ddab16ae252635fb361a8bf966b9431bcc6a")
