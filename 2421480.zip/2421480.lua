-- Lua provided by SkyAPI 
-- Game: Poly
addappid(2421480)
addappid(2421481, 1, "ca47391221726d95b0f9d18141773180487a4f719faca0583ce852a89786377b")
