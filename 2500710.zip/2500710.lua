-- Lua provided by SkyAPI 
-- Game: VoidBound
addappid(2500710)
addappid(2500711, 1, "7652e1f524e128a675ae5781df8731e8cba8bfb20e81868fdcac46e4ca45b94c")
