-- Lua provided by SkyAPI 
-- Game: AppID 1218930
addappid(1218930)
addappid(1218931, 1, "2e36d6554e9ba981aeeef1b93148198af63b4e43d76e8f79320551bac8ce05fb")
