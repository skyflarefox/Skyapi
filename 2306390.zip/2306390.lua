-- Lua provided by SkyAPI 
-- Game: Soul Knight: The Forest of Spirits
addappid(2306390)
addappid(2306391, 1, "039989a58fa43d9b94decb32954555254948ea7b2cfd80d7a03434f0f5f4585a")
