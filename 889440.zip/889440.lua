-- Lua provided by SkyAPI 
-- Game: AppID 889440
addappid(889440)
addappid(889441, 1, "32aca97653fd610457c17e920f3ec6fe646a91e05f606c4cc13fc64ca0812c05")
