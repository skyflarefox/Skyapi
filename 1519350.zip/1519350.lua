-- Lua provided by SkyAPI 
-- Game: Madden NFL 22
addappid(1519350)
addappid(1519351, 1, "c12c22ddc527c9f36ca8a82809b85dc5781d294e147e1d296cf677075706e493")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
