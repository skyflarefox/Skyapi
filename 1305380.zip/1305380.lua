-- Lua provided by SkyAPI 
-- Game: AppID 1305380
addappid(1305380)
addappid(1305381, 1, "d05236775fbea7f83b6a392acf1a7d3d9d71f7b6249defa9ff4c5317f5d9067e")
