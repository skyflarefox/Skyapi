-- Lua provided by SkyAPI 
-- Game: Black One Blood Brothers
addappid(1621560)
addappid(1621561, 1, "28de5a653d01514649d6e16ec7b28d6ee5ac2897abc4609b507964835bfab62d")
