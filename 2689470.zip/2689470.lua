-- Lua provided by SkyAPI 
-- Game: CRUEL
addappid(2689470)
addappid(2689471, 1, "bf7dfabb9ffa695bfb5f72b1d1ecadae3ef1752843c38ad898ec38f72273dcaf")
