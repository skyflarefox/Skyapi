-- Lua provided by SkyAPI 
-- Game: NejicomiSimulator Vol.4 Demo
addappid(1931610)
addappid(1931611, 1, "e43e0129f49044729decdb88c6d6a78a4375ce35771bf6c348ec34087b3e43cc")
