-- Lua provided by SkyAPI 
-- Game: AppID 1455920
addappid(1455920)
addappid(1455921, 1, "532d5950edde40d1248022fdaf5e5be966e01ee19e1f106187a14f94ca1a5edf")
