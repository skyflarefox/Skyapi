-- Lua provided by SkyAPI 
-- Game: OBSCURA
addappid(2342920)
addappid(2342921, 1, "372d08f03d618294fbd92e12ac6f207df23a9de4c5f57bfbfb15edd7b9500363")
