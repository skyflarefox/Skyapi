-- Lua provided by SkyAPI 
-- Game: Death Ski
addappid(1483580)
addappid(1483581, 1, "8bf29917d2aa980234a023cf7471c66134bacf687359387f9fe9b1830ac06a0b")
