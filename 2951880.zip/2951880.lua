-- Lua provided by SkyAPI 
-- Game: Travellin Cats Around the World 2
addappid(2951880)
addappid(2951881, 1, "2256502c66b1481b9e7ea022e0ea314909eb3c8f6f4ee80fcda2b5059bf516bd")
