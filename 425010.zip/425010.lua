-- Lua provided by SkyAPI 
-- Game: AppID 425010
addappid(425010)
addappid(425011, 1, "7c1a981800010cdf902e49bc28861284d3e029964913b9780613f6597db2c11e")
