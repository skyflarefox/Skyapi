-- Lua provided by SkyAPI 
-- Game: Second Sight
addappid(11550)
addappid(11551, 1, "cfd4dfdb9aa688f87fc4c92629d381cf0fa5362fa36c0bc5c6fec05ebf9f698f")
