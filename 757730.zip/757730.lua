-- Lua provided by SkyAPI 
-- Game: Shadowcrawl: The Dark Pilgrimage
addappid(757730)
addappid(757731, 1, "ca2778ea1de88fe03e9fc610d45fc6a3514918cbec835d4d001a8cc1082c260f")
