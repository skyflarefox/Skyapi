-- Lua provided by SkyAPI 
-- Game: Barrow Hill: The Dark Path
addappid(520990)
addappid(520991, 1, "f487efe30ff8ff4a7c2a317fdd64f0109783aea8ce43d388b287635022afa081")
addappid(520992, 1, "6296d010c3ef2ab8e63082fa2c7019df8faaa92b8ff9e972939aa70acabf12d4")
