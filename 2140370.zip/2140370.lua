-- Lua provided by SkyAPI 
-- Game: AppID 2140370
addappid(2140370)
addappid(2140371, 1, "48b875648824324fe272bfedb5d0888fee07f6162319c53acbd940c16a82beff")
