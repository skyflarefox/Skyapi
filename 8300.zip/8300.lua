-- Lua provided by SkyAPI 
-- Game: Sam & Max 205: What's New Beelzebub?
addappid(8300)
addappid(8301, 1, "072a8e968e3866d1a335521df02650e9509eaf8a964a18dc31c073c7710f236f")
addappid(8302, 1, "90e2ac67ffd72efa87b6360fae2c7e3e159c007c4673021c18d85b8b924c6cdf")
