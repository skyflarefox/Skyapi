-- Lua provided by SkyAPI 
-- Game: AppID 1206180
addappid(1206180)
addappid(1206181, 1, "ac7bd2c5002c5bf042b9e44ac95651a93c606029516bd3fbcd96e339c5a80072")
