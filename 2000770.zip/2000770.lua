-- Lua provided by SkyAPI 
-- Game: Ballance
addappid(2000770)
addappid(2000771, 1, "cd3e0cb07ab504552cc2159a81353daff01a6d4448632d91ae3b38c9e8a5e9cb")
