-- Lua provided by SkyAPI 
-- Game: Hentai Puzzle Universe
addappid(2264210)
addappid(2264211, 1, "e7bea39402cce0a7c1acc6dd5dbc6415255422b58abc6d197186f9876e56cc5e")
