-- Lua provided by SkyAPI 
-- Game: Minigolf Galaxy
addappid(2303080)
addappid(2303081, 1, "81a6fbc3e6744d7dc8563f6f97067ed84e6ce992d6c0324ed2b94eb65a8600b6")
