-- Lua provided by SkyAPI 
-- Game: DRAW CHILLY
addappid(839080)
addappid(839081, 1, "66cc2da6a55615512023c4611242292baea0aa4c07c7e8e38091f6f429fd05c5")
