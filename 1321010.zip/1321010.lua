-- Lua provided by SkyAPI 
-- Game: AppID 1321010
addappid(1321010)
addappid(1321011, 1, "e6e34bfb352da1c5d524312a0143f27c5aae8999fa06ab6b7b164134cdaa7a67")
