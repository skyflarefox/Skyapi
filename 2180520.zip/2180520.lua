-- Lua provided by SkyAPI 
-- Game: AppID 2180520
addappid(2180520)
addappid(2180521, 1, "6ea8d814caaa052ae245e5525ddcbe799f4d8f32c6d504754b1e4d2ce8787efa")
