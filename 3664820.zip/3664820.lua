-- Lua provided by SkyAPI 
-- Game: AppID 3664820
addappid(3664820)
addappid(3664821, 1, "a5f074a366a8dd4ab0bd26ffde13a7503f5081b8a683e089237f418194ee04c3")
