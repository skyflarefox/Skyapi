-- Lua provided by SkyAPI 
-- Game: AppID 1231970
addappid(1231970)
addappid(1231971, 1, "3fdd5d3ab3e168c155b9ce14e38d31b996fa245ded6f10d1d4741f3025e9dec7")
