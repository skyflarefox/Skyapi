-- Lua provided by SkyAPI 
-- Game: Mining Factory
addappid(2210810)
addappid(2210811, 1, "8b0e46c890d13a3423e5294cf9f710cebb469a02837cce5d9d439a040c4ce154")
