-- Lua provided by SkyAPI 
-- Game: AppID 1283740
addappid(1283740)
addappid(1283741, 1, "ba48bbebb3b03b357fc409773571d08737bc029821a9fdd73b6f9b8eb220d907")
