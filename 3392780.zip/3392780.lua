-- Lua provided by SkyAPI 
-- Game: Shadow Siege
addappid(3392780)
addappid(3392781, 1, "115186b84f20ede09b8f330e868464bc65b3f2e39bae65e538bb18b1a1ed4b2f")
