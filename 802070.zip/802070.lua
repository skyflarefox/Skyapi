-- Lua provided by SkyAPI 
-- Game: AppID 802070
addappid(802070)
addappid(802071, 1, "465962527a41f5c3e46f0af508f6250a6b27e6eced8ea2c9f81a559d050cd4ca")
