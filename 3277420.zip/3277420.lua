-- Lua provided by SkyAPI 
-- Game: AppID 3277420
addappid(3277420)
addappid(3277421, 1, "dcd650c29fa863623eb0bfe500e6c83c85e4fd2ca096d7f451118df7de069b80")
