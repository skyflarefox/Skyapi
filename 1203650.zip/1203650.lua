-- Lua provided by SkyAPI 
-- Game: AppID 1203650
addappid(1203650)
addappid(1203651, 1, "1485f32146cab64acfcd7324850987cc8dabdf2490934ec7b6bcf72c35a12d64")
