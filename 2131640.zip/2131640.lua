-- Lua provided by SkyAPI 
-- Game: METAL GEAR SOLID 2: Sons of Liberty - Master Collection Version
addappid(2131640)
addappid(2131641, 1, "9e0f2cb55b09888aff90e9aade07595c51381b2dd13720057b88e569fc795868")
addappid(2314260, 0, "9eea628721d13db63c23c3818238e17b8ce84693d659577fcb951ec4fb35110f")
addappid(2314261, 0, "39588cf7f429a47c8ebafcd19084333ca255a9e983122f3b329bb57e00661727")
