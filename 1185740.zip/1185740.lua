-- Lua provided by SkyAPI 
-- Game: AppID 1185740
addappid(1185740)
addappid(1185741, 1, "d9fcb1fe5af6d5a028746071391b9f27f19e1fbda065f2cd47306d3b7daa777f")
