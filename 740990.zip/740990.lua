-- Lua provided by SkyAPI 
-- Game: AppID 740990
addappid(740990)
addappid(740991, 1, "cf3e1ff3e37698fcc43f294afcc9fb3e98631b38c1c3b7a94f703d4b9c8fb7ca")
