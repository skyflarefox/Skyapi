-- Lua provided by SkyAPI 
-- Game: AppID 2971920
addappid(2971920)
addappid(2971921, 1, "ae017c7fc02bef5c2870aaec7ed0c2401336e55a3c9cb6d0eab9cbfd279629ba")
