-- Lua provided by SkyAPI 
-- Game: Ninpaw
addappid(2523650)
addappid(2523651, 1, "0e72b3ae328c3935df5179eb5fac7fb4bb27ad007255f81a345f44788e7eb959")
