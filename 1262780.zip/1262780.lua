-- Lua provided by SkyAPI 
-- Game: AppID 1262780
addappid(1262780)
addappid(1262781, 1, "866df8d1e60f32ea7d262bec9bcb0a7e215c5a1c00ee3565d2a2f5fc818bac49")
