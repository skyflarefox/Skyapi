-- Lua provided by SkyAPI 
-- Game: DEMON GAZE EXTRA
addappid(1732340)
addappid(1732341, 1, "1207092ee029140ed2eff6e778a50219b80cd2379420b6e3aa1563d3ddd63ad3")
