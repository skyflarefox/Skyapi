-- Lua provided by SkyAPI 
-- Game: WIL
addappid(717940)
addappid(717941, 1, "bf29af6dfc07f5331572f0d375a704b91922371cd73ca51d0368e24a6c3c6936")
