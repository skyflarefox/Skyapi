-- Lua provided by SkyAPI 
-- Game: Apocalypse Hotel - The Post-Apocalyptic Hotel Simulator!
addappid(423700)
addappid(423701, 1, "8bd91c27bc5ca9ee87ce3c74ce98f5873daf94d62d68b70daca92e24874b0044")
addappid(443710)
addappid(446900)
