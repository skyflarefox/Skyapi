-- Lua provided by SkyAPI 
-- Game: AppID 3139890
addappid(3139890)
addappid(3139891, 1, "0d6a1dd1b167221ae493fcfd7d637899ead4a54a8381f2603ba1c21c870541f4")
