-- Lua provided by SkyAPI 
-- Game: AppID 1695340
addappid(1695340)
addappid(1695341, 1, "4359a65499f286751c8a33d52eb1e5656c93646a83e4707fe9f3d95a8b900ec9")
