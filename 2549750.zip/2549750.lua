-- Lua provided by SkyAPI 
-- Game: Mow That Lawn
addappid(2549750)
addappid(2549751, 1, "f4e3bb6eb78e43459f4c2732e43a0e115c36a57698c02c043550464e34b050e8")
