-- Lua provided by SkyAPI 
-- Game: Sexy Girl Next Door - Virtual Valentine Sex
addappid(3115840)
addappid(3115841, 1, "3180f7ad45376d2df8da7e98444b2ae2b7434f57b731ca208afc9079867f4ef4")
