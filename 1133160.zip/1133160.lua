-- Lua provided by SkyAPI 
-- Game: AppID 1133160
addappid(1133160)
addappid(1133161, 1, "3dd00c9a6da67b0864f3069c9a8040c4f2f647b47f75326a1cd58c725de146f1")
