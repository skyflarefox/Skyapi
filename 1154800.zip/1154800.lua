-- Lua provided by SkyAPI 
-- Game: AppID 1154800
addappid(1154800)
addappid(1154801, 1, "95da9af8cf68ebfe7b3bd1b992619e2d6eed15b3f7fbe1a4e5675d1158b98f16")
