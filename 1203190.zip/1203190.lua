-- Lua provided by SkyAPI 
-- Game: AppID 1203190
addappid(1203190)
addappid(1203191, 1, "46aa2b5ac9dd960c2fb3808c8033df048fede7062052f754db267609ecbef621")
