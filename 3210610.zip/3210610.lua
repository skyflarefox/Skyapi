-- Lua provided by SkyAPI 
-- Game: Boyhood's End - Digital Soundtrack
addappid(3210610)
addappid(3210611, 1, "8ef8c4b02011531656b8968b33fffe80aba1937afe89d220abdb5f6509b612e4")
