-- Lua provided by SkyAPI 
-- Game: Thomas Scott
addappid(1279480)
addappid(1279481, 1, "0848ca8f7576fb3b3905eb7e8a7bbde3d463bbbb33c9123b74d0de0fe41278ed")
