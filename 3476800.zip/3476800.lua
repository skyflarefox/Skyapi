-- Lua provided by SkyAPI 
-- Game: Anturi
addappid(3476800)
addappid(3476801, 1, "c6693ecfd7a8c0e9f2d552aca94109b0797bf644c61df9cc34e3f7a3f9c30e3c")
