-- Lua provided by SkyAPI 
-- Game: AppID 2767140
addappid(2767140)
addappid(2767141, 1, "182c17a7616529020d9f0bcd9f37c2074e5467a948036575b8e58624ed789ca8")
