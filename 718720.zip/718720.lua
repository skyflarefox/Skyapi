-- Lua provided by SkyAPI 
-- Game: DEATHPIT 3000
addappid(718720)
addappid(718721, 1, "8008b8166416b8efc601288f14018a6b6a74951ed5f565cb71a1b4102c67e15b")
