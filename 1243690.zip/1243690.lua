-- Lua provided by SkyAPI 
-- Game: Gods Will Fall
addappid(1243690)
addappid(1243691, 1, "d32aeb7b89cafa56d8c3f9e512dd64eb7026842d81ac6d95e5b6fee18d9da778")
addappid(1636180)
