-- Lua provided by SkyAPI 
-- Game: To Trust an Incubus
addappid(825300)
addappid(825301, 1, "f0cf1ebebfa068f75682026fdaf87e892c08bf184bab99fd014865aca04c0694")
addappid(968273, 0, "d5c7f1f5c7f2ea646ec63a029a337ad765db19c37fecb90f40e37c15dc2d6cab")
