-- Lua provided by SkyAPI 
-- Game: Aurora
addappid(1422610)
addappid(1422611, 1, "6d67077da653147f7614fef1fb3889c819b3bf179629275f143de1f7e79a07c1")
addappid(1474340, 0, "9e3ee0442a88f0743f6acf0bc91533b6b718c8ca4303e22d2d198504a60efa5d")
