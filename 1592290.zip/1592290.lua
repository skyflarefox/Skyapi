-- Lua provided by SkyAPI 
-- Game: Paranoia Place: Escape Together
addappid(1592290)
addappid(1592291, 1, "acd2f8b4b5818e8958a6f694789fe7f6c3127753e27e8da0c99dfe11a97bab22")
