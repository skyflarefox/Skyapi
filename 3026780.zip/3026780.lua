-- Lua provided by SkyAPI 
-- Game: Grand Circuit Demo
addappid(3026780)
addappid(3026781, 1, "0a801504e583b5f682b08adafbdbdf1efc520741353ad0966420ab858808bd26")
