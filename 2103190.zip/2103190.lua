-- Lua provided by SkyAPI 
-- Game: Reilla ~Sweets Adventure~
addappid(2103190)
addappid(2103191, 1, "d424ea93323f701b415f34c8da682f535efd21e22d7186643610409982b11054")
