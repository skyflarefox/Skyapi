-- Lua provided by SkyAPI 
-- Game: The Letter - Horror Visual Novel
addappid(460430)
addappid(460431, 1, "dcfc7d89afcf650def01d20ede66c9c3e2e44ca5742e33b96b6611dd8119408d")
addappid(460432, 1, "d18351df5abc1cd890d068a20c0b1f4fa997622fd6839bd7696941f669febe2d")
addappid(460433, 1, "0027ecd96534d4a58a90d6cc65fa15d0ed48e38decadf17a7b2e9425270789d3")
addappid(742350, 0, "f5472f987e7c359ec907bb3535b11df0d7a16980402e4d23f64f3cd1bbf6f6df")
