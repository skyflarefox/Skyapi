-- Lua provided by SkyAPI 
-- Game: Silence In The Cabin
addappid(2240910)
addappid(2240911, 1, "6ecf71aaefabd000eda907b5c8167b0688443061e6d2d0b7ce2cc381bb06c736")
