-- Lua provided by SkyAPI 
-- Game: AppID 2418150
addappid(2418150)
addappid(2418151, 1, "1738e8d8df67072a1b5c74b36c3f05025f540d3e62d691b09fde3e30aa11383d")
