-- Lua provided by SkyAPI 
-- Game: SpaceKraft!
addappid(1703020)
addappid(1703021, 1, "0d516cd5cbf102de9ba78d2a45a9d0c8a529d921a3baf5d608ad3e2b4a35dc72")
