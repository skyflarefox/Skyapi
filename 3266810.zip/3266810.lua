-- Lua provided by SkyAPI 
-- Game: Jetpack Birdie Playtest
addappid(3266810)
addappid(3266811, 1, "0dc0ce04d653a02a0c211740b662b1978c66dd4b1d9017746305778ccbdba6ed")
