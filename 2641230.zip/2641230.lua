-- Lua provided by SkyAPI 
-- Game: Mazes and Labyrinths
addappid(2641230)
addappid(2641231, 1, "602812a82cb416e4b699dc1900732af45e0743c813ec6865842656cb74ba6bef")
