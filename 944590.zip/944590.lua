-- Lua provided by SkyAPI 
-- Game: AppID 944590
addappid(944590)
addappid(944591, 1, "a7576c3316fdb88ab3ab08c95a8fac16fd4b9941c6fa5b7a09eed4dd2b6f0b49")
