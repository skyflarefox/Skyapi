-- Lua provided by SkyAPI 
-- Game: Ratopia
addappid(2244130)
addappid(2244131, 1, "7340a83f2505a34c0c785f3f3987f8ce558a86a11e0d806d8d8cd6d7a2f742ec")
