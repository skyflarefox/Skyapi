-- Lua provided by SkyAPI 
-- Game: Super Bit Blaster XL
addappid(865040)
addappid(865041, 1, "5d0ab197caecf3318014b9c77389078031ccf4c0ed488fa9c8acb19d87704d6f")
