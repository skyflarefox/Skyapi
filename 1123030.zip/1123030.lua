-- Lua provided by SkyAPI 
-- Game: WHO IS AWESOME
addappid(1123030)
addappid(1123031, 1, "7a831183dce67d62306c50fd9e64b3115a8eb81d3b2392f455960832ff963518")
