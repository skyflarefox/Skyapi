-- Lua provided by SkyAPI 
-- Game: Verbal Verdict
addappid(2778780)
addappid(2778781, 1, "a68992db63dc62a430f08b8ac1c1fe722fef1c4dd9a5a4317b9c4f0fc4ac05b1")
