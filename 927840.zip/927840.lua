-- Lua provided by SkyAPI 
-- Game: AppID 927840
addappid(927840)
addappid(927841, 1, "75afa4752695f7b33de11d167f0a142b1a70bc1a99ae35ae2ed37311bd9328e5")
