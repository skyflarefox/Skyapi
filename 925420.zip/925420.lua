-- Lua provided by SkyAPI 
-- Game: AppID 925420
addappid(925420)
addappid(925421, 1, "a1d1b93c4791503c866e2870a067c61e897d49fdcb50a7b6fe978d6263a57336")
