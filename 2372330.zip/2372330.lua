-- Lua provided by SkyAPI 
-- Game: Poetry of Blood: Eclipse
addappid(2372330)
addappid(2372331, 1, "07f41754bba0b990ab7cb40d3b98264155d8095234b71eed3a3e2fca7dbf3462")
