-- Lua provided by SkyAPI 
-- Game: AppID 2430930
addappid(2430930)
addappid(2430931, 1, "167990c9090224e269e4239efcec5810b0bbd3972ad9310b8d3b2c48cc88221d")
