-- Lua provided by SkyAPI 
-- Game: Race.a.bit
addappid(336030)
addappid(336031, 1, "f8be52da492eac147c1f2c6407d1f10e8eeaf79d8ab0f96f9c2bc54b9e20e6dd")
addappid(336032, 1, "f85bc40d976cf0fc10b5ee2bea8a6ffb592edcf9ff3fc3ec148e1de61bc36f1a")
addappid(336033, 1, "386827407d4fa8e56657e785df177910c045235f7d0502273188d0641de6ac3c")
addappid(336034, 1, "2006745a75746c4294fc243319f531e2d83de4f905cbb402f5e87091e5887e3c")
