-- Lua provided by SkyAPI 
-- Game: BrokenLore: DON'T WATCH DEMO
addappid(3272530)
addappid(3272531, 1, "07cfe6ffe16bcc0caaad67dbf05c9d9e074b011bbb3ef0ab84b5f7dab2f2e813")
