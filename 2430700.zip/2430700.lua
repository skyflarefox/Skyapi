-- Lua provided by SkyAPI 
-- Game: Love X Crotch X GYM
addappid(2430700)
addappid(2430701, 1, "afbc916900bc78d7753c3fd2886678938a2708d44c7729f2b9bd6bcc45343e0a")
