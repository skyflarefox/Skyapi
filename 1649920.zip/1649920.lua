-- Lua provided by SkyAPI 
-- Game: AppID 1649920
addappid(1649920)
addappid(1649921, 1, "2c6ef6c5b21805d6599635f2ba5f82e3d4a99b63f9c1c383bf37d17c08941dee")
