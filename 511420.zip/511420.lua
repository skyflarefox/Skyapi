-- Lua provided by SkyAPI 
-- Game: AppID 511420
addappid(511420)
addappid(511421, 1, "11fe738ee0a54e3eacbb2e9d58490ec7db0222aeb3df82b8fc5b8a43327dc714")
