-- Lua provided by SkyAPI 
-- Game: Interrogation Simulator
addappid(2059480)
addappid(2059481, 1, "430ed7f8e029a3ba968befe067966a3d2b6724a4fa0c82af87d12ca9d2881fba")
