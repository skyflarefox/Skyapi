-- Lua provided by SkyAPI 
-- Game: AppID 277950
addappid(277950)
addappid(277951, 1, "740cb4098eb16010bc602aa63a09dac96e2047105c2e8bef1ad1b7947ea27ef3")
