-- Lua provided by SkyAPI 
-- Game: BRUTALISTICK VR
addappid(2669380)
addappid(2669381, 1, "090e1bcded479bdd950b9884d5966cfa9ee95438a9857d823c3d288f80a7ac70")
