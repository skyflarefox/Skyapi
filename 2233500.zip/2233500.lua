-- Lua provided by SkyAPI 
-- Game: Tribe: Primitive Builder Playtest
addappid(2233500)
addappid(2233501, 1, "35cd0754a6b1dd0de92618ac123ae789c9f2272841f0c57949ebc6595e49c9f3")
