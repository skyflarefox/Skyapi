-- Lua provided by SkyAPI 
-- Game: Meridian 157: Chapter 3
addappid(1689870)
addappid(1689871, 1, "9421a5da95ed04715a38e36322b516f22c8e49b8759140e48742834b37194219")
