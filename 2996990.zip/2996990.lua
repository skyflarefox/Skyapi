-- Lua provided by SkyAPI 
-- Game: Flag Clicker
addappid(2996990)
addappid(2996991, 1, "1c8e6975946ddbde1455937580cde66b08917829cc3088c261a4477b114a25d8")
