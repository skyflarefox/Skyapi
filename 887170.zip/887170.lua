-- Lua provided by SkyAPI 
-- Game: AppID 887170
addappid(887170)
addappid(887171, 1, "114613e3f4ae04a4bf2a31a6c10636261752f6f833a5fd87fa9db466e7243fce")
