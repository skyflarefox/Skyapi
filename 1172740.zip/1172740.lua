-- Lua provided by SkyAPI 
-- Game: AppID 1172740
addappid(1172740)
addappid(1172741, 1, "8b82b5e401e704a5afb9a9ed9d862aa7f04a592a188899e5fe6eba15e5a05fce")
