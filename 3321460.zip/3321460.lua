addappid(3321460, 1, "dc014470e47064263f3003feb526a87cc64784292e2a608455d18fa70ec2c1e0") -- Crimson Desert
addappid(3321461, 1, "e2e570c84eb8b4cfe9c20268cd30b84f8c1c7c076691c92ae8c5ba7b510b8a95") -- Depot 3321461
addappid(3321462, 1, "6eb3bfe7d16b9eb6441dba4f7d18b341fe83ab2f1e9385d042ce622f38a600cb") -- Depot 3321462
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4024620) -- Crimson Desert - Deluxe Pack
addappid(4024630) -- Crimson Desert - Pre Order Pack
addtoken(4024630, "17135069641874014023")
addappid(4193060) -- Crimson Desert - Ultimate Pack