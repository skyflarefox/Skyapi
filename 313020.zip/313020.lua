-- Lua provided by SkyAPI 
-- Game: Soul Gambler
addappid(313020)
addappid(313021, 1, "5c0696b457082f7ecae0e89ee04bb16b8b8c1262fcbc3a202646f9c25482c17f")
addappid(313760, 0, "8e136921c8ce5bc4b3a3af5b768394899e653aac55508d99e2a5ce4d7b3502eb")
