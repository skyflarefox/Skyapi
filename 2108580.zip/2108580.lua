-- Lua provided by SkyAPI 
-- Game: AppID 2108580
addappid(2108580)
addappid(2108581, 1, "82447be4625f913a2b88ab3e0525bc9f66a8793ba25d6cb7a1918e0a71b35e11")
