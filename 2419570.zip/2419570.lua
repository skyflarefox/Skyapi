-- Lua provided by SkyAPI 
-- Game: AppID 2419570
addappid(2419570)
addappid(2419571, 1, "4d1c712f337a4256e1691b5ac52767e0101c61d0eecaad35ebcc7eef011886e7")
