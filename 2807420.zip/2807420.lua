-- Lua provided by SkyAPI 
-- Game: Spellfort Demo
addappid(2807420)
addappid(2807421, 1, "bf6c3e6397cdaeac09d2b290125ef8a3f1e7723032662993a1b8a42edc1521fd")
