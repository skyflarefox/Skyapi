-- Lua provided by SkyAPI 
-- Game: AppID 888040
addappid(888040)
addappid(888041, 1, "e7c113c3591b403342314c08a967a28740da94e6c05987e2da7ebd2196e01688")
addappid(888042, 1, "0f1b8bbd841e05fb5ac862115fc779e299bd04f0ddbdfac3c26e53dfff87ec01")
