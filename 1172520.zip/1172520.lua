-- Lua provided by SkyAPI 
-- Game: AppID 1172520
addappid(1172520)
addappid(1172521, 1, "5d5edba858bcffdeb50ae5c227186a9c8181e7bdc6f011568fe746b8a302bba0")
addappid(1172522, 1, "e7e27eab87f9668461eb70e85261bf6a42dc7ae95b712d77da4c6d50da36b924")
