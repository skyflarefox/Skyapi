-- Lua provided by SkyAPI 
-- Game: Lunacid
addappid(1745510)
addappid(1745511, 1, "d07aafcd878b15a1b9e8c79d8197df4971a4392d31c00e32580055c4f5a9b012")
