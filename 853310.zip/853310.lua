-- Lua provided by SkyAPI 
-- Game: AppID 853310
addappid(853310)
addappid(853311, 1, "098ca944b38d023024886d9e36d106723f7b345416c5c14a8a5991de2fba1060")
