-- Lua provided by SkyAPI 
-- Game: Alisa
addappid(1335530)
addappid(1335531, 1, "2d17f7797a7334cdf7fd328185995bd76b2d9ce1d9b258303f8080c88d740815")
