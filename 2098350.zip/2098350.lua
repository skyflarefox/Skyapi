-- Lua provided by SkyAPI 
-- Game: Escape Memoirs: Mini Stories
addappid(2098350)
addappid(2098351, 1, "34202c22271c288aa527cea772c8beb990ccf489d2a6d124aac1c5858def4bac")
