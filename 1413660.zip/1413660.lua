-- Lua provided by SkyAPI 
-- Game: Elderand
addappid(1413660)
addappid(1413661, 1, "b1332b5755e3bab36587c10b18dd191021c63d01316179bf28429c9a347704cf")
