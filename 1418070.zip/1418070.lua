-- Lua provided by SkyAPI 
-- Game: Vigil: The Longest Night Soundtrack
addappid(1418070)
addappid(1418071, 1, "0fc14254748cf52a5ffb674a38106b62956b421a187233f66381af16c9e4236c")
addappid(1418072, 1, "55320f667cab00d7690be42717a64ce334d2f001959066648aa28b6f048e547c")
