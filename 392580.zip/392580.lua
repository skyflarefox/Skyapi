-- Lua provided by SkyAPI 
-- Game: AppID 392580
addappid(392580)
addappid(392581, 1, "8651fc07fa6b55b50ab52db6474959fd7e6712e476f59baca470e7be7858ce5d")
