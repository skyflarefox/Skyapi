-- Lua provided by SkyAPI 
-- Game: AstroBike
addappid(1539600)
addappid(1539601, 1, "083efa9f7a65bf6092e884db552effc894ddd3f9be897338acacf05f9920e228")
addappid(1539602, 1, "bb9dfdbf5bea40bc7032150be8ef8dfe98564cd804fd1c9c820b0889448d9711")
addappid(1539603, 1, "ed033b0ec5ef2c6645a022c9d74421897a72f7f35d0593957a0887a6c67fb805")
