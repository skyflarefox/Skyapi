-- Lua provided by SkyAPI 
-- Game: Tinker Racers
addappid(1234620)
addappid(1234621, 1, "91cb259cada019145ee85554bd5e8de1dd1d7d02f3c652dcefef693eaaa1e086")
