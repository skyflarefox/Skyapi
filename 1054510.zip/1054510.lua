-- Lua provided by SkyAPI 
-- Game: AppID 1054510
addappid(1054510)
addappid(1054511, 1, "4bb6f2708dc837f78156fadb98d5d7e0c06e598c26f6a4dac7a3711064372e7c")
