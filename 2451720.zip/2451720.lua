-- Lua provided by SkyAPI 
-- Game: Slayin DX
addappid(2451720)
addappid(2451721, 1, "c2d3a128c851290fb321d82b2b33de2e89f14c061bcae65d74ae5478a7913976")
