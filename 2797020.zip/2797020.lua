-- Lua provided by SkyAPI 
-- Game: AppID 2797020
addappid(2797020)
addappid(2797021, 1, "6dfffb9521733483a5c34db3129a6f61f233d74c6d0cebbb6365f628c6fa0e60")
