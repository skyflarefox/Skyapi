-- Lua provided by SkyAPI 
-- Game: PILGRIM
addappid(2965660)
addappid(2965661, 1, "f0915354709d3813ae653f8bd002cfb65030eda052000e004b678946d8060ce4")
