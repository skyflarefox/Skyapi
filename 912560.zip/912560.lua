-- Lua provided by SkyAPI 
-- Game: AppID 912560
addappid(912560)
addappid(912561, 1, "1533d3bdd560769d6ad712bcac06f56d04bad7d96dd21256e5278ce9884d53e7")
