-- Lua provided by SkyAPI 
-- Game: The Picture in The House
addappid(1489010)
addappid(1489011, 1, "922fd3b138a6f3be50798e56303d050651eba66735090ccbcd17ab022df3f613")
