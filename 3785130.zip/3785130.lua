-- Lua provided by SkyAPI 
-- Game: Shop Mistress NTR
addappid(3785130)
addappid(3785131, 1, "2e85f5a855a4c29b2f27b04f3f0c5fdfb025fa607c5d5864682e2015b8e6bd6e")
