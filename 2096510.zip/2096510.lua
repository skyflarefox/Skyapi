-- Lua provided by SkyAPI 
-- Game: The Ouroboros King
addappid(2096510)
addappid(2096511, 1, "a8a921b3d9869991f4c4e13aef96fe20085bfb03140a8ccfd9969ef6a9ebefc4")
