-- Lua provided by SkyAPI 
-- Game: Shadow of Fear
addappid(2644260)
addappid(2644261, 1, "d1e7856b96b6963dca7a42328c056d632fa504324234e6d6d7b856005423a10a")
