-- Lua provided by SkyAPI 
-- Game: AppID 1639860
addappid(1639860)
addappid(1639861, 1, "d7e164792228df959b6cf8767ea105f554eb85135b075dc70e4af8669633c42b")
