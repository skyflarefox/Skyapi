-- Lua provided by SkyAPI 
-- Game: BEAT AIMER! Demo
addappid(2146890)
addappid(2146891, 1, "1b69fd3c188311a500099bfcbd0aff07a51a6278c37dae4ae6571ac2d2da73aa")
