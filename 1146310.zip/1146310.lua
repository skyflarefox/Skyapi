-- Lua provided by SkyAPI 
-- Game: AppID 1146310
addappid(1146310)
addappid(1146311, 1, "82b5631117e585c70bc2ec981e702ba1eb3a279e5a4e402013f735712442182f")
addappid(1368360, 0, "6f8bd8f553d8ac0a77c1e7bd8ced741fedce382bf90ba4a8c3bbb28f784c0d79")
