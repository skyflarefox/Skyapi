-- Lua provided by SkyAPI 
-- Game: FMTC Playtest
addappid(2454930)
addappid(2454931, 1, "166d5df7c7dbb95b73b9664e64c1b4563e2b7fd697ae41665b3f2111666fa50e")
