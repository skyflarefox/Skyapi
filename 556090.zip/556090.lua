-- Lua provided by SkyAPI 
-- Game: FIGHTING SPACE
addappid(556090)
addappid(556091, 1, "c1b3dce4d0ba176088acb5728f6537b5ebe70256adcdab2e2cc3c3d0f93042a3")
