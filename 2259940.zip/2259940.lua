-- Lua provided by SkyAPI 
-- Game: AppID 2259940
addappid(2259940)
addappid(2259941, 1, "d28e9401dbe3d468a82842b0bcd6b980663533aaf6e82ab8b7b073cb898dd068")
