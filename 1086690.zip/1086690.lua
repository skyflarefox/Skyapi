-- Lua provided by SkyAPI 
-- Game: AppID 1086690
addappid(1086690)
addappid(1086691, 1, "78e45c327e2e3ec47d8d2da2268af6d8711c77805391e263d304238e4b530f5a")
addappid(1115460)
addappid(1182180)
