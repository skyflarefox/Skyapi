-- Lua provided by SkyAPI 
-- Game: Three Days to Chicago
addappid(2495380)
addappid(2495381, 1, "61922cf011178dd56c8f433c3912aeceaa2fd9de174d3b0cb96a7587a5031966")
