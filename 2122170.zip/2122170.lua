-- Lua provided by SkyAPI 
-- Game: MEGA
addappid(2122170)
addappid(2122171, 1, "70283a6a2d131834c048a2aa70e7033887639e4a73c09e669b472993ef651223")
