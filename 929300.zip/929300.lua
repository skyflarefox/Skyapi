-- Lua provided by SkyAPI 
-- Game: Chroma : Sexy Hentai Girls
addappid(929300)
addappid(929301, 1, "d3290485b35d9171aa3ae631181d268b1af4f886de1e8758847413d77a34450e")
addappid(929302, 1, "4870b8bffdefff31e0d44e8ac8a759995fff9b0ee5c869d3037ad40477de3510")
