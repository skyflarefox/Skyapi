-- Lua provided by SkyAPI 
-- Game: AppID 644640
addappid(644640)
addappid(644641, 1, "d8171b52487a91c21b03ef1aeccb5eb46cb58c1e060281a714a53dd4f8c4a9ed")
