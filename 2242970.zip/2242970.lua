-- Lua provided by SkyAPI 
-- Game: Project Tower
addappid(2242970)
addappid(2242971, 1, "0251711471aa300c2239374363a89f820f07217615a83d02c2175ec8bbb31d5c")
