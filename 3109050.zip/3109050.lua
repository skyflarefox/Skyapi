-- Lua provided by SkyAPI 
-- Game: Waifu
addappid(3109050)
addappid(3109051, 1, "ac8350cec66d95ce0f8925bc4eb8cc7d3a2921aac2a3d50edc87e1f40f11806d")
