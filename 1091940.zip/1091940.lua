-- Lua provided by SkyAPI 
-- Game: AppID 1091940
addappid(1091940)
addappid(1091941, 1, "fbeb54deaf72384a65627598e6d477624f13cd10f0c17961d4e4cdc0858b8bd4")
