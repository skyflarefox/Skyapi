-- Lua provided by SkyAPI 
-- Game: AppID 1039960
addappid(1039960)
addappid(1039961, 1, "44ba2a62e359d4b3540df0f329122325fbf7c4082bfb9978e5ab097d30892c5a")
