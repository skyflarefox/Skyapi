-- Lua provided by SkyAPI 
-- Game: Start Programming
addappid(1876660)
addappid(1876661, 1, "b801e21c0d95bd99912dfb3a2bd76b8972ecfb04af9cfe9537676ac7326857f3")
