-- Lua provided by SkyAPI 
-- Game: AppID 394840
addappid(394840)
addappid(394841, 1, "bc6932c20b9f53ca7b47a6f8320445c759cfbdd6619e1f97161085d50aa05634")
