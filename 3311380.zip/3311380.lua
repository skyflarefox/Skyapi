-- Lua provided by SkyAPI 
-- Game: Netveil
addappid(3311380)
addappid(3311381, 1, "24a54ccc7ba322168388e5ecbc728788f90604fb6a94be17acd5c1639933962d")
