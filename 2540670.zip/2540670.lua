-- Lua provided by SkyAPI 
-- Game: Terralysia
addappid(2540670)
addappid(2540671, 1, "031e60823ba4813030e082fc4ddcfbf56d0d9854e8b8276740a5b2f00988bff2")
