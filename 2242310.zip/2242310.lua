-- Lua provided by SkyAPI 
-- Game: Folcroft Monastery
addappid(2242310)
addappid(2242311, 1, "ecece70bf8a9b5a13be93e9097215f99f37e981281862f7d9018471c63522d17")
