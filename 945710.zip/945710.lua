-- Lua provided by SkyAPI 
-- Game: DreadOut 2
addappid(945710)
addappid(945711, 1, "2e9ef743e6601a105ebcaf4f19e48ea65955cf9dae1a058534a7629869cd07d1")
addappid(1359590, 0, "7f23eaab7da942825ad18236e285de76df414aa7a7247719260a54fbf7670f12")
