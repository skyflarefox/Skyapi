-- Lua provided by SkyAPI 
-- Game: AppID 359620
addappid(359620)
addappid(359621, 1, "c44dc2a19cd78b92adcbf1dfd3a8508dab612d4a8228d94ff808263a79401e5f")
addappid(359625, 1, "2e57515f29e071bb2f25441fbff0a1c7a91bca6673168cdaeed337e5cc3c4f20")
