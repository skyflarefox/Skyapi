-- Lua provided by SkyAPI 
-- Game: Waking Up: Way Back Home
addappid(2542530)
addappid(2542531, 1, "bc487344f0446e8e3ebc0f779887f0e0b95834661212d602564a3cf8fd9020e5")
