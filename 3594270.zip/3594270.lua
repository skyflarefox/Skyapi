-- Lua provided by SkyAPI 
-- Game: All in Abyss: Judge the Fake - SOUNDTRACK
addappid(3594270)
addappid(3594271, 1, "b3d9ccdbacf0a7cb748ebc94c62a4e7ec92421fbaa257e998f13b3bfa2ef7df7")
