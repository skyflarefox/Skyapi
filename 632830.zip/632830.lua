-- Lua provided by SkyAPI 
-- Game: Aztec Venture
addappid(632830)
addappid(632831, 1, "0baa9c85a775c0bc616e82805ce4e7423e0b7bc644753b8a751b8cbf1b312ef9")
addappid(632832, 1, "bc36ab1a5a26995c4f8f066ca0847b47f14d5b8cd23aaa50b281ad26cda74514")
addappid(632833, 1, "14da2f717fe825522489a3583f3ddd577b614db9293e42647a259824748fb7c1")
