-- Lua provided by SkyAPI 
-- Game: ЕСТЬ ДВА СТУЛА
addappid(873190)
addappid(873191, 1, "d53c9452d9d5fdfe19780021d095ec7bda0db8bd07665b915cd907668be225ca")
