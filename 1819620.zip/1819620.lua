-- Lua provided by SkyAPI 
-- Game: Huygens Principle
addappid(1819620)
addappid(1819621, 1, "8fed3298abcd4468fc952c07090cd096b18ef94a956876b553ea735329d9c1e7")
