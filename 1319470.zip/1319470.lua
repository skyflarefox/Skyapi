-- Lua provided by SkyAPI 
-- Game: Lovely Overseer Demo
addappid(1319470)
addappid(1319471, 1, "c4c1dbbed0ddfd6d5800a7f509d889e7880442d131760462b5fa40e5fb5a8fe2")
