-- Lua provided by SkyAPI 
-- Game: FPV SkyDive - Airport
addappid(1838190)
addappid(1838191, 1, "e9c6abda122b743030aeeb924a19d2ae519a15d3ed7411d8a5297762048837df")
