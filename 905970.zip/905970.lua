-- Lua provided by SkyAPI 
-- Game: AppID 905970
addappid(905970)
addappid(905971, 1, "084a7cd54c1fe51a88dd2240c0045acc8af131e2765a8af8319a5a88503b15c4")
