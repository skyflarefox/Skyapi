-- Lua provided by SkyAPI 
-- Game: Hot Lava
addappid(382560)
addappid(382561, 1, "c7cd9dead01a600a3c00ea545eb74a140a35557e5ace4ac29434b0d1472c2b3e")
