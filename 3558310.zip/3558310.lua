-- Lua provided by SkyAPI 
-- Game: Bring the Book back
addappid(3558310)
addappid(3558311, 1, "492b53645d0edc258e82c18431600f9f38791aaff3f49ebf172f2fdb4e288855")
