-- Lua provided by SkyAPI 
-- Game: My Museum Prologue: Treasure Hunter
addappid(1945030)
addappid(1945031, 1, "92d63d11b6bc3f926fc2e7eb7e3673e5eccf2520cb2b718f45f3c65ee8c0e9e1")
