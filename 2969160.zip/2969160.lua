-- Lua provided by SkyAPI 
-- Game: AppID 2969160
addappid(2969160)
addappid(2969161, 1, "8a72f527e85e3515970130c2b7cfd62faecc546adb25d2f2abdb5ce1c129dddd")
