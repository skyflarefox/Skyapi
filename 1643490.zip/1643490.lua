-- Lua provided by SkyAPI 
-- Game: Zagu Espionage
addappid(1643490)
addappid(1643491, 1, "4fe1016c8d53280e4695e792ef064a090488be34c12c962d7604a146a08c4b06")
