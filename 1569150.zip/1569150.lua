-- Lua provided by SkyAPI 
-- Game: Glyph☀️
addappid(1569150)
addappid(1569151, 1, "9c5dd82eaf10cbaa98aab6220cbcd2415247b1bf6cff97b2d6149d0191e35cd4")
