-- Lua provided by SkyAPI 
-- Game: AppID 1256380
addappid(1256380)
addappid(1256381, 1, "7b3d28bad9ce722f67541b6c938831e73c54db172e0097cce10e1ca2d2c04ddd")
