-- Lua provided by SkyAPI 
-- Game: IDUN - Frontline Survival
addappid(2186360)
addappid(2186361, 1, "e5c469955c4eedc6f11a88a247842af0d74f884765f46916576028e59555c437")
