-- Lua provided by SkyAPI 
-- Game: The Preposterous Awesomeness of Everything
addappid(435840)
addappid(435841, 1, "4cca4cbd060adea0a159fcaf057919c70ef9658b806e1e7870d58d0a7dd77c1c")
