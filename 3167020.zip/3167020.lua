-- Lua provided by SkyAPI 
-- Game: AppID 3167020
addappid(3167020)
addappid(3167021, 1, "6a1377569bff7441f985074b6ed8692c0c8f6681b80a75e020dd1a10419b5dea")
