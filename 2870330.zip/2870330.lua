-- Lua provided by SkyAPI 
-- Game: Grocery Store Tycoon
addappid(2870330)
addappid(2870331, 1, "a9a0a57ed438e8191840566e133c88a816e88bd0b6f4d56e2bf9819bc57508ef")
