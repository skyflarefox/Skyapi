-- Lua provided by SkyAPI 
-- Game: Assemble with Care Soundtrack
addappid(1293620)
addappid(1293621, 1, "9700b00d4c521670cfbf4f2339549187b9f13c18c2f8a337eb99b843a2eef886")
