-- Lua provided by SkyAPI 
-- Game: AppID 1663970
addappid(1663970)
addappid(1663971, 1, "26979121bade4d77536d94e7d79b1c087a6ba435a0c34af3586326c556ed3d60")
