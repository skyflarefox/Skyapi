-- Lua provided by SkyAPI 
-- Game: Dogs Club
addappid(2401370)
addappid(2401371, 1, "23bf9cb5bff143d1892be7594cd8a28d342b6d51966512c0af74d1f2aa1f4203")
