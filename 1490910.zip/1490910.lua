-- Lua provided by SkyAPI 
-- Game: Fast Cubes
addappid(1490910)
addappid(1490911, 1, "4720db09763f84e650f8e120f6eb35c7ece5d32b44f0d4833a3d6ac27bd7885c")
