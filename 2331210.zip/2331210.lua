-- Lua provided by SkyAPI 
-- Game: Quit Smoking VR Therapist
addappid(2331210)
addappid(2331211, 1, "72b1b347aa1e51ed84f5fc572bb32566297d085e0d6e18cd7c11acd9f8c32e5b")
