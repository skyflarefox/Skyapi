-- Lua provided by SkyAPI 
-- Game: AppID 2450930
addappid(2450930)
addappid(2450931, 1, "2fb3c61a97fa9d7351d9e395b9ddb5487cbd4069da8d178662f519606cea5de6")
