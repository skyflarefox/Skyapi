-- Lua provided by SkyAPI 
-- Game: AppID 1036640
addappid(1036640)
addappid(1036641, 1, "64815a8bd36127e977b7959101e3fd9352c237cf06e86ddae2e669ac714d52e9")
