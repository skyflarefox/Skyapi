-- Lua provided by SkyAPI 
-- Game: AppID 1289060
addappid(1289060)
addappid(1289061, 1, "bc124817e1dc8c88a0a14223c98c480aa5908fd4b1028118b32ff4c0a7778954")
