-- Lua provided by SkyAPI 
-- Game: The Mermaid of Zennor
addappid(1502520)
addappid(1502521, 1, "c9f6bee03f90889ccf4eecf32eb3f4556b2f0693c71a32d8b2cdd51566269002")
