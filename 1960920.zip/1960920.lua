-- Lua provided by SkyAPI 
-- Game: Zetria
addappid(1960920)
addappid(1960921, 1, "afd1e33b8ce98b26096ece7f3e2ff1016580da2365390a4f92b62509fb746f62")
