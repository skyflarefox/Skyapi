-- Lua provided by SkyAPI 
-- Game: BROK the InvestiGator - Prologue
addappid(1318790)
addappid(1318791, 1, "6038ea5e8711be2cc2438b6bde465148a5d2e67026e5688e1e0530c595d42be9")
