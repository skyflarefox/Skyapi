-- Lua provided by SkyAPI 
-- Game: Seal: WHAT the FUN
addappid(2347910)
addappid(2347911, 1, "b9d2a2d7a81f7fa45f112b1cc9333d3a22f4602f2ba79b687b0c5477091cebc7")
