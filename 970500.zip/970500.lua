-- Lua provided by SkyAPI 
-- Game: 秦殇 (Prince of Qin)
addappid(970500)
addappid(970501, 1, "6e1f0d2117377fbaccba27ed209d9f1cd63708616ecb81ae95acbe2def1cb488")
