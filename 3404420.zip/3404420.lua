-- Lua provided by SkyAPI 
-- Game: Eternal Strands Soundtrack
addappid(3404420)
addappid(3404421, 1, "b169de2f3ed304df51a3d79e79ddc6582d8fc9ef30ca92ef759815d2feefb3cc")
