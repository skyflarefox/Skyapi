-- Lua provided by SkyAPI 
-- Game: ATV Drift & Tricks
addappid(622020)
addappid(622021, 1, "1ba2b1d2e297e4b059cb128b04e44f315d41f22165ecfd8714e816acd5aa14c9")
