-- Lua provided by SkyAPI 
-- Game: AppID 1118200
addappid(1118200)
addappid(1118201, 1, "d99e7ccbd86c7d168a651c52fc54891a1b5ad40ee46627fd11bd2b4ab6bfb8d8")
addappid(1118202, 1, "a4e87225a2ee63931a6b945691d1c12696020bbc45de5e21d46ae158c8672b32")
