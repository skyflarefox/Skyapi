-- Lua provided by SkyAPI 
-- Game: Death Skid Marks
addappid(326150)
addappid(326151, 1, "a1f841a0d8c18d133220c1e8337e47376e515118375de7612fc40e52ff62ded3")
addappid(326300, 0, "d7888edb89add8fb06845eeef30a754a994ee6d81663fd6d9f8e0dc68ce9f035")
