-- Lua provided by SkyAPI 
-- Game: AppID 2799210
addappid(2799210)
addappid(2799211, 1, "fae3763105dd1174aa517621dca5778763c85890d8f51ac87c73dac3a1a7ffcd")
