-- Lua provided by SkyAPI 
-- Game: AppID 338390
addappid(338390)
addappid(338391, 1, "f9e1ed02b7c368ec7626fe4e0b722d4dbb78f2c4c5285e329085b4b073509464")
