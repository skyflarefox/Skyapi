-- Lua provided by SkyAPI 
-- Game: Gotham Knights
addappid(1496790)
addappid(1496791, 1, "40ad1c77c16c71b4c353e1a71b9d7c7a5c2cc1474a2333926db9842c70a45df3")
addappid(2074431)
