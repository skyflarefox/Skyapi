-- Lua provided by SkyAPI 
-- Game: AppID 341720
addappid(341720)
addappid(341721, 1, "457bf082fc694a0b3100ff7be5105426a12f96af9a559b4923b8ca598b207ad8")
addappid(341722, 1, "da9b46ae926a05e56e9b35eb0dab2e20a137fc09a826758c152afbc0705472ae")
addappid(341723, 1, "94e7b913cd970b079773b4f0d63fed18fdf5cba0596cf1e3df961d5ce799316d")
