-- Lua provided by SkyAPI 
-- Game: GearBlocks
addappid(1305080)
addappid(1305081, 1, "5137f201daad2a7ee699149c46ff8b27786d400d8ffc959a0fb1c7cf53beb4b2")
