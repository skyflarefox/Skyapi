-- Lua provided by SkyAPI 
-- Game: 少女妖精弹珠台 Elf Girl Pinball Demo
addappid(2138660)
addappid(2138661, 1, "d84af37f9b65dd3a5ef469e8c9782e546147b7440818ecd4496ff0261973c942")
