-- Lua provided by SkyAPI 
-- Game: AppID 1288420
addappid(1288420)
addappid(1288421, 1, "af95aa0c04e33160e4a27c32596963eb1e52b4fc81e8bb9c40397e34ea8f2621")
