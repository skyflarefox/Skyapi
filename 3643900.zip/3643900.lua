-- Lua provided by SkyAPI 
-- Game: Ragdoll Boxing Multiplayer
addappid(3643900)
addappid(3643901, 1, "d6f81233f30ce3870e22f137ae10f561c3ba304508a87fb8d6c416cbf34a91cc")
