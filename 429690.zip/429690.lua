-- Lua provided by SkyAPI 
-- Game: AppID 429690
addappid(429690)
addappid(429691, 1, "474f09329fb06752e4f9cabbfd6f14b675c1e3e171b3e0256d34322a8ed00d90")
