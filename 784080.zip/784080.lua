-- Lua provided by SkyAPI 
-- Game: AppID 784080
addappid(784080)
addappid(784081, 1, "b8b97d071286439862b9f60a8898a85f6e6c648afd1e3064b37f125523f14a46")
addappid(1456211)
