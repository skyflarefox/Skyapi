-- Lua provided by SkyAPI 
-- Game: Bloody Zombies
addappid(449640)
addappid(449641, 1, "13601a8fc041500f1661c01589c03f6e97b8456979f63d4c797e644f01e2f494")
