-- Lua provided by SkyAPI 
-- Game: Castlevania: Lords of Shadow – Ultimate Edition
addappid(234080)
addappid(234081, 1, "ab40bf1e8f8f4e355c8bae5308935e25aab33dfa288481d8daa4a10db80794e1")
addappid(234083, 1, "b87b6f66b1adb93c834b430768ddf9b1cf1457edf63f2a6235366c28cbcc711f")
