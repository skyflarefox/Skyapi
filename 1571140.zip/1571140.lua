-- Lua provided by SkyAPI 
-- Game: 东方十昊狱 ～ Hella Dazzling Hell!!
addappid(1571140)
addappid(1571141, 1, "cf648a545f8d8c44ffa661e1d25928c318f6bada1b57e9d484fe58cd7dbe1649")
