-- Lua provided by SkyAPI 
-- Game: AppID 1307250
addappid(1307250)
addappid(1307251, 1, "7fcd1edbc86e24d0ed3146afa83818ae7c9047f26ec5fb6a30625670a4f31a3a")
