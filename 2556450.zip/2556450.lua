-- Lua provided by SkyAPI 
-- Game: 哈希绿洲 Hash Oasis
addappid(2556450)
addappid(2556451, 1, "6db6a7b666608570f1521b7ba2fe4ff8c55650d84ae21005bcc6511c044ab994")
