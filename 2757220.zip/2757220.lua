-- Lua provided by SkyAPI 
-- Game: SCP: Descent
addappid(2757220)
addappid(2757221, 1, "105fc32f9a7adc217b0bfc26aafc55b8e8748ead192dbe480ff5d5e42b645fb5")
