-- Lua provided by SkyAPI 
-- Game: FOREWARNED
addappid(1562420)
addappid(1562421, 1, "c25810bf9718e5f1478a56120bc69663eeba36ee9972e8a4de4a1ff3ada546df")
