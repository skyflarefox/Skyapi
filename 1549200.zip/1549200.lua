-- Lua provided by SkyAPI 
-- Game: Anachronism\>
addappid(1549200)
addappid(1549201, 1, "09e018b60b6d670277e38ab488a5528085ddb37a2d1f5a3b7593a03ff9b758a2")
