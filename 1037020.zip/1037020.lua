-- Lua provided by SkyAPI 
-- Game: ScourgeBringer
addappid(1037020)
addappid(1037021, 1, "4a2d389fbdc5b892beae45c1fa9ec799eac30975f5a0ea8153cd5edd45f60aca")
addappid(1408650, 0, "2ab1a48a7d33903d4dd15c49b34d138ae6d4337ee0339b8bfc6f7d6b2a9b8b83")
