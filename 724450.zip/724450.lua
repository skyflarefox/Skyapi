-- Lua provided by SkyAPI 
-- Game: AppID 724450
addappid(724450)
addappid(724451, 1, "352b6b935fb9a18c12be7ab91fe9c1883bae44b47afc63cff46b05371ad115db")
