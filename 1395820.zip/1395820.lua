-- Lua provided by SkyAPI 
-- Game: SURVIVAL: Postapocalypse Now Demo
addappid(1395820)
addappid(1395821, 1, "5370f20df0d53ea71f264d69d2536629c70eaa78f9dfe251a277f641b319fc69")
