-- Lua provided by SkyAPI 
-- Game: AppID 1090900
addappid(1090900)
addappid(1090901, 1, "ec945ea1bc3ce560b4ee4d92bbdf67de7fdee3e3dd4e7624bd5cd875debb4c91")
addappid(1090902, 1, "ae0315a3e8e076462190dbf039d985876f157a8204a156891e82390aba2bbfab")
addappid(1090903, 1, "ae96b1b81fd9f22172d48f92af17e6f8a4702f54ba31223efb75c15b4fce0d2d")
