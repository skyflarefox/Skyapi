-- Lua provided by SkyAPI 
-- Game: We Were Here Together Demo
addappid(1614610)
addappid(1614611, 1, "b9066e040fb19f1c66e8452f590176d21dac493fc0894e9a9ee7bf54913734f6")
