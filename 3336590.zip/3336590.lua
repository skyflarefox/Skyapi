-- Lua provided by SkyAPI 
-- Game: Puyo! Push Brain
addappid(3336590)
addappid(3336591, 1, "a19f63c49397e94241cc396956dc99b5ebc494d91643715764ab5f9cce17a928")
