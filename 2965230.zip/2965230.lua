-- Lua provided by SkyAPI 
-- Game: Where it all Began - Season 1
addappid(2965230)
addappid(2965231, 1, "4fe18a2f3165f65fad0d9ab26a8649b14b726553b6c6e2055fa906ea636dfb3a")
