-- Lua provided by SkyAPI 
-- Game: No More Heroes 3
addappid(1744330)
addappid(1744331, 1, "35a5ff9a91ea79ea241820f3d5554be376a9c4b89f22b978a942503b118de9af")
