-- Lua provided by SkyAPI 
-- Game: AppID 851670
addappid(851670)
addappid(851671, 1, "a52d6f893a3bd97c89b5a9791a7431131e438415e5ed0751b73f56a7f717604b")
