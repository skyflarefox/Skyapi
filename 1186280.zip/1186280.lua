-- Lua provided by SkyAPI 
-- Game: Dodge If you Can!
addappid(1186280)
addappid(1186281, 1, "9591c125ab01c7a199a1b3c4a062c7d97f32007f3794808f80ab01307c3dff90")
