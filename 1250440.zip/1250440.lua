-- Lua provided by SkyAPI 
-- Game: Garlic
addappid(1250440)
addappid(1250441, 1, "36691ab9b54a1583cdb72655ddf3395c1cbf455105f9640a28f73e2ac98f54ce")
