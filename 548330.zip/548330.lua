-- Lua provided by SkyAPI 
-- Game: Wheely
addappid(548330)
addappid(548331, 1, "de6cecca9a4d203d9abdd4a4f93935507c202bb0e3d2b234d0284f62fc24c76d")
