-- Lua provided by SkyAPI 
-- Game: URU: Complete Chronicles
addappid(63650)
addappid(63651, 1, "899fed63d3006053bfe2ec5febe2fe764d889be2c41bc18d5a60d586d5073ab0")
addappid(63652, 1, "32793e3235036460412f4fd620afb8a6de97feaca825b047ab41336d3d528a37")
addappid(63653, 1, "430d442395f68ccfca35a9692ad156ed6521e9e8e046fd6dc26da70f755b7bfe")
addappid(63654, 1, "c5f97b6ecd75e75ddc87b19ee81367bb99957c92fe5bc076666180c90fa532e9")
addappid(63655, 1, "b54054a062e30050839152114cbecc62635cddd39e1931f80c0b0abdc81b0b2d")
