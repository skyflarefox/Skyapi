-- Lua provided by SkyAPI 
-- Game: AppID 2188910
addappid(2188910)
addappid(2188911, 1, "71ebfb397bcf9719a93d7c9545b1b760801349f09ca63964771badc5ce94b0a7")
