-- Lua provided by SkyAPI 
-- Game: AppID 424870
addappid(424870)
addappid(424871, 1, "0b9cb2c6a817714473358a2f6569757558d8e11435ab2386c194cfffca9de23f")
