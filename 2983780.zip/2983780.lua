-- Lua provided by SkyAPI 
-- Game: AppID 2983780
addappid(2983780)
addappid(2983781, 1, "04fb3bd53f6f4a84a10004174ad12f9e79a2afc85d750089d745206f85f2acb6")
