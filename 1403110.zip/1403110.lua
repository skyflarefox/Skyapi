-- Lua provided by SkyAPI 
-- Game: Primeval
addappid(1403110)
addappid(1403111, 1, "34b6d448bfb8d8f729ed928d9642a2d256b5a4ef720b9090ee9e6ceb81ef458d")
