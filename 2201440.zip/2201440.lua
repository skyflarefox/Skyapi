-- Lua provided by SkyAPI 
-- Game: AppID 2201440
addappid(2201440)
addappid(2201441, 1, "d0711d48f90b4478fe6820c45e401578a96774d1ba0460155a7a9d16f491c6a4")
