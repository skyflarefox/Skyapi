-- Lua provided by SkyAPI 
-- Game: AppID 1692060
addappid(1692060)
addappid(1692061, 1, "4c57762024eddceee8ccec97ec08d88d966538f333c7d14539b74fefde984441")
