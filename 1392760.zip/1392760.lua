-- Lua provided by SkyAPI 
-- Game: Furry Heroes
addappid(1392760)
addappid(1392761, 1, "9d96080a5748ace3fc15b4c9a417124205af2a3a0b14d7dd579b60d4506bbff6")
addappid(1427001, 1, "d37db520a6a7b40b7856d6e982ccaee570f99fdfdabff5e1cf338260276bbeef")
addappid(1427000)
