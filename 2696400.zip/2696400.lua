-- Lua provided by SkyAPI 
-- Game: AppID 2696400
addappid(2696400)
addappid(2696401, 1, "14430b1b2e9b7d9f625e7218cd05369df409a356768868e0dd7c87c5cc62ce2d")
