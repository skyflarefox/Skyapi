-- Lua provided by SkyAPI 
-- Game: Open Blocks
addappid(3077230)
addappid(3077231, 1, "d7d23d28089fd14a03d576338c08b82362958f1b43f1b15cc0c560b366869287")
