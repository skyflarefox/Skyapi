-- Lua provided by SkyAPI 
-- Game: AppID 516890
addappid(516890)
addappid(516891, 1, "a26ca1822f4ce597a3c7be4193e96e1e7a3477db247f1dac50f8e9d64fc3d7b5")
