-- Lua provided by SkyAPI 
-- Game: CORRUPTION 2029
addappid(2660410)
addappid(2660411, 1, "c28fa0cbbd5e491db3bed6a601263e0df760ae2165975b45acdfe498d95edab3")
