-- Lua provided by SkyAPI 
-- Game: Nordic Ashes: Survivors of Ragnarok
addappid(2068280)
addappid(2068281, 1, "ee7ffd7c9029c2c860eab9bb927eba2a68583d2327418c1fa50e13a0aa0e3534")
addappid(2952100, 0, "288f3607fd60a1291dc7c8ac494a41f2f85aa8c9ca7cffc02e25fcbe4489ecf5")
addappid(3312220, 0, "bab077fa19c68ee5c41735feff8f93076ae2d6c43631a8394311c453d1c7644a")
addappid(3312221, 0, "aa939f25a524b5953c06c2efdf929ea8dff8946b60f531a949f1ff71d317b30c")
addappid(3312222, 0, "978fabfc5fcaa61865a4c1fba48f7363495110c31bc7001f14f4ed3a7b5c6a52")
addappid(3636780, 0, "cb00c6cd0e5c55518a12fac8bf4339a6ad9580427e363e3f54cd97403ebbd75a")
