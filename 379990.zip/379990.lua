-- Lua provided by SkyAPI 
-- Game: Hush
addappid(379990)
addappid(379991, 1, "4427345a2043dd9778b88dd2e87140777836aa1b69129dad099e583b4c3f8311")
