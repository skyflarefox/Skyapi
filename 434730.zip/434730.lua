-- Lua provided by SkyAPI 
-- Game: Half Dead
addappid(434730)
addappid(434731, 1, "dfa1506ae9e0870abc1a16a85dfbdd420b7b31fe27c2745ae1b788c6c1b15c6a")
