-- Lua provided by SkyAPI 
-- Game: AppID 792710
addappid(792710)
addappid(792711, 1, "b7e78e5bf8315548b49cfb76662927330226c46f2cf89a9099191fa9ff6b7b06")
