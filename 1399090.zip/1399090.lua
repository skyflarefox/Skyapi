-- Lua provided by SkyAPI 
-- Game: AppID 1399090
addappid(1399090)
addappid(1399091, 1, "da050e706bd45e6a24e3b6eaf0b741f8ab325778344f441cc0d8724d040ec457")
