-- Lua provided by SkyAPI 
-- Game: Diner Bros
addappid(846800)
addappid(846801, 1, "bc3d69981590b243a5626b0d3f12c0d4a38f357ffa56e44db91292b628b5945b")
