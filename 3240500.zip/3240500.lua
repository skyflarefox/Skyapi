-- Lua provided by SkyAPI 
-- Game: Sakura Isekai Adventure 3
addappid(3240500)
addappid(3240501, 1, "5379b20cf66532c3f159a527b2a516e9f5bc293ad6949296407fbf3706255ae4")
