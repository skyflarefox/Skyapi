-- Lua provided by SkyAPI 
-- Game: AppID 2710480
addappid(2710480)
addappid(2710481, 1, "7765451235157fe8932eeebf00a41af0f17b2267a35e3795492dd9b7b3931572")
