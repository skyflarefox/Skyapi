-- Lua provided by SkyAPI 
-- Game: Speebot
addappid(731320)
addappid(731321, 1, "c0546dfb6e33ca41023ac0d621a860365a88fe97e4949f9193a1e4708eaf570c")
