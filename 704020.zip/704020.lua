-- Lua provided by SkyAPI 
-- Game: AppID 704020
addappid(704020)
addappid(704021, 1, "3104d0e53956de150339daa35b4e70194dda24a79567f93d413d3fb166bcb7b8")
