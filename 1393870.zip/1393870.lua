-- Lua provided by SkyAPI 
-- Game: AppID 1393870
addappid(1393870)
addappid(1393871, 1, "255c9cc0f1620031e595db453c2ae66b7b2eb6f897eb487afff665c63abf0ccd")
