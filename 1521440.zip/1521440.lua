-- Lua provided by SkyAPI 
-- Game: Flowers Blooming at the End of Summer Soundtrack
addappid(1521440)
addappid(1521441, 1, "eb4e730fb151caaf4ba45d4dd2c6a59565b13c92a9eafe9674259afe218e0d0e")
