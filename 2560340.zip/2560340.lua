-- Lua provided by SkyAPI 
-- Game: Bonaparte - A Mechanized Revolution
addappid(2560340)
addappid(2560341, 1, "8bca18896136a286690aca12ab1b52ab1c6274e4501a749b64fd8e25e867ad98")
