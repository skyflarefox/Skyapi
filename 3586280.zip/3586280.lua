-- Lua provided by SkyAPI 
-- Game: 夢現しろっぷ - Dreamy Syrup -
addappid(3586280)
addappid(3586281, 1, "2f30c97a6783ac00d24c769d398aced9c2e6c8e0aa5c94bda09c55ff476452c5")
