-- Lua provided by SkyAPI 
-- Game: AppID 1097110
addappid(1097110)
addappid(1097111, 1, "bf33d4bbc776ccf70c5fbc9b40caf2dd19f47788425e57fe37ca85586f5e1096")
