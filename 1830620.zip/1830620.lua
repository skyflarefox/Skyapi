-- Lua provided by SkyAPI 
-- Game: Pleasure Party
addappid(1830620)
addappid(1830621, 1, "89cc55b751c7698e29cb5ad63605cce893f156f3f2460441a3948bb76d92132f")
