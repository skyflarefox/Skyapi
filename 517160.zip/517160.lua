-- Lua provided by SkyAPI 
-- Game: Richie's Plank Experience
addappid(517160)
addappid(517161, 1, "b2c28238837e10b8090f19d16b4926f562feb8ebe42fbc3a2527bb74a63b92dd")
