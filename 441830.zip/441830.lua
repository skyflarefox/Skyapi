-- Lua provided by SkyAPI 
-- Game: AppID 441830
addappid(441830)
addappid(441831, 1, "6988f2389a442305a32cd353593837b14ae608b590d3407289a8060b8ac0c75b")
addappid(501040, 0, "2246fafc79b08f13a4632cb379251efe14a35dee4bec9b7eecdff8ba50a7bfb8")
