-- Lua provided by SkyAPI 
-- Game: Megaloot
addappid(2440380)
addappid(2440381, 1, "def2da358b14cdc00d139af62c7d7275bb0a1eab0c9409d162edcac2ad5842ea")
