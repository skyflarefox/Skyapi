-- Lua provided by SkyAPI 
-- Game: AppID 1864740
addappid(1864740)
addappid(1864741, 1, "7ca6f2b045d1c360c796ab4751fc2d90cba5b7a4c86e46c3a0762884e56529a4")
