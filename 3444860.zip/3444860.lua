-- Lua provided by SkyAPI 
-- Game: AppID 3444860
addappid(3444860)
addappid(3444861, 1, "b743ab735f5a3181a30648527a733addffa7763e8fae9b17782948fd31982d29")
