-- Lua provided by SkyAPI 
-- Game: Shui's Odyssey
addappid(2808960)
addappid(2808961, 1, "10eb66acf9ccc4466d2532d6949d85f0fbe6e170ec8c461e022f2192d981b97a")
