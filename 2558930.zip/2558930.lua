-- Lua provided by SkyAPI 
-- Game: Hoversteppers
addappid(2558930)
addappid(2558931, 1, "2919466c4c9464d6358a4c7f570e934991c94de4aa750b1ba988072224165c34")
