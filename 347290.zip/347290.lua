-- Lua provided by SkyAPI 
-- Game: Rise & Shine
addappid(347290)
addappid(347291, 1, "05fa7cc98f46969041d720e86d6d645426b1c422b92522c23a57a5754c6c3bc8")
addappid(347293, 1, "7c4394a31510719bd450da6180669d4fb8a3b0c651ecc7b2eef4b88aa9c17bc9")
addappid(347294, 1, "80add1ce3dc29d7b7067c82c510232f29a955a9732e90f50b26cfc11a5e1ecab")
