-- Lua provided by SkyAPI 
-- Game: Typical
addappid(906730)
addappid(906731, 1, "1d83d90cf53a77411bdf5e192ec41ca1e7fe8a8f86f0ada75a7e3af8def3af46")
