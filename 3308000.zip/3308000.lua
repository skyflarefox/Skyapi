-- Lua provided by SkyAPI 
-- Game: AppID 3308000
addappid(3308000)
addappid(3308001, 1, "cd1de533d044ea57f5c7e1061f95c26d7704de9e357301b9b529c113f7cd69ab")
