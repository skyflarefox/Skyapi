-- Lua provided by SkyAPI 
-- Game: Shoot Them 2
addappid(1261130)
addappid(1261131, 1, "7c3c5fa3bb950d50a4bf557ce00dabd3e13b98387317603296c62a8e0248a475")
addappid(1261510)
addappid(1281060)
