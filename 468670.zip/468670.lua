-- Lua provided by SkyAPI 
-- Game: Speed Brawl
addappid(468670)
addappid(468671, 1, "65b8f4965b057a778cf6b4ab06d015c09eec29c5d3925f355b14f9edbafb4e1a")
