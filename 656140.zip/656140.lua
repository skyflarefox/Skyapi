-- Lua provided by SkyAPI 
-- Game: PLANETS OF WAR
addappid(656140)
addappid(656141, 1, "cc0009d46f942a29d3f4be1febe480aa559979997e67d69f6854e0df1a0d3d5f")
