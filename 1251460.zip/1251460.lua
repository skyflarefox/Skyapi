-- Lua provided by SkyAPI 
-- Game: Tanuki Sunset
addappid(1251460)
addappid(1251461, 1, "33fb5f658421326839a6c27f2003927c046ecf3f0b9c998a820efc7f3d1c1556")
addappid(1251462, 1, "a847ddfa8c7a093d68ad2a77094f0d5828cce623648e5675fdd9e1df5c2557c5")
