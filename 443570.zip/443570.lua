-- Lua provided by SkyAPI 
-- Game: AppID 443570
addappid(443570)
addappid(443571, 1, "7c9dd04edda43bcc5e08d8cc7b9ffdb9091988ac5b6fcaf1d30e9d5b702117a8")
addappid(443572, 1, "a1e716d779ff118b49131ba6ced3e441373992bd427d0f34aa564578c578c2bd")
addappid(504970)
