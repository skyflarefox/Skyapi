-- Lua provided by SkyAPI 
-- Game: Late photographer 2
addappid(1867290)
addappid(1867291, 1, "a1e900a5404d04b6f11d8b503f54065316c8d11e70a0aad98447e95c2db1cfc8")
