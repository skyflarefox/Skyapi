-- Lua provided by SkyAPI 
-- Game: 101 Cats in Cancun
addappid(3582790)
addappid(3582791, 1, "8550299231c7a5605434273cbdab661014b9352dec5cb3f8c3fda0730b18d2fb")
