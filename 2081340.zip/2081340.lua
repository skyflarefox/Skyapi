-- Lua provided by SkyAPI 
-- Game: KAMiBAKO - Mythology of Cube -
addappid(2081340)
addappid(2081341, 1, "443b58c300e665bb6c6ef65c7f5b38b2131cbb5d24d9eb953b4f8035ddafdf02")
