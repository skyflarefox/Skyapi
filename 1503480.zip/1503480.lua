-- Lua provided by SkyAPI 
-- Game: AppID 1503480
addappid(1503480)
addappid(1503481, 1, "5441c0bf5c5ee684c63b2e5f6f313d18e9c7e128e9a73bb26d3f3dd11e3fc618")
