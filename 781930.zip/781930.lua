-- Lua provided by SkyAPI 
-- Game: AppID 781930
addappid(781930)
addappid(781931, 1, "4364cad05969ce304663842799794113b32d4aaf589b6a068fc54f3860373378")
