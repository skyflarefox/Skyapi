-- Lua provided by SkyAPI 
-- Game: AppID 3399700
addappid(3399700)
addappid(3399701, 1, "756ae02f34c7b9cff282d550e6537e6344b9d9ea0134b68e5ccc2f97785f54cb")
