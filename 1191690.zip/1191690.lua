-- Lua provided by SkyAPI 
-- Game: AppID 1191690
addappid(1191690)
addappid(1191691, 1, "e09896cd7d5235648b1a503c0a062282b88e403bd28f5be6a004d30c720947f2")
