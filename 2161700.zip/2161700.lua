-- Lua provided by SkyAPI 
-- Game: Persona 3 Reload
addappid(2161700, 1, "bf1950cacab9ce218e10c58f74c39b508f1e5917aad3dc4107be9a6f0298cad7")
addappid(2161701, 1, "9644c57e48eb13144cd26fa9423b85051e1c474221f8f6cfcb017478cd8f3503")
setManifestid(2161701, "8534679793765499772")
addappid(2322840) -- Persona 3 Reload - Persona 4 Golden Yasogami High Costume Set
addappid(2334530) -- Persona 3 Reload - Persona 5 Royal Shujin Academy Costume Set
addappid(2334531) -- Persona 3 Reload - Persona 5 Royal Phantom Thieves Costume Set
addappid(2334532) -- Persona 3 Reload - Persona 5 Royal Persona Set 1
addappid(2334533) -- Persona 3 Reload - Persona 5 Royal Persona Set 2
addappid(2334534) -- Persona 3 Reload - Persona 4 Golden Persona Set
addappid(2334535) -- Persona 3 Reload - Persona 4 Golden BGM Set
addappid(2334536) -- Persona 3 Reload - Persona 5 Royal BGM Set
addappid(2689210) -- Persona 3 Reload: Expansion Pass
-- Persona 3 Reload - Digital Artbook (AppID: 2517300)
addappid(2517300)
addappid(2517300, 1, "e3e3cd94bb2d0486c49a49696f35805949b32a399b0b1361a4484ba2bb825ee3")
addappid(2517301, 1, "99c413d3350860f2c095f2948891bdaf234aff41e3de3ecdce62384d0db89c1e")
-- Persona 3 Reload - Digital Soundtrack (AppID: 2517310)
addappid(2517310)
addappid(2517311, 1, "6fe33390db2c2102f8745ea2cfe432836e4337a33b4e78ef71456aa4e37529d0")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") 
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")