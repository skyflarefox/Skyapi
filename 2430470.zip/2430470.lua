-- Lua provided by SkyAPI 
-- Game: Vilde
addappid(2430470)
addappid(2430471, 1, "003e2f29b651f13ced562761e2661d1f9436e28c504d16ed7ce77a52d219565c")
