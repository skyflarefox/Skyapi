-- Lua provided by SkyAPI 
-- Game: Human-powered spacecraft
addappid(699180)
addappid(699181, 1, "a0d6e4377e27eb8a1c15b64ff057bdf2fac3cfe5bb4a804ac013d917dfabdc96")
