-- Lua provided by SkyAPI 
-- Game: Psikodelya
addappid(742510)
addappid(742511, 1, "e7f757ba1eefa6a2145937e431b9016fb3a0032d898c826f6470e01eb423333f")
