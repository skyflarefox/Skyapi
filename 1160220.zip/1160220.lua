-- Lua provided by SkyAPI 
-- Game: Paradise Killer
addappid(1160220)
addappid(1160221, 1, "7fb3eebf32057deb18863fa94f3483b3943bf2adc6ddab784f3c6ad0e146c156")
addappid(1492560, 0, "b6f856b763c5b6820f3ed8d3ab6eaca84c48657e425afd9133c3ea316442013d")
