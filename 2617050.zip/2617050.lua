-- Lua provided by SkyAPI 
-- Game: AppID 2617050
addappid(2617050)
addappid(2617051, 1, "e66bc4bd2571e5409c7b23aa3c7eef0145924a9780ef4b49c79a776f6da4a13c")
