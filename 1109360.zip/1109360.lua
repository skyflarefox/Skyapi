-- Lua provided by SkyAPI 
-- Game: AppID 1109360
addappid(1109360)
addappid(1109361, 1, "5c601b3853bc1d61e7bbbc0bf881cc0bad125460ecd9fe97bc7044819e43e0c2")
addappid(1117640, 0, "4b1b35fa189ee84230fb7b1db9e3f1943ecfa6ae6627601b361829f31c4d597a")
addappid(1117641, 0, "c3371aa1adb419906f9d452aac9326ff6f23cff629c8798144bc271bfec98dd7")
