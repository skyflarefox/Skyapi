-- Lua provided by SkyAPI 
-- Game: Clone Drone in the Hyperdome
addappid(2401230)
addappid(2401231, 1, "adef8b8c08460980073f49a920b727586898eb979fded407e77facc0471d75cb")
