-- Lua provided by SkyAPI 
-- Game: Mac Biskwi Adventures
addappid(1495170)
addappid(1495171, 1, "0fed99ace16a44b0a07a4d46bdc60b636fea07f6a489590c98017263ed322e6e")
