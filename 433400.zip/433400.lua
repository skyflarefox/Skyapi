-- Lua provided by SkyAPI 
-- Game: Kim
addappid(433400)
addappid(433401, 1, "66862c77245ddacc95da87372b95161450f5cd5c711ea90346f17c9e1194ba30")
addappid(436990, 0, "1b911a79cb8a7b091e921313dcd8d74d5447f052ad415692b6a9da7ce7ff95ea")
