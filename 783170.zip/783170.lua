-- Lua provided by SkyAPI 
-- Game: AppID 783170
addappid(783170)
addappid(783171, 1, "ba1ab6633e2b86104da96f113a58f7ed61581e0ec70f43976ef9dad4661f33e3")
