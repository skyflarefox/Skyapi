-- Lua provided by SkyAPI 
-- Game: Nova Empire
addappid(1962770)
addappid(1962771, 1, "e276a325685d489fc7bd1aa55d354dfa7075353179f7f0349d3c539adcd4f189")
