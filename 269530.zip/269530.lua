-- Lua provided by SkyAPI 
-- Game: AppID 269530
addappid(269530)
addappid(269531, 1, "6bfa30a7ca2b18cf80f9f20732bb5876f1f910f2e981bb26802f3333ea3816d6")
addappid(269532, 1, "b9d0cf81f5d44a88263018daeda8f81d91fa91fa8318798cffe46bf627886ac9")
addappid(269533, 1, "e334413d675ecbb9b5f25e1f53f2a8acb40fa099acb691716a531c6c7fc75a2e")
