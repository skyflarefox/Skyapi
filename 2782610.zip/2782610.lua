-- Lua provided by SkyAPI 
-- Game: Bad 2 Bad: Apocalypse
addappid(2782610)
addappid(2782611, 1, "45627ca1f4145d7e4add546fe84250bf7d30c3b2722ade20c4046df5dec57949")
addappid(3110390, 0, "25daa2b56d8bc48f2079fd40188941e3898e8ecdb61e4b48a032b551785496f9")
