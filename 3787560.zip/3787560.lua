-- Lua provided by SkyAPI 
-- Game: Hentai Gymnast Scarlett
addappid(3787560)
addappid(3787561, 1, "c5ef4936b511d95f149a87f2cd7cfb0acc4eee6abe15f610fca57c83d5995a81")
