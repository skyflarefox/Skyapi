-- Lua provided by SkyAPI 
-- Game: Jade's Journey
addappid(552580)
addappid(552581, 1, "a54f54ae633f6c80b73a83adf3d4155d0cb3185b7f01e02fb83f21883d84944b")
