-- Lua provided by SkyAPI 
-- Game: Cybernated Demo
addappid(3105230)
addappid(3105231, 1, "23d5e2ccb5cb3df4705f8459f251149cda8f4bed62353bf44eb598187d3aa351")
