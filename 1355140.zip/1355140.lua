-- Lua provided by SkyAPI 
-- Game: AppID 1355140
addappid(1355140)
addappid(1355141, 1, "8fadf91a0fb71d9c24b5cf4b8e723cc8210359e3513e824de4f35ebf6679e255")
