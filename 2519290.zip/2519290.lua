-- Lua provided by SkyAPI 
-- Game: Gravity Force
addappid(2519290)
addappid(2519291, 1, "4bbaf23914eb68898c06c277cd0d57a30193a44809634263d825c98b179fa62f")
