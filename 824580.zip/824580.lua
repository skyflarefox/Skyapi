-- Lua provided by SkyAPI 
-- Game: AppID 824580
addappid(824580)
addappid(824581, 1, "d7bdbf3382fc774226c3ad15dc8f8da0285c296175452beb1b19bc39bafe15be")
