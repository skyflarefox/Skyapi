-- Lua provided by SkyAPI 
-- Game: Saviour of the Wasteland
addappid(2418120)
addappid(2418121, 1, "50839666b3ef05c73e5878beb75a06dd3168dea826f438706589fbc5146153fc")
addappid(3625900, 0, "77f4496cb989c6deb0625274196e17073975d194f599c1cc96dd6d4af386f574")
