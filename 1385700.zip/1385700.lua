-- Lua provided by SkyAPI 
-- Game: True Hate
addappid(1385700)
addappid(1385701, 1, "09bb7a294f589189694dc62128fdd9eaa696975c17d0d65c2bb54e99c712d332")
