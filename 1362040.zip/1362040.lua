-- Lua provided by SkyAPI 
-- Game: Dungeon Swappers
addappid(1362040)
addappid(1362041, 1, "b6bf0e6a5a3858c0975e1c1454ed19745c9927c4944bf3f47946bc55c4010fd8")
