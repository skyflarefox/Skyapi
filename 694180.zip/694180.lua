-- Lua provided by SkyAPI 
-- Game: AppID 694180
addappid(694180)
addappid(694181, 1, "370f36935401cfcd993b30903545d7d9806e3c1ed7ae1ffae128abf0533c211e")
