-- Lua provided by SkyAPI 
-- Game: ArtPose Pro
addappid(741150)
addappid(741151, 1, "2f9e7ee17de8a644ff848d5667ab18dac2d48a3eeeb91f276171ca8e6f9cc26c")
