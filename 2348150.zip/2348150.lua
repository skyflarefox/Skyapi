-- Lua provided by SkyAPI 
-- Game: Fragment of CISCD Demo
addappid(2348150)
addappid(2348151, 1, "2760304bf1aa4b5ee8fb27d3ceb31893b88344a5cf44bf0c6890593b35931e7b")
