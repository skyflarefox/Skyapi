-- Lua provided by SkyAPI 
-- Game: AppID 846050
addappid(846050)
addappid(846051, 1, "c9ebfb8a0e90df5c8d7396a285eedd6d83c330a97f7056816a5efe8690963503")
