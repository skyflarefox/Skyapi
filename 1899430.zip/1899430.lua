-- Lua provided by SkyAPI 
-- Game: VEREDA - Mystery Escape Room Adventure
addappid(1899430)
addappid(1899431, 1, "1704c78185aee118fb35649f54c552f9bc660e0b2aefe35c3a508ee442b97f13")
