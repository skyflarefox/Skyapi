-- Lua provided by SkyAPI 
-- Game: Line/Dash
addappid(497670)
addappid(497671, 1, "dea2a7bceea39cef4ae2bc9e2033d4d86127ab57a01bf2d7ccaf56c8a23b245e")
