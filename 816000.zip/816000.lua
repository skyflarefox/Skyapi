-- Lua provided by SkyAPI 
-- Game: AppID 816000
addappid(816000)
addappid(816001, 1, "9df7714ddf70e848789f6e1512c45d0e435da625d8cceafcb7b66b2357053e92")
