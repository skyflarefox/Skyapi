-- Lua provided by SkyAPI 
-- Game: Jelly Is Sticky
addappid(1492620)
addappid(1492621, 1, "a19333d517b43c91d85da7bf721b3be61c026a90e08cef9a0b10f3a35140212e")
