-- Lua provided by SkyAPI 
-- Game: AppID 2981020
addappid(2981020)
addappid(2981021, 1, "53b433e58b19e03fbaea6a6497fb550dda23e2b7d980f0f467abf30291b3a8db")
