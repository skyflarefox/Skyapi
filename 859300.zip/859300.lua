-- Lua provided by SkyAPI 
-- Game: Hakoniwa Explorer Plus - Original Soundtrack
addappid(859300)
addappid(859301, 1, "333d1a86b8b0cbb32e5053cb83d00c49f60884e151904e730ca6d1bd38d0b917")
