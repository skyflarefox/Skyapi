-- Lua provided by SkyAPI 
-- Game: Choco Pixel 7
addappid(1359450)
addappid(1359451, 1, "380e5f8c406937b2fde4895ea6d065149733a55883bfd8127c270aeaaad8fe41")
