-- Lua provided by SkyAPI 
-- Game: Legion Tale
addappid(604040)
addappid(604041, 1, "08d7084f1364bda8b88d121a83146b27250adffc4224d134b104f28295376375")
