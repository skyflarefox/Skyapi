-- Lua provided by SkyAPI 
-- Game: Fantasy Sliding Puzzle 3
addappid(1776640)
addappid(1776641, 1, "b7138013ab762aed9accf4ea04f4b027acaa49ee525512a0531b871c779b0057")
addappid(1776950, 0, "736e60583c6f4419c884d399e00fe6d8677e55ffb1d1efadc1081e7aafc0c5f0")
