-- Lua provided by SkyAPI 
-- Game: 浊之铃 Demo
addappid(1873950)
addappid(1873951, 1, "39894a6d3215de8763f98964849469348ec2df9efda84f616ecb2021febc58c0")
