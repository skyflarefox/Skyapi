-- Lua provided by SkyAPI 
-- Game: JumpBeard
addappid(1584860)
addappid(1584861, 1, "e5c6665c3ee4d0e578265ec6e79b966d4310ffe79b5bcbf01c1273ceb587fbd8")
