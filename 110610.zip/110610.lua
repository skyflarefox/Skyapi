-- Lua provided by SkyAPI 
-- Game: Alien Zombie Megadeath
addappid(110610)
addappid(110611, 1, "9dfbbdf3b94a033f8c06787246f44c8d2ab9a132070410cf1074a672a53df870")
