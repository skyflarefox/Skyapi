-- Lua provided by SkyAPI 
-- Game: LostWinds 2: Winter of the Melodias
addappid(447800)
addappid(447801, 1, "a11daee00340e01e51476bad7b863f44240e382f66e93e26a1aac09080a32e48")
