-- Lua provided by SkyAPI 
-- Game: AppID 2928730
addappid(2928730)
addappid(2928731, 1, "16f983083f062313c2d04717228db34cec0f9d9d1ff3ec83a919f27797a72ea0")
