-- Lua provided by SkyAPI 
-- Game: Magin: The Rat Project Stories Demo
addappid(1210940)
addappid(1210941, 1, "6ea93a1e4972856c8ee3fbd28773352c7b1d227115d017821fc063546b7a7204")
