-- Lua provided by SkyAPI 
-- Game: AppID 565600
addappid(565600)
addappid(565601, 1, "9a1d0c488752918010911bbe4b030df91f4ef8badf88cefb9794b81e54983ef9")
