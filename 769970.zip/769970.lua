-- Lua provided by SkyAPI 
-- Game: AppID 769970
addappid(769970)
addappid(769971, 1, "c7317c7725929e502bfa6b0a5e890dc6b6b38e39be1fabbe8da3f87c2e2e5153")
