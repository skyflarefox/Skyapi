-- Lua provided by SkyAPI 
-- Game: AppID 2810940
addappid(2810940)
addappid(2810941, 1, "bf144bfcb9feb605768ee7012138f5255a79507e26bf984502c562f872b65faf")
