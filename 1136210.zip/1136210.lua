-- Lua provided by SkyAPI 
-- Game: AppID 1136210
addappid(1136210)
addappid(1136211, 1, "f44f22ca2f41c811f43bcf7799eff5c0ac330a630249af088458752eec5d767f")
