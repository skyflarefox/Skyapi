-- Lua provided by SkyAPI 
-- Game: AppID 835650
addappid(835650)
addappid(835651, 1, "303aa5cf9ac4c0d43a57dd173753a1d76e9bf428373d0d798298af8f86e3dc0a")
