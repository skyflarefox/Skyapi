-- Lua provided by SkyAPI 
-- Game: AppID 227050
addappid(227050)
addappid(227051, 1, "239cc9377d6648d22460f36168eae8cd87842a88277b1fc2a8cd09ac4f92dc5b")
