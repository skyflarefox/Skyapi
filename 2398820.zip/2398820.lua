-- Lua provided by SkyAPI 
-- Game: AppID 2398820
addappid(2398820)
addappid(2398821, 1, "4b9f761334d5aa5863eb81e3481081805480bcea713530104da93b835d88e8d2")
