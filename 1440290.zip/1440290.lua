-- Lua provided by SkyAPI 
-- Game: Psycho
addappid(1440290)
addappid(1440291, 1, "70501091474aefeecb6e655452bac8b5b94ddf44b6a35c7db159d0a10fb34c75")
