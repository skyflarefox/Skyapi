-- Lua provided by SkyAPI 
-- Game: Void Sols Demo
addappid(2898150)
addappid(2898151, 1, "468e4706198b8d31ef5dbfaccbfabe1cfb701533475a01c8150445f46c5a93a7")
