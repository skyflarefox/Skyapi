-- Lua provided by SkyAPI 
-- Game: Touken Ranbu Warriors Demo
addappid(1912000)
addappid(1912001, 1, "1d73cce304fbce4e38a2f5141bcbd8f6d157627979289a7852027af3153b9343")
