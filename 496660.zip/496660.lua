-- Lua provided by SkyAPI 
-- Game: AppID 496660
addappid(496660)
addappid(496661, 1, "dd47442de7a57e92b5e11688a3e231cc798a94277fd799d8ec980e9421c24b85")
