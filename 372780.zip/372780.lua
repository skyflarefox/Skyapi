-- Lua provided by SkyAPI 
-- Game: AppID 372780
addappid(372780)
addappid(372781, 1, "8e3ce4013c4e55ddd5dcdc0d3a848571d55023e1f4e578256852da5343dbc1dd")
addappid(411150, 0, "c4ef508de3722b6f7123e6a6bf45cc06cf6eaade7a0fe7e120d87d0afbfcc204")
