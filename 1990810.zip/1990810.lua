-- Lua provided by SkyAPI 
-- Game: AppID 1990810
addappid(1990810)
addappid(1990811, 1, "df4af2f1c395bd591a022905cd990846b6b5e18d04c214dbf180fc0f6594d490")
