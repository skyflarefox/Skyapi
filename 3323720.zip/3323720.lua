-- Lua provided by SkyAPI 
-- Game: AppID 3323720
addappid(3323720)
addappid(3323721, 1, "ab3a14bb56c2e5c76237cdc430b374b6202476ff1304644d0373862a285f5d90")
