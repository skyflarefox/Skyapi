-- Lua provided by SkyAPI 
-- Game: PAC-MAN MUSEUM+
addappid(1665130)
addappid(1665131, 1, "fe1b574cd3fd2a82bd0a0d56a7dbd0abfcad414b522a1f437ea24b69c1a2a21b")
addappid(1763630)
