-- Lua provided by SkyAPI 
-- Game: Worldless Demo
addappid(2262290)
addappid(2262291, 1, "7668c19c09cb6d4dadbf0a9d91d26b052fcb4bb07765f180b0de76852cfb46a5")
