-- Lua provided by SkyAPI 
-- Game: AppID 2740110
addappid(2740110)
addappid(2740111, 1, "74fb30c289e007d4f7f59b3d39a9b49307df7234b0625f9b2400c30693a4779b")
