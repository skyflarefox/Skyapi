-- Lua provided by SkyAPI 
-- Game: AppID 814710
addappid(814710)
addappid(814711, 1, "220ebed2fcb4fd25dd7df3d8b1d9801d0e40c879a85b9823f4f3d686cd829553")
