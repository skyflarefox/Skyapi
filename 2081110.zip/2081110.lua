-- Lua provided by SkyAPI 
-- Game: AppID 2081110
addappid(2081110)
addappid(2081111, 1, "71651a8d9f493afb7a7e74b1ef9e918f0fb68b4615614685a53f97dc657ed0ec")
