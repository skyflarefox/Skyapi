-- Lua provided by SkyAPI 
-- Game: AppID 3378000
addappid(3378000)
addappid(3378001, 1, "d1a4989f3be7ea3f77d04653ed53e532dd52100294f36278169c37f75ff9e676")
