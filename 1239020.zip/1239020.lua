-- Lua provided by SkyAPI 
-- Game: TOGETHER BnB
addappid(1239020)
addappid(1239021, 1, "82aede50519233eae836f4cdf8091356f7f4d10f51555c31cabf58c3d2c235ce")
addappid(4030120)
