-- Lua provided by SkyAPI 
-- Game: Mindcop
addappid(1517180)
addappid(1517181, 1, "24c46be0da12d827d8f7b10575577ea3721057d13fb13116551918a7b97e2c13")
