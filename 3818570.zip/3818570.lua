-- Lua provided by SkyAPI 
-- Game: ANOVILL
addappid(3818570)
addappid(3818571, 1, "6d35cac187ca5650b54b904b684f77d36dbb83e05f5a17f240a7cd95f09de489")
