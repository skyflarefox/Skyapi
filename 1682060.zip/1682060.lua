-- Lua provided by SkyAPI 
-- Game: Warriors of the Nile 2
addappid(1682060)
addappid(1682061, 1, "ca21c05ae26ef70ea28fc33a4b52cead451561b3bf58513cdd9d2c3f3aa99863")
