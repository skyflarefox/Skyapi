-- Lua provided by SkyAPI 
-- Game: AppID 375190
addappid(375190)
addappid(375191, 1, "6aa64485a79423ab82b4c1c005261096f7d2da57353ea7d1d18171e6c65a52e3")
