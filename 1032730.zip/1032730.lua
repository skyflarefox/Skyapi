-- Lua provided by SkyAPI 
-- Game: AppID 1032730
addappid(1032730)
addappid(1032731, 1, "6b52cf6b83257c0853e8f5ee1762ad00cf35223d5e0077e753c8e014c494e5fc")
