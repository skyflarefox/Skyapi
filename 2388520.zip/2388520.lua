-- Lua provided by SkyAPI 
-- Game: Kessler Syndrome
addappid(2388520)
addappid(2388521, 1, "e5dac9a7472ba3bad736dc57f4786d248aba71b58d73c3da013d8de22a82ef0f")
