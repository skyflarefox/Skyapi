-- Lua provided by SkyAPI 
-- Game: Gnome Jigsaw Puzzles
addappid(1520250)
addappid(1520251, 1, "c220839af9031411f2738a115228f39116951a299596ce9645e22bc01e72c2a1")
