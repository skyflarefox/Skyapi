-- Lua provided by SkyAPI 
-- Game: Yummy Mahjong
addappid(1689980)
addappid(1689981, 1, "1086b4d0b0a32a42dbbe2b814f28479da579e3e2769bb66b5c2f5d8673ce2a9d")
