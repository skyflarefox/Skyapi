-- Lua provided by SkyAPI 
-- Game: AppID 1202310
addappid(1202310)
addappid(1202311, 1, "d82aa698bc5ca6cd804322cec63dbb91a959b8d11d465375f924f4283c1c7ae5")
