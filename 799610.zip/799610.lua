-- Lua provided by SkyAPI 
-- Game: Drill Arena
addappid(799610)
addappid(799611, 1, "66342bd0bd0a17f836da6783e9d01a5a09f2b087e65c54236125297671d5a1a3")
