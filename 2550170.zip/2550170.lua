-- Lua provided by SkyAPI 
-- Game: AppID 2550170
addappid(2550170)
addappid(2550171, 1, "cc94013274e6a4a204910c012aca3be311cc936cbaaefd2af95e843df1eae769")
