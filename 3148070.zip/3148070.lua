-- Lua provided by SkyAPI 
-- Game: AppID 3148070
addappid(3148070)
addappid(3148071, 1, "3106293a911534754cae452680b004e3ac974cb84d49f5947bbb7bff903d9028")
