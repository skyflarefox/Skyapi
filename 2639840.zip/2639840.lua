-- Lua provided by SkyAPI 
-- Game: Dino Survivors
addappid(2639840)
addappid(2639841, 1, "e6fd25d523ccfff41df1cd2619c3511d7e8b6c38ec166de51b2b37d7aca44a21")
