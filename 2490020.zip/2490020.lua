-- Lua provided by SkyAPI 
-- Game: さよならナイト・キャップ
addappid(2490020)
addappid(2490021, 1, "6431397a3a75820ef3ef1f389ed2c40026fe859d1287d3cf75179cd81a4e958f")
