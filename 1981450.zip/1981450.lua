-- Lua provided by SkyAPI 
-- Game: Piko Piko - Original Soundtrack
addappid(1981450)
addappid(1981451, 1, "8d0b4d40dfb8f6e43f730fa43cabfe317b2da4cfd7e8a2ba918803d44839a291")
