-- Lua provided by SkyAPI 
-- Game: Villages & Dungeons Soundtrack
addappid(3731210)
addappid(3731211, 1, "01c99b0b52a51388fe38e782f7026bf05e76e5cecb3e85f4df9bfe1239b51c6a")
