-- Lua provided by SkyAPI 
-- Game: Supfly Delivery Simulator
addappid(1403350)
addappid(1403351, 1, "a1e6dd89fb247871adfaa1b333abcdc256d5087c37542d406e0602df2faaee19")
