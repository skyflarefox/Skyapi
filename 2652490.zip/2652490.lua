-- Lua provided by SkyAPI 
-- Game: AppID 2652490
addappid(2652490)
addappid(2652491, 1, "6e24f3764bd3075c81f7d16c37a20481526acc72c2c6765bf80ce05e179b0d50")
