-- Lua provided by SkyAPI 
-- Game: Tiny Pasture
addappid(3167550)
addappid(3167551, 1, "2eb36141e330220bd89c47de8cca1c780182686771b6f5e9251eeef811774d14")
