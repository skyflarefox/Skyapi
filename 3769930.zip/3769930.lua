-- Lua provided by SkyAPI 
-- Game: AppID 3769930
addappid(3769930)
addappid(3769931, 1, "7c7c99c7a112ad1106cf2bc3a5ff042d4d562cfbe75f481d61ef70be75cddbfd")
