-- Lua provided by SkyAPI 
-- Game: Frigore
addappid(1836220)
addappid(1836221, 1, "849a9515c11db937b9f69a0308116fd9400787389147241e11312dca772a970a")
