-- Lua provided by SkyAPI 
-- Game: Lifecraft
addappid(1839930)
addappid(1839931, 1, "90e99f7e92b78e8bf291f6be1a6be1298c3a05504b89436cb4f543120987dd38")
