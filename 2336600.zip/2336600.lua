-- Lua provided by SkyAPI 
-- Game: ALPEN GHOUL: Prologue
addappid(2336600)
addappid(2336601, 1, "987b50d7f022641db3dbaad2b567f0d1acca6d3f6d1aedd295acc15c832d6a05")
