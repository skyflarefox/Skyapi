-- Lua provided by SkyAPI 
-- Game: the jester's revenge
addappid(1072090)
addappid(1072091, 1, "fd4fd4765d90a47e89b2c1d260274878bd59e8ffba8fcd18f8146ce2323e327b")
