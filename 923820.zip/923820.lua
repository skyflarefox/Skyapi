-- Lua provided by SkyAPI 
-- Game: AppID 923820
addappid(923820)
addappid(923821, 1, "38723f5067e6af32eb79f8bba50d9273de13185b989d22547c8ac9c5420f50f4")
