-- Lua provided by SkyAPI 
-- Game: Jumperbird
addappid(1310480)
addappid(1310481, 1, "5171ad5bb1c3e14b76a105ba725e3ffabf410d4c6c89d8ceffd3808a3cc0f024")
