-- Lua provided by SkyAPI 
-- Game: Skeleton Village
addappid(2921770)
addappid(2921771, 1, "6310d7e201b30742ae7e885ae883d752ebca771a901220b0e1e5f0460915ee6a")
