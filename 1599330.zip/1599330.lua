-- Lua provided by SkyAPI 
-- Game: Wildmender
addappid(1599330)
addappid(1599331, 1, "afd9a47ff2961d2300f050adb60d8518347475523c6708a9208f349156cc6835")
