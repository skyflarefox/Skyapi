-- Lua provided by SkyAPI 
-- Game: AppID 796340
addappid(796340)
addappid(796341, 1, "41d7e2f9c818d0e489962b40aa24da0775f9e96239bac4a93d4bf82211890e02")
