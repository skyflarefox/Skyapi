-- Lua provided by SkyAPI 
-- Game: Legend of Krannia: Cursed Fate
addappid(1458340)
addappid(1458341, 1, "aa3812cc5100589a30f2f3eb03191ca22df76f7cb2a6d53f00b167922e807c7d")
