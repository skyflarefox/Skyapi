-- Lua provided by SkyAPI 
-- Game: It Was Raining That Night
addappid(2543770)
addappid(2543771, 1, "8cd1aac09116c0f8e1f2fa54c330dc0c1adcebddbb5781638777a7db11c9de9f")
