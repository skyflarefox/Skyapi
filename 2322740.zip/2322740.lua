-- Lua provided by SkyAPI 
-- Game: AppID 2322740
addappid(2322740)
addappid(2322741, 1, "5f96a66026886d7a20898cac9080d1ce1200fd1e936e50399a61dd7008b62736")
