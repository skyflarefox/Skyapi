-- Lua provided by SkyAPI 
-- Game: Acid Planet
addappid(2641530)
addappid(2641531, 1, "8e851a2abd8dec84cce86ef102891152e11461d58a3a655c12dd179f3dd500b5")
