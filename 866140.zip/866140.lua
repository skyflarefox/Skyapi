-- Lua provided by SkyAPI 
-- Game: Arise: A Simple Story
addappid(866140)
addappid(866141, 1, "bc1d9fc90b9f1fe4f26c77680eef7130cb4c7d5a5a8b238d5273e20ba3186ad7")
