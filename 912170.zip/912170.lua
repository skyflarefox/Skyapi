-- Lua provided by SkyAPI 
-- Game: AppID 912170
addappid(912170)
addappid(912171, 1, "c0ab53207618897cd5183b18eaf68351f11c0f746d80322050258f8ed50a4322")
