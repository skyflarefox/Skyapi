-- Lua provided by SkyAPI 
-- Game: Davey
addappid(1928350)
addappid(1928351, 1, "6ef658e4282942f630d0f57d6a2bd7b58cb87ddce923880f6aa406ea98bda14c")
