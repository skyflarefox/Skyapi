-- Lua provided by SkyAPI 
-- Game: AppID 2753610
addappid(2753610)
addappid(2753611, 1, "94c3f286eead46cb94dcbf9f64dc7ab453010abf2c51ebceae7ce6a7fd722aa9")
