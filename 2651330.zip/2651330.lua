-- Lua provided by SkyAPI 
-- Game: Intravenous 2: Mercenarism
addappid(2651330)
addappid(2651331, 1, "ae93ebe6b8baae2d4fd79e56f751d123e83392a529d1efb5feeb35884716b0a2")
