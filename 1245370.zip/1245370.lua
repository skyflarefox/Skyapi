-- Lua provided by SkyAPI 
-- Game: AppID 1245370
addappid(1245370)
addappid(1245371, 1, "d874e9830dbabd9017f4a5ce184969380b13b735896493642e2e601520be0c6c")
