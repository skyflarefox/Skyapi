-- Lua provided by SkyAPI 
-- Game: AppID 462910
addappid(462910)
addappid(462911, 1, "85ef6bdc45587d4e5d6322334c59065cd376c5b4d55bc90209c8b56d740b6f87")
