-- Lua provided by SkyAPI 
-- Game: HARK THE GHOUL Demo
addappid(3132850)
addappid(3132851, 1, "4846c27fc16475d9f13f8c5cc8fda7eb7c2e44a89fa872a5cf15ce764fd80ff8")
