-- Lua provided by SkyAPI 
-- Game: LurkBait Twitch Fishing
addappid(2767520)
addappid(2767521, 1, "25b89f570154680e82f3497125d1a02335b21e604601c505f0c20b86ce7af980")
