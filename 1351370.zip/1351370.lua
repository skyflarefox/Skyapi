-- Lua provided by SkyAPI 
-- Game: AppID 1351370
addappid(1351370)
addappid(1351371, 1, "36360296fd81678d5854be48152b785deec3d433fca8a522c2cca9bda6685325")
