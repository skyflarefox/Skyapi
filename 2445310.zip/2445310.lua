-- Lua provided by SkyAPI 
-- Game: AppID 2445310
addappid(2445310)
addappid(2445311, 1, "b9440d817cd126cdad734f7f4535f3d963a2e2a298468b2224ff55b443d335ab")
