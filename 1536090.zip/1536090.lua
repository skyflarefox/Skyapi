-- Lua provided by SkyAPI 
-- Game: Echoes of the Plum Grove
addappid(1536090)
addappid(1536091, 1, "3d3857b760b7b5ff52f50f5b402d4413a1e911ba3238c4b9ee9c225792fc32b9")
