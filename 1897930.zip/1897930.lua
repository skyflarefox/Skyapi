-- Lua provided by SkyAPI 
-- Game: AppID 1897930
addappid(1897930)
addappid(1897931, 1, "79d7d77c802c55797a033ddb1f403680c6f2f59a54908cf429f0a8fea22e46f1")
