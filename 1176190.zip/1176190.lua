-- Lua provided by SkyAPI 
-- Game: AppID 1176190
addappid(1176190)
addappid(1176191, 1, "b9f0170653733d7cfdba5cb8a22ec6d92f2bd223d0dc85899437b90f886caf93")
