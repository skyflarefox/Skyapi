-- Lua provided by SkyAPI 
-- Game: AppID 2092280
addappid(2092280)
addappid(2092281, 1, "f392ce39e28e1f94a16830f47bbefc83833ecc3271a65593b6cabb7d6fb74b47")
