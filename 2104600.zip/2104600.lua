-- Lua provided by SkyAPI 
-- Game: Sex Adventures - The Pool Party
addappid(2104600)
addappid(2104601, 1, "efa36dee8abb195b8ecb81cf8584f4228aca7d64482487d700f68c437955fa66")
