-- Lua provided by SkyAPI 
-- Game: Setteeh
addappid(1566450)
addappid(1566451, 1, "c4546af894afa897c5fa6093f8bcdf69436211257932aad8d251521253566ae1")
