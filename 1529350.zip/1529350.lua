-- Lua provided by SkyAPI 
-- Game: AppID 1529350
addappid(1529350)
addappid(1529351, 1, "e66d404366cfdb5ecd9cf2dd2b9d678830641139c8f060e8854a7449e0037f4b")
