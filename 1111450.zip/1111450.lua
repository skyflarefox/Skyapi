-- Lua provided by SkyAPI 
-- Game: AppID 1111450
addappid(1111450)
addappid(1111451, 1, "756b1f5dcc9a4220be7ec84a53f0e6c8fa733e0117533fbf142c4bff4684585f")
