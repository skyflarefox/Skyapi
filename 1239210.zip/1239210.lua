-- Lua provided by SkyAPI 
-- Game: AppID 1239210
addappid(1239210)
addappid(1239211, 1, "6f804f8101feb0438f82b0a2721b175ec7c3bf0fbbc0f5822da9bb17bb789b41")
