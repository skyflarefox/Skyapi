-- Lua provided by SkyAPI 
-- Game: Bingo Hall
addappid(1219230)
addappid(1219231, 1, "709c97edc93659f80132a1c2c1d7ad04713745d8ff5bc66b940f67a3e91d2c5b")
