-- Lua provided by SkyAPI 
-- Game: AppID 1118880
addappid(1118880)
addappid(1118881, 1, "c34a209bdefa07f5bc6d1315d8875fb2a2737dd81b5822ad5853f916e5f200f6")
