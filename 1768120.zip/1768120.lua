-- Lua provided by SkyAPI 
-- Game: Idle Champions - Bardic Inspiration Vol 1.5
addappid(1768120)
addappid(1768121, 1, "1945bef007186ef164b39459f836989bfe0c36d9775babd9577f41e36842eed1")
