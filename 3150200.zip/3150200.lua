-- Lua provided by SkyAPI 
-- Game: REYNATIS Demo
addappid(3150200)
addappid(3150201, 1, "25eb6bc97cb0c0e73d9881825bf8251ed01438a3ea41735857febeec09d3d8ca")
