-- Lua provided by SkyAPI 
-- Game: Stream Toys by Zokya
addappid(1535420)
addappid(1535421, 1, "46e3eca00a4ede5a8a6d73d0c155772da04d720ea47b3724b7257a3827cc8be5")
