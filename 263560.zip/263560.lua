-- Lua provided by SkyAPI 
-- Game: Paper Sorcerer
addappid(263560)
addappid(263561, 1, "7f4a9c19823764988fd0376af0859ffc07a894a65caf5ba04af8a1641dd2e0f0")
