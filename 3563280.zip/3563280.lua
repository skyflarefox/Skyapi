-- Lua provided by SkyAPI 
-- Game: Trainfort Playtest
addappid(3563280)
addappid(3563281, 1, "ca672ddb80128dde595c342e7fc5fdc33ce1471759b303e2dfd8f8d3695a9049")
