-- Lua provided by SkyAPI 
-- Game: What's Your Gender?
addappid(1761630)
addappid(1761631, 1, "de1161c16f3e9187a0b85c94981335efd0bbf7779d51ee59b6494796b0b2632c")
