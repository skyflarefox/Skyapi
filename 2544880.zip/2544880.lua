-- Lua provided by SkyAPI 
-- Game: Dreamland
addappid(2544880)
addappid(2544881, 1, "a67c60f49e7760faedb47606ce3d208287630e604731e9ee82ed7741a7d1b343")
