-- Lua provided by SkyAPI 
-- Game: Strip Black Jack - At The Pub
addappid(1416710)
addappid(1416711, 1, "1f993ae4bbe4c4d1e149cbd2fe4dfbaa36c5b0bd47e9d3c07657394afb310168")
