-- Lua provided by SkyAPI 
-- Game: AppID 2581010
addappid(2581010)
addappid(2581011, 1, "b046b0ab68f3e21e60ac2575da0fc4899584f0925c8b5d0315e392dabf3fbbd3")
