-- Lua provided by SkyAPI 
-- Game: Catsby
addappid(590270)
addappid(590271, 1, "27c1da0396f63f9f1cf92a8dc8e2c2d8fe189841fb614f2fc2ada2214ecfc75a")
