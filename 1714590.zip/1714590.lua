-- Lua provided by SkyAPI 
-- Game: Buck Up And Drive!
addappid(1714590)
addappid(1714591, 1, "3905056b454f38803812955bfd78df1d027fae3640ea4304c3bd52b50593d2b8")
