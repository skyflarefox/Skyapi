-- Lua provided by SkyAPI 
-- Game: AppID 2581780
addappid(2581780)
addappid(2581781, 1, "18fd36ac413fa3299f79d63eacecf7de0723f339af4a87b444b4ce17345d82fb")
