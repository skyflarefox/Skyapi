-- Lua provided by SkyAPI 
-- Game: Hentai Sakura 🌸🌊
addappid(1736360)
addappid(1736361, 1, "29149ad52684f223829223b0282db915116714124b12dd5ae0916a06a1e43b3d")
addappid(1787250, 0, "e2f98900762a5e69be3b4ebae101d965932d6c563fe1613287f78e6686b04fcf")
