-- Lua provided by SkyAPI 
-- Game: PROVIDER
addappid(1604390)
addappid(1604391, 1, "46a9b62f0b7c52615e25191a5496a391348f616626e1ad731152c6785eac672a")
