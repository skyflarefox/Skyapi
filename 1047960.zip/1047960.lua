-- Lua provided by SkyAPI 
-- Game: TOK 2
addappid(1047960)
addappid(1047961, 1, "5ffae2af1479c2fc7b2eb5dba0923ccdeb1df95e4c788fd419fd2377dc17ea5a")
