-- Lua provided by SkyAPI 
-- Game: AppID 968730
addappid(968730)
addappid(968731, 1, "9c37db0b961ed11ef34edaf7cc5d5a6f15e2abffc882a784373176a30b66a3a7")
