-- Lua provided by SkyAPI 
-- Game: Maze Burrow
addappid(1244190)
addappid(1244191, 1, "46f585f9b3634d2c334d73b5e15a4b368993597dc3f9e6665f0284cb4d77cdf0")
