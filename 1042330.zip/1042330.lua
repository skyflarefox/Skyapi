-- Lua provided by SkyAPI 
-- Game: Tricky Cat
addappid(1042330)
addappid(1042331, 1, "a7974af0414abc73353a22e1dbd7d5d200056aac1a5c9b042a44ec108f1f22a5")
addappid(1043820, 0, "e1a1ab0b125b596399811634f13a0694a14898b23625fa719b5bb6578369d4c3")
