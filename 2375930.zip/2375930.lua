-- Lua provided by SkyAPI 
-- Game: Simple Multipliers
addappid(2375930)
addappid(2375931, 1, "b1684bc8303b5e2656ca83cb03561603a7296c8b5d5ac9574411e1b51714d34a")
