-- Lua provided by SkyAPI 
-- Game: AppID 1510580
addappid(1510580)
addappid(1510581, 1, "1f244b9241af9ab2debf7d905cbe81ec6ad5d7c60889ddbe6ef711ca4508aed7")
