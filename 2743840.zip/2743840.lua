-- Lua provided by SkyAPI 
-- Game: SHADOW DETECTIVE
addappid(2743840)
addappid(2743841, 1, "2928ba62e59bc417d220c12a1aff908cd00872838742b3ff2ba6d3273366b6c8")
