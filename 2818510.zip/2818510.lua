-- Lua provided by SkyAPI 
-- Game: Observe and Report
addappid(2818510)
addappid(2818511, 1, "e46f588890898065ef46e3f188acb2cf826b68f9e55c5ef4e7dbd5be3ee10d4e")
