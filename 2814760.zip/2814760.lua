-- Lua provided by SkyAPI 
-- Game: AppID 2814760
addappid(2814760)
addappid(2814761, 1, "4cf5f171eadd4210c50206203d57bf04b9ab217bfa385c2c5f4fc079bf316827")
