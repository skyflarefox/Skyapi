-- Lua provided by SkyAPI 
-- Game: Iron Conflict
addappid(1371480)
addappid(1371481, 1, "5ed5f7b5c62fffed62429a1218dbcc18427050c54a0e2d77c4ed26516bb4a7cc")
