-- Lua provided by SkyAPI 
-- Game: AppID 908310
addappid(908310)
addappid(908311, 1, "de40027a0c8e5a8bf41ffee7e19b0ccf136991d5d183827c634f69200e8d9663")
