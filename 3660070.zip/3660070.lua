-- Lua provided by SkyAPI 
-- Game: Disaster Blaster Soundtrack
addappid(3660070)
addappid(3660071, 1, "960909f82834e715ebcc18de1add002c34bbbebe6efbab6f8b016bcdd81cd78b")
