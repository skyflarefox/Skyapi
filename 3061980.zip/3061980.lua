-- Lua provided by SkyAPI 
-- Game: AppID 3061980
addappid(3061980)
addappid(3061981, 1, "ea5200c3b75e7c78878e32b3d0374b9bb32f186d64ab532b53aa36cea0e78632")
