-- Lua provided by SkyAPI 
-- Game: AppID 1608470
addappid(1608470)
addappid(1608471, 1, "685dfc0ea1beebf4266f2b08e2afdf0aa7ca8b42ebda0205ad12b214aa51fb96")
