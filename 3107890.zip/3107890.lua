-- Lua provided by SkyAPI 
-- Game: SNOW BROS. SPECIAL: ANNIVERSARY EDITION
addappid(3107890)
addappid(3107891, 1, "159cce2b4c32e927f294bb9d4b339f1b112acf522ed28dbd81bcf15aa964ff3d")
