-- Lua provided by SkyAPI 
-- Game: AppID 3122890
addappid(3122890)
addappid(3122891, 1, "2eaef0c5bd436a30169b775378846c1e0e1b1e2288682a4e7374ad13f3354dd8")
