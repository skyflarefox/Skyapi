-- Lua provided by SkyAPI 
-- Game: AppID 2259210
addappid(2259210)
addappid(2259211, 1, "8bfc3a32cd948f3b67aadf01e873527807da44a6c67708e69303f5991133d4ff")
addappid(2508140)
