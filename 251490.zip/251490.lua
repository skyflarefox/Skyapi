-- Lua provided by SkyAPI 
-- Game: Gravity Ghost
addappid(251490)
addappid(251491, 1, "8968cefaabab335f03e08b30e7a50d1f425a0bcbcd3614d38b7ef28d2d1ecf8c")
addappid(251492, 1, "721d59a4089c18391ede2aef3131923db3d374204d5f50fa4319c7c208774b1d")
addappid(251493, 1, "1622d270bde16d28c72e8c02a2fd223baf5a091ec59621c5425f112f3983b2b9")
addappid(343510)
