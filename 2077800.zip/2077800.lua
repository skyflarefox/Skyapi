-- Lua provided by SkyAPI 
-- Game: Streamer's Court
addappid(2077800)
addappid(2077801, 1, "57fe0965658176dbc24cf1f21a30885a830aea9123208c2412935b1d151ea358")
