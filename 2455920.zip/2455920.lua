-- Lua provided by SkyAPI 
-- Game: Mimic Logic
addappid(2455920)
addappid(2455921, 1, "dd03f5a2e3abca6cfbcd154b28f7f46a81b088984291261d19da3ac4522d5140")
