-- Lua provided by SkyAPI 
-- Game: AppID 1023040
addappid(1023040)
addappid(1023041, 1, "6d5bbd174ace9bec89bd7ee86d28023a0910697e0bce082f7df2b372688ad0b4")
