-- Lua provided by SkyAPI 
-- Game: AppID 1676910
addappid(1676910)
addappid(1676911, 1, "606b06d68ee52ff3a0819772155d92eb6227b18085be5484a631a59db9ddbbf5")
