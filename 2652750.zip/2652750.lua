-- Lua provided by SkyAPI 
-- Game: Grappling Gunners: Arena FPS
addappid(2652750)
addappid(2652751, 1, "270fde28a2e3ac2f421d9a1880027b6a426aa70212edba3c2488dfe1d7040ec8")
