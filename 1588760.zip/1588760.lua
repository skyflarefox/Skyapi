-- Lua provided by SkyAPI 
-- Game: Switchball HD
addappid(1588760)
addappid(1588761, 1, "631f7f8a64a6f4d7eed22b4db0d100b4ae3ce9ca24000ba47de96de81f66511f")
