-- Lua provided by SkyAPI 
-- Game: In a search of a new home
addappid(1284510)
addappid(1284511, 1, "64285289ae8b92b1e479aa067956b2b812c99c46115e126cb836476c643533d9")
