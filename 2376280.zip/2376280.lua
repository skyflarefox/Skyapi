-- Lua provided by SkyAPI 
-- Game: Whisker Witchery
addappid(2376280)
addappid(2376281, 1, "e00a8a4d8d72b23266ecebbb65fd7140f15532afac43810cc5bd7273e28f7867")
