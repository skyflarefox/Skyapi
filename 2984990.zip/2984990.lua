-- Lua provided by SkyAPI 
-- Game: Rise of Kenshin Playtest
addappid(2984990)
addappid(2984991, 1, "2218896d984432fedf759ec338c92a2c586fad949972c1c9cd2f7b38c1db7669")
