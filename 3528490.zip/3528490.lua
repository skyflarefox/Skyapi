-- Lua provided by SkyAPI 
-- Game: Swipe Right for Sugar Mama Sensei
addappid(3528490)
addappid(3528491, 1, "8c677c9138fdc8975b87b443690800448c2c012e7f7045d4491f01a4b7bf0f5d")
