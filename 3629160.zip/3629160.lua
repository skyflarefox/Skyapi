-- Lua provided by SkyAPI 
-- Game: 手机时代 Mobile era
addappid(3629160)
addappid(3629161, 1, "fdd3ab8294ca3e434935c39407db4d4c688aeb4eb854c19d09d03023cc8e2d41")
