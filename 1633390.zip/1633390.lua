-- Lua provided by SkyAPI 
-- Game: Hentai Pretty
addappid(1633390)
addappid(1633391, 1, "b8ef02eee1b58a7c9bf2317b55b4037f750892ddd46759dd5c7ae16a37a596b6")
