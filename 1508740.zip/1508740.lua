-- Lua provided by SkyAPI 
-- Game: Xuan-Yuan Sword 2
addappid(1508740)
addappid(1508741, 1, "5b56a4411827c0072421584eec11065101858b104ddfbf9aa7d524a7e5e7b367")
