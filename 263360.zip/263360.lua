-- Lua provided by SkyAPI 
-- Game: 3089 - Futuristic Action RPG
addappid(263360)
addappid(263361, 1, "723b1009b96e18c89ecdd788c9493e2c551d24fb379316dcf3d0499ed330327b")
addappid(263362, 1, "06853a00e9bd8f1a2046a28e9a1a57bc5e7a38772089702eea5d15eb25308a1b")
addappid(263363, 1, "ca911b9f7685c2ebc17f6de83f1f69e41343d3a5aaae736329c1ce426b08559a")
