-- Lua provided by SkyAPI 
-- Game: Alteil: Horizons
addappid(379870)
addappid(379871, 1, "614e594271e7171201a816c9506c72fb94c0e98726fbcb27405abe6bfbaff017")
addappid(379872, 1, "76a45f736d81f7270361e76a4142773082bb1a5edda7c02ad8756500874fd549")
