-- Lua provided by SkyAPI 
-- Game: Land of Screens
addappid(1271260)
addappid(1271261, 1, "a04ae5191d490d3c5c2fe27b1df24ad83b1b19d2ab48bfb0c3c48b9c57936357")
