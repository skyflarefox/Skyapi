-- Lua provided by SkyAPI 
-- Game: Night Of The Living Dead VR
addappid(1210910)
addappid(1210911, 1, "5f59ddb6e38a7033041b4eaf1fb46163b256e6a95e4af208d6de3f758fd1e3c5")
