-- Lua provided by SkyAPI 
-- Game: AppID 1036600
addappid(1036600)
addappid(1036601, 1, "ce20068d2d27cfd1bb3267deb3212908f930c16387f7a227f868b758991be0d9")
