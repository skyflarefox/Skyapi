-- Lua provided by SkyAPI 
-- Game: Laundry & Supermarket Simulator
addappid(3125570)
addappid(3125571, 1, "f0120aa244caeddda39251c1ccd4717bdc1a74eda70dad620f8fae943119cc18")
