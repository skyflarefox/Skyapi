-- Lua provided by SkyAPI 
-- Game: AppID 1107750
addappid(1107750)
addappid(1107751, 1, "6405f23c21b53080786a713cc4aa04456e24c07039b0fbb0d9d0e9900329b631")
