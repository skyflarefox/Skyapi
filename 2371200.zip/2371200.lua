-- Lua provided by SkyAPI 
-- Game: No Creeps Were Harmed TD Demo
addappid(2371200)
addappid(2371201, 1, "0dc3beef38ca1450d1ea7cbbdfec4cdf06e426d63a70605e6f2d31c90353f093")
