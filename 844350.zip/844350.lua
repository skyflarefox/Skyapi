-- Lua provided by SkyAPI 
-- Game: AppID 844350
addappid(844350)
addappid(844351, 1, "126312b4e0060e9ac4ab87c7974f98c03aae765564b0f968f38784eae04ffd83")
