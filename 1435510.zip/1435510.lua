-- Lua provided by SkyAPI 
-- Game: ATRI -My Dear Moments- Original Soundtrack
addappid(1435510)
addappid(1435511, 1, "6d8433d962bcba178ad6213acf6947d5003ec7726d39b6444b769e6377b38209")
addappid(1435512, 1, "4c6bcf43d0784719a51234c898f836c17903972a582344730b57ed40da297339")
