-- Lua provided by SkyAPI 
-- Game: HROT
addappid(824600)
addappid(824601, 1, "ff5fa9dd3f22286f54d972522560bc51f5bc451817ffd0ad40a2c1d7829212d1")
