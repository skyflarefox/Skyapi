-- Lua provided by SkyAPI 
-- Game: Hentai Forever
addappid(1472950)
addappid(1472951, 1, "9a8e2bab45640a00e045aa196de0cff6577fe12d964874f03a1424f7ba178976")
