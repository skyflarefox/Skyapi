-- Lua provided by SkyAPI 
-- Game: Redux: Dark Matters
addappid(336930)
addappid(336931, 1, "8d5a6357208bdf28f32dd596f6baf62643034f59c5864ab53b6a2bca9f1aa1df")
addappid(338480, 0, "0b819f6c7ca4a57b392062b6576fcca00e8003078ff64a53f4f5fc7d3ad2bae9")
