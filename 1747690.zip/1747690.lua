-- Lua provided by SkyAPI 
-- Game: AppID 1747690
addappid(1747690)
addappid(1747691, 1, "69933882389b9fec453bd6bec159c6c140b06a1467e40f84c3060df17aa1b277")
