-- Lua provided by SkyAPI 
-- Game: AppID 705070
addappid(705070)
addappid(705071, 1, "85babf2982b1896b0c7c773dd10254fd04f7c74d032b9e8248ca1dfc99a4d30d")
