-- Lua provided by SkyAPI 
-- Game: Shoot, push, portals
addappid(1197990)
addappid(1197991, 1, "4fe4cf111fb5f854d8689e26d96bdd85d2779f7ac4538064804d32d5d91bc893")
