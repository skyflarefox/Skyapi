-- Lua provided by SkyAPI 
-- Game: Beach Gas Gas
addappid(2387820)
addappid(2387821, 1, "5db210c732a834eddb35127d67f0a31801515cd7e8afaa77350ec98e13bd10e8")
