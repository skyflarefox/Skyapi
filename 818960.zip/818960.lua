-- Lua provided by SkyAPI 
-- Game: AppID 818960
addappid(818960)
addappid(818961, 1, "459e66d3373e3c629aafc845c54b419e953a493d93eba77b90e36fd66e32c8f5")
