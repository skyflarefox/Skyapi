-- Lua provided by SkyAPI 
-- Game: WASDJK
addappid(2953790)
addappid(2953791, 1, "ff0c65f659dc58b2a03d7fe7f05f6924af9bfa77bbcee4e841f9b5653bbf3664")
