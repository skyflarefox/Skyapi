-- Lua provided by SkyAPI 
-- Game: Strange Antiquities
addappid(2885870)
addappid(2885871, 1, "04d90ad9cc572621850a39b182186c2ad581d4fa73491b5a7d9afe3427e87145")
