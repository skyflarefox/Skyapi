-- Lua provided by SkyAPI 
-- Game: Red Pistol
addappid(3213790)
addappid(3213791, 1, "68d3d35d14733d62c1beec3bab1123df0fbe6e56e0a5c4be8d390d9c6ae531df")
