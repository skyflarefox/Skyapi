-- Lua provided by SkyAPI 
-- Game: Conor Origins - T Trilogy
addappid(2748450)
addappid(2748451, 1, "00d4a1c1ae5496fdb1b4d36bbe7aaa75388d16fc1d68c1ae8194f2844b7ae451")
