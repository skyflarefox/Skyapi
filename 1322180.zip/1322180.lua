-- Lua provided by SkyAPI 
-- Game: DriftZ
addappid(1322180)
addappid(1322181, 1, "d211d2dbdb88c47621c210ad1976926d58cddff93d6987952bf6001ea344b8b1")
