-- Lua provided by SkyAPI 
-- Game: AppID 369140
addappid(369140)
addappid(369141, 1, "a9a20735660ef002dc6188c9e24173a0691a09c2d3f0b24e2a967adafd7fd361")
