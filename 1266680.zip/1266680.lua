-- Lua provided by SkyAPI 
-- Game: Strobophagia | Rave Horror
addappid(1266680)
addappid(1266681, 1, "ccdd02da6e945de84742d22fdb9e2353d52e75ec9ba89ff0443fb31321cc259d")
