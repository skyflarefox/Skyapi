-- Lua provided by SkyAPI 
-- Game: AppID 1184890
addappid(1184890)
addappid(1184891, 1, "232fb57bbb82ac9949ed006d78e3abc534e64f79d2288baaed387155719bb618")
addappid(1184892, 1, "5a82b146896ebcbcd7e78000497226a32f6bf16740f3450ee4c7151dccbfa404")
