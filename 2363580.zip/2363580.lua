-- Lua provided by SkyAPI 
-- Game: Hentai Ellie
addappid(2363580)
addappid(2363581, 1, "ad95f93243f077534662804705ac3e4bbf7531c09a0bc29be542a6fcbc4149b7")
