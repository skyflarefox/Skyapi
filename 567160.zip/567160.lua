-- Lua provided by SkyAPI 
-- Game: AppID 567160
addappid(567160)
addappid(567161, 1, "556f23dfded7498c70678c6f9cee13bffb881536bc52143c806a3b2fd957d417")
addappid(983470)
