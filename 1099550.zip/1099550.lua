-- Lua provided by SkyAPI 
-- Game: 3D Organon
addappid(1099550)
addappid(1099551, 1, "a5f1c62741607a0cb20569d7d52d5b8db55ab0daf879b43e7c79d69bb14959e3")
