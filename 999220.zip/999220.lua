-- Lua provided by SkyAPI 
-- Game: AppID 999220
addappid(999220)
addappid(999221, 1, "16e1b3abd66452bc21db04d4031cfe2aafa0911774a821ad984b59c2ac02ffb5")
