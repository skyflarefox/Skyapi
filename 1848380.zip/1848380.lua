-- Lua provided by SkyAPI 
-- Game: Era Dream : Rose
addappid(1848380)
addappid(1848381, 1, "9ba31c7073ef13f277b6d6c2924bcb5d918e54fb0de80f6022691897981505ea")
