-- Lua provided by SkyAPI 
-- Game: Zup! XS
addappid(673800)
addappid(673801, 1, "2ec06614ff1bbedb1e5f1082d8d926e4ec14e6de791eddf1c9f610d0897b9568")
