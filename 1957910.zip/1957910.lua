-- Lua provided by SkyAPI 
-- Game: Farmland Realm
addappid(1957910)
addappid(1957911, 1, "071d221be756c2ec937cedb12c7fc165be623f40bc23544b24f6f0a7a96c687d")
