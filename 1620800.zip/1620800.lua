-- Lua provided by SkyAPI 
-- Game: Helix
addappid(1620800)
addappid(1620801, 1, "366007cc7bea76d1f6c2b3e91ab67471f88a4ab5de55df5e109420c99e340f58")
