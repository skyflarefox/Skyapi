-- Lua provided by SkyAPI 
-- Game: Minnano Gensokyo Single
addappid(1223020)
addappid(1223021, 1, "7f3c3ce7002c1a17c533b22c9ccf488a4d04725ad9d310b780792ff38c10edb6")
