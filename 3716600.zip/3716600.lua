-- Lua provided by SkyAPI 
-- Game: Mage Arena
addappid(3716600)
addappid(3716601, 1, "e310c1b9ef27e0d9ec00ac3593dc3851ee94ffa39699fed48341039f9ec50fc6")
