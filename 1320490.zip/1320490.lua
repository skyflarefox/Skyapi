-- Lua provided by SkyAPI 
-- Game: Princess Farmer
addappid(1320490)
addappid(1320491, 1, "710bee858b8759deb077a5098857d749cf7111b156f53f03d8a33f0f43b4f24d")
