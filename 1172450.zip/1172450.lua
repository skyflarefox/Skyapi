-- Lua provided by SkyAPI 
-- Game: AppID 1172450
addappid(1172450)
addappid(1172451, 1, "14689acd87c8b9785336e0fe9c95c17747498e2108d546e2c83d9af8a02a39e5")
