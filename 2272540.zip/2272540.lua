-- Lua provided by SkyAPI 
-- Game: FBC: Firebreak
addappid(2272540)
addappid(2272541, 1, "a07aa761da92da0deb6a785fac179e2fc66fd3cb9b177051ff9b397b2b966ceb")
addappid(3625720)
