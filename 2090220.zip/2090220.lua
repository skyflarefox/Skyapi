-- Lua provided by SkyAPI 
-- Game: OneHanded
addappid(2090220)
addappid(2090221, 1, "075490eee0ea9f25b3228b04afd65f6c690162fedd0a1b1ee7084cbec92f590f")
