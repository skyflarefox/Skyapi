-- Lua provided by SkyAPI 
-- Game: AppID 451140
addappid(451140)
addappid(451141, 1, "b98d4cf2c263c083f797f1c30446e74e179f430e6dd39b94415fd60a15b870d0")
