-- Lua provided by SkyAPI 
-- Game: AppID 206610
addappid(206610)
addappid(206611, 1, "9f7b90208d3fa0a8699c0e90338c7e46996327d0e16148e3b62b488ead637597")
addappid(206612, 1, "fae5a5f4700c4785d0088aea6f161692d24b4cca3be8c654bcadcae49b3441e8")
addappid(206613, 1, "c9bbe3701c1b309d2138131cbb4b58f40a413ddd7e190a1ba451ffa0f6d85acd")
