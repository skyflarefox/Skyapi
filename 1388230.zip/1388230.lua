-- Lua provided by SkyAPI 
-- Game: DANMAKAI: Red Forbidden Fruit
addappid(1388230)
addappid(1388231, 1, "db42f9836d112149612344d88b6630f6cd8acea678766035e1c77717e48dffac")
