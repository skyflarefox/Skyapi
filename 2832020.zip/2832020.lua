-- Lua provided by SkyAPI 
-- Game: Hentai Tales: Mysterious Clinic
addappid(2832020)
addappid(2832021, 1, "e6b11b53d06b4aa472b4815f8917278a3d5edf92afc9a9b8ee1c2f8da9f2f251")
