-- Lua provided by SkyAPI 
-- Game: AppID 1476420
addappid(1476420)
addappid(1476421, 1, "deb6ec91a12dd1fe9c42840d2e1298a32c8358f270584461da17237b6c48500a")
