-- Lua provided by SkyAPI 
-- Game: Mini Metro
addappid(287980)
addappid(287981, 1, "869521420d64e94f80ef03c34189e5190ea3447ec82d3fd53ca8684b098e48a9")
addappid(287982, 1, "cde736bc19e35c54b9cffadb1e2d83ce76777c30aefe71a2d140ad02ff2262b8")
addappid(287983, 1, "d9349b18e926a03ef90642f1badb275fb5f746e61435c2c07418a9dad49d09f0")
