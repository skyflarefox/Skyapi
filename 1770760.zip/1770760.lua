-- Lua provided by SkyAPI 
-- Game: Codename: TIARAS
addappid(1770760)
addappid(1770761, 1, "2b46a4a36401dddd4494beb26985712efa3d1e449064a8064accf151b69fb0cb")
