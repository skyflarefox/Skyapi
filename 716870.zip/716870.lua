-- Lua provided by SkyAPI 
-- Game: AppID 716870
addappid(716870)
addappid(716871, 1, "d77fe0c84242001f3cbe45e51bb36d2145b91680c27108bd6f6cac9aa0b45381")
