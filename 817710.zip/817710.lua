-- Lua provided by SkyAPI 
-- Game: vridniX
addappid(817710)
addappid(817711, 1, "9b6ef24443e62bef0ab4f058d206b220a18d19c7e816081f136744bb6299a169")
