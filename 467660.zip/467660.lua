-- Lua provided by SkyAPI 
-- Game: Paranormal Activity: The Lost Soul
addappid(467660)
addappid(467661, 1, "bb60992510d4cd7e4c854ab1099be01618a38f64d867c4ed1cb094e2e3aecba8")
