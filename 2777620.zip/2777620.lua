-- Lua provided by SkyAPI 
-- Game: AppID 2777620
addappid(2777620)
addappid(2777621, 1, "b8883a4b66554946413fcadfb30b1fc5067082a630b4685713a0de1484be0dad")
