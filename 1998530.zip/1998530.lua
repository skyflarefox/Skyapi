-- Lua provided by SkyAPI 
-- Game: Yoiyami Dancers: Twilight Danmaku Dancers
addappid(1998530)
addappid(1998531, 1, "06316840763ebe0acc0396c37963c6ac5c2433d0d3d5b3af6406160710f18f01")
