-- Lua provided by SkyAPI 
-- Game: Zemblanity
addappid(1897380)
addappid(1897381, 1, "1119b820081389e013e0b1faef58ebe840c16223e55d20ca87b1735e00a7ede3")
