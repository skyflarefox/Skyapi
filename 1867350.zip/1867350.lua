-- Lua provided by SkyAPI 
-- Game: Slime Village VR
addappid(1867350)
addappid(1867351, 1, "7fa4b9054060fb5c7fe98b0d4203021aa6e7fe2a8fe02b9524cc864b92c07459")
