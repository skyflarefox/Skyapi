-- Lua provided by SkyAPI 
-- Game: I was here
addappid(707960)
addappid(707961, 1, "461cbeb67e38c419cac17d87247b88ff9a412f3067b87c445d924cff5fc5f67c")
addappid(731540, 0, "b4ba19374d0f6f0d43e8e5521db3840ec6c744bd75c630647d57e60468523646")
