-- Lua provided by SkyAPI 
-- Game: Oniwaki Village -Horror game-
addappid(2085100)
addappid(2085101, 1, "818f5e465cee8d130ed7fd305df8bc6388434ae7d31988daa522102c7f8a12fc")
