-- Lua provided by SkyAPI 
-- Game: Red Faction
addappid(20530)
addappid(20531, 1, "2e80e8a0245677b13163c98b58d4b01f07263a3726501504b52aef6b6cc71d38")
