-- Lua provided by SkyAPI 
-- Game: Feeble Origins: Path of a Hero
addappid(345020)
addappid(345021, 1, "405d204aaed5213db96509ae6359231d471f7305333ec130b0e51495fc9802e7")
