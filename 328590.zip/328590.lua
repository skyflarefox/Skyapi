-- Lua provided by SkyAPI 
-- Game: AppID 328590
addappid(328590)
addappid(328591, 1, "acaf34d52e1f81e1e3b5fba6753407167cc4e200a6f249010ed55f0870a7b9b1")
