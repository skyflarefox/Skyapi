-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(280680)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(280681,0,"baddb076af5bd847f9b4a70a0cdb83740b1a0724a1b4cedf1a3e3a223a745b4b")
setManifestid(280681,"5697720818733026338")
addappid(280682,0,"86c126ddb42071c4ce7cd430018739e0b35e228dd59d35ce160360eabed73f72")
setManifestid(280682,"8300849784599135186")
addappid(280683,0,"9c024c741808fd1d0203e1e31b77ad9a3e0e29b7b3c06dc5228e258bfafb92aa")
setManifestid(280683,"3146621334072240907")
addappid(280684,0,"e57e0186d6d1f641e1a40408a81f126382a46ce850b451064ba027fbaf0dbecd")
setManifestid(280684,"3339336248399235216")