-- Lua provided by SkyAPI 
-- Game: AppID 3225010
addappid(3225010)
addappid(3225011, 1, "34cb2c0023c0b262527470556a20b848bd3d5e1b07b9bc8afacd2d9d23122a3f")
