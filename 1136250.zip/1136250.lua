-- Lua provided by SkyAPI 
-- Game: Forep Man
addappid(1136250)
addappid(1136251, 1, "c6d0476ef86c307cd598974c215acfa3872813347387477758ee1e6b534a47df")
