-- Lua provided by SkyAPI 
-- Game: Alice - Behind the Mirror
addappid(835700)
addappid(835701, 1, "545822290ec8d0df39d2974ee8ed07285a2c35f258413ad6823c58211f21c9d8")
