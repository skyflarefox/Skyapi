-- Lua provided by SkyAPI 
-- Game: Death Rpg
addappid(1007080)
addappid(1007081, 1, "17b413b8413f0c88ef7954bb7b92452e4da391d5a7e889b0cefb4e6a13907109")
