-- Lua provided by SkyAPI 
-- Game: AppID 1240870
addappid(1240870)
addappid(1240871, 1, "58bcaf82281401051928789aa1250883ebba7f1cf5c16d0c67fd73b8f191a206")
