-- Lua provided by SkyAPI 
-- Game: AppID 325470
addappid(325470)
addappid(325471, 1, "75aa1e809d2c4ba74c1725dcbaa0108f528a30fbe259053252149f385ae14ca2")
