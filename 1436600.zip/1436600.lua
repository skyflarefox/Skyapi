-- Lua provided by SkyAPI 
-- Game: Holiday Time
addappid(1436600)
addappid(1436601, 1, "8b51c5f734bf455f9b49126e64c85b4573fdb841bed57015900d48ea8abf6b7d")
