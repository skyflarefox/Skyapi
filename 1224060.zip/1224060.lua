-- Lua provided by SkyAPI 
-- Game: AppID 1224060
addappid(1224060)
addappid(1224061, 1, "2dbf1cc92e91a0246464bdc841e6650d4da9828c7d58fa89112bca575e1f19b2")
addappid(1224062, 1, "79a8098dc51f57a71361b5d7cbca3ee90fb8fe7be54dfe6332439a8f4ec93a32")
