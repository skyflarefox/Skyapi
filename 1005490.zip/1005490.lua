-- Lua provided by SkyAPI 
-- Game: The Deep Diving of FloodDragon
addappid(1005490)
addappid(1005491, 1, "781d1c9ce1e622644e11402d6dc64ef8222831aa5791e57f24962685ae4ca9c0")
