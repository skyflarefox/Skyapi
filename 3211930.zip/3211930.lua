-- Lua provided by SkyAPI 
-- Game: Waifu Simulator
addappid(3211930)
addappid(3211931, 1, "a77bec61044aee738b7b0dfe0cf19e5782e6b06ca206d1468df7d7f16b937321")
