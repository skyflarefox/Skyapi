-- Lua provided by SkyAPI 
-- Game: Isles of Limbo
addappid(1389260)
addappid(1389261, 1, "95d7470bd056005495b0581ea63ab3ac44394d26588c438c3d893feab38dadfe")
