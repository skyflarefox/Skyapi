-- Lua provided by SkyAPI 
-- Game: Zodiacats
addappid(1817000)
addappid(1817001, 1, "5ce758f33041693ee7d4b1c1de2e77dd3076475a9a290f1053d999fb41072498")
addappid(1950330)
