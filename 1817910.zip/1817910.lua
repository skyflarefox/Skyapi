-- Lua provided by SkyAPI 
-- Game: AppID 1817910
addappid(1817910)
addappid(1817911, 1, "1225aaaf4e6e20fd8e04ba87ba0d715cdbe90b85aec756c99cd8775a7c3e66d1")
