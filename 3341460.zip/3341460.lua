-- Lua provided by SkyAPI 
-- Game: Metathrone
addappid(3341460)
addappid(3341461, 1, "a9343a30bab4ed32f53456e313c7ec9e3b5379a9901d8d7d77832820055427ad")
