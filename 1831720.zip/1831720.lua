-- Lua provided by SkyAPI 
-- Game: Treasure Temples
addappid(1831720)
addappid(1831721, 1, "066a83369d10889c32460bb63cd9f8cb459fe4007e132436519bb89355ce33f6")
