-- Lua provided by SkyAPI 
-- Game: Pure Sniper
addappid(1612020)
addappid(1612021, 1, "4d97f163b978d77532f50499ff8edadcd99f48517210f4d34b000f7c2272eee3")
