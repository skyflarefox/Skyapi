-- Lua provided by SkyAPI 
-- Game: Loco Dojo
addappid(667800)
addappid(667801, 1, "6e9102b976c9bc689155f12a6c8fec4d0e39b8828b8f501eb7dd03c8510bb75d")
