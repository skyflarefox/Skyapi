-- Lua provided by SkyAPI 
-- Game: AppID 1142500
addappid(1142500)
addappid(1142501, 1, "60995328e213db5589ccebb9c28fccca223395e7bcdd58881555d1c28de66a8e")
addappid(1142502, 1, "8ae29460936da602bb6348b2bd021640a608e8bc0eb6f0c4e5cf356cd12231f1")
