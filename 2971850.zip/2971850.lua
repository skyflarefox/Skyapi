-- Lua provided by SkyAPI 
-- Game: Europa Soundtrack
addappid(2971850)
addappid(2971851, 1, "dc9b5a405dc9ff67e3a2a22781bff20fe1c626e8c36e3030ed6cdc65e8e9521c")
