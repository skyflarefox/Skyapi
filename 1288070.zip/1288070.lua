-- Lua provided by SkyAPI 
-- Game: LightBall
addappid(1288070)
addappid(1288071, 1, "758957a38b2e25e23a1f16922f1de59401388753d8001b52f2ae254d1b11b191")
