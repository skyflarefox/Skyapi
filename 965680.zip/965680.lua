-- Lua provided by SkyAPI 
-- Game: AppID 965680
addappid(965680)
addappid(965681, 1, "05685e2eda75d5459cd0ec3a1735e0eed68414c8fb3a56585c6c0938b3102f57")
