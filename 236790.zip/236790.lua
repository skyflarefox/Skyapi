-- Lua provided by SkyAPI 
-- Game: Agricultural Simulator 2013 - Steam Edition
addappid(236790)
addappid(236791, 1, "a8241f7fc1bcad087c6ed7600069aabebfa543a7c850be56e0dd7cfe0a4383a1")
addappid(236792, 1, "846dea6b71e0460ee3016faac30516e3f3d6c96e2fd557a37ca1ff29ad9ead7f")
addappid(236793, 1, "991a7e744d37e4de5d7ac42acfaf7dbf49da9060b73f8809f73c201288c031ec")
addappid(236794, 1, "b3cbf7d5cb2a8faf7510db9d5a0509ee05f99e2f639f267be928dd1379ad830c")
addappid(236795, 1, "f5f9904462f67ee6db159d272f503f47ee3410ef67d21f2cc18e7d9d1fdc45c0")
addappid(236796, 1, "57c7cbddd8e1ed32a47a5c08186e26cae28b2f23636954dff39dfa22c0479c39")
