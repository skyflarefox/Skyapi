-- Lua provided by SkyAPI 
-- Game: Pixel Dungeon VR
addappid(3063750)
addappid(3063751, 1, "6265f528576bd352c2a35a18154ed52fa3972a61b67e16e84abfff989d64a837")
