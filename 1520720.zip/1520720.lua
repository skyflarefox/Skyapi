-- Lua provided by SkyAPI 
-- Game: AppID 1520720
addappid(1520720)
addappid(1520721, 1, "37f87468014942c2b9fdec29b42bd57bb8551e2bddcc23940955e50113704d08")
