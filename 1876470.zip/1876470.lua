-- Lua provided by SkyAPI 
-- Game: MAFIA: Sex Noir
addappid(1876470)
addappid(1876471, 1, "676024fd1b56e6700fc450e923fb437fdf09b4f9536d6709051f376a0bf949d0")
