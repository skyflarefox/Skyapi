-- Lua provided by SkyAPI 
-- Game: Astervoid 2000 Soundtrack
addappid(563590)
addappid(563591, 1, "ee590aec9438559505e7e5dc5bcc470e97967393be08f3488c783fa86fbde87b")
