-- Lua provided by SkyAPI 
-- Game: AppID 2369110
addappid(2369110)
addappid(2369111, 1, "d88a93d10aae4786ab1097d4527cd16f838989c98815d02fab78b3bd33d5afc9")
