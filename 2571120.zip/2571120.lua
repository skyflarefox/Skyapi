-- Lua provided by SkyAPI 
-- Game: 只有向下 Only Down
addappid(2571120)
addappid(2571121, 1, "bd58ce98548d1182075c6b1c7abb8ce0ff69dff30b70ef99f89359ed5374fac8")
