-- Lua provided by SkyAPI 
-- Game: AppID 492530
addappid(492530)
addappid(492531, 1, "27428980d1e967db09511e56f949765cc860d391c7cc69c087c8bcca48bcf148")
