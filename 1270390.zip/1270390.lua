-- Lua provided by SkyAPI 
-- Game: The Golem
addappid(1270390)
addappid(1270391, 1, "ad75e44145b29e58af247ab0c96966d188f78b742d626e1025c9fa3e6c11574f")
