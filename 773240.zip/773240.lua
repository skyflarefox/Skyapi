-- Lua provided by SkyAPI 
-- Game: Raceland
addappid(773240)
addappid(773241, 1, "8c7bdacd2858e16856dc9f7d065f379916a09fc5ed6ad24abc966fba06706488")
