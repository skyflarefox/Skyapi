-- Lua provided by SkyAPI 
-- Game: AppID 2102680
addappid(2102680)
addappid(2102681, 1, "e91a1d1287fb3f3f74b31461123e08015373b88f0d2f7d041e556a1df3d6c1a6")
