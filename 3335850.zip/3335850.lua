-- Lua provided by SkyAPI 
-- Game: AppID 3335850
addappid(3335850)
addappid(3335851, 1, "930e63993da4079a344d68af7b9ed9d6fbcb3df2336c847bffe811f0d60687c9")
