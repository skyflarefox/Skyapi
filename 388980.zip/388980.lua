-- Lua provided by SkyAPI 
-- Game: Race Track Builder
addappid(388980)
addappid(388981, 1, "b254c2a807e4c68fac47f91d74e7788f884eb4781862c65e0765bdaa6956e5f0")
addappid(388983, 1, "30128acac011e801d17e21018ca0e1c8c65d468231736e64310b188aab7d84cf")
