-- Lua provided by SkyAPI 
-- Game: AppID 1000830
addappid(1000830)
addappid(1000831, 1, "a6904622833b87f678a7891a8999f32fb3a4e1c21b5f3c8697d278a4dc96e464")
