-- Lua provided by SkyAPI 
-- Game: Ratten Reich
addappid(1717250)
addappid(1717251, 1, "c27382226fdd0b0fbc98069808e7cf68ee74402a72362485c919c350df2ad8a2")
