-- Lua provided by SkyAPI 
-- Game: AppID 491620
addappid(491620)
addappid(491621, 1, "b040761dec0bd8cffb503de5ca85786019fd7e03c64ccac596b17df185248437")
