-- Lua provided by SkyAPI 
-- Game: OshiRabu: Waifus Over Husbandos ~Love･or･die~ Demo
addappid(1700790)
addappid(1700791, 1, "58407ded60a58f9cdfc5fa520e57fea650e87010e6c09a326d3aa28f12c7fd72")
