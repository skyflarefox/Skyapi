-- Lua provided by SkyAPI 
-- Game: Truberbrook / Trüberbrook
addappid(757300)
addappid(757301, 1, "5491c0cd98003bdf7138d63eaf1a72c1d31e27dbdc6658a019fa5a3cfe5b45b4")
addappid(1049050, 0, "72209a33375b7120672b2de8a304f695689110b2be2a6dc94acba5cbc493e8ba")
