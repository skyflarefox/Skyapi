-- Lua provided by SkyAPI 
-- Game: AppID 1495900
addappid(1495900)
addappid(1495901, 1, "c98d5fea70b98423320267c33b7225d089f20943dabb03c0ee9d0bc282559bc4")
