-- Lua provided by SkyAPI 
-- Game: AppID 1966100
addappid(1966100)
addappid(1966101, 1, "f7ff1b8834688292d4db86750ac524041a2a46ab9f73f69ba46cdd6db37ee11c")
