-- Lua provided by SkyAPI 
-- Game: Balloon Party
addappid(3770560)
addappid(3770561, 1, "0b36781a2d37f4b1bc848100e4106adc92487a8374033f6c0c1edd3d3efa9c62")
