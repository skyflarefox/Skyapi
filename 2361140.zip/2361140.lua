-- Lua provided by SkyAPI 
-- Game: Terminal Velocity
addappid(2361140)
addappid(2361141, 1, "540a05cac131117b3e1858d57aecb6272480c195cbd48d9fd16b27e50061e2eb")
