-- Lua provided by SkyAPI 
-- Game: AppID 1766720
addappid(1766720)
addappid(1766721, 1, "47efb24c9629e8b7af0f291aee5987a1817b95b9c198fa1c008cfb834fe5e695")
