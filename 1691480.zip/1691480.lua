-- Lua provided by SkyAPI 
-- Game: World Titans War
addappid(1691480)
addappid(1691481, 1, "aa3e63c0bc7de344fdee4b59ecc0ff1f6fb41d9f8f1b5b541f39c51386b301e5")
