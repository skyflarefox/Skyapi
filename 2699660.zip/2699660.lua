-- Lua provided by SkyAPI 
-- Game: PowerWash Adventure
addappid(2699660)
addappid(2699661, 1, "09a590e041aad9ba10e1c32aaf05985553752dbd2bcf8d117327d77a5edb9dcf")
addappid(2737890)
