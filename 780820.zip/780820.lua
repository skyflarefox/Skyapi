-- Lua provided by SkyAPI 
-- Game: XOXO Blood Droplets
addappid(780820)
addappid(780821, 1, "9b954252e3107c14d4dcabf5558614a14c454bcbad0ae6b40cc18f661cb6fd81")
