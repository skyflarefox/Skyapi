-- Lua provided by SkyAPI 
-- Game: Factor Y
addappid(2220850)
addappid(2220851, 1, "acb39ef1cd7e8b47661d06aa130f01fa3077ad26e8bf530d69cf07a3bce6a86c")
