-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1087930)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1087931,0,"cd11b3deb484649591557ac4d0ce0b5a628cd3ab868bf0ecf7d80054dc4faf9d")
addappid(1087932,0,"574644b02250e4aa7150e25c1f9b0f0392b962b2861499a7cfc02f77fce5a25c")