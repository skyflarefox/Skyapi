-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1072190)
addtoken(1072190,12222814922638457394)
addappid(1072191,0,"31a05be963eb3ff21ef0e1ac6df9a46e33ebcfffbaf3c8b32d81f34ebcba3ebc")
setManifestid(1072191,"8922085483336969226")