-- Lua provided by SkyAPI 
-- Game: AppID 1983040
addappid(1983040)
addappid(1983041, 1, "3d3e4ba70495cbd84a529e9ed36d9adb6d5fbe3b66f617944f380b03d83b22ac")
