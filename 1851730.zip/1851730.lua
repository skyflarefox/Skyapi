-- Lua provided by SkyAPI 
-- Game: Meow Express
addappid(1851730)
addappid(1851731, 1, "c2d7739de7b238a2c3f97b676041c1be8b2bd77a5ec6217f96b99aecdf03a44c")
