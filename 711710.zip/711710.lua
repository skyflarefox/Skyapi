-- Lua provided by SkyAPI 
-- Game: RedEyes 赤瞳之勋
addappid(711710)
addappid(711711, 1, "2ae0afd3222a838728cd331f6185a2460473e924a23f0caeec45792fa8765842")
addappid(947980, 0, "a35107c382e7f08344a835434c880d9d93f16e8c1830a5d42987210a480b74d0")
addappid(966440)
addappid(1011920)
addappid(1046220)
addappid(1698490)
