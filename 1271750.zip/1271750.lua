-- Lua provided by SkyAPI 
-- Game: Unferat
addappid(1271750)
addappid(1271751, 1, "2f7671af70dda1f58812fbd838967664f8b84a1ee5e8624be8fc5a83299933fe")
