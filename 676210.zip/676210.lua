-- Lua provided by SkyAPI 
-- Game: AppID 676210
addappid(676210)
addappid(676211, 1, "85441d67953e320b89a902cf719f9016fe5548c77496992eb3d63318f65f3e40")
