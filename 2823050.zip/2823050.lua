-- Lua provided by SkyAPI 
-- Game: SCP: Descent Demo
addappid(2823050)
addappid(2823051, 1, "8693220285e2504dc6899820cd17cd5b7add3e3ae0794fc0df5dee1b3ca8a20c")
