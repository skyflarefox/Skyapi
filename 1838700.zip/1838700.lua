-- Lua provided by SkyAPI 
-- Game: MINDHACK Demo
addappid(1838700)
addappid(1838701, 1, "fd2255cfaced832e8b33a3091541746830acf69030736a3a9f94d87e0cb87b06")
