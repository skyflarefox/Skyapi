-- Lua provided by SkyAPI 
-- Game: Nancy Drew®: Midnight in Salem
addappid(1038450)
addappid(1038451, 1, "731df41d11a8fafa54d4602dd29f80435f1b4db60948d9190e629a12bbe8d27c")
