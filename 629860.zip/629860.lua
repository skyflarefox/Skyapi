-- Lua provided by SkyAPI 
-- Game: AppID 629860
addappid(629860)
addappid(629861, 1, "1ac9916ead1d57392f4b6665d5e2b2f45c70920405cfa8261f08cf72b758b086")
