-- Lua provided by SkyAPI 
-- Game: AppID 424000
addappid(424000)
addappid(424001, 1, "cd8ec710fa4dae2a5842fa6741e6b01a4bde87cd96d336b0a71d4fd2f9d0a151")
addappid(432600, 0, "a4b2645e1fc0faf43a192dfafa26b9dfc4c6a9e09b1bdb2dd7c8649c4adba702")
