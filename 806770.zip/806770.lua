-- Lua provided by SkyAPI 
-- Game: NoReload Heroes
addappid(806770)
addappid(806771, 1, "7c6f09e3adf77db89eceb37a2f6cc05ac4846759b30f79934ef3093899a9c97e")
