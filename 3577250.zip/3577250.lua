-- Lua provided by SkyAPI 
-- Game: Vacation Romance ♥️
addappid(3577250)
addappid(3577251, 1, "3def6309416ccbeba5e547e9f0d9c074cb2c3e11209b8bc154a0a9f469d02fdf")
