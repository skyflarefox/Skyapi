-- Lua provided by SkyAPI 
-- Game: Multiplayer Shooter FPS
addappid(2364570)
addappid(2364571, 1, "a0a47992acda9e63d7d57ce7dcc50557ead506d4e0826fc35e1f588ae0098110")
