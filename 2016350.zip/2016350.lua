-- Lua provided by SkyAPI 
-- Game: Elfheim - Chapter 1
addappid(2016350)
addappid(2016351, 1, "7d7908948c21fb2b25a332b0d4204610c31b965e994fc67becb5d4d94e552323")
