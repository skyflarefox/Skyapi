-- Lua provided by SkyAPI 
-- Game: AppID 1142670
addappid(1142670)
addappid(1142671, 1, "58c9239f8933325f9a65d8fc4c70165059d8e1ece79b5ba1476546a9b32d223b")
