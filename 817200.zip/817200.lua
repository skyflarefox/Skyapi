-- Lua provided by SkyAPI 
-- Game: Nautical Life
addappid(817200)
addappid(817201, 1, "f70842a4b111efc017ac61d0668ffb44e79b56ac773d4dcb1da444fbfc416b33")
