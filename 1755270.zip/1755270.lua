-- Lua provided by SkyAPI 
-- Game: Cosmic Cube
addappid(1755270)
addappid(1755271, 1, "d93196f5fa2515dd91953b63169aa3c9e836969db95a21639d3cd46788b39cd7")
addappid(1756400, 0, "2f8957f29afb4fc73c8d3dcef602f451d883f3f7e5e27b70dd491980798837e5")
