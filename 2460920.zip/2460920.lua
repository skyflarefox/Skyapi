-- Lua provided by SkyAPI 
-- Game: ACRES
addappid(2460920)
addappid(2460921, 1, "ad0b9b063d3c69f1fe34bf3c4510219dae3ca63111aa38b5363735d52eb8f94e")
