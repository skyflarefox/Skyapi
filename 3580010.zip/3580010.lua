-- Lua provided by SkyAPI 
-- Game: Lust Odyssey
addappid(3580010)
addappid(3580011, 1, "a96d01b6d79cb1db4fc2bc45ed05932cc7c6c722a53a698c71eec6ed6e8f0d37")
