-- Lua provided by SkyAPI 
-- Game: 大科学家
addappid(2403340)
addappid(2403341, 1, "cc57e9273fb8db16680f8014f5db391b766e33a89bcb018098af8d678d535167")
