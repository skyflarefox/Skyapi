-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1218280)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1218281,0,"a4dc33c78b2492e16075ce060543244cd8d94322af6e5df832a72076d2cf8128")
setManifestid(1218281,"5641510712780005022")