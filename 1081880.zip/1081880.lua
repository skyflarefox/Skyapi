-- Lua provided by SkyAPI 
-- Game: AppID 1081880
addappid(1081880)
addappid(1081881, 1, "0afc94f7ac59f4e8245a43dafa0a84f75e3dce7bacefdd60bf9cc147a2c92469")
