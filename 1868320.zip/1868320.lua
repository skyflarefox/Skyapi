-- Lua provided by SkyAPI 
-- Game: Daymare: 1994 Sandcastle Demo
addappid(1868320)
addappid(1868321, 1, "df4c00e9b91f27e71bcf44b198ada2942060c4a8a61582766c2fd65cff008267")
