-- Lua provided by SkyAPI 
-- Game: Guildford Castle VR
addappid(1862880)
addappid(1862881, 1, "553ffe1964d7e22adec09fa1f13b17b06c28659e21cc35149598dd6ba7e22d2b")
