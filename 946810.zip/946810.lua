-- Lua provided by SkyAPI 
-- Game: AppID 946810
addappid(946810)
addappid(946811, 1, "e987760081b3ef75b1102c306b02816c5c1b573ee171b467e12efc609bb51a70")
