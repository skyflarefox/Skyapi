-- Lua provided by SkyAPI 
-- Game: Minimal Dungeon RPG
addappid(1806030)
addappid(1806031, 1, "c412d37af5cad68e4611b624fdbee8a753b709bab133845863fe629edc378625")
addappid(1830121, 0, "8042dd93fb35a8fef3bbd71f6207db5bb024b38ad364b90ddf0aeff36b8cde6e")
