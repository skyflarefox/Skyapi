-- Lua provided by SkyAPI 
-- Game: Mercenaries VR
addappid(1232670)
addappid(1232671, 1, "e45394ffbc7d17d24e42c9613800ec67c32eaafdf10e1ed3a969f5d9c4d28173")
