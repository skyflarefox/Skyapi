-- Lua provided by SkyAPI 
-- Game: Bravery and Greed
addappid(943370)
addappid(943371, 1, "96a567d77dd49570c16752f5cb3c5fc47d2680dfe0a19fdc3682503a0d887318")
