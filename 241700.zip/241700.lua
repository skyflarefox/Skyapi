-- Lua provided by SkyAPI 
-- Game: Vector Demo
addappid(241700)
addappid(241701, 1, "85df55a5fc841d5d46d45e224e7a536e21135fa0bd2a03369d73d33d7ad1706e")
