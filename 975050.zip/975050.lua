-- Lua provided by SkyAPI 
-- Game: AppID 975050
addappid(975050)
addappid(975051, 1, "f183156c7a7227351dd62c39f9d6ca8931ee6415afee862505c60bc64d9a1f2e")
