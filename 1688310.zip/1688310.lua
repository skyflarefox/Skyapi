-- Lua provided by SkyAPI 
-- Game: Perfect Affection Plan: Cassiopeia
addappid(1688310)
addappid(1688311, 1, "04e51b7b001698d429206d90990099b6c42861d06c7b4fe3cfc0c89d91cf9aee")
