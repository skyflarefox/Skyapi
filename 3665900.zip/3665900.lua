-- Lua provided by SkyAPI 
-- Game: HougekiShoujo
addappid(3665900)
addappid(3665901, 1, "2280997bf0f1ae7b876c67f97d7d8cd4fc6db1321716264b62f6d8b804d1d1d7")
