-- Lua provided by SkyAPI 
-- Game: Public Toilet Simulator
addappid(3472870)
addappid(3472871, 1, "f36fd6ae98e5da8c2e8de42e0f3b782c1230e70e31caeda02445b5afb8e8191e")
