-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1337520)
addappid(1337521,0,"d29ccb9d1e840ba82ffc903c35e40c258c9552e4260a57e3fe2626a181cdb195")
setManifestid(1337521,"2126128840766829407")