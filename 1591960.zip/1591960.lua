-- Lua provided by SkyAPI 
-- Game: Randy Blaster 3D
addappid(1591960)
addappid(1591961, 1, "bf0f37f4979e42462af23c28fc9d86d4e655ce3343dc09502e05487f421de1d6")
