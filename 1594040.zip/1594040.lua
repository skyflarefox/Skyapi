-- Lua provided by SkyAPI 
-- Game: Wreckreation
addappid(1594040)
addappid(1594041, 1, "087f7afba241d83af08955b0c7caec2a209a483aec68960ae2831fc9894972a8")
