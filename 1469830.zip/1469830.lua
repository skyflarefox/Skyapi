-- Lua provided by SkyAPI 
-- Game: The Happy Little Virus
addappid(1469830)
addappid(1469831, 1, "0aab3f8f04525799b008cc2ac3d0faf57d67d75ffd7d859be491e57a23910ae3")
