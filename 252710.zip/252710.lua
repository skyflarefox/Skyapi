-- Lua provided by SkyAPI 
-- Game: AppID 252710
addappid(252710)
addappid(252711, 1, "ea52a8802559e0045e34fe68c3fbe0452b8429d81fdf654808a696ed0afe4729")
addappid(252712, 1, "ffc209361c5dc22ab1359befc4392b79a643e8fdf2c4955b6fe70170474d2d95")
