-- Lua provided by SkyAPI 
-- Game: 我愛師大附中HSNU
addappid(2797170)
addappid(2797171, 1, "2b1ea52154f09338dd4402f753cd0cf5c151c360f03650affdbf180043304777")
