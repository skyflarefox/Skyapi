-- Lua provided by SkyAPI 
-- Game: Total Battle
addappid(978290)
addappid(978291, 1, "8f02ffad4994d8efd32433050da706848d20ec72050bd0e699a16b3d8461343a")
