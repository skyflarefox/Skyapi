-- Lua provided by SkyAPI 
-- Game: Override 2: Super Mech League
addappid(1329790)
addappid(1329791, 1, "27278c273b6bd900a591ca0175026461db89f183e2b45877ce0f27e3e2ee9c7e")
