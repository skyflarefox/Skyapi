-- Lua provided by SkyAPI 
-- Game: Case Files: Behind Closed Doors
addappid(2659650)
addappid(2659651, 1, "71539eefe67d098940e6651c3cae9483cbd05938be208fe83196c387d1fdde99")
