-- Lua provided by SkyAPI 
-- Game: Disfigure
addappid(2083160)
addappid(2083161, 1, "ab5d38b44afb84e371210fbd060536d5bdf40b2032c65c8de4eb54ca2f72e751")
addappid(2497100)
