-- Lua provided by SkyAPI 
-- Game: AppID 746350
addappid(746350)
addappid(746351, 1, "7dcc1e6994a892db975caf996540b03f851585f54f7161e7e5a6250ba77dcea7")
