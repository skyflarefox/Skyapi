-- Lua provided by SkyAPI 
-- Game: Adohiinage
addappid(3715630)
addappid(3715631, 1, "d32358f0a5b94387b05f6e34c1fbecbfa5e3b39ea7b10c42e29f21aafdd73c63")
