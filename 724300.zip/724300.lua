-- Lua provided by SkyAPI 
-- Game: Roof Rage
addappid(724300)
addappid(724301, 1, "fc4fd50b7f1fe0de4c0f323a620a44e9720ac51d6cda1df3d690c87cbc0ad42d")
addappid(875290, 0, "ca48680ffea035d721711e3673af1523e4a18ea9be42c0d40a5b37890aa1eb0e")
