-- Lua provided by SkyAPI 
-- Game: From The Darkness
addappid(1517340)
addappid(1517341, 1, "04e006ecc8ca586b0168dff007ea2c719b8b2b4b8a8522640b9af43b2fdc77c4")
