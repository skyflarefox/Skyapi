-- Lua provided by SkyAPI 
-- Game: Secret Of Magia
addappid(396160)
addappid(396161, 1, "d96b1ec77c062e1cd4774ef40a9662f199dba5b835ca0efeee866c79c6bb64f8")
