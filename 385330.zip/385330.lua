-- Lua provided by SkyAPI 
-- Game: Stray Cat Crossing
addappid(385330)
addappid(385331, 1, "60be3b7f461e29387175a79bbf860835f868e44873f231c9d75bf8f01ebde1d0")
