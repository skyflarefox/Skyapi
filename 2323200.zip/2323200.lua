-- Lua provided by SkyAPI 
-- Game: AppID 2323200
addappid(2323200)
addappid(2323201, 1, "e1564da70e976dbc8a04814a64a271c3cc239ff0accc09e9d99e4d1a7e5ce414")
addappid(2337210, 0, "aacb5bdb2c830ecfaeac020dcc7c6effd1945086a9441c1f365ce745222e74b0")
addappid(2337211, 0, "30f56f18f5395cfcffc3342fe8bb9c9562de729dea3b3e89a0dc7f9c7f62cf6b")
addappid(2337212, 0, "1f1725672e521e00c2bae64a8250d86f7d89dff0070380a506fcf0b193fced82")
addappid(2337213, 0, "6bab93b40b5f575c0ced193dda5cc41a7ab9dcc2355000aafccffe1d47b0586f")
