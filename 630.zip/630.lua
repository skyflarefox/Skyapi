-- Lua provided by SkyAPI 
-- Game: Alien Swarm
addappid(630)
addappid(631, 1, "3a2c1e15d9e982313db3de3a7408bdf3a7b50da0e753e8c440d71dd5c3074e95")
