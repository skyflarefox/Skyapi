-- Lua provided by SkyAPI 
-- Game: AppID 359560
addappid(359560)
addappid(359561, 1, "031078b07bf6a74d250898643b0d64c07a0b934db83f7eecf7d5eb46db9714f2")
