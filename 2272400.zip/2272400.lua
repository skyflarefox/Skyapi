-- Lua provided by SkyAPI 
-- Game: Station to Station
addappid(2272400)
addappid(2272401, 1, "c6766d1c5f96d22d51cc4c3c6561cc7fe7de6a9309e25c10f2a389ff36e8092b")
