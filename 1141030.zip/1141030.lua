-- Lua provided by SkyAPI 
-- Game: Last Message
addappid(1141030)
addappid(1141031, 1, "69e01134c81ece1b21faa975fee37020784c8c4b92b6596463e800f9cc44b995")
addappid(1141032, 1, "81bd8d470c099028a006d66755b234657a377febb39399a53940770effec24b3")
