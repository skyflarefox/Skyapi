-- Lua provided by SkyAPI 
-- Game: AppID 2277460
addappid(2277460)
addappid(2277461, 1, "9cd6215e068bee2846f29c4b354f29cf487685c519d4f33ee5678776b03e29d1")
