-- Lua provided by SkyAPI 
-- Game: AppID 3406640
addappid(3406640)
addappid(3406641, 1, "1352f9c407608ecfcbea2c3f16bfc7f51b784f4cefa27ca487b49edfe7421f5e")
