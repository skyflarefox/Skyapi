-- Lua provided by SkyAPI 
-- Game: Stealth Labyrinth
addappid(450040)
addappid(450041, 1, "0e6c325c8dbfacffff5ed6ac334b2f1accdff8c2688d3ee0ead985a7ce237c7d")
