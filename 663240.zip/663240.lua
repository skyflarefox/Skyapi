-- Lua provided by SkyAPI 
-- Game: All You Can Eat
addappid(663240)
addappid(663241, 1, "41652ad5d56929dbcec49a565f0bd4063b331728a5384cc7706d14aadd157878")
