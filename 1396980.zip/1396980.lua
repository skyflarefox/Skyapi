-- Lua provided by SkyAPI 
-- Game: The Sealed Ampoule
addappid(1396980)
addappid(1396981, 1, "0128b007104eef7f9b1889b5ff6a3909c52acfb944291b18f1deb227f21b8c5c")
addappid(1396982, 1, "708d57f3b67df8124420ea301715e9b75e011daea28cc54681860e62f16f45e3")
addappid(1396983, 1, "ba8ff590cb8a59cf66aa98ae0fcf36a9aaf8213abbe8b92f8b4a833838552f43")
