-- Lua provided by SkyAPI 
-- Game: Demeo Battles Demo
addappid(2611090)
addappid(2611091, 1, "13b1d36db715c3babba36ddf3b054326cb6a6761943f0c9a5342692cbe565825")
