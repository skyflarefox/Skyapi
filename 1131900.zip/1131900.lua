-- Lua provided by SkyAPI 
-- Game: AppID 1131900
addappid(1131900)
addappid(1131901, 1, "68bb874504b2c29bae9eced53d04cd7d2c3f90c8e50843acfb2f74af9a67b076")
addappid(1131903, 1, "9934e41612c11aad64de4b16a618aa98930e3cc9944d1d1b0fd30600f1407486")
