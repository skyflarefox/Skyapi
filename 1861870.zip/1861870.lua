-- Lua provided by SkyAPI 
-- Game: Shadow Fate
addappid(1861870)
addappid(1861871, 1, "877e4f9b32d0dfc9b8729de4b0ed90108c96ead5b7e67b825f2eafce341782b6")
