-- Lua provided by SkyAPI 
-- Game: Gran Saga
addappid(3016760)
addappid(3016761, 1, "55801fbeaf784e8ee04652c3cc98666100143afcd23b68d4160b5a57899d8ffd")
