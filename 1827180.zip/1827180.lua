-- Lua provided by SkyAPI 
-- Game: Toram Online
addappid(1827180)
addappid(1827181, 1, "aaad9e8b14d16ba8ca8680ba71ca1a94637567d0e6202f1c8befcfa3f0f38581")
