-- Lua provided by SkyAPI 
-- Game: Out of Sight VR
addappid(3558720)
addappid(3558721, 1, "f8416581142cb6812c72a937bdb5df289667d94564989da1b535a696131193ec")
