-- Lua provided by SkyAPI 
-- Game: Ambulance Emergency Simulation
addappid(1959470)
addappid(1959471, 1, "a4b2e039a674fc0e4ff7674145d779805b1bb62e0bae39bd01ca7f0bc85a9768")
