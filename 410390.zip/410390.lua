-- Lua provided by SkyAPI 
-- Game: AppID 410390
addappid(410390)
addappid(410391, 1, "49624449728e83f85d84ff0aff11fad1f3643684846975121daf46b3fe788ac0")
