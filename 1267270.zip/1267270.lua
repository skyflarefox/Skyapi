-- Lua provided by SkyAPI 
-- Game: Yumeutsutsu Re:Idol
addappid(1267270)
addappid(1267271, 1, "5b0f9259f27dd390e07769d0fcaa97a2b93d910b342424c8f960276abb086216")
addappid(1267272, 1, "d3df21fa52812c3078a9218f8b7db866258b99fcc5b6a86318a1249abe564c1a")
