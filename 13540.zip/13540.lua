-- Lua provided by SkyAPI 
-- Game: Tom Clancy's Rainbow Six® Vegas
addappid(13540)
addappid(13541, 1, "a53494bacf76b2fc012b4a2d525e4015781238a58d0916f7044ece4dc92639da")
addappid(13542, 1, "b3d9ca3ccd1b2011a8ddda25ff3b9f8c94e7c716937b7dcc44a95fdbd5b1bfbc")
addappid(13543, 1, "10bede656b478998d41877a81068af471df653debd83504d9885316c3cf76ba0")
addappid(13544, 1, "ffc2627dcfd846b63d81ac891af0cbe48839432e816d73aefa8ac587ceb86fae")
addappid(13545, 1, "2e11a6013e13a689a2b36afe968a0683fb5329b9dfb9f1933a259ef75a82f800")
addappid(13546, 1, "89bf0d7b9ceca3c0a2e70f46cd2b1e3b135251f4e4ba3a2194566dbe314e9676")
