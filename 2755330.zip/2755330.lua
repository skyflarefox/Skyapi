-- Lua provided by SkyAPI 
-- Game: Chushpan Simulator
addappid(2755330)
addappid(2755331, 1, "210347fd10d9ff3eabefdfca3a4471e392a3a9e1d70689e63953f055a30e2b99")
