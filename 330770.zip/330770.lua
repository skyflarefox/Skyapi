-- Lua provided by SkyAPI 
-- Game: Radial-G : Racing Revolved
addappid(330770)
addappid(330771, 1, "56d5d468c2cc832178128b0ee0cbc6993bce1ffa799c317390f6bf75b0737d5f")
