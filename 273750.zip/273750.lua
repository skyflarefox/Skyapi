-- Lua provided by SkyAPI 
-- Game: Formula Truck 2013
addappid(273750)
addappid(273751, 1, "6ccbf5504843adc5ac3b2fe43ac8fe5043700e377b848f14cb9bfc96a2a69c12")
