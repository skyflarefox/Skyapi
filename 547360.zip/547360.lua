-- Lua provided by SkyAPI 
-- Game: AppID 547360
addappid(547360)
addappid(547361, 1, "6c81c6a485dc69b3c4dd72862089dd2d47938e09b47be3b5bb33c46bd2b25e1e")
