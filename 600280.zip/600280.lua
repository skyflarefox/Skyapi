-- Lua provided by SkyAPI 
-- Game: AppID 600280
addappid(600280)
addappid(600281, 1, "61c2738da3cb7e0b2867aa8864dccd1d3fb47a739da910d676ce4959b3b875c1")
addappid(600282, 1, "28106a4a078a3e8a38e67585eefe243f3dd9255680a4ef2d62cad997e3b2e252")
