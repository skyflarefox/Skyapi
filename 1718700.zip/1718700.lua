-- Lua provided by SkyAPI 
-- Game: inAntrum - Prototype
addappid(1718700)
addappid(1718701, 1, "052c98727d6f9f7bf2cc2905c89f577ed8f8ca8684cdc8c6ade72f6e10a64618")
