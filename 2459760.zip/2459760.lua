-- Lua provided by SkyAPI 
-- Game: AppID 2459760
addappid(2459760)
addappid(2459761, 1, "0e7dafb04590bfcc7948111247ac084a663548f8b5fe14ff340219e61bd1c11e")
