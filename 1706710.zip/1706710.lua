-- Lua provided by SkyAPI 
-- Game: Pizza Apocalypse
addappid(1706710)
addappid(1706711, 1, "03afd324801a87e7baf330e461dd883495387937f4b09c8aec3fd5c59ef1083b")
