-- Lua provided by SkyAPI 
-- Game: Team Sonic Racing™
addappid(785260)
addappid(785261, 1, "9d51fe375965802388bc5c627589d5a41f3fad4ba0270d6f7dcf5fe5fe9a886c")
