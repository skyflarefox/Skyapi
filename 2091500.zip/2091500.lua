-- Lua provided by SkyAPI 
-- Game: Warlords Under Siege
addappid(2091500)
addappid(2091501, 1, "4e845660c7eeae140561f31c279fb36b625f9c0277bda568e4a729dc867f16c3")
