-- Lua provided by SkyAPI 
-- Game: Gachi: Space Orgasm
addappid(2217810)
addappid(2217811, 1, "05571d027a2ae8d1a75b46c74fd9fc06e072a509bbf687c7d22cdb44863946d5")
