-- Lua provided by SkyAPI 
-- Game: AppID 449540
addappid(449540)
addappid(449541, 1, "b546c71b36e7f583b14617b17fb7ebe66cc2871cef2900227ae152a301e8107e")
addappid(449542, 1, "a337e5fa49780d3adf4f08b785aaaa901cde50ed8fdc1e7e299bf1ed159f7e1a")
addappid(449543, 1, "509d24c0187ea95ffe92fc05622f43e726f27ffa857982527e8eb6127bc500ba")
