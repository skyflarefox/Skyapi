-- Lua provided by SkyAPI 
-- Game: Underwater
addappid(1676200)
addappid(1676201, 1, "41d8a7e67e1c2e9771d2a4e12c95a6112315e66978128d3654ac75e8365411aa")
