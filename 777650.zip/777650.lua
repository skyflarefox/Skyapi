-- Lua provided by SkyAPI 
-- Game: Yet Another Research Dog
addappid(777650)
addappid(777651, 1, "44a5489702626e165546b4bdecd3afe6b850a8f33d8f4253f85d43282ee2242f")
