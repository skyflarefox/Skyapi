-- Lua provided by SkyAPI 
-- Game: AppID 2321430
addappid(2321430)
addappid(2321431, 1, "5bb800500b019aa3e7cf3a7362ae3e8561340180ce8a388d462fe7d5ab69e67f")
