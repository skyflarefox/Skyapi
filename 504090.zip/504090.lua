-- Lua provided by SkyAPI 
-- Game: AppID 504090
addappid(504090)
addappid(504091, 1, "def698c001b6294478406018624b3474a7fa02719e601be645c8210c2cb55b18")
addappid(621190, 0, "950f75dcfa20cd0da62cfbcd51963ef8eef6b18ed1ed4184fcb22721b53d5cb3")
