-- Lua provided by SkyAPI 
-- Game: Sidestep Legends
addappid(2077590)
addappid(2077591, 1, "ba149a9fc6c4fdc6b5c1ca69772e489eda260f4c68ef11a45cfe760cf5bde621")
