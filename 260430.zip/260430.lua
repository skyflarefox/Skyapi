-- Lua provided by SkyAPI 
-- Game: The Four Kings Casino and Slots
addappid(260430)
addappid(260431, 1, "b708a09ff33f2072e96e77b794150db30ae40fa4ccaf063c554ded9e189b08dd")
addappid(260432, 1, "df632e2bdacc3abf8cb3f42c87c865654c0ea46a9de1b9d195926f935a7606b5")
