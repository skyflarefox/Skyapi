-- Lua provided by SkyAPI 
-- Game: AppID 803800
addappid(803800)
addappid(803801, 1, "42907f8b72c68057cbaef7491746c49216b015609c9c01c43701c5d3d156d8b9")
