-- Lua provided by SkyAPI 
-- Game: Crab Game
addappid(1782210)
addappid(1782211, 1, "72f79d12aaf3b30c359742921f65b0cc6a11e5b73d4003eaaaf72deb34d4ad03")
