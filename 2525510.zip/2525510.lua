-- Lua provided by SkyAPI 
-- Game: NITRO GEN OMEGA
addappid(2525510)
addappid(2525511, 1, "763e3dc5df900a6f23d69d322f1b8caa123fe07552d48886e9dad50e4c870f6d")
addappid(3782960, 0, "bd10425035e3c651690a732e813e8b61d2d40fa1fb63545a0ada81700e3c6c5f")
