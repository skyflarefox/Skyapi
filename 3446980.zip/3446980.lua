-- Lua provided by SkyAPI 
-- Game: #holoReversi
addappid(3446980)
addappid(3446981, 1, "bc34ef7ee0286c15a5363062d57b9b2493cbf8210d40abd2e234d309488ef482")
