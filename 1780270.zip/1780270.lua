-- Lua provided by SkyAPI 
-- Game: Laptop Tycoon
addappid(1780270)
addappid(1780271, 1, "822c8b3e340ec700ba50fc790c9c54896197e796fa2f745cbd991cd82a9e960c")
