-- Lua provided by SkyAPI 
-- Game: DREAMWORLD_MUSIC
addappid(1643410)
addappid(1643411, 1, "9dda9eb1c950e3c67819133416e1bf64800dfd56439597454ecfdd6b95580920")
