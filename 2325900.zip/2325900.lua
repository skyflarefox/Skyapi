-- Lua provided by SkyAPI 
-- Game: These Doomed Isles: The First God
addappid(2325900)
addappid(2325901, 1, "6634839fc21d17e4478c9e3e9b98be9e07a7d7d290b9011a38d12b0d7f1b1316")
