-- Lua provided by SkyAPI 
-- Game: Back to the Scene
addappid(1397070)
addappid(1397071, 1, "bab02cf932ff98895b0cbd2cb149345263c8613b32c603d1d11101f3cf5faaf7")
