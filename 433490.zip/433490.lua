-- Lua provided by SkyAPI 
-- Game: Super Flippin' Phones
addappid(433490)
addappid(433491, 1, "838d4a6762872b860c1ecced5ebd6a323fade2269968469fa4b69a0b989c3f8c")
