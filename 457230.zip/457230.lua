-- Lua provided by SkyAPI 
-- Game: Atlas Reactor VR Character Viewer
addappid(457230)
addappid(457231, 1, "0a6cb8c36c8a4d50f7f4d22f1ee7173573781faed2e4449485a378327548f947")
