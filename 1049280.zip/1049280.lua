-- Lua provided by SkyAPI 
-- Game: Pilgrims
addappid(1049280)
addappid(1049281, 1, "7c5209bbdb617f4abfb1f788e0b4a6c58118a2d822925bd469bc6018f4135cb3")
