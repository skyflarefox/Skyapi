-- Lua provided by SkyAPI 
-- Game: Age of Wonders
addappid(61500)
addappid(61501, 1, "fd87bea5517c9ef6c7ee670c5036edc8e0b5fa74259bbefc0655d0fec531f425")
