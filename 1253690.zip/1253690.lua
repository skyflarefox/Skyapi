-- Lua provided by SkyAPI 
-- Game: AppID 1253690
addappid(1253690)
addappid(1253691, 1, "749d95f6bb06981f740138285e0c4fef787fc22d3c9645008ccc4c90cd2f9c9b")
