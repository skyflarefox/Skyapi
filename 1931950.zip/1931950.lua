-- Lua provided by SkyAPI 
-- Game: Vade Retro : Exorcist
addappid(1931950)
addappid(1931951, 1, "2ffb86dd9875a0a79beebb596868d696505e63a39272556c5f3f03f4ae2831d3")
