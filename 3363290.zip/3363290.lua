-- Lua provided by SkyAPI 
-- Game: AppID 3363290
addappid(3363290)
addappid(3363291, 1, "0a4795dde80017699d7d32e540249e42a79929d51b8b4977a6cd4e4a151e1aff")
