-- Lua provided by SkyAPI 
-- Game: A Bloody Night
addappid(639720)
addappid(639721, 1, "c562f5bdc7da4b33c7f3a55b8099c2af13bb0ca328334d05dc00ee04bb5853c0")
