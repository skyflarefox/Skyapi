-- Lua provided by SkyAPI 
-- Game: Delic Demo
addappid(2929190)
addappid(2929191, 1, "7797d78245868c8d02a7fe69826cb4e6a94cc877841f495740857a2ca014ea02")
