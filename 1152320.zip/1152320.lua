-- Lua provided by SkyAPI 
-- Game: AppID 1152320
addappid(1152320)
addappid(1152321, 1, "ae344591aa0d55d6339a5de23f85512f23dd11d608e3fa2ea158a4345a6b5eb0")
