-- Lua provided by SkyAPI 
-- Game: Anvil Saga
addappid(1587540)
addappid(1587541, 1, "da7ff0b6ee036d14e58c2aca69462b3d605ad4ec85070c6f3e919a22350f9a21")
