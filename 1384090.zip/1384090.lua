-- Lua provided by SkyAPI 
-- Game: AppID 1384090
addappid(1384090)
addappid(1384091, 1, "14732d6270d173ec1977152dfb32e744c96e13369d60d55b125f40bc47372e20")
