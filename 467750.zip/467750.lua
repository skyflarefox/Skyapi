-- Lua provided by SkyAPI 
-- Game: Chromo XY
addappid(467750)
addappid(467751, 1, "74fb76023aadd7a02c4f5b28a64238376b6a1414c919d6e9bd71cd2e05cf725e")
