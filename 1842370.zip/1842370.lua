-- Lua provided by SkyAPI 
-- Game: Milf Puzzle
addappid(1842370)
addappid(1842371, 1, "de477829bae159f94b907f1b226378640b7eac42979e868e0c7e83f643df6821")
