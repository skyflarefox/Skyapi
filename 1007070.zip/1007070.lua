-- Lua provided by SkyAPI 
-- Game: BorderStrain
addappid(1007070)
addappid(1007071, 1, "d365a6f0fa9a08328659d637f86c5ef81dbd6a6428f529966913a36f971a0755")
