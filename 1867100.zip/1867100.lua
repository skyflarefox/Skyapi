-- Lua provided by SkyAPI 
-- Game: Merge Hero
addappid(1867100)
addappid(1867101, 1, "e975b4adbe8ebc37cc112a93ff2298d0c3f68fb4c1abc066fad08b4b1fee04d5")
