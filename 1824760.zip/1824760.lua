-- Lua provided by SkyAPI 
-- Game: Hentai Memory - Sexy Couples
addappid(1824760)
addappid(1824761, 1, "2b5471d47a28f95dad4b051f2f9df0e8d91a474288271f5dc7b09a664875e716")
addappid(1831600, 0, "e53681d75016bdd6ca4481178dbfe3be76e0ea167c8fb1fc3072923e618f2fd4")
