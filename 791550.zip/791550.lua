-- Lua provided by SkyAPI 
-- Game: AppID 791550
addappid(791550)
addappid(791551, 1, "475200863fefe8ecacbf62c0928bc212078f75df21c0524cb619de8d2ff37ebc")
