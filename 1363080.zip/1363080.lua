-- Lua provided by SkyAPI 
-- Game: AppID 1363080
addappid(1363080)
addappid(1363081, 1, "28763f0001125b10d1d269c0655d8d3f9e6a7678dd9fed0af3f4a37701443e70")
addappid(2932660, 0, "1adba25f4fa5ce03145e033f1f027e5d411e8db2042fbad6317352153d507bfe")
