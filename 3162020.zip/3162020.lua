-- Lua provided by SkyAPI 
-- Game: ToriDori 2
addappid(3162020)
addappid(3162021, 1, "f12b5f3f36b008079a9b0d83e28f30991b86e5a544fee5bdf5b08731f1ee52c2")
