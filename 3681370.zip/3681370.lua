-- Lua provided by SkyAPI 
-- Game: ABYSSAL BLADE
addappid(3681370)
addappid(3681371, 1, "6f228a8ba06f8bfa9240b2d31cc5aa8921d08fe72a03a69772cc8dc262acaddb")
