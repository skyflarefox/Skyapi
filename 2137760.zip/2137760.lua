-- Lua provided by SkyAPI 
-- Game: Crafty Survivors
addappid(2137760)
addappid(2137761, 1, "573e82875fce23d4f27f3e5d1b4e125b9520114551a9b17d930b43ae297b25d4")
