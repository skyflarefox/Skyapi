-- Lua provided by SkyAPI 
-- Game: Sora no Ao to Shiro to
addappid(2135500)
addappid(2135501, 1, "b9f7762079477d5f7a966cebda8f8f279d725978f5530f48705d7863b185a8f8")
