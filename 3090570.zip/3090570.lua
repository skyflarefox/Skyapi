-- Lua provided by SkyAPI 
-- Game: AppID 3090570
addappid(3090570)
addappid(3090571, 1, "a5ca59f9c357a8489a4ef2d2352db86b4aea5bc7a67254f9e6cf8e9b099f5ce2")
