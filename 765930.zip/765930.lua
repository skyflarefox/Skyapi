-- Lua provided by SkyAPI 
-- Game: Follia - Dear Father VR
addappid(765930)
addappid(765931, 1, "272ef068c8c1e1c71ccf0bf08fb93c21f7ca01feafb951548e85cec72078c9ec")
