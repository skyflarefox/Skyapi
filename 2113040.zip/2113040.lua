-- Lua provided by SkyAPI 
-- Game: RUNGORE
addappid(2113040)
addappid(2113041, 1, "9d8d75fac5fc285f4fb82a7c7b4e1e4ad2a42b8625d5d8c88e7d51bd59e8ed70")
