-- Lua provided by SkyAPI 
-- Game: Pixel Puzzles 2: Anime
addappid(350810)
addappid(350811, 1, "093ef6f3a554599a98f9ebce1adb358e06311e35a458472702cc1f97b6bcd9ba")
