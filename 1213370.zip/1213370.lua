-- Lua provided by SkyAPI 
-- Game: Mr. Fast
addappid(1213370)
addappid(1213371, 1, "28fb11f2df92e30488000a61825cc3e30ec6d4441ceafd4f2d6635fbf832a109")
addappid(1213372, 1, "a546cde2775367b643860d8a73660dd98223cb0e88da453af4d35b0527c7241c")
