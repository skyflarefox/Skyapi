-- Lua provided by SkyAPI 
-- Game: AppID 1687530
addappid(1687530)
addappid(1687531, 1, "4693d1361670cfb9d7dc20354e0a2ffd8cb73d1d2021e5889467229895d01721")
