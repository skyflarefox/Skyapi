-- Lua provided by SkyAPI 
-- Game: This Is Not A Jumping Game
addappid(745890)
addappid(745891, 1, "629e55133df3fb6657d347bebeb3be73f546f73af1f45c8ee5eeca5ad3a1f7cc")
