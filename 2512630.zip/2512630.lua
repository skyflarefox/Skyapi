-- Lua provided by SkyAPI 
-- Game: One Life To Alice
addappid(2512630)
addappid(2512631, 1, "d1ab8babc89fa48cad461d1aa9c822a6116c4865077ec833da8462732179674a")
