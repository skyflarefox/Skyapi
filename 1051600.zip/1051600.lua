-- Lua provided by SkyAPI 
-- Game: Surface: The Soaring City Collector's Edition
addappid(1051600)
addappid(1051601, 1, "b942a01a92ef24bfd309bc2c36e62f3b37f5d49d3a135090b94b85a66acfdb50")
