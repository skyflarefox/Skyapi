-- Lua provided by SkyAPI 
-- Game: Furry Striptease
addappid(2109380)
addappid(2109381, 1, "fd44a1994763128d4a5154b34875e98b72c088b341af5dbf8e75c76144da7933")
