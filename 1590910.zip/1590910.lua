-- Lua provided by SkyAPI 
-- Game: Forgive Me Father
addappid(1590910)
addappid(1590911, 1, "8e2ba27316a162742cd823bb6a93eca7ed9a19826e1adcb9e5efc4c882505347")
