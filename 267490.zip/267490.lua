-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(267490)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(267491,0,"e52240acea700d02909d4f96f9b64d05b808152723a4a4487a212a013e6bc1d6")
setManifestid(267491,"5177120768393799519")