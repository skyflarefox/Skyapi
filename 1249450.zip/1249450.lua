-- Lua provided by SkyAPI 
-- Game: AppID 1249450
addappid(1249450)
addappid(1249451, 1, "54df9263d55339d88d874b0729684174e48d109fda3d021a903dad6b4e159413")
