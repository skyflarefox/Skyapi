-- Lua provided by SkyAPI 
-- Game: Quad Battle Playtest
addappid(2532140)
addappid(2532141, 1, "3a898dac8d610b747dcefd10dcca208c0d03c926a0a464d51201765616250123")
