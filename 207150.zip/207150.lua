-- Lua provided by SkyAPI 
-- Game: Stellar Impact
addappid(207150)
addappid(207151, 1, "58289198685d32c7045f4662fb5bed4e0ac848c661c28e749b8f8338337a7b9a")
