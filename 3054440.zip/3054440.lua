-- Lua provided by SkyAPI 
-- Game: Short Snow | Cold Survival Game
addappid(3054440)
addappid(3054441, 1, "ebf4804f30552083c811eb2963acc9d753e3f3b05f69f0c8fc28293c577b7600")
