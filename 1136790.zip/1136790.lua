-- Lua provided by SkyAPI 
-- Game: AppID 1136790
addappid(1136790)
addappid(1136791, 1, "6850f9ad32b8be60424de1b4e6e89812902c794b28a68587852e8ca1835e2c03")
