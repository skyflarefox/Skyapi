-- Lua provided by SkyAPI 
-- Game: No one lives under the lighthouse Director's cut
addappid(1254370)
addappid(1254371, 1, "66d686f79db47710a72395e20b1dae04aaec7cad5e0a1fd457fe4fbb9ced5e61")
addappid(1254372, 1, "ed3739a082e0a1773f44d248eb43591d6295f4e615725e3970229fc35a7a5977")
addappid(1254373, 1, "8955f9361b2b741f17724d3f253de8f5884aa21ce44e36f7599e242cfa027d2b")
