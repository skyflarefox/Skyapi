-- Lua provided by SkyAPI 
-- Game: Mustache or Revenge
addappid(1131780)
addappid(1131781, 1, "b250883b15ea0ee9b2689a393aba69f1d0eb88c47ff980f0a11b7b4c6b160234")
