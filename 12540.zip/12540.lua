-- Lua provided by SkyAPI 
-- Game: Mahjongg Investigations: Under Suspicion
addappid(12540)
addappid(12541, 1, "371dedb5e7668703344bbefd831cbd88d9a6c7fadad690ccf69886a3140be3f3")
