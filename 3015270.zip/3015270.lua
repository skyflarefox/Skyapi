-- Lua provided by SkyAPI 
-- Game: Tower of Megami Descents
addappid(3015270)
addappid(3015271, 1, "1bb4faf6bc3ed9dffb3076d3bdbff16c13cc693a57982a85929e8d9df3458645")
