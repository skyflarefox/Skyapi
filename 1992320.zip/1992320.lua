-- Lua provided by SkyAPI 
-- Game: Sons of Valhalla Demo
addappid(1992320)
addappid(1992321, 1, "213beec89d9805f100413fa505579ddbd18d66ae84ef838e525fd7f4c5dccc26")
