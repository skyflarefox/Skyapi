-- Lua provided by SkyAPI 
-- Game: AppID 1229240
addappid(1229240)
addappid(1229241, 1, "ff27f2f37168a59dc0e34b830a8e3f070c20ad3e2d63df4011d9849a103a242c")
