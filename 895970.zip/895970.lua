-- Lua provided by SkyAPI 
-- Game: AppID 895970
addappid(895970)
addappid(895971, 1, "a6ce55c9a935d5f2fb2e830dab45cfa32f36cab4e741cdb0b9710c47d0e80112")
