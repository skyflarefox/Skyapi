-- Lua provided by SkyAPI 
-- Game: Tyrfing  Cycle |Vanilla|
addappid(429430)
addappid(429431, 1, "8273a8ca20ad07831ae4ac102e4903b4d0e0e876b00221d261a9ece0322470ea")
