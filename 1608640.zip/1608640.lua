-- Lua provided by SkyAPI 
-- Game: OTXO
addappid(1608640)
addappid(1608641, 1, "1bc1d0a1e2499d9575a5814e5c01c15664f11e1813d86e56f10766e78757584f")
