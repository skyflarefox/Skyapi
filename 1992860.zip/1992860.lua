-- Lua provided by SkyAPI 
-- Game: Vetrix Worlds
addappid(1992860)
addappid(1992861, 1, "2a7b35a888175a80463211e91e7645068379304d6cf093624f1860b33831ef9e")
