-- Lua provided by SkyAPI 
-- Game: Gear Path
addappid(764470)
addappid(764471, 1, "90d957f9c75ae80917f8becbc6f0a0f2db33eb02c0489b2a6dc5b53ecacfc3a4")
