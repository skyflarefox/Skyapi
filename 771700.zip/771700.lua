-- Lua provided by SkyAPI 
-- Game: AppID 771700
addappid(771700)
addappid(771701, 1, "aa71e8bb13c6d0bf005ce3537d5cf45d15645435d492837b2e0b3e2e7c823542")
