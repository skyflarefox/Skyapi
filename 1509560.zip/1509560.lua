-- Lua provided by SkyAPI 
-- Game: AppID 1509560
addappid(1509560)
addappid(1509561, 1, "b198d088fab17596e77b5cfe2b7d2cb6b42f7d85a21351c05786b366a550173c")
