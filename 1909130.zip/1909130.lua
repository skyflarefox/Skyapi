-- Lua provided by SkyAPI 
-- Game: Lust Academy - Magic Soundtrack
addappid(1909130)
addappid(1909131, 1, "e23a15881f2783bafb90d652a1b957b82209966f9f75e7a776657731f6af92b7")
