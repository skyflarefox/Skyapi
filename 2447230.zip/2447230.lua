-- Lua provided by SkyAPI 
-- Game: Sáivu
addappid(2447230)
addappid(2447231, 1, "075824563731c801cf5c54b9bfc6af4a056c9d6c86e5e37b6b9af2255485b36f")
