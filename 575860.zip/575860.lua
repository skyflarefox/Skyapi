-- Lua provided by SkyAPI 
-- Game: AppID 575860
addappid(575860)
addappid(575861, 1, "690212534c3b01de5bac0e4fcc452afe154736cc86900c4dd976c9fe045f0722")
