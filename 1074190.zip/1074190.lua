-- Lua provided by SkyAPI 
-- Game: Dragon Spirits
addappid(1074190)
addappid(1074191, 1, "1d577ca46478e011d314007fd76b519c93a6bd23237af86969956193ebb21731")
