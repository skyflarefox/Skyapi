-- Lua provided by SkyAPI 
-- Game: Purrfect Apawcalypse: Patches' Infurno
addappid(1599470)
addappid(1599471, 1, "43090e52f0e5ae8440721d51c7256a07b1a447a9e25685ffd9b1e1d76292be0f")
