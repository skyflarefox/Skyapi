-- Lua provided by SkyAPI 
-- Game: Gordian Quest Soundtrack
addappid(2021340)
addappid(2021341, 1, "c18119306ad4d15258bb4d26b2bc01e2e6e85f1998a9e94b50f161cd4b1b765c")
