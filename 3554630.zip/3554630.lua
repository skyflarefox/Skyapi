-- Main AppID
addappid(3554630)

-- Main Depots
addappid(3554631, 1, "0da595043e2e1bee8737544538c288910b41e895612771f9875f7c8f9c742825") -- (windows)
setManifestid(3554631, "5544769887538624692", 3124978796)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
