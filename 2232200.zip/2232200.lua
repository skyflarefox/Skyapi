-- Lua provided by SkyAPI 
-- Game: AppID 2232200
addappid(2232200)
addappid(2232201, 1, "ad8eb3b2c56ee1a7a6505f4b138122534e23244daacec9fa4c7ff39dfcb37437")
