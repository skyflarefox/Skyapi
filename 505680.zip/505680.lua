-- Lua provided by SkyAPI 
-- Game: Glaive
addappid(505680)
addappid(505681, 1, "c97f016c9e44f08236b5889ffc829f0c4992309bf77cd5b2b9c6b8730b66d31e")
