-- Lua provided by SkyAPI 
-- Game: Trash Top Down Racing
addappid(2752650)
addappid(2752651, 1, "e11666440a206e295d4970e4c64b80ad1b9bcaab44c1e2711355140752d183d7")
