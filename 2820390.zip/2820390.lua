-- Lua provided by SkyAPI 
-- Game: Seclusion
addappid(2820390)
addappid(2820391, 1, "8db2b6923013c287df2b356e30484836e18278f657dd7b2939f5ce63854885ac")
