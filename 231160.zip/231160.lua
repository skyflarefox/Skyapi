-- Lua provided by SkyAPI 
-- Game: The Swapper
addappid(231160)
addappid(231161, 1, "e6812325d6c6299b4f4c2af217c1061b5ef6a50bebc4707cd49ec680ac9fcfc7")
addappid(231163, 1, "fd030fd481bc1dab38c113c92e3b65ff30e650454ee193454e2991d5dfeebf8c")
