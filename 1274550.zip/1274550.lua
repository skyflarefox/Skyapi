-- Lua provided by SkyAPI 
-- Game: Dragon Storm
addappid(1274550)
addappid(1274551, 1, "8bcb73e2dbc4bc4ae209e7389d3d63a21a341b1476dd8fbfc0d4ee6c85692f18")
