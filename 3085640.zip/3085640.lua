-- Lua provided by SkyAPI 
-- Game: AppID 3085640
addappid(3085640)
addappid(3085641, 1, "7a5eff2d30643526f645c30926fecbd461dd96b55a645a6aa25746f1333f742e")
