-- Lua provided by SkyAPI 
-- Game: Roboquest
addappid(692890)
addappid(692891, 1, "6de29760974d9a062f71a50a766e6560959934a90bd6c43849e4b5c2c3040c66")
addappid(2729110, 0, "7147a52fbc37206a8101897f11ccce51c3fe1fd5cb493899bfa7bc357f1b5d8c")
