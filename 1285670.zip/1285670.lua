-- Lua provided by SkyAPI 
-- Game: AppID 1285670
addappid(1285670)
addappid(1285671, 1, "1f10daaab6c8c2f531459d76a7391456675dfc3daf564662d44506d361b7540b")
