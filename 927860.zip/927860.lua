-- Lua provided by SkyAPI 
-- Game: AppID 927860
addappid(927860)
addappid(927861, 1, "ad98456b264b26c8f1096e1fee15bc2d5eb6aa6a0e5736d8d8e97b6b27cbe052")
