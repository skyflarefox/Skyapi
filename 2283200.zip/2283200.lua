-- Lua provided by SkyAPI 
-- Game: Eleanor in Miami: Chains of depravity
addappid(2283200)
addappid(2283201, 1, "01d47319ef387c7173fad4e8ff335ea79daac432ab2a0715e9d7fbab4d6f2316")
