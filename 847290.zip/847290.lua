-- Lua provided by SkyAPI 
-- Game: AppID 847290
addappid(847290)
addappid(847291, 1, "17eed51d1f4e99f03b408b015c7a1f2d33eaf46ee893203b26776e8451f29840")
