-- Lua provided by SkyAPI 
-- Game: AppID 1125240
addappid(1125240)
addappid(1125241, 1, "1bfcf656f87f970028487f832ba08b3131dd9c57882e261e9e8585a9cd84ccd5")
