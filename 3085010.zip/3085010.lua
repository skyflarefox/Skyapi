-- Lua provided by SkyAPI 
-- Game: Emoji Shooter
addappid(3085010)
addappid(3085011, 1, "4dd1db2d667abc92b12d01713d0861c15911e7e31f99ffb7f5fbb5b4304531c9")
