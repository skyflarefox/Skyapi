-- Lua provided by SkyAPI 
-- Game: Maybe Immortal
addappid(1640810)
addappid(1640811, 1, "6a8fde9c79f3b3d2d5b24f3a3d90f77783247dc4e4cf42fa42827ac81ae91ab4")
