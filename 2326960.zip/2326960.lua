-- Lua provided by SkyAPI 
-- Game: Battle of Hořice 1423
addappid(2326960)
addappid(2326961, 1, "7088ad993360a1e549fc7890c4ff252734e5791bd9485e900cb61a30171e33e4")
