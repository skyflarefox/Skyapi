-- Lua provided by SkyAPI 
-- Game: Dungeon Survival
addappid(2369880)
addappid(2369881, 1, "c11328b9802ce878f3d9ae51541ab12f4c41bf0b6b29d14b670e2d521691aeda")
