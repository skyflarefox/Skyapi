-- Lua provided by SkyAPI 
-- Game: Sam & Max 203: Night of the Raving Dead
addappid(8280)
addappid(8281, 1, "f6ac04aee4dc62ab075478c9f6b370203913f6e4304b71784e1c5d749ceaa713")
addappid(8282, 1, "7ee8fc10b59ffb8ff36d46b8084e85a1cc64468fbaaed79f5b8d74b3e39e4a9f")
