-- Lua provided by SkyAPI 
-- Game: AppID 438100
addappid(438100)
addappid(438101, 1, "3479e8ef2bdeedf17313e5cd206d1eab607bc61385b6fe88bc499ea004033f70")
