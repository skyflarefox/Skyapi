-- Lua provided by SkyAPI 
-- Game: AppID 775530
addappid(775530)
addappid(775531, 1, "ea4fe25563abf7656e20a13649293ae92a64786b784fbfdceaaa404d49d7ff76")
