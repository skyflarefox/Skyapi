-- Lua provided by SkyAPI 
-- Game: Light Apprentice - The Comic Book RPG
addappid(569570)
addappid(569571, 1, "1f0c4c69fa6f5a1d2885872b8f6d81a82c0ddea690ac9e61518da7e8cf9d4846")
addappid(569572, 1, "cdca689df0ba75ec116a7736c9b57d4b75ed575b82e5c634074517a28448b7e6")
addappid(569574, 1, "86f0d8ab8b270a472811c4e905b9dca95b516638e5898cb547a4d89128f7785d")
