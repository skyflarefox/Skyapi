-- Lua provided by SkyAPI 
-- Game: Asterball
addappid(2837470)
addappid(2837471, 1, "759cfc21b93b24374dc9ef8bbf37e9bfe53ee7ba9afbcc79ed6e5523ae3f2332")
