-- Lua provided by SkyAPI 
-- Game: Borderlands: The Zombie Island of Dr. Ned
addappid(8990)
addappid(8991, 1, "fb5fc9aa2607f09225e79d4ce75f788ec3b5e2ad14e6861f1b998c65296a16a7")
