-- Lua provided by SkyAPI 
-- Game: AppID 1295940
addappid(1295940)
addappid(1295941, 1, "0b1e21b0f6817dc3176282710708debf13f68d8d9833ea1322ac0d1b8283f8d6")
