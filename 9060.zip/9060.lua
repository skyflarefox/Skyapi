-- Lua provided by SkyAPI 
-- Game: HeXen II
addappid(9060)
addappid(9061, 1, "aa03e466ff2b46478a4d5ecc292065644f58c5efbd4116ad3af928308dc662f8")
