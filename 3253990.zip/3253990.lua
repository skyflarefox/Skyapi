-- Lua provided by SkyAPI 
-- Game: THE WALLWAY
addappid(3253990)
addappid(3253991, 1, "43974538cc51a20b9fbe9a9dda6c06485e5814a390f8e8b26a696234397fe322")
