-- Lua provided by SkyAPI 
-- Game: Endangered Proposition Demo
addappid(1093740)
addappid(1093741, 1, "b5412e46bbc207cafc3c146d7af81ea39c2b2a7a36cd23d40009a1a57f90277a")
