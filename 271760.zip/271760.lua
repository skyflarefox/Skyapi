-- Lua provided by SkyAPI 
-- Game: Dungeon Lords Steam Edition
addappid(271760)
addappid(271761, 1, "d550342f0ea488462deb25b234fb12d0b66b0aba2298f120fe2d345c37019713")
addappid(271762, 1, "0fc82e7c00f0fe2b57692c83593c7e8fa3d02292f8f7620ce5b77599689922b9")
addappid(271763, 1, "b598190e9c8dd31921269aadfd34620fcaed7010f9aa05edf9bdb2c7bd8bc939")
