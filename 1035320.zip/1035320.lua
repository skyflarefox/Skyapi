-- Lua provided by SkyAPI 
-- Game: MarineVerse Sailing Club
addappid(1035320)
addappid(1035321, 1, "be62478ea02f3ca850f8323d18723ea8c21215ce36ab97f3bafd18374b5c94a2")
