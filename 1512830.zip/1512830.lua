-- Lua provided by SkyAPI 
-- Game: 黑巢姐妹
addappid(1512830)
addappid(1512831, 1, "6354ee4f3748eb5a1bca5e638d7fe2d9a4c8835c848f52c6fff6d3c8c0dc4d34")
