-- Lua provided by SkyAPI 
-- Game: AppID 1202120
addappid(1202120)
addappid(1202121, 1, "539c31ca621c302b6927d9690bec2414257a36437f3b4b206ebf4f560dc1aa59")
