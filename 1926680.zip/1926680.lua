-- Lua provided by SkyAPI 
-- Game: FUCK PUTIN
addappid(1926680)
addappid(1926681, 1, "9f4597faa8d99cf44dcb8ddb823b07fa84c7d973aac8e5b6f4ab675bb727ee16")
