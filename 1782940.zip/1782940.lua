-- Lua provided by SkyAPI 
-- Game: Cyndefense 2
addappid(1782940)
addappid(1782941, 1, "bd4c105c781802c298b31c0ccb4963e43d10ed152655976faa07d2511cff6b95")
