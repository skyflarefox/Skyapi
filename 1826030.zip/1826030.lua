-- Lua provided by SkyAPI 
-- Game: Dark Reflections - Shiori no Kotoha
addappid(1826030)
addappid(1826031, 1, "26b05283f5b34de65296321ffc8feb312259a6b7d65c346dae8ceebe6b9cf7c7")
