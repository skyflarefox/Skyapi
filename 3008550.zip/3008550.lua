-- Lua provided by SkyAPI 
-- Game: Spill the Beans Demo
addappid(3008550)
addappid(3008551, 1, "4cff8a2dc7f58ce52adf4ee8151d479816bb24739f37647a16d16cbe4a1d5d4a")
