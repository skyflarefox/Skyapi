-- Lua provided by SkyAPI 
-- Game: Skydance's BEHEMOTH
addappid(1707990)
addappid(1707991, 1, "573a21de5c170e2cab9f3a65540656d19ff87f616d2746c35d4d7e1470ea4923")
