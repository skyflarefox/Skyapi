-- Lua provided by SkyAPI 
-- Game: Towers of Aghasba
addappid(2178070)
addappid(2178071, 1, "a0cc1ebf88bc7bfcac11875c070fb0a2b0b439f439779695e2f7a3499ebcc7fd")
