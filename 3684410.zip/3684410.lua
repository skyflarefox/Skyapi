-- Lua provided by SkyAPI 
-- Game: Goat Stand and Turtle Guy
addappid(3684410)
addappid(3684411, 1, "edcd8bf625a5d8f764feb19090110ae329a6c768183e0c3a5e5938bab0f2f256")
