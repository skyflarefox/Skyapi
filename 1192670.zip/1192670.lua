-- Lua provided by SkyAPI 
-- Game: CODE VEIN Demo
addappid(1192670)
addappid(1192671, 1, "07c24d2cc4af6aa988aca0ba66860f8a7993d48e37aef6417c43c54d4767357f")
