-- Lua provided by SkyAPI 
-- Game: AppID 3658110
addappid(3658110)
addappid(3658111, 1, "bf95f0ac418e99d85c6b710461304c693358757ad4d2e8f706504c12a526404d")
