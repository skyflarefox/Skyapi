-- Lua provided by SkyAPI 
-- Game: The Guest
addappid(2506110)
addappid(2506111, 1, "a009733b93f814685be6169306369594b9aa322cc448bab7425056bd5d5087da")
