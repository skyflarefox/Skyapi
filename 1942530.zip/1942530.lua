-- Lua provided by SkyAPI 
-- Game: The Anointed: David Saves Keilah
addappid(1942530)
addappid(1942531, 1, "94809b9b5e290f9231ac80248a8ab814342f6a9b4f7f1a6d672b08fc9c65e68e")
