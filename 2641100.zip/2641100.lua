-- Lua provided by SkyAPI 
-- Game: ImmortalSurvivors Demo
addappid(2641100)
addappid(2641101, 1, "e6de86a24bbae7591806b8f794be321bd471a7f568d52aeb747e1972ce28b772")
