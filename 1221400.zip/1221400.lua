-- Lua provided by SkyAPI 
-- Game: Trusty Brothers
addappid(1221400)
addappid(1221401, 1, "2cc6f5401b8c0a7d27ccaba9520311d1e4b2248b6144ff9fd7fb628b25cd14c1")
