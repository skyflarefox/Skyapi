-- Lua provided by SkyAPI 
-- Game: Train1999 Demo
addappid(2184780)
addappid(2184781, 1, "bb3ae379687e2bb49e395aec6f9bcc22b50742a017d1c29cdda02d4742f84ade")
