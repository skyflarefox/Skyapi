-- Lua provided by SkyAPI 
-- Game: 古龙风云录
addappid(2340650)
addappid(2340651, 1, "a97e3fe5b1737a82dc6c602b5983ceb9119b915ab9efc58a3408b767e5e3fbea")
