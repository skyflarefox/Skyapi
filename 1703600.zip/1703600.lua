-- Lua provided by SkyAPI 
-- Game: Our Personal Space
addappid(1703600)
addappid(1703601, 1, "66014c6d74e09c05d890c269e9b325cd24c593dd88f07f90b49c2c4b14d4be1c")
