-- Lua provided by SkyAPI 
-- Game: AppID 2428670
addappid(2428670)
addappid(2428671, 1, "335d5158282fccbbca48c75263a075774e1957de63699da0ac2127cd394fecd2")
