-- Lua provided by SkyAPI 
-- Game: AppID 911880
addappid(911880)
addappid(911881, 1, "429b110a154d2f069121b4bfd18dffb7448cd2d0d123ea0c597819fab1554278")
