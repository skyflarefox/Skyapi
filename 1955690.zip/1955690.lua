-- Lua provided by SkyAPI 
-- Game: Ready Action
addappid(1955690)
addappid(1955691, 1, "df4a0c9f503701496cbba6bb1850788d3a5e7d8a4fa0798d3951cf226c37fabf")
