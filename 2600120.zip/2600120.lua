-- Lua provided by SkyAPI 
-- Game: AppID 2600120
addappid(2600120)
addappid(2600121, 1, "f49c54a8cc4383b7040058b583790797aa8cfbb895bf38f0a92434007d78e69f")
