-- Lua provided by SkyAPI 
-- Game: AppID 1114000
addappid(1114000)
addappid(1114001, 1, "de62b5c5f84e8338dd2dc6c40477b5b7853186b60ec1d0739821f20f88aff1bf")
