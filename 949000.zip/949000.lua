-- Lua provided by SkyAPI 
-- Game: Marble Combat
addappid(949000)
addappid(949001, 1, "bac43ec64122998c9d8ed2b6026d9723b0b7f6bd5d9ed906c1771ebf80984781")
