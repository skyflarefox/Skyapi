-- Lua provided by SkyAPI 
-- Game: Jurnal Malam : Bestfriend
addappid(2931750)
addappid(2931751, 1, "aeb13259c1582136a9cc085b58c07b43fd9bc3287c725fac54e55cdf17b972ca")
