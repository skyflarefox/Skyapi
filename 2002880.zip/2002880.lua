-- Lua provided by SkyAPI 
-- Game: Rhapsody III: Memories of Marl Kingdom
addappid(2002880)
addappid(2002881, 1, "f492dfd5f7053776bf8fe86784666ac35da69fb8f2a7d543b4f5a4a065b78873")
addappid(2517660)
