-- Lua provided by SkyAPI 
-- Game: Realm of the Undead Demo
addappid(2768250)
addappid(2768251, 1, "8ea64c472e7d0b87299eb6caff5ac5510f0dd6aa643135d9cb93c82512967c91")
