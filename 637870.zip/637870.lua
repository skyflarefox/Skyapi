-- Lua provided by SkyAPI 
-- Game: Slice&Dice
addappid(637870)
addappid(637871, 1, "94e9e02d2967ddb70b80861b91ebd4cac3a2434f766a00e2469f164c51590e42")
