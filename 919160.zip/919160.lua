-- Lua provided by SkyAPI 
-- Game: Submerged: VR Escape the Room
addappid(919160)
addappid(919161, 1, "59e01e99048ed2d1ddfe711a813b352c57cfca98b1e0b1e352c1e6ab8c1567e7")
