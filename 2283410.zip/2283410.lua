-- Lua provided by SkyAPI 
-- Game: CTHULOOT
addappid(2283410)
addappid(2283411, 1, "133f28fc93dd9acec253e20551c7f75246a38f06d08953f37ad3a66403126484")
