-- Lua provided by SkyAPI 
-- Game: Loot Box Simulator
addappid(889240)
addappid(889241, 1, "8989700e53b14dc80e233ab6352bbc2709de5d74f5f2e0fbea1b2706249ccaa9")
