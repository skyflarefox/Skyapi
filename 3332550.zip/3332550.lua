-- Lua provided by SkyAPI 
-- Game: Light in the woods
addappid(3332550)
addappid(3332551, 1, "f0919dba04b97b8783ee28c5dac42003177ef763a2d7562860a02edef714b412")
