-- Lua provided by SkyAPI 
-- Game: A Bad Day For A Hangover
addappid(2442880)
addappid(2442881, 1, "c418b177c7df5b713c4d59c5011e6bdbe0af282b2994fa4adf43f0169207a22e")
