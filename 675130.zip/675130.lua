-- Lua provided by SkyAPI 
-- Game: AEGYPTUS
addappid(675130)
addappid(675131, 1, "e456029379780d925c4efb50b5a5a7c953740f58ac04a631e0068087f106701b")
