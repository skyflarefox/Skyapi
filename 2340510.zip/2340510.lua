-- Lua provided by SkyAPI 
-- Game: Moon's Creed
addappid(2340510)
addappid(2340511, 1, "6f68925b081efcf091d8028396312ae6a81cbff3b3b1450b8cdf8f3645fa895a")
