-- Lua provided by SkyAPI 
-- Game: The Blunderbuss
addappid(1875160)
addappid(1875161, 1, "877f2680e0e7be283fe69d832917ecfebee9b78e25d3616d32250814251bbb69")
