-- Lua provided by SkyAPI 
-- Game: The Legend of Cyber Cowboy
addappid(3298570)
addappid(3298571, 1, "aa24d87367dde72b58fb9635cd1a50b43f54a17aa1be1d041577eb698797f10d")
