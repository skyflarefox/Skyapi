-- Lua provided by SkyAPI 
-- Game: AppID 2400640
addappid(2400640)
addappid(2400641, 1, "7b7434476b362ddfd828e706bf0271cd1b87abcc5bc4d82201fbeeb743d2e164")
