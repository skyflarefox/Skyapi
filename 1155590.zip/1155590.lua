-- Lua provided by SkyAPI 
-- Game: Warplanes: WW1 Sky Aces
addappid(1155590)
addappid(1155591, 1, "931e1bf70c88dbd33d3c223cecc8000d166faca0c703694d2b885be23aa022a7")
addappid(1155592, 1, "ff4a169902e46f48844663090e5817fdf9be91b6b77386b1961d3873cd760899")
addappid(1155593, 1, "3f4b90f4fced2a4635f67341b402654da3971b97fef9c9087eee0f4e77927f3a")
