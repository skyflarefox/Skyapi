-- Lua provided by SkyAPI 
-- Game: LoveCraft
addappid(2692440)
addappid(2692441, 1, "265ff61fb95c6ca10afe9ae21cc3e1bc01bb93754e8d658167e217de34002a00")
