-- Lua provided by SkyAPI 
-- Game: Kunkun Terror Express
addappid(2923130)
addappid(2923131, 1, "012305f5296d70552b81b1d4597e041c95ec90d9ac9b40b2a7fdb9ce3ea9f4d7")
addappid(2930000)
