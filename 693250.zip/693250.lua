-- Lua provided by SkyAPI 
-- Game: Panda Run
addappid(693250)
addappid(693251, 1, "82bc7c3db910e5a783f8cc3055496cfe564c68dfd00021b885b5071efaeb11c5")
