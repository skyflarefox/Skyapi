-- Lua provided by SkyAPI 
-- Game: Survivor Challenge TD
addappid(2443170)
addappid(2443171, 1, "379e629757d60e6dc27f1d0624d7caf060dde4a43169780c3ebec6f9e6faaccb")
