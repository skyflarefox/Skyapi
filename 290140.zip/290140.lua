-- Lua provided by SkyAPI 
-- Game: AppID 290140
addappid(290140)
addappid(290141, 1, "36b5445bbf9dd8fab8c5b4a53cd32bc4e82389e18e1e37d7235e4a8ae80f418c")
