-- Lua provided by SkyAPI 
-- Game: AppID 2129750
addappid(2129750)
addappid(2129751, 1, "9b55e52ae63e9e80647b14ac94db3a61c96c46ba1be1e5aa755e2414cd69c5f8")
