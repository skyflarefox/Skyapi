-- Lua provided by SkyAPI 
-- Game: 20XX
addappid(322110)
addappid(322111, 1, "b4022475ec1beae0d8c52f80d38b62433930db6c70561db41a15db914b7f86d1")
