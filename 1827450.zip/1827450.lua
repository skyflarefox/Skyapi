-- Lua provided by SkyAPI 
-- Game: Champion of Venus
addappid(1827450)
addappid(1827451, 1, "6cf60fd4c4d18f84d8275320627774bade59043dfbf0cf32f593cd6b72f0740c")
