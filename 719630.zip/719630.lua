-- Lua provided by SkyAPI 
-- Game: AppID 719630
addappid(719630)
addappid(719631, 1, "6c764ef1fdc6368ee7eed1c8db16e4184c7b2331ba069fbe9afa3571a015846b")
addappid(719634, 1, "8a6b8fabe3ab3be487dcb80dc3aad9f7d0930aecc81513df55b0318b7ff758ad")
