-- Lua provided by SkyAPI 
-- Game: Leaf on Wind
addappid(1601040)
addappid(1601041, 1, "c5964c7d963fb26559532b3c2c3dc90bfc140301d18f03419c46afc1fb1bb9ed")
