-- Lua provided by SkyAPI 
-- Game: Street Cleaner Simulator
addappid(2856100)
addappid(2856101, 1, "0d83e8167d3cb4c24c6b24b0ae6493b6acd282b87a003203c832b222fdd798fe")
