-- Lua provided by SkyAPI 
-- Game: AppID 1576550
addappid(1576550)
addappid(1576551, 1, "bab48580e3a77f6277bbc46da4204dffedc96d883bbe309e249b915ca638c4cb")
