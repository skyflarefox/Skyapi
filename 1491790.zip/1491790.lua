-- Lua provided by SkyAPI 
-- Game: Atom
addappid(1491790)
addappid(1491791, 1, "78d61475478bfa6f24c7b2b515143e9da241e30000da9077f1603eb31a7d76e0")
addappid(1491792, 1, "98fbb9b2b003268155a33c98b8e3435baf28e06f167a50b36c9e8a4d0dbf6c76")
