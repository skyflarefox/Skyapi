-- Lua provided by SkyAPI 
-- Game: Tavern Master
addappid(1525700)
addappid(1525701, 1, "148f2103f69eac632cc21e2946672efc48866c28e811cf4548c86d486585d13b")
addappid(3261130)
