-- Lua provided by SkyAPI 
-- Game: AppID 703920
addappid(703920)
addappid(703921, 1, "e127b610d2722fdced0fa491718de3eb9c9b985e039eb0f16691f93e3a4bd346")
