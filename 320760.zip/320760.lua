-- Lua provided by SkyAPI 
-- Game: AppID 320760
addappid(320760)
addappid(320761, 1, "e61ac7091046ffbc9b8c4e3f1d76cc8cf7009b7ba4fa7435b555eedbe4bd928c")
addappid(374880, 0, "014160b4a19a0ef252e625189b479353bc963361aa559bb2a74ca85d16c2052e")
