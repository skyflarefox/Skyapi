-- Lua provided by SkyAPI 
-- Game: AppID 3151090
addappid(3151090)
addappid(3151091, 1, "0f63b651a050b3035416d4c12e2bb87aa8c9c569001aa7ce02e3687b0f9c9ee4")
