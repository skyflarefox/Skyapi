-- Lua provided by SkyAPI 
-- Game: AppID 2589700
addappid(2589700)
addappid(2589701, 1, "ee353f61f153ea2efbe2d3de52d82e22d4fe58408151fe83770e7e25ae528dcf")
