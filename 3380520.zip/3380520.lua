-- Lua provided by SkyAPI 
-- Game: ToHeart
addappid(3380520)
addappid(3380521, 1, "76ab56f6f887226caa5e5f8453facba45a2f5df5475fd6788484b6dec37a3f76")
addappid(3452830, 0, "fd45547b3fdd8e458e1d728122680ed85bb38fb479684086aa6186554ce77dd8")
