-- Lua provided by SkyAPI 
-- Game: Hitler On The Moon
addappid(1603200)
addappid(1603201, 1, "e6e8efa6a0e0d4c2b50955e318117ddf66bd36bc5be7fdf3fab24caffe2b7e82")
