-- Lua provided by SkyAPI 
-- Game: iZolated Demo
addappid(2801130)
addappid(2801131, 1, "b4c731e78b952aeaa42061d88c4d89a41fae0bb301be4a1b9871d898967d53d6")
