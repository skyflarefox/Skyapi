-- Lua provided by SkyAPI 
-- Game: Black Roses
addappid(856560)
addappid(856561, 1, "31a078f0cdf5a19d07832961318f0edad4172ae45464faf28d267cd0b4ba84b1")
