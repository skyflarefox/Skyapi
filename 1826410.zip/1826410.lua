-- Lua provided by SkyAPI 
-- Game: Runnyk
addappid(1826410)
addappid(1826411, 1, "12266ba616c4b5ea797217390dccf5e382a296f66b4e114983145d71813c7a79")
