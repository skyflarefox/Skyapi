-- Lua provided by SkyAPI 
-- Game: Mafia Pigs
addappid(2106110)
addappid(2106111, 1, "4b3e193d64d9f2e476359d48916cda33c2b2e1ded43ee65f35fd6766168f59cc")
