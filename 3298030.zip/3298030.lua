-- Lua provided by SkyAPI 
-- Game: Feigning Innocence
addappid(3298030)
addappid(3298031, 1, "490dfbb24fad3f19b29a22a85a7b5f6d3bf0d39447cb5b87fa1c0f2763292712")
