-- Lua provided by SkyAPI 
-- Game: AppID 2706200
addappid(2706200)
addappid(2706201, 1, "6e520b514c477fa4a6225b202f22a3f4001369497b81bc5d17f367705a4c9379")
