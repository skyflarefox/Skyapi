-- Lua provided by SkyAPI 
-- Game: Cuisineer
addappid(1963570)
addappid(1963571, 1, "18dae24b737b1b3b430cd23b33b0ce4058f0b6ba568710aa5a64ecb1d3177b68")
