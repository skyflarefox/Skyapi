-- Lua provided by SkyAPI 
-- Game: TITAN SLAYER
addappid(528260)
addappid(528261, 1, "dac2d95f55dd6aa19bd8cf147a674e54e618de4a22996d134940124798ee3c9d")
