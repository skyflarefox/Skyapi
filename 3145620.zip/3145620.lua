-- Lua provided by SkyAPI 
-- Game: Without a Dawn
addappid(3145620)
addappid(3145621, 1, "1448408ac9293b312495604c58cdeb90e85acbdb6737bfd311a4b2d38f17b3fc")
