-- Lua provided by SkyAPI 
-- Game: Just Skill Shooter
addappid(2417160)
addappid(2417161, 1, "e9202c4949d165b54e3d4f9b8dd72faaea60de38dfd7056f157949253a6708c4")
