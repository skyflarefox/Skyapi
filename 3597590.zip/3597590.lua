-- Lua provided by SkyAPI 
-- Game: Dungeon Mori
addappid(3597590)
addappid(3597591, 1, "19a6bf4e7b45f2b0d8742b282e7da4d65fc05f447643894f333d978816d55130")
