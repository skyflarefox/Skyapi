-- Lua provided by SkyAPI 
-- Game: Wytchwood
addappid(729000)
addappid(729001, 1, "780040a91bd50436fc7fcf7bffbb8de3340117c553345c76a4c83040d5b07c58")
addappid(729002, 1, "64e7f31a4490a8f0885ee747209065d5cdd29591f2aae800c3164dcc221b9dbe")
