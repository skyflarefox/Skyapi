-- Lua provided by SkyAPI 
-- Game: Memories Off
addappid(675610)
addappid(675611, 1, "487a6c675ebe0eeba4549a838be23950d402337c9ad63b759a914727686442a0")
