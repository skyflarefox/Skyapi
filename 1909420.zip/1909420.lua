-- Lua provided by SkyAPI 
-- Game: Tinyfolks
addappid(1909420)
addappid(1909421, 1, "a8f7371a4af993ae2d78fef76fc4c1dcb26235e5f2713294f3688d4897dd077b")
