-- Lua provided by SkyAPI 
-- Game: American Theft 80s
addappid(1321450)
addappid(1321451, 1, "854fb36f9afc9e1fa4de85db4a52b06ce48742d30c4e8c9e0b44c6f36eb1d1c3")
