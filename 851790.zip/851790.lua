-- Lua provided by SkyAPI 
-- Game: AstronTycoon
addappid(851790)
addappid(851791, 1, "ff47050fb81c6169b02bce3499e7167adf4d5526571dd9dfb642680275439647")
