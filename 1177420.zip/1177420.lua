-- Lua provided by SkyAPI 
-- Game: AppID 1177420
addappid(1177420)
addappid(1177421, 1, "382bd3c5475ffe32e1472b4ab62537038ecea26dcfa0ddfae97de494ba2cf0e9")
addappid(1501400)
