-- Lua provided by SkyAPI 
-- Game: Hentai Puzzles: The Origin
addappid(2320990)
addappid(2320991, 1, "d7c349e7438472da433dc759e52b7c6493c2a730b15d5544e09ab619dcfa81b3")
