-- Lua provided by SkyAPI 
-- Game: Aery - Vikings
addappid(1975450)
addappid(1975451, 1, "7d63e9e438079bc5e7de8263ac7a0d2f0e0b4fed330d931644aded3e986b2bc0")
