-- Lua provided by SkyAPI 
-- Game: The Jewel of Monostructure
addappid(1644280)
addappid(1644281, 1, "23ac9112eb95555e56338e0558388c33e2c86b93b350186c17988c7d1dcc1b66")
