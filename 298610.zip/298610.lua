-- Lua provided by SkyAPI 
-- Game: Ylands
addappid(298610)
addappid(298611, 1, "6bc200dd240d5740da26c4c6229c364c925d970444f2648458251f0c56b013d2")
