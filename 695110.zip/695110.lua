-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(695110)
addappid(695111,0,"b836d18110aaca3874b4f36d911043a0da379424ed9bbedbb6cfc6ef6199f71a")
setManifestid(695111,"8774431977661269325")
addappid(695112)
addappid(695113)