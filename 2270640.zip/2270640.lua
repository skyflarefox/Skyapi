-- Lua provided by SkyAPI 
-- Game: Grim Tales: The Time Traveler Collector's Edition
addappid(2270640)
addappid(2270641, 1, "ae8cafb899561b9c701d52e126e428e133515cce5b102788d8c5c076e7fb9a09")
