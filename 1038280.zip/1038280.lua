-- Lua provided by SkyAPI 
-- Game: AppID 1038280
addappid(1038280)
addappid(1038281, 1, "e3ce130e9e741ac41c0815f1e14252dc0281759369ddbef8e19b2d14d628da75")
addappid(1038282, 1, "82671419ddfe78e1090292bbdb122681cb8d0b8b85d39b39dc64b3342dbb16fb")
addappid(1038283, 1, "0ad67f68534fdb050e53a361cebb2d09d6b806557fc8d87aaebedfb7f9b869fa")
