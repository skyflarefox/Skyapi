-- Lua provided by SkyAPI 
-- Game: Star Dream Journey
addappid(3373900)
addappid(3373901, 1, "ac70fba6e37dc8438473dd6c82f89ddd22e67b3136a53149b997d23b8d792e01")
