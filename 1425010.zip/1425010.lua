-- Lua provided by SkyAPI 
-- Game: ForkJump
addappid(1425010)
addappid(1425011, 1, "87fee11312d6afbcd30710c026be7125cc08ff8b5c917cf8e1a20817a64f3ec6")
