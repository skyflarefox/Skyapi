-- Lua provided by SkyAPI 
-- Game: AppID 238870
addappid(238870)
addappid(238871, 1, "fd41e2943f4e77eac4e02d403d7cc8b67bae4f37cb64298c9396277811115f2c")
