-- Lua provided by SkyAPI 
-- Game: Virus Hunter - Adult Only
addappid(3002000)
addappid(3002001, 1, "fc3f158863e8ea3ec6f94386873c6c2e433e28e9f455223e2d1ec9fb14fbac3d")
