-- Lua provided by SkyAPI 
-- Game: Erotic Rhythm
addappid(3226190)
addappid(3226191, 1, "b4abd2588a37fa811397cab88491976314116b06eeb449c56ff4a322d16cd355")
