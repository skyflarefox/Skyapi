-- Lua provided by SkyAPI 
-- Game: Evil Bank Manager
addappid(896160)
addappid(896161, 1, "869c6a05eacbbca7f9216094bc808e7466b583d8ada8ccb4f38931d34c574e75")
