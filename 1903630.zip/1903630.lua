-- Lua provided by SkyAPI 
-- Game: Evasion from Hell
addappid(1903630)
addappid(1903631, 1, "f26452d480207c382dc11d4e8ef75814fb6266aa67c1ada096917b2ce353e247")
