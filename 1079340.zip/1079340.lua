-- Lua provided by SkyAPI 
-- Game: AppID 1079340
addappid(1079340)
addappid(1079341, 1, "0d257c7c278aac683791db4bfc28c25f68a20742b938f5798155a78acfc1e8d1")
