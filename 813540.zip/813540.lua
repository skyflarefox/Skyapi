-- Lua provided by SkyAPI 
-- Game: AppID 813540
addappid(813540)
addappid(813541, 1, "5454c6bd101d0eb4a25fd41058579e33c48939ea0e2936d0ed38c0ca8679108f")
