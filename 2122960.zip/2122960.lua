-- Lua provided by SkyAPI 
-- Game: AppID 2122960
addappid(2122960)
addappid(2122961, 1, "deeaacadde214385f9de99030105e500fd1e460899b498c412e6757523e4ebe9")
