-- Lua provided by SkyAPI 
-- Game: Brutal Rifters
addappid(1898550)
addappid(1898551, 1, "59c3c8eb94ac192b13c3545750e517bce1a47f41fddc603daa25fd9defd4be0b")
