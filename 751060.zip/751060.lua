-- Lua provided by SkyAPI 
-- Game: AppID 751060
addappid(751060)
addappid(751061, 1, "17d8493448d430d74652fed214e70edcf4c2b03dae9585d7486076c99f9236dd")
