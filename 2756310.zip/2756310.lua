-- Lua provided by SkyAPI 
-- Game: AppID 2756310
addappid(2756310)
addappid(2756311, 1, "5255e5f69ca1003921e39d383c39fb042c3a4cb8fb312ff4914d51fbe6e6f9c1")
