-- Lua provided by SkyAPI 
-- Game: AppID 1032700
addappid(1032700)
addappid(1032701, 1, "bd0b43d9509d0dbea13aafe38305c27a2543d35b4ce9a1a081291272ce716d63")
addappid(1032702, 1, "94f90626d570e91abd1d2eb50aa670b48cb5e2e943e0521351134d6c534c0f85")
