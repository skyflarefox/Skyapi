-- Lua provided by SkyAPI 
-- Game: Ants Took My Eyeball
addappid(1627890)
addappid(1627891, 1, "b861249ab7ffd634b52c15ed3a318456e388e4c4f1a666163f43c96121315139")
