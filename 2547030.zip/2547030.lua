-- Lua provided by SkyAPI 
-- Game: Catch Up
addappid(2547030)
addappid(2547031, 1, "3e6643ff00f094f92426a4bfdb5d7522ff63b5ad1c2e1f22925311a8863b3e7a")
