-- Lua provided by SkyAPI 
-- Game: Hordes of Hunger
addappid(2157710)
addappid(2157711, 1, "aae1b54d52d987432e2554037a1c3b2176de82193e23ac6613b422c4bbc15775")
