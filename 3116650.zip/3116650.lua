-- Lua provided by SkyAPI 
-- Game: Serke Demo
addappid(3116650)
addappid(3116651, 1, "64ea31cc686b44044e48a90fcabd44be38d9a3534a2bac3239d192c70ea73551")
