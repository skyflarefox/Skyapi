-- Lua provided by SkyAPI 
-- Game: WarOS
addappid(3259910)
addappid(3259911, 1, "4ba96a3e4399090a237644bb5bda96619f36b3d21c29330d384269897a07a7f2")
