-- Lua provided by SkyAPI 
-- Game: AppID 1240060
addappid(1240060)
addappid(1240061, 1, "96beb02c693855c8614214eb84be8b4a6319ec724365c3a30185ec162b1cfe77")
