-- Lua provided by SkyAPI 
-- Game: Alien world Millionaire
addappid(1462640)
addappid(1462641, 1, "77c475d08f67a09d9da32cac186d938774a0a42117ccb348ca7acbb4157e103e")
addappid(1507920)
