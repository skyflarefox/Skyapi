-- Lua provided by SkyAPI 
-- Game: AppID 1154350
addappid(1154350)
addappid(1154351, 1, "2e8307fb0dcb9880865c5246ca11931475ce3e61e18b5821bfe2971e98875571")
