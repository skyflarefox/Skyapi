-- Lua provided by SkyAPI 
-- Game: AppID 851220
addappid(851220)
addappid(851221, 1, "83d24d91bf1babfd1448f9051d914f47fbc9374401ce3a5580f78cffbbcdc252")
