-- Lua provided by SkyAPI 
-- Game: Space Worthy
addappid(1599910)
addappid(1599911, 1, "1ced71d02275cd9218a7c03e51844a8bb77abab4f8975c529595f658e84aca9c")
