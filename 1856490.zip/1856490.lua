-- Lua provided by SkyAPI 
-- Game: Arhaekon
addappid(1856490)
addappid(1856491, 1, "96f6d747b8621873e9f4f0c02bde00c06341ff9e7a4d00e2b7a6699a32aaa729")
