-- Lua provided by SkyAPI 
-- Game: AppID 1138130
addappid(1138130)
addappid(1138131, 1, "cde0b96c9a0a5d5012a10fdc6beecea7fa21078f544f60965725607d2af0eb63")
