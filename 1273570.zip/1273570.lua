-- Lua provided by SkyAPI 
-- Game: AppID 1273570
addappid(1273570)
addappid(1273571, 1, "89b2ab379027ac38a0e81ec1e0695976e2c4b8e4351bbb244e39078cd81ffe51")
