-- Lua provided by SkyAPI 
-- Game: AppID 457820
addappid(457820)
addappid(457821, 1, "cb5404fe4e26a24a9d27df3c74613fb5bf4e8917db93d6c67b44659690d8c5f8")
