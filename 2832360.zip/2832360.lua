-- Lua provided by SkyAPI 
-- Game: Mirror world
addappid(2832360)
addappid(2832361, 1, "0b21baa7ee0c88d5f9244f11446adc9909e1236a00555f3d9f50921bb13cb686")
