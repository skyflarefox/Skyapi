-- Lua provided by SkyAPI 
-- Game: 梦蝶
addappid(2083600)
addappid(2083601, 1, "f03d993b8740a96cf50c1eb4dcf30b6957f2cb2717254791f104316dec4253ee")
