-- Lua provided by SkyAPI 
-- Game: To Be Headed Or Not To Be
addappid(1165380)
addappid(1165381, 1, "bfb4100a24ff441387ca6059bc9c6e2a90fe2707d885a1606880c2898031e0d7")
addappid(1165382, 1, "b80ed46dcf0ca9bb596b571d5ff0c0e4cdb7b2abc3413170971bd095fb58bd05")
