-- Lua provided by SkyAPI 
-- Game: Green Field Silver Tree 绿野白银树
addappid(1069520)
addappid(1069521, 1, "65978dd584ca0e5bb52fab22bf604ddd265e4291872e37875c8741ca55dd0ef4")
