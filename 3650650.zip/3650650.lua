-- Lua provided by SkyAPI 
-- Game: Fief Lord
addappid(3650650)
addappid(3650651, 1, "7779dc2b4bd7d1ebf1c7e7a8746b822a8c30a62dfb4c8f098add31880c232d0e")
