-- Lua provided by SkyAPI 
-- Game: Mushoku Tensei: Jobless Reincarnation Quest of Memories
addappid(2459420)
addappid(2459421, 1, "73a87df86ca8e806923eeb8c95e92c9bc1a3f0a75b82743b00019d499310553a")
