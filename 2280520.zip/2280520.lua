-- Lua provided by SkyAPI 
-- Game: AppID 2280520
addappid(2280520)
addappid(2280521, 1, "d167876e22b70d6addc56d5c661b8fc9aafb32b6247f5d51703dda07123c3af1")
