-- Lua provided by SkyAPI 
-- Game: Dawnbreaker - Aeon's Reach
addappid(1631790)
addappid(1631791, 1, "4c6c0074350cbead7c6f112975e49c10dad2ea8d8233a331d5a50673d3e2fc42")
addappid(1631810, 0, "483cf53a1852a7c939539181f96918a0b67972d1407ab7d497c1fc74a88be89f")
