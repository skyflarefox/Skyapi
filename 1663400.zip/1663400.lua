-- Lua provided by SkyAPI 
-- Game: Reigns Beyond
addappid(1663400)
addappid(1663401, 1, "af4ae82987db199bcc35730e7ede092951b900a77d61e4445667ee8ab4603ebe")
