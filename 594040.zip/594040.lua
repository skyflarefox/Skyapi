-- Lua provided by SkyAPI 
-- Game: SERIES MAKERS TYCOON
addappid(594040)
addappid(594041, 1, "464b7f803ff4e1535a597574552ce85c169bf944d373ba699be9081aa172d8ed")
