-- Lua provided by SkyAPI 
-- Game: Blue Effect VR
addappid(522020)
addappid(522021, 1, "4b13ff54eb92b9b8a8a38e49ece78a45e415bbe22daca278ed9b9c8cf7d83023")
