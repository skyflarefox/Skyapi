-- Lua provided by SkyAPI 
-- Game: AppID 795420
addappid(795420)
addappid(795421, 1, "506d9172e8c59e6c01a475b97da217e8cc8813bf019f637ef74afbebdbd004a5")
