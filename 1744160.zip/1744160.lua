-- Lua provided by SkyAPI 
-- Game: Rubber Bandits Soundtrack
addappid(1744160)
addappid(1744161, 1, "6459da581ee55eacd6423d16d5eb8904ed05627801464ae83e3f14289bb59324")
