-- Lua provided by SkyAPI 
-- Game: AppID 806240
addappid(806240)
addappid(806241, 1, "68e73aa2de22de37325f60e311147d83ff7a5ef1a44863ce5e3dda069626fd38")
