-- Lua provided by SkyAPI 
-- Game: Vyanka's Memories Demo
addappid(3236210)
addappid(3236211, 1, "fafe25c224a511dbeb91611c9717250ddd9eeb3f0e26c5b1537a8e2ba1e29227")
