-- Lua provided by SkyAPI 
-- Game: I Am The Prosecutor: No Evidence? No Problem!
addappid(1591470)
addappid(1591471, 1, "dd667843343b957f0fcbac93917fe5b8a03664c3165187e67402fbc5f563e521")
