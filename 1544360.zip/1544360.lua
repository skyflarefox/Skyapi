-- Lua provided by SkyAPI 
-- Game: LEGO® Builder's Journey
addappid(1544360)
addappid(1544361, 1, "f68c8ea838a50a342ba77fc9816a952a46f6a54a86d821c3adb661e4b9455868")
