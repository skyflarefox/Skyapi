-- Lua provided by SkyAPI 
-- Game: Mahjong Magic Journey
addappid(567140)
addappid(567141, 1, "505ed4f2c11f57f804d6d77b1e032cf5189ec296576d51f1f2efb3ea18f01dca")
