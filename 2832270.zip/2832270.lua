-- Lua provided by SkyAPI 
-- Game: College Gay Sex - Episode 1
addappid(2832270)
addappid(2832271, 1, "13a3bf56104049c54859ea8a1d964a7d2ed5f1db9ba043a26b379784481fdc3b")
