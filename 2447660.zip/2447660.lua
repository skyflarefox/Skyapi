-- Lua provided by SkyAPI 
-- Game: ASMR Food Experience Demo
addappid(2447660)
addappid(2447661, 1, "0f89baaf1daca1e8251b2313184f5fb8428e6584581a411b3597f5272491abd8")
