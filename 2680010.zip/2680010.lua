-- Lua provided by SkyAPI 
--  Game: The First Berserker: Khazan
addappid(2680010, 1, "1421e968f8fce076add3633dd0c538406bc9f3969e5c70613d12134644b51dcb") -- The First Berserker: Khazan
addappid(2680011, 1, "fe9a3ee6a263260b75cf97d27ffc4eeda8c9eebc8019bdc57c247a546f450077") -- Depot 2680011
setManifestid(2680011, "1428956032304461996", 56620645037)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3265140) -- The First Berserker Khazan Pre-Order Bonus
addtoken(3265140, "3403688366037590208")
addappid(3265150) -- The First Berserker Khazan Deluxe Bonus
addappid(3265160) -- The First Berserker Khazan Sound Track  Art Book


-- voices38fix
setManifestid(2680011, "6765731590953570327", 56614426437)
