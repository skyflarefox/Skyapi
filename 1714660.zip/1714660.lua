-- Lua provided by SkyAPI 
-- Game: Camellia Train
addappid(1714660)
addappid(1714661, 1, "61c36686d4636662e07ef707a76f2a2c6a0d6e87ec999aa8adc21e949f3ec6c5")
