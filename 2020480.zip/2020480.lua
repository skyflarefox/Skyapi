-- Lua provided by SkyAPI 
-- Game: 魔導聖戰:風色幻想
addappid(2020480)
addappid(2020481, 1, "28e158fc5d9d4119dd2af72d740ec6bbad8253798b30adbfda1c1f135f4cd4ba")
