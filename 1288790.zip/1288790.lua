-- Lua provided by SkyAPI 
-- Game: BeachHead
addappid(1288790)
addappid(1288791, 1, "c42f84ba58146d04de9e76c3450cf004b23e26b31a5504d08e5f3f73f2d2c500")
