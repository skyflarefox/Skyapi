-- Main AppID
addappid(3712080, 1, "c00531633bfaa0680f7d3d83c0b672887989ff7c879671823c4557f081365c1d")

-- Main Depots
addappid(3712082, 1, "08653891068ae60dfcf4e6d57470f5146491abfe6631ac3b2be16e565be8513b") -- (windows, 64-bit)
setManifestid(3712082, "5298406800795759601", 3728138404)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
