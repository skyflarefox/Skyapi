-- Lua provided by SkyAPI 
-- Game: Brickadia
addappid(2199420)
addappid(2199421, 1, "dd5d3a0060c907a988b6971044f22aaef92eb8ae98c17a52646265fc2f11b95f")
