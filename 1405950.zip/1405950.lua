-- Lua provided by SkyAPI 
-- Game: pear potion🍐
addappid(1405950)
addappid(1405951, 1, "89cd62c25484c1f7b63b16f09a6581e5a99f848321040bc7d9cd859cc9bf9be6")
