-- Lua provided by SkyAPI 
-- Game: Blackthorn Arena: Reforged Demo
addappid(3280460)
addappid(3280461, 1, "31e60bd339d8422c9dbaad6469156ad3bcc7b6cd7992effff786218abc78ffa4")
