-- Lua provided by SkyAPI 
-- Game: AnnaRedux Demo
addappid(3121520)
addappid(3121521, 1, "6df1f96025d0ed8a16a79801696e72f7cc7efe1b90393cf851a6d7cadef3e210")
