-- Lua provided by SkyAPI 
-- Game: DEAD GUN
addappid(1873800)
addappid(1873801, 1, "4c9bcec7f6e60f5b2255723e1cf665f614e63240f2d27201f06a061c798dff59")
