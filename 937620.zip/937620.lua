-- Lua provided by SkyAPI 
-- Game: Zack Y
addappid(937620)
addappid(937621, 1, "4e1dcdfc8b99aa3421ad96581ef9f9e7e4822cf5b899f8d54df5ddabbb20bb02")
addappid(937622, 1, "50bc60801c22c2c6af09936339dc068d8e159cd727e4677bb58d9d84f715c466")
