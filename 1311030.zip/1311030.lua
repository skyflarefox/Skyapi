-- Lua provided by SkyAPI 
-- Game: AppID 1311030
addappid(1311030)
addappid(1311031, 1, "bf78374a70831e9c5586f83954b089eb3eada112dac82c427c05cba204cfdfe5")
addappid(1311032, 1, "152f5a9c0d1fa7096619ad182b0cde6c198fcfc47a3da85253ccd71ff1b43970")
