-- Lua provided by SkyAPI 
-- Game: Date Banger
addappid(3086060)
addappid(3086061, 1, "bca70a2e14a6c005cd9f488d8798f97e0e0936f239448bd04c0312de03f03ad3")
