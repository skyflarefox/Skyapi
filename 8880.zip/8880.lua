-- Lua provided by SkyAPI 
-- Game: Freedom Force
addappid(8880)
addappid(8881, 1, "5a07296b85a2ec74b499f303a2139a146874afe470ffd646e00614e8d75fab15")
