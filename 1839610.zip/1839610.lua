-- Lua provided by SkyAPI 
-- Game: Hammer Kid
addappid(1839610)
addappid(1839611, 1, "c6b2995e22ab75b6f7147d9bfb41639d85bf05d8938aa4b0a63faa7de611b755")
