-- Lua provided by SkyAPI 
-- Game: Shut Up and Dance: Special Edition
addappid(2218930)
addappid(2218931, 1, "b8659d1981fcc1defcbd6dacb72132f10b95627b2ac3af2ae249537a90512e40")
addappid(3024790, 0, "81dc8d51fcdece129616d5f425923af2a199560a0773c98ef9abaf4dbfb04c7d")
