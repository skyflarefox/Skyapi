-- Lua provided by SkyAPI 
-- Game: AppID 644290
addappid(644290)
addappid(644291, 1, "5d60e1417a2ab3929a3933fbabd944ac2691f52f2de54e9d06ceb6c7fe2584f3")
