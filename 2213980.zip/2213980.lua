-- Lua provided by SkyAPI 
-- Game: Caverns of Mars: Recharged
addappid(2213980)
addappid(2213981, 1, "c642b7a7d8aefdaae078e9c541d9561c97e2d0c65470fde2244d45ac42623d98")
