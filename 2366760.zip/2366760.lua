-- Lua provided by SkyAPI 
-- Game: Hentai Kaiya
addappid(2366760)
addappid(2366761, 1, "b82db6e869b1a9e42527d73fcdb3355d0c03f4948dacd7716ab4bd685e65525b")
