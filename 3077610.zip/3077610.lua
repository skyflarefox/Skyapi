-- Lua provided by SkyAPI 
-- Game: AppID 3077610
addappid(3077610)
addappid(3077611, 1, "a51bfcdd0e97ce1e174d4360800d16de4f7a64965ad854ce69a920d5a1b5d043")
