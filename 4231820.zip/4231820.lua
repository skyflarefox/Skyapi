-- Lua provided by SkyAPI 
-- Game: Castlevania: Belmont's Curse
addappid(4231820)
addappid(4231821, 1, "b818e4c603d272e5c06a132f10ba31757a7f71a980a51625329d35ce620fb0e4") 
setManifestid(4231821, "7077766796164783764", 6284880115)
addappid(4708530) -- Castlevania: Belmont's Curse Alucard Style Costume
addappid(4708550) -- Castlevania: Belmont's Curse Bonus Contents Pack
-- Castlevania: Belmont's Curse Digital Sound & Art Gallery (AppID: 4740130)
addappid(4740130)
addappid(4740130, 1, "8c5d625861d3f720927a630a2e7477ad5175390ef32b75b000bb0fdba0a20af9")
setManifestid(4740130, "7188009525124262301", 1816424755)
-- Castlevania: Belmont's Curse Demo (AppID: 5000760)
addappid(5000760)
addappid(5000761, 1, "363453fc6bb6fa17583b4cdcb17772bd45f93f9264224009d35f673a986f0b1b")
setManifestid(5000761, "8920687738470069666", 1932632560)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") 
