-- Lua provided by SkyAPI 
-- Game: Damien Crawford's Golf Experience 2022
addappid(1964940)
addappid(1964941, 1, "4c6c7967f8cc4a9b7d61e352d013bb280cf527d9a7299fb5ae4daf06842d6f74")
