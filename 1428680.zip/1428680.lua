-- Lua provided by SkyAPI 
-- Game: Abiko The Miko 2
addappid(1428680)
addappid(1428681, 1, "5fedea41372e2840e1ac80ed2bcc6a4e71a5366760d8c89fbc01cde0b32e9e54")
