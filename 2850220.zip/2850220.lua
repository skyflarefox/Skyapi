-- Lua provided by SkyAPI 
-- Game: The Girl's Moving Castle
addappid(2850220)
addappid(2850221, 1, "9103ddc9b429f88c627351d06883403e74cb9baabd6e70fc95c187e57a136db6")
