-- Lua provided by SkyAPI 
-- Game: Myth
addappid(2430410)
addappid(2430411, 1, "4215060d547d5578347bf86842d60b286505c021ea35c37dd140d5a14543d422")
