-- Lua provided by SkyAPI 
-- Game: AppID 810510
addappid(810510)
addappid(810511, 1, "e8c056cc9de874d1c77bac139240e6650e3182ad8e35698e9787161f0561ac4c")
