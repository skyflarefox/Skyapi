-- Lua provided by SkyAPI 
-- Game: KóterGame
addappid(975700)
addappid(975701, 1, "b8e6a07d20f682cb1a1128d5bbab2bb03b52e2da1d978f940194603e1767b1c0")
