-- Lua provided by SkyAPI 
-- Game: Hentai PuZZles
addappid(844610)
addappid(844611, 1, "1aafc447e9d009b23f4092bcee2250e0d95a02343296a203ba7233433553fb05")
