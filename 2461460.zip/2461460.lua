-- Lua provided by SkyAPI 
-- Game: Womanizer
addappid(2461460)
addappid(2461461, 1, "62dc73ebf2f505a1ec7edc0d23331a4c64c687cfb0534f6023a2f0f8d3d97d4a")
