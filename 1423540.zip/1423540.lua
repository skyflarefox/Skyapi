-- Lua provided by SkyAPI 
-- Game: Air Gun Fighter
addappid(1423540)
addappid(1423541, 1, "14b192e9c563001c023e502717b70ecc59364bbdb4e2e6ecc62fb64506edc76b")
