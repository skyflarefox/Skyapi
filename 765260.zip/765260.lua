-- Lua provided by SkyAPI 
-- Game: AppID 765260
addappid(765260)
addappid(765261, 1, "70597db8616bb312411d4ae418ad1f188b7d49973451c8c212c55f7282e3a616")
