-- Lua provided by SkyAPI 
-- Game: Freeways
addappid(780210)
addappid(780211, 1, "fc6214507735818e62e64d94ab620d9391d6390a62b76e135b489483cdcd4ac0")
addappid(780212, 1, "d72ae46ccdd7fc790cff1f94142f98c782617e1803de262fbcb4d87ad6cf9a14")
