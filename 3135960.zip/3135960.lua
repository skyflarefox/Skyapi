-- Lua provided by SkyAPI 
-- Game: AppID 3135960
addappid(3135960)
addappid(3135961, 1, "9b11ebbf08538b05881c89c61a66b9a365b292237698c9438542fea9d58ffa79")
