-- Lua provided by SkyAPI 
-- Game: AppID 717060
addappid(717060)
addappid(717061, 1, "76e39a6b46e347cc5f3cc891f2bb8dc2aefc9c554e81ba65aea7b1ac44514531")
