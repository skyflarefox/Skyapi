-- Lua provided by SkyAPI 
-- Game: AppID 2378260
addappid(2378260)
addappid(2378261, 1, "f57247a8b3e957605c6068b12a40fe940f9c7e7ee9b437ac63c4292c23502236")
