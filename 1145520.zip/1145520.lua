-- Lua provided by SkyAPI 
-- Game: AppID 1145520
addappid(1145520)
addappid(1145521, 1, "9196ebaaeb7184e6586591ed7c35af98ad59d517ea67dc0b2e3c7ad6c25a7e66")
