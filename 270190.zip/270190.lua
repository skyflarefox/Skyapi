-- Lua provided by SkyAPI 
-- Game: 1HEART
addappid(270190)
addappid(270191, 1, "a42ffa55b833f5d6c0dccc1296a9b175afea3a0526fa3b364d20e9fb25dd5321")
addappid(270192, 1, "3fb37268010f193742a854de85558253f4668a1816af094a1b5c755953d77636")
addappid(270193, 1, "aaa50f013143ffd5cd10d55a0a872ecc46dcec66aff6f8ac27aa0000d5445bed")
addappid(270194, 1, "c6514e768371c23bce0db8ac10a17de46acfb31ad392aa34aaabcdacc0b35ee2")
addappid(270195, 1, "6ffa8053c613346ba6b9c465dc7b51f382ed83dbe664bfca0fbcfa68540ef4c3")
