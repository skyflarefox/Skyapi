-- Lua provided by SkyAPI 
-- Game: AppID 3216870
addappid(3216870)
addappid(3216871, 1, "dcd96faaa736f5586dab96c1d8e73071b333e34981391e78d62d374662989e78")
