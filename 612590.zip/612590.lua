-- Lua provided by SkyAPI 
-- Game: AppID 612590
addappid(612590)
addappid(612591, 1, "bfc160aa11cdd12a714be212e6d66c3b12083275e642e28c1a9e145e15e29cec")
