-- Lua provided by SkyAPI 
-- Game: AppID 779050
addappid(779050)
addappid(779051, 1, "b2a5aadfdf5ea2b1d6d717a57634ead59094ba29a33ea4384ab14369fad75d8e")
