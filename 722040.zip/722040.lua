-- Lua provided by SkyAPI 
-- Game: Cargo Breach
addappid(722040)
addappid(722041, 1, "f885c11d259c0b1d150a3d30ec3a102cd8c0b4f23a323389379f353c0ee69393")
