-- Lua provided by SkyAPI 
-- Game: AppID 844290
addappid(844290)
addappid(844291, 1, "4ac0ea640d5c1b0c7cd6b7a2d4940a4dfe394c20c2a2c78348bef1275ac056ae")
