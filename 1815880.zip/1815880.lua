-- Lua provided by SkyAPI 
-- Game: Maze Art: Blue
addappid(1815880)
addappid(1815881, 1, "40bddb0d0e73523b2897bf84fa4e395756e3fa29021170f3d781b37b31bb0150")
