-- Lua provided by SkyAPI 
-- Game: Territory: Farming and Warfare
addappid(1455910)
addappid(1455911, 1, "1853a5d82beb2ff63b27d9d52a4aadfc134d817c5d2e37aa12626bd7e75d4687")
