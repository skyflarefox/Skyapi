-- Lua provided by SkyAPI 
-- Game: AppID 529050
addappid(529050)
addappid(529051, 1, "a29769755a350fd4cfda399c36256912e9572d43f4d35152b662b24bc9f028be")
