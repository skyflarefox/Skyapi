-- Lua provided by SkyAPI 
-- Game: The Last Caretaker
addappid(1783560)
addappid(1783561, 1, "41cafd1c9367ffc962fab9d00cf8e6f16d2111b649a8161810a924b1cbf91fc2")
