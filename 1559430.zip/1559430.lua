-- Lua provided by SkyAPI 
-- Game: Purrfect Apawcalypse: Purrgatory Furever
addappid(1559430)
addappid(1559431, 1, "028eee584672c960e435bd2f7bfc012238417bb3fa55dbf9ff556c47691822b2")
