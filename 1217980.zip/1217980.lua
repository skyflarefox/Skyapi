-- Lua provided by SkyAPI 
-- Game: Vengeance Demo
addappid(1217980)
addappid(1217981, 1, "11a6a1b142f46b7bc3f8663b4f3e0d4029abf662d2647e5a653d9e1d59827c79")
