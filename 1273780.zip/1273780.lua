-- Lua provided by SkyAPI 
-- Game: Peekaboo Collection - 3 Tales of Horror
addappid(1273780)
addappid(1273781, 1, "c1b5df0d748289b6af85731706dad5d403c1a894f01d3f0e232b791bb857dd7e")
