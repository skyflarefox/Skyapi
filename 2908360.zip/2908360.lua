-- Lua provided by SkyAPI 
-- Game: The Night Guard
addappid(2908360)
addappid(2908361, 1, "81d25fdd31edc00c7259da2ba1e960b4bbea4842efa9978247e6cedb6012bc40")
