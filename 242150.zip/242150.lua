-- Lua provided by SkyAPI 
-- Game: AppID 242150
addappid(242150)
addappid(242151, 1, "59b803c2c1e947c18b86b86a0e309c75aacbbd00998c510311be587fa26192e9")
