-- Lua provided by SkyAPI 
-- Game: Super Hydorah
addappid(628800)
addappid(628801, 1, "a6efddcbc18ae462fa543e95d0b3683d3100728a610612ac4555dbcf61311f7f")
