-- Lua provided by SkyAPI 
-- Game: Grand Brix Shooter
addappid(1115580)
addappid(1115581, 1, "19fd2a66a0780527762a1a436392f626acf34eb0b7f230540798c13bb4e46b2c")
