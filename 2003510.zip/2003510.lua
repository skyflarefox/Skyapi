-- Lua provided by SkyAPI 
-- Game: 诸神陨落
addappid(2003510)
addappid(2003511, 1, "b9a3b93f584dbee0dcb8af1ab78be46f056ed82dae39b1c2eba65e40f8dc2eb1")
