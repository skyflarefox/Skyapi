-- Lua provided by SkyAPI 
-- Game: KIDNEY STONE Clicker
addappid(2410420)
addappid(2410421, 1, "7efa70ee6999ce7a96625d1aa5be9c32db94b703cc9c305739a0f73a33a9e51d")
