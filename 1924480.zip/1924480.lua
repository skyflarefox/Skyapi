-- Lua provided by SkyAPI 
-- Game: College Kings 2 - Episode 1
addappid(1924480)
addappid(1924481, 1, "ff635112056ca80dc0760a59372d872768946344dc5d10a5e63676f081245cf7")
