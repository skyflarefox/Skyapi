-- Lua provided by SkyAPI 
-- Game: House of Velez part 1
addappid(724010)
addappid(724011, 1, "f7b71d67ba09fe3e390099c5ece05ddf2014455b3ac4a654cd273f08ed04769f")
addappid(1061740, 0, "7938902e7395847956965e691e971a019fb0d23703b25d1c345de3324a5575b2")
