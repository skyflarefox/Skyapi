-- Lua provided by SkyAPI 
-- Game: AppID 740090
addappid(740090)
addappid(740091, 1, "95a3d36c235bc624289d5d3dd6ce6b78577f9a0eb0e2cce192d90a79c8d4d7c2")
