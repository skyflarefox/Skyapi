-- Lua provided by SkyAPI 
-- Game: AppID 3229740
addappid(3229740)
addappid(3229741, 1, "aa5d7802f86b6f9a40db828a1391dda7313ce526c11aabb5e67c71d5a9c8b58b")
