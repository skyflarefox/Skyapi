-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(739080)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(739081,0,"aa1b588da2ee859a1e530435c7a206d0796edeea69790d1b8fc20f907b51b852")
setManifestid(739081,"9192281143840947113")
addappid(739082,0,"848fdc92e4a4276b9d487573dd6a2dee840f8e79ad8e54917552d7272352d078")
setManifestid(739082,"4243471491152097947")
addappid(1426920,0,"edab9c31af39bd300990e325da324c74004919288d0237d674384a04aa7b3d87")
setManifestid(1426920,"7510440578275091803")
addappid(1426921,0,"f39853ffc4f96854986733d5cecb93c67d37c209c9bb818f371d042a2a4b309c")
setManifestid(1426921,"8651686801092409660")