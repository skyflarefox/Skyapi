-- Lua provided by SkyAPI 
-- Game: Musaic Box
addappid(29130)
addappid(29131, 1, "8ef218c2afc5d042815f691e000b130b09d9a3f4ca08f29787326ef68005d7c4")
addappid(29132, 1, "d749f0f9f130bb208beb09c4d4c7e5af090503d72b489b24d0d516969e265372")
