-- Lua provided by SkyAPI 
-- Game: Capcom Fighting Collection ［Original Soundtrack］
addappid(3785470)
addappid(3785471, 1, "11238f606538d55c530020ba2ec3172f4623abe27f28154a37d59d67cea06383")
