-- Lua provided by SkyAPI 
-- Game: Inferno Wizards
addappid(1269960)
addappid(1269961, 1, "a51b8870867abb135cc081cdd96d0bb9dd0c43c0b233c844ab4c2b49b4acb99c")
