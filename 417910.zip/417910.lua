-- Lua provided by SkyAPI 
-- Game: Street Warriors Online
addappid(417910)
addappid(417911, 1, "0f4ff81f9357052af87b0b9aff5838e00e46eef2839ea4b907652e89f8ebdae9")
