-- Lua provided by SkyAPI 
-- Game: Gladio and Glory
addappid(1527910)
addappid(1527911, 1, "8a14cecd2d0bd76b5afa63dbf6f7d24e8e18366aad1ffac5f6bf0d9a68d01433")
