-- Lua provided by SkyAPI 
-- Game: Fantasy Jigsaw Puzzle
addappid(1723490)
addappid(1723491, 1, "0ddd54ab424b05907c39a8033eb78573bbeac1587dba4b0634ca564f312ea105")
addappid(1725140, 0, "94f94a39b58db72d05c651ea3e4002ee801e9eba36511678a838a46e15f430f0")
