-- Lua provided by SkyAPI 
-- Game: The Defenders: The Second Wave
addappid(351400)
addappid(351401, 1, "922abae4e28ad4ba773ff75d507a8cbb030cb57eb8e99751ec486778bc93c819")
