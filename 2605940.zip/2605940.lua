-- Lua provided by SkyAPI 
-- Game: Clown Art
addappid(2605940)
addappid(2605941, 1, "16b0f34debb79cc07b12bcec72eaddb968dd6cc404d601fcc5d16d880d2cb503")
