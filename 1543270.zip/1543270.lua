-- Lua provided by SkyAPI 
-- Game: Clash of Irons
addappid(1543270)
addappid(1543271, 1, "949d27407ec8c378329e8270794e068ba1eb528ca0e1e508afe3bbba714472b1")
