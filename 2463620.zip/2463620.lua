-- Lua provided by SkyAPI 
-- Game: Connection: The Nightmare Within
addappid(2463620)
addappid(2463621, 1, "afc4266296f920dad2d1de47710439808ce55edf96d67ad439cf729604870f2b")
