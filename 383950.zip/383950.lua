-- Lua provided by SkyAPI 
-- Game: AppID 383950
addappid(383950)
addappid(383951, 1, "3205c3f8b5c43c8f2125c895fc6899117db158224a94d2f2a9d2b518b21157db")
