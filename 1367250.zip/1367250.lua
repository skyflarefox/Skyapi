-- Lua provided by SkyAPI 
-- Game: Arabel
addappid(1367250)
addappid(1367251, 1, "3d1eaf1fc9e4f24f289f7ae5e9cd4e47ad5bad38a1e08ce9fe2024c680837850")
