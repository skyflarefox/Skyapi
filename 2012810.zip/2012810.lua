-- Lua provided by SkyAPI 
-- Game: AppID 2012810
addappid(2012810)
addappid(2012811, 1, "2eb2a47e82471becada97919a3ee04a5012c2384eb42f26f2a9c78b275008e88")
