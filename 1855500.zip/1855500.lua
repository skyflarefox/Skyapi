-- Lua provided by SkyAPI 
-- Game: Neko Doll
addappid(1855500)
addappid(1855501, 1, "035a4243baa5b8547b19c3cdfa71d151abd06aebd89d79e37d0f617474891ffa")
addappid(1879350, 0, "206a0f58ecda78e43209856711392bee3187589acd31e7f79d42b6d07b475266")
