-- Lua provided by SkyAPI 
-- Game: Body swap story—Aunty Yui & Yuto
addappid(3676460)
addappid(3676461, 1, "f2310c1f3a44a4040ea03e95daf4715451c0599f969d1171af79cb3335df80c4")
