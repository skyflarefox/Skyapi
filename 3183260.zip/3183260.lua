-- Lua provided by SkyAPI 
-- Game: The Lighting Ages
addappid(3183260)
addappid(3183261, 1, "4d9393ad92b50612c3263dc1b9cc8137db6ee274d89f0c92dbbfc47c4531ca5d")
