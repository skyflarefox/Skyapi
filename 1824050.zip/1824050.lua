-- Lua provided by SkyAPI 
-- Game: Perfect Date Demo
addappid(1824050)
addappid(1824051, 1, "86cb3b72c82ad05aaf7592c0ee18f8b71538e40bf044e93f72c03f59f292dd2a")
