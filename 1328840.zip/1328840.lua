-- Lua provided by SkyAPI 
-- Game: Lost in Play
addappid(1328840)
addappid(1328841, 1, "ced632dc70dc2b26d0dd6394025b43c0b54e4e580ee72da795b4ce31ced31b7b")
