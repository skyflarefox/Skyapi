-- Lua provided by SkyAPI 
-- Game: AppID 821570
addappid(821570)
addappid(821571, 1, "2592339c730394108a4cc9848f10a0e4e598452223113dd87de19a845ad219cf")
