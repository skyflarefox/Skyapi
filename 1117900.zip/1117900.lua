-- Lua provided by SkyAPI 
-- Game: Fantasy Maid
addappid(1117900)
addappid(1117901, 1, "cd86205345148797df46cb0d47dbfa23182256e36a827b55f0605fec9262ded6")
