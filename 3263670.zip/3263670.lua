-- Lua provided by SkyAPI 
-- Game: AppID 3263670
addappid(3263670)
addappid(3263671, 1, "ac4c1ab513c7fb993286cbc35067ec8b8516dba3305ed1637037c2ed4e325440")
