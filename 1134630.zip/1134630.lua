-- Lua provided by SkyAPI 
-- Game: Pear Quest
addappid(1134630)
addappid(1134631, 1, "53a2e89c1f5834d6cd71f9afc0203661ca76eb969a06bb84973072ea79a0ce73")
addappid(1134632, 1, "680090600f01836ec5079c92ca6eacaac3435492ccf866e75e237eed8ce068df")
