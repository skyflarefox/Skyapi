-- Lua provided by SkyAPI 
-- Game: Book Bound
addappid(3320800)
addappid(3320801, 1, "88d442e0d7c02c21de98d19c386ca695e45ae1186970b729228cdb111eb8fb91")
