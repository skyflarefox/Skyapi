-- Lua provided by SkyAPI 
-- Game: Shovel Knight: Treasure Trove
addappid(250760)
addappid(250761, 1, "897c8575e16463ffb846336d3c94feddcdbc5a10976ca1c1e6c3b21134aabf00")
addappid(250763, 1, "b2f715c24260faeb8476ccb07fe99ca9ca105e4e5a868b2a1afe6217c2901e34")
addappid(250764, 1, "53390b208ea0022be6f8a23a23c47c6352fbe3de4198c7cf2e0ebb9bc370afb1")
