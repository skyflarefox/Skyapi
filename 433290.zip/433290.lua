-- Lua provided by SkyAPI 
-- Game: Nemesis of the Roman Empire
addappid(433290)
addappid(433291, 1, "70da914b59c3650e582fb5387537135201d04fbbacdbab78053396ab317cf308")
