-- Lua provided by SkyAPI 
-- Game: AppID 810720
addappid(810720)
addappid(810721, 1, "5df51aec23aeb3ea93cbe0ec5e9debb7d8c4b312c6b1c4417f9e3d2c927d458e")
