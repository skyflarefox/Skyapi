-- Lua provided by SkyAPI 
-- Game: AppID 468220
addappid(468220)
addappid(468221, 1, "09e951b3861bd590e28afe3152d279de8352abceffedcc01f77ad146dc9814ef")
addappid(468222, 1, "4d112841f4e7cbe2c587224054e6766302959eb6673842499e15707b01e331dc")
