-- Lua provided by SkyAPI 
-- Game: AppID 1106670
addappid(1106670)
addappid(1106671, 1, "1d21567747a3abdee4e8802322e8aa49e3bd2fd49befd39d7f8469777282a4b0")
