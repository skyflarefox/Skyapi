-- Lua provided by SkyAPI 
-- Game: The Ascent
addappid(979690)
addappid(979691, 1, "8f6782f423cd2844f6369c96e17e6778495eb7c864d0e32f401fae10868fe04b")
