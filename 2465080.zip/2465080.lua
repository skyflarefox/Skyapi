-- Lua provided by SkyAPI 
-- Game: Jelly & Toast
addappid(2465080)
addappid(2465081, 1, "98564e225dbfd4b59484a5691d603e4f7de5299ef82ae72a14a76764dc4ea0a6")
