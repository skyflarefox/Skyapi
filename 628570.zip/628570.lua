-- Lua provided by SkyAPI 
-- Game: AppID 628570
addappid(628570)
addappid(628571, 1, "2a3c4d14ea9b60ae5e57e00ae913561a3acf68e06b4ddf8b6305dc892e4459bd")
