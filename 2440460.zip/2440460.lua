-- Lua provided by SkyAPI 
-- Game: Botany Manor Demo
addappid(2440460)
addappid(2440461, 1, "a7e38ef1d7da5628287f37dd894f1e7526991028836b350ab7c3390090831734")
