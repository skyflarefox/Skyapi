-- Lua provided by SkyAPI 
-- Game: Quadrilateral Cowboy
addappid(240440)
addappid(240441, 1, "8e9073f759e075a9f3d712fe3fece67ee8830a7f6a634108b8b803ddb1ba5f81")
addappid(240442, 1, "a2c40d54c10fb411aa64161a9d346cde86f0c33d74c3ea7069b15b3a8ec19ecc")
addappid(240443, 1, "b90a2b2845e847f317b94f4a73cbbea5d495bbc5d7d21b16f4a5104bcc42fa6b")
addappid(460091, 1, "06ed29616c6f7406f969234ffeb7841b0d268944379064f6cb08c54c9c267e96")
addappid(489490)
