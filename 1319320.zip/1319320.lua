-- Lua provided by SkyAPI 
-- Game: Pangman
addappid(1319320)
addappid(1319321, 1, "6c75358a695d550df94e3f1d0b5fbe3f34b809d7a65f222fe9f91ec2fa1c79dc")
