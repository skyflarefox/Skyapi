-- Lua provided by SkyAPI 
-- Game: AppID 2130080
addappid(2130080)
addappid(2130081, 1, "95331793aa8fa780c9c9f51214571e4c31075b828aa3490607cc890fc0990780")
