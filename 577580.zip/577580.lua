-- Lua provided by SkyAPI 
-- Game: Gladiator: Sword of Vengeance
addappid(577580)
addappid(577581, 1, "f0dbf9ddfd7cab6bc7df92b88687377035ab74f262540bdfd7395bd400075285")
addappid(577582, 1, "25c2c1603184219829c9be61843bf0bb0ea602c53c29fca4aa5973a0c7052dae")
addappid(577583, 1, "93baecc8b9cf6e7188ca97f69fc3d846df4584bef610a17b5a1250cb7ba7df0c")
addappid(577584, 1, "fa05717d14e9b0492d79906df2bcbec800ccee5118db89f1d3e9654c2a4df573")
addappid(577585, 1, "e524ca16a82f1f9a4d13ae8f03a10924063313c9dba9e86efc4229d6859e2af9")
