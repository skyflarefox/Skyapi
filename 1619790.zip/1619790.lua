-- Lua provided by SkyAPI 
-- Game: Aggressor
addappid(1619790)
addappid(1619791, 1, "135ccb40c2f0391658c7fb4bb84ddf7052f96f34213fcb4471d99164ab58e4d5")
