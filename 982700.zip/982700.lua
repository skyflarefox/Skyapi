-- Lua provided by SkyAPI 
-- Game: AppID 982700
addappid(982700)
addappid(982701, 1, "3c9a8576a3fce9692b075e16f083ec2fb8a4caa9f32b87b4e9f3f766562ba927")
