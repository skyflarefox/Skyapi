-- Lua provided by SkyAPI 
-- Game: AppID 1135190
addappid(1135190)
addappid(1135191, 1, "0ac53098dc4d697096b8a1405cd909b0834b3c481663bae90c5a100986f52fd8")
addappid(1135192, 1, "3f04b1235d4d6cc438f83bf789ccc1fc8567647508dca8ac72fc209d8d5fd4b3")
