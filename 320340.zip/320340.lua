-- Lua provided by SkyAPI 
-- Game: Cosmonautica
addappid(320340)
addappid(320341, 1, "a50adb50a24af6a98d749b2e84311f1b91c930941d1f786313a0a369be621408")
addappid(383380)
