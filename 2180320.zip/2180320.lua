-- Lua provided by SkyAPI 
-- Game: AppID 2180320
addappid(2180320)
addappid(2180321, 1, "5fb0c3e8d2752c1da28fd7baf1dc33d84e2d24bd2548af8f7db0a3cdb7d38b2c")
