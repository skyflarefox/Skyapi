-- Lua provided by SkyAPI 
-- Game: Deliverace - Battle Racing
addappid(587540)
addappid(587541, 1, "1d4949e76d49b45f6d11336abe55136700d4befd08729d2d72097ee2360ae77e")
