-- Lua provided by SkyAPI 
-- Game: Quantum Conscience
addappid(375770)
addappid(375771, 1, "3565214ac2b3882bc05351ac74562f2e914b17dad118f43a4dbdc5d9c92720ab")
addappid(375773, 1, "e3bdc2ca0d84ae9b01d54bb56173b8cc2bcaa9a350f0bd14ced9e1d61161cf22")
addappid(454660)
