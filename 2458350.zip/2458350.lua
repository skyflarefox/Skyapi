-- Lua provided by SkyAPI 
-- Game: AppID 2458350
addappid(2458350)
addappid(2458351, 1, "59f95b73b2b621d7df07b1c07d1ffbab8590345d946936847a3568e34f1e62ca")
