-- Lua provided by SkyAPI 
-- Game: Best Served Cold Demo
addappid(3403420)
addappid(3403421, 1, "3273842aab6c90a1e848c9235c44d373c3cc79ec3de316e6a1b4d0049bd2c15d")
