-- Lua provided by SkyAPI 
-- Game: Rogue Lords
addappid(1069690)
addappid(1069691, 1, "b0b62c3ca8b5fdeae36530e7baa52e37ed21aee3ba813044d12e4458ff5c4240")
addappid(1556061)
