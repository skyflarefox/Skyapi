-- Lua provided by SkyAPI 
-- Game: SpellRogue
addappid(1990110)
addappid(1990111, 1, "f723416114aee3b707f497bfa2a6c20fc931920e4ad4d7d1526b8b9b8b3cdde6")
addappid(2900220)
