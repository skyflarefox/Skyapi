-- Lua provided by SkyAPI 
-- Game: AppID 1216540
addappid(1216540)
addappid(1216541, 1, "829e2b3490ffec9c8d94fc8aa3d9e3e1700a0b345aa57d10945dfd6608883093")
