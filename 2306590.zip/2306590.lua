-- Lua provided by SkyAPI 
-- Game: Apewar
addappid(2306590)
addappid(2306591, 1, "689156c990a38f4886226f6e26b34240022c4797df61376b9ae4d897a8deaf8f")
