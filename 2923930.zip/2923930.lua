-- Lua provided by SkyAPI 
-- Game: ArchWilio
addappid(2923930)
addappid(2923931, 1, "691a36f9d4dc6af81aed461105659397b73522dbc2a57058c713ee762173e054")
