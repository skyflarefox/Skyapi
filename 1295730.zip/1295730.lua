-- Lua provided by SkyAPI 
-- Game: AppID 1295730
addappid(1295730)
addappid(1295731, 1, "ecd4fa55c564ffb3bcbcd3626f26a654aa0ae0eb35fd4c1743afc08997881d54")
