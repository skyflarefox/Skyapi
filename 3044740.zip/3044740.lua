-- Lua provided by SkyAPI 
-- Game: V-LOVER!
addappid(3044740)
addappid(3044741, 1, "7fe1736dcd0fdddc507d4692a06a7610a694c6875eeeca84ae09158c2ddf2165")
