-- Lua provided by SkyAPI 
-- Game: VR Dungeon
addappid(553150)
addappid(553151, 1, "e9eb291a9772a47b8b4e2104d45681c2995e2837f7dfab26a1fdc0cd926f408e")
