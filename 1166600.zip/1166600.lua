-- Lua provided by SkyAPI 
-- Game: AppID 1166600
addappid(1166600)
addappid(1166601, 1, "57259e27371eeb1ab7f7499017876553a28ba1b5f5fcef67dcd7b30d4ea8559c")
