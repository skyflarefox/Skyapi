-- Lua provided by SkyAPI 
-- Game: AppID 1547350
addappid(1547350)
addappid(1547351, 1, "deceed4083aa72eba142429b28c46e6b5f9129d43ec142f6d4d9134a116c0477")
