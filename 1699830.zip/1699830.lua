-- Lua provided by SkyAPI 
-- Game: Obscura
addappid(1699830)
addappid(1699831, 1, "783d36059e3357079d9bc9a45fee5b804e643628b2476fbdef3149924f5969a1")
