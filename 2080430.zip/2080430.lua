-- Lua provided by SkyAPI 
-- Game: AppID 2080430
addappid(2080430)
addappid(2080431, 1, "2bfe56e1427cd3c4e3d34b53689602740a45de8f22cc17aca9ed0ef05613acaf")
