-- Lua provided by SkyAPI 
-- Game: EOS RAGNAROK
addappid(2639000)
addappid(2639001, 1, "678368ab21657b5e28817a5f7f5d4849020daf61d0b4509909b14791586d003a")
