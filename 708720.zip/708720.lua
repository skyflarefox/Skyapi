-- Lua provided by SkyAPI 
-- Game: AppID 708720
addappid(708720)
addappid(708721, 1, "7fcfb0b21b6298fd795c78b1a435b83b6652c844176358574ba1ad53c43cceed")
addappid(708722, 1, "e3fe8ecc2f7b1f655b6ffd1bff89e7e0061e158790bd09e29f09b61e64e4f62a")
