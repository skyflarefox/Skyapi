-- Lua provided by SkyAPI 
-- Game: Roman Triumph: Survival City Builder
addappid(1864880)
addappid(1864881, 1, "d28e6e4ef6e0ea3e64e4fcf6b30932ee4ccbbfbfee4b66d0c8c85f47f1979e74")
