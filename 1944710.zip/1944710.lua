-- Lua provided by SkyAPI 
-- Game: Goblin Gladiators
addappid(1944710)
addappid(1944711, 1, "b69d633cbaeef2c5ed0b770a4fb586f30dae83f1b6260112502932399248db32")
