-- Lua provided by SkyAPI 
-- Game: ia scatter city
addappid(2394500)
addappid(2394501, 1, "3cd53dbdcb509fb1343420b4f65c427739a45b3bcf5a8de25be43b2c173c8296")
