-- Lua provided by SkyAPI 
-- Game: Ties
addappid(1362390)
addappid(1362391, 1, "b3844554027f4f23e67d4971861868f62cc367b1bf522d20cc94d592f8061786")
