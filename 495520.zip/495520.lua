-- Lua provided by SkyAPI 
-- Game: Ping Pong League
addappid(495520)
addappid(495521, 1, "4b864544aa0104e689d699de6fe482e956fd8cf513b092be4ba5991945b23ac5")
