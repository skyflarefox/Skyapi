-- Lua provided by SkyAPI 
-- Game: LOOPERS
addappid(1811500)
addappid(1811501, 1, "0d09ba15e0345b7f8c05ca7f8f82e9960ac0cfc62cd74e3206b266a998d38291")
