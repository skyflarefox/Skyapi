-- Lua provided by SkyAPI 
-- Game: My Grandparents' Christmas Mystery
addappid(2253290)
addappid(2253291, 1, "419cfff78315401a9e9ce4ccc2df0326db2e682d46b85cf5159950213e9378f6")
