-- Lua provided by SkyAPI 
-- Game: OXENFREE II: Lost Signals
addappid(1574310)
addappid(1574311, 1, "4d03fdf2f21a74afd012ffb29d0b8cb9d1b96b0b46c8e392432bf1b15719b303")
