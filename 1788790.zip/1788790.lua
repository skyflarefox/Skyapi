-- Lua provided by SkyAPI 
-- Game: Hungry Wolf
addappid(1788790)
addappid(1788791, 1, "c9e541af803546839b7bd10561fa97b780891fe27f1a48b6236e669e7863c02c")
