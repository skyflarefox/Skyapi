-- Lua provided by SkyAPI 
-- Game: BEARS, VODKA, BALALAIKA! 🐻
addappid(1129220)
addappid(1129221, 1, "7e5f17cbf5959bf944f26fb928ba06e9dae31b96ee9f4a80ccf8f07f5691f26d")
