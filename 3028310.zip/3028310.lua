-- Lua provided by SkyAPI 
-- Game: Nordhold
addappid(3028310)
addappid(3028311, 1, "553fc1b6d6075185f02a8eba5821d274d56536e35f297a4733b779552e9b07e7")
addappid(3453990, 0, "6b5ee20b58e6268ecbdc302b151f75c70818bac9adeac5b600680781c73afed6")
