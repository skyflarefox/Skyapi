-- Lua provided by SkyAPI 
-- Game: Episicava - Vol. 1
addappid(618430)
addappid(618431, 1, "232c10c90df248c7d32dbd6d37709179ded336856f4654de8e40497d953dc182")
