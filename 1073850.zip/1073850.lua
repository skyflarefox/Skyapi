-- Lua provided by SkyAPI 
-- Game: AppID 1073850
addappid(1073850)
addappid(1073851, 1, "a1b86e1d52e89eaa65f2467a937a85bc6815fde6114a312548b71ddaca4ba166")
