-- Lua provided by SkyAPI 
-- Game: AppID 759300
addappid(759300)
addappid(759301, 1, "9d267af7d88841190156c1285cc24003d194154ffee032cf5f3a5450ea1d55d3")
