-- Lua provided by SkyAPI 
-- Game: AppID 816160
addappid(816160)
addappid(816161, 1, "649e3fa0551f9ef3eedfe6c2a113ef8a497b7a0248b7348eabade0c998cfae99")
