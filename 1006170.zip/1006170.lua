-- Lua provided by SkyAPI 
-- Game: AppID 1006170
addappid(1006170)
addappid(1006171, 1, "9006eabfc4f23d8ce394a734f83c27b21ff392129288a988ca89e21b360126a4")
