-- Lua provided by SkyAPI 
-- Game: Balls of Steel
addappid(2050260)
addappid(2050261, 1, "478f9b42793dffda5caef092960c4bf38eae95107e9a35bba1d8cac259ab3592")
