-- Lua provided by SkyAPI 
-- Game: AppID 962130
addappid(962130)
addappid(962131, 1, "809ed5f98fa8a3d2c3636c33504157cf05fc683e1810d35e554d7976573a4424")
