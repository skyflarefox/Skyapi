-- Lua provided by SkyAPI 
-- Game: Hazard Horizon
addappid(2155100)
addappid(2155101, 1, "afef43af5a2eb9943865be25883f3c56071357e548a1065051a3da13556ba4ec")
