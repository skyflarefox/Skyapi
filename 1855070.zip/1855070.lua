-- Lua provided by SkyAPI 
-- Game: Kukumushi Virtual Pet
addappid(1855070)
addappid(1855071, 1, "797624ec576c12acf5fc7443a490822808afca5919f4cc2cf3376c9b625c48bd")
