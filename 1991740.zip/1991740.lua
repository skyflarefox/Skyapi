-- Lua provided by SkyAPI 
-- Game: 天地归虚 Demo
addappid(1991740)
addappid(1991741, 1, "2df484fc3da41018ccc824fac1b53502818dfc83b4fd273809d0a4f95d9d789b")
