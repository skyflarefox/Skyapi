-- Lua provided by SkyAPI 
-- Game: Sea Chronicles
addappid(2347290)
addappid(2347291, 1, "d926dc43486859d7605687050b31807be4e9d32c47bd7f0de6f512c0b3856a3d")
