-- Lua provided by SkyAPI 
-- Game: FreeInfantry
addappid(2830720)
addappid(2830721, 1, "28ac5ab944a46135989b095fdfd950cb9b159902d4f4c0de04b3e97f771eeb1d")
