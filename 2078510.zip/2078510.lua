-- Lua provided by SkyAPI 
-- Game: VIVIDLOPE
addappid(2078510)
addappid(2078511, 1, "6b40f2cf36c34cbf1e3b359b60696ecd31ad0f7e42fc86a1dfce661d6b9d116a")
