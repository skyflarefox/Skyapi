-- Lua provided by SkyAPI 
-- Game: AppID 1119060
addappid(1119060)
addappid(1119061, 1, "6c08fb4afbe8e53e25bc2a91b06915bc3e0d2b50d5a67f89bb40fc322f38f691")
addappid(1119062, 1, "9b541b0b37ede95285f03b6c0997255ed928ffeb769695a0fd799dbad2165d14")
