-- Lua provided by SkyAPI 
-- Game: AppID 969230
addappid(969230)
addappid(969231, 1, "d170cfdb0b783d9f28dc6f1748659e9dc9d86becd3e382e305894acd23a48adf")
