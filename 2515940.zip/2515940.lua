-- Lua provided by SkyAPI 
-- Game: AppID 2515940
addappid(2515940)
addappid(2515941, 1, "798374fafbc52d116f2495cf14a6a2ed506d0f53a7b8e5edfceb4a9cbad306ce")
