-- Lua provided by SkyAPI 
-- Game: Trials of the Blood Dragon
addappid(435480)
addappid(435481, 1, "ddd7b6747b7a31651a8cb793ab966a8017f56627b1b9dfafabe568c3687a089e")
addappid(435482, 1, "36a2c6ef9ad6cb45f1725d4d9e5b23cce0c2ffcf02db57b1f965baf250fc6c8c")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
