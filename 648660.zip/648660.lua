-- Lua provided by SkyAPI 
-- Game: Boobs vs Zombies
addappid(648660)
addappid(648661, 1, "ad4754327228735416379eb37391887b1ca85371b77723151856fd2ecb8fec77")
addappid(1109330)
addappid(1109331)
addappid(1131020)
