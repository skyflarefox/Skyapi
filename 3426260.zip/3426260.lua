-- Lua provided by SkyAPI 
-- Game: Sex & Coffee ☕️🤎
addappid(3426260)
addappid(3426261, 1, "a4336cfb51f88aae12daa8587c72fcc64f2800a568b690bd18c84715da13dae3")
