-- Lua provided by SkyAPI 
-- Game: POOLS
addappid(2663530)
addappid(2663531, 1, "c4286bf964a6ae3ee6a54f2619f4222b3ec80a55a458d8281062b27d35afa8d0")
