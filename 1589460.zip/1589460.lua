-- Lua provided by SkyAPI 
-- Game: AppID 1589460
addappid(1589460)
addappid(1589461, 1, "99cae8409a83d8117d5d90a2fcdb604f0524beaff7559591fc36b11fb21b55e6")
