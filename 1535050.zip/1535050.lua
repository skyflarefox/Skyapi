-- Lua provided by SkyAPI 
-- Game: AppID 1535050
addappid(1535050)
addappid(1535051, 1, "568275e812731c233d44181e70f3281b688df44a6a744f5039377c49e17ff2c3")
