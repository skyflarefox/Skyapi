-- Lua provided by SkyAPI 
-- Game: Erenshor
addappid(2382520)
addappid(2382521, 1, "f8cbec933e93c31051dd48bc3b6a2b7fdba101b74110bd6e1447427f8ac30377")
