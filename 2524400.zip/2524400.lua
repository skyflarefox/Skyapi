-- Lua provided by SkyAPI 
-- Game: APlaceDominatedByHoles
addappid(2524400)
addappid(2524401, 1, "50873f6b4b3e9feba97626b89a0ec79030fa55fd9413e4a061350453ee8ff2ba")
