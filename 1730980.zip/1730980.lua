-- Lua provided by SkyAPI 
-- Game: 死前30天
addappid(1730980)
addappid(1730981, 1, "b4ca23f034f44742a54b64ccdfd2b8c5f5e22bf1394fa60cf1daadf7224a42a2")
