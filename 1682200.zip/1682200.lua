-- Lua provided by SkyAPI 
-- Game: BJORN
addappid(1682200)
addappid(1682201, 1, "6cad449e95fa7fa5320f64ddfda8abb9396c3dc48d862fc65ec3597f5d328e0b")
