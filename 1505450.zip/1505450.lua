-- Lua provided by SkyAPI 
-- Game: Oscar & Gems: Puzzle Quest
addappid(1505450)
addappid(1505451, 1, "b1a05d4c7bce1232fce04583fb0d0caee6bdd1ca3a8f94e004c4a7408ee21679")
