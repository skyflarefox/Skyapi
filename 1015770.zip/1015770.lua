-- Lua provided by SkyAPI 
-- Game: Tina: Swordswoman of the Scarlet Prison
addappid(1015770)
addappid(1015771, 1, "01b24ac801c132dcc08a87efa9ca31c645add6aef79cbf0ac46f3623cf438406")
addappid(1015772, 1, "1efb2221e35b4c37f54ba72e87d88aca91e0bc0632e9941d68583691c908d50f")
