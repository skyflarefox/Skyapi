-- Lua provided by SkyAPI 
-- Game: ULTIMAHJONG Demo
addappid(2865950)
addappid(2865951, 1, "16c171b66451d206c173b7e47db9181bb754b540205d8107c5be44131024ac79")
