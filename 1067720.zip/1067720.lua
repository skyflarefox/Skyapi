-- Lua provided by SkyAPI 
-- Game: AppID 1067720
addappid(1067720)
addappid(1067721, 1, "05a57f2322bf3b336a349a955fef23b74d525cf5ac5d1c107bbe0f0ac611abc1")
addappid(1113510, 0, "a9861ace051ebec1bc45a76d22b70492a95361632c8438f4b573dbed386349b7")
