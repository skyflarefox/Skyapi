-- Lua provided by SkyAPI 
-- Game: Din's Legacy
addappid(911550)
addappid(911551, 1, "1fd42db702ea9be6193920b003b712b24c1f96871b48b551f7bcfc9d26fc852c")
addappid(911552, 1, "8e7d203d1aef2a753107c69a85bd14540c122469fff4cb8242d03007d6f13475")
