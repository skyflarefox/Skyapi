-- Lua provided by SkyAPI 
-- Game: 鸭鸭大冒险 (Duck Duck Adventure)
addappid(3378260)
addappid(3378261, 1, "d94b8cd204d1fd3273d50180d432419f2c026e8acbd5d71d8e6f6db0c589722b")
