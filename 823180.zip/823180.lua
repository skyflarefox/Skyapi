-- Lua provided by SkyAPI 
-- Game: AppID 823180
addappid(823180)
addappid(823181, 1, "1506f4e4533e39567fb1fa0f8032339e762c9cc3304ca4512b7814819c9d6e6b")
