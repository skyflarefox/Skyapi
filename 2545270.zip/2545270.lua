-- Lua provided by SkyAPI 
-- Game: The Inquisitor - Demo
addappid(2545270)
addappid(2545271, 1, "2cb6345cd54c65851182bd1ca54bdb523453f3fd0d0eed3eaf74c842e3804aa4")
