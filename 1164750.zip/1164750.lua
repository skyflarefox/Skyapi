-- Lua provided by SkyAPI 
-- Game: Hospitality VR
addappid(1164750)
addappid(1164751, 1, "803c403006424d0b0da89e713229a3f0588adc9469f80a95465e2f8c2bb201fa")
