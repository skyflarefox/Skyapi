-- Lua provided by SkyAPI 
-- Game: AppID 616360
addappid(616360)
addappid(616361, 1, "044f574db707ba69531379f0aafe253324f47a7aa22b41fcec1b573807600896")
