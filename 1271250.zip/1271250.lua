-- Lua provided by SkyAPI 
-- Game: AppID 1271250
addappid(1271250)
addappid(1271251, 1, "7072cf8c9574e41edecb7987d8d9ff6f6c825e7e75f387afa15f04776cb05f2a")
