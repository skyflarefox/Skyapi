-- Lua provided by SkyAPI 
-- Game: Secret Agent Wizard Boy and the International Crime Syndicate Demo
addappid(3281870)
addappid(3281871, 1, "010583d2f8806a211a4273aace2fa9f8c19cfcc7cd643f1a57535ee49ca7c256")
