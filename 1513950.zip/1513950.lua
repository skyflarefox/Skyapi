-- Lua provided by SkyAPI 
-- Game: Motor Assailant: Betrayal
addappid(1513950)
addappid(1513951, 1, "d62635066e0e598dfee18f43799ab09e62b9eee5e2b1a31a3db7e73a038b3e86")
