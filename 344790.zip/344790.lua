-- Lua provided by SkyAPI 
-- Game: AppID 344790
addappid(344790)
addappid(344791, 1, "37059a54569aab68ae5e26ce2fe1f29bf9d1531a8ec7321c6d4cf8eb89c662b7")
addappid(344792, 1, "1a6457a2d9d958698b15d20f729945fcc2065e15d7b39139490842ab6b97408f")
