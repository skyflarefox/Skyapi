-- Lua provided by SkyAPI 
-- Game: AppID 973600
addappid(973600)
addappid(973601, 1, "5d8908ddaafda2bd13b89efa3ea35edd9c36050b2579610aac863396c37c273f")
