-- Lua provided by SkyAPI 
-- Game: Shin Megami Tensei III Nocturne HD Remaster - Merciful Difficulty
addappid(1497870)
addappid(1497871, 1, "c69557689949c168190c43b8cb47a31b64e8dc8e357a3d35d5b52fdbfbee9a87")
