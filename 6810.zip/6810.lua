-- Lua provided by SkyAPI 
-- Game: Commandos: Beyond the Call of Duty
addappid(6810)
addappid(6811, 1, "75fee0e03b4c5544ce244e82a83257d22fa3725cfeddba91ad06d39190ef7945")
addappid(6812, 1, "57e06e06e744e266311546b4633db684b81b3bf0c81a72e9ca5dc17b5975e858")
