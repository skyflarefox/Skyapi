-- Lua provided by SkyAPI 
-- Game: Debut Project: Cooking Café
addappid(3155560)
addappid(3155561, 1, "d219c05375237beada93b230be8980b34f97319bf031ff4d982a03ca65850ea6")
