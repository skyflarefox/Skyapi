-- Lua provided by SkyAPI 
-- Game: Hotel Transylvania: Scary-Tale Adventures
addappid(1433500)
addappid(1433501, 1, "46c4e6f29ea70beb9dea54357b402f84387cc5f04489286c06209d36af5529e1")
