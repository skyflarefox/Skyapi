-- Lua provided by SkyAPI 
-- Game: AppID 1286370
addappid(1286370)
addappid(1286371, 1, "f0ad563475d0a167b984304c86438eae566c83f3cf9324993880154c1318c034")
