-- Lua provided by SkyAPI 
-- Game: AppID 2533950
addappid(2533950)
addappid(2533951, 1, "215aa4dcacdaebbd68882f266a318bb0db5d7e2f7526d6d501a81cf615989cbc")
addappid(2551000, 0, "773cdcd47a7d93882afcdbeab496652e2feed12106f65caccd6e676844d2c660")
