-- Lua provided by SkyAPI 
-- Game: AppID 611120
addappid(611120)
addappid(611121, 1, "cb59b7a222ea4f505ee150cde3dbcdd6dac68440b6fdf8f917582417eff0692c")
