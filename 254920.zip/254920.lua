-- Lua provided by SkyAPI 
-- Game: Lords of the Realm
addappid(254920)
addappid(254921, 1, "0afd4a46b595f8f7c4d139decb2c8c560096f503b59c707fad519f2a8cb14e3d")
