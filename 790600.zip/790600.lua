-- Lua provided by SkyAPI 
-- Game: AppID 790600
addappid(790600)
addappid(790601, 1, "11010f6ca08ac27991201a37d9e9d33673c15e98d51c0eb8ac9bf1e523d092d3")
addappid(790602, 1, "017c171c6b14bb0920d5f32739dc0be3d160437b9ab15c25bb0335611e4cc207")
