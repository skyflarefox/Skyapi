-- Lua provided by SkyAPI 
-- Game: AppID 3161800
addappid(3161800)
addappid(3161801, 1, "ef98232c09ec100410a1fba248efea652a1e268b93eabbc2892db8b339c48ab8")
