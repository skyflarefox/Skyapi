-- Lua provided by SkyAPI 
-- Game: AppID 1356040
addappid(1356040)
addappid(1356041, 1, "0ff1bd3b10491e4407b717174d3a2770d832b60ac8413dced2e2cbd1393e316b")
