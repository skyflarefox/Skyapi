-- Lua provided by SkyAPI 
-- Game: Gravity Field
addappid(1425250)
addappid(1425251, 1, "71fc6a888384d5a49544ba32c1e6788fd33c4a9a0c3c770d4cc7947104e7d3be")
