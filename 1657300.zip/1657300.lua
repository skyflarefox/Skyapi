-- Lua provided by SkyAPI 
-- Game: AppID 1657300
addappid(1657300)
addappid(1657301, 1, "47962c5cf2f6d54b62957e9b7c8a9a3795abdc773b15a0d185d7b09082f5fdbb")
