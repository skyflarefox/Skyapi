-- Lua provided by SkyAPI 
-- Game: AppID 523160
addappid(523160)
addappid(523161, 1, "8e1ece544428bb9afee4c467c1d01e2c60aa179f0dd50af065f39ba5291e7f53")
