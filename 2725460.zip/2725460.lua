-- Lua provided by SkyAPI 
-- Game: Cover Yourself in Blood
addappid(2725460)
addappid(2725461, 1, "d0ee3e83ab975d2778116b4797351b3721ab383b326a1b781d3e9c922926f5fe")
