-- Lua provided by SkyAPI 
-- Game: Song of the Deep
addappid(460700)
addappid(460701, 1, "0ebe367bb799c062584d7b2e80ae8b8fd5901aa4263bbdb451e309d904b9120f")
addappid(475210, 0, "2f6c4e041926c70db8474f38c21c4d844e6e146ab33e312c3cd4010fb30565a3")
