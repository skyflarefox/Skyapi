-- Lua provided by SkyAPI 
-- Game: Blood Bowl 3
addappid(1016950)
addappid(1016951, 1, "f93ae1131d7bd8a01d305f157b3fa0efe69afc3d78535e3b5490d26012015350")
addappid(2197250)
addappid(2197251)
addappid(2197252)
addappid(2197253)
addappid(2197254)
addappid(2245810)
