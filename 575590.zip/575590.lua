-- Lua provided by SkyAPI 
-- Game: AppID 575590
addappid(575590)
addappid(575591, 1, "22f082cf8f82de0a66c1ddaaccfa770b67e8857803d4731a3399363a92cbb23d")
