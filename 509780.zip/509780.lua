-- Lua provided by SkyAPI 
-- Game: AppID 509780
addappid(509780)
addappid(509781, 1, "951c19cbbc08f7f19c2a0850d2165d57815395c3256e35367f1c84134929c335")
