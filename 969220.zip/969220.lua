-- Lua provided by SkyAPI 
-- Game: Up in the Air
addappid(969220)
addappid(969221, 1, "484b54e85a5a93a753baa714588a7a6d53636b163f48c58fdfd96d03f347d174")
