-- Lua provided by SkyAPI 
-- Game: The Quinfall
addappid(2294660)
addappid(2294661, 1, "39cbd76774d7cd7e3a7638344169ac77056c44361a66db94cb7e59fac501c576")
