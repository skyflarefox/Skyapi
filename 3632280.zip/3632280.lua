-- Lua provided by SkyAPI 
-- Game: AppID 3632280
addappid(3632280)
addappid(3632281, 1, "9486b855d432fe76937df553f2cfbf02de9fb621390d22c649454588bee295be")
