-- Lua provided by SkyAPI 
-- Game: Terrorist Elimination
addappid(740390)
addappid(740391, 1, "8312f5cb81f767fb14005da9986a9d635ee6be7ce6217fdbff0b3a5529b56174")
