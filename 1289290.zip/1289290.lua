-- Lua provided by SkyAPI 
-- Game: AppID 1289290
addappid(1289290)
addappid(1289291, 1, "1ca2159e10c2a75e05ac8bc9b7ed1c51c307fd6deb74c4280d86298a38de8fe5")
