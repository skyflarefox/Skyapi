-- Lua provided by SkyAPI 
-- Game: Pirates Girls
addappid(1337270)
addappid(1337271, 1, "7ffc1b3a7a25a06510bb049b149249a76441dcc1189cfb705f15614d96bb35bd")
