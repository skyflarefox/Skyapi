-- Lua provided by SkyAPI 
-- Game: Vision Soft Reset
addappid(1005450)
addappid(1005451, 1, "2c866e5a9e16716fd957375ad45325a9e60605b68d61b76060e42ebbb625f340")
