-- Lua provided by SkyAPI 
-- Game: Crazy Machines 1.5
addappid(18460)
addappid(18461, 1, "1a470d31335300d16a06f050b36abd6b1603cf27ec226ac568e63c44b0a28c34")
