-- Lua provided by SkyAPI 
-- Game: KUR
addappid(1243520)
addappid(1243521, 1, "0d41e285f40871e5453f84917d72701b19f094d0bfb8e7e457c89a6751cdad73")
