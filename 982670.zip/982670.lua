-- Lua provided by SkyAPI 
-- Game: Clan N
addappid(982670)
addappid(982671, 1, "cfe594a62229b6066444e007173117bfd0c70821ac98d5922accca64c1988ee9")
