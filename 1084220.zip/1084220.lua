-- Lua provided by SkyAPI 
-- Game: Cavity Busters
addappid(1084220)
addappid(1084221, 1, "7340f96ac043fcae777cf34e24caadcfafee665113c35449b877adef8b2264fe")
