-- Lua provided by SkyAPI 
-- Game: Cricket: Jae's Really Peculiar Game
addappid(1381520)
addappid(1381521, 1, "b6f3379afc94e4d142123a0e25fd076dd675762ca0bd34299f96cf74204820b1")
