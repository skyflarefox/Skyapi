-- Lua provided by SkyAPI 
-- Game: MechWarrior Online™ Legends
addappid(342200)
addappid(342201, 1, "12285849aaf10836b6960bfd4e55f616991f2e64391b136463436acbec3f23db")
