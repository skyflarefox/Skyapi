-- Lua provided by SkyAPI 
-- Game: AppID 929140
addappid(929140)
addappid(929141, 1, "03382c049f763e2ff86193c8dca468b0f5a380661737f9a2ed65fdbb923e7ee2")
addappid(929142, 1, "a3114f7cd12e41649f7850f1be5b13a4cae96a9fe8c23f7d893077f0622f91c6")
