-- Lua provided by SkyAPI 
-- Game: Breathedge
addappid(738520)
addappid(738521, 1, "4c18853b78cacf0c4cba33d0c37b2d60aa1833ad25fb7604f9b517607d994e63")
