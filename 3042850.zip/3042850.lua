-- Lua provided by SkyAPI 
-- Game: Holy Light
addappid(3042850)
addappid(3042851, 1, "b56ac69c5f99c421e5731377013412370c160c138fd8b6484b46db659d40b462")
