-- Lua provided by SkyAPI 
-- Game: AppID 383530
addappid(383530)
addappid(383531, 1, "de0686630195a65a01731463188975697533de4c5c0331c9196ddf7bae77253b")
