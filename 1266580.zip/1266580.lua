-- Lua provided by SkyAPI 
-- Game: AppID 1266580
addappid(1266580)
addappid(1266581, 1, "9cfcdb94c29475db9d2b7fb47d07ca3e12cc78146f85e2a03088de018b0c9c3c")
