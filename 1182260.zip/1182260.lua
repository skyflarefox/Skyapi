-- Lua provided by SkyAPI 
-- Game: Kukui 2
addappid(1182260)
addappid(1182261, 1, "7896ff17c2a799bb724dcb998ebac8bfd7cec184166ff63316f59246109059c2")
