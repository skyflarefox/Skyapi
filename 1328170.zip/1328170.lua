-- Lua provided by SkyAPI 
-- Game: AppID 1328170
addappid(1328170)
addappid(1328171, 1, "0e00400899a90654d87d7e0c7bb682372347b7e5fb13c25329af9d9e45ddf610")
