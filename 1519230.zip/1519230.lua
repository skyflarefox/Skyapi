-- Lua provided by SkyAPI 
-- Game: AppID 1519230
addappid(1519230)
addappid(1519231, 1, "c7a03b7920033793b399a8feac025cbfea7e4a0da89c2f632db1ba098e58c813")
