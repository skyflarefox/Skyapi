-- Lua provided by SkyAPI 
-- Game: Zoelie - SCAD Games Studio
addappid(1592240)
addappid(1592241, 1, "a301738c65aea05aed06a2477cf68910d81728217c15f2bd8aaa8fbef5da136d")
