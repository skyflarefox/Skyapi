-- Lua provided by SkyAPI 
-- Game: AppID 567020
addappid(567020)
addappid(567021, 1, "71f6a671dc32d4d99b9e4d4f793d697631937b921a404d9b2297241c31e29aa3")
addappid(567022, 1, "537a948b99593d9dcf37d90b45644f7fce18cc1e03170e865755ec61e2afd0fb")
