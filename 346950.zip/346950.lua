-- Lua provided by SkyAPI 
-- Game: AppID 346950
addappid(346950)
addappid(346951, 1, "ddff6abf16e26a96310b38a215bda10b3dc9c606e7e612c4bb91675cb30e6595")
