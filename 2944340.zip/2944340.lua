-- Lua provided by SkyAPI 
-- Game: Unless
addappid(2944340)
addappid(2944341, 1, "95517c6cff2f7e8dc552838d3d8c2762c8230dea88a121826ee9025531e6cbe4")
