-- Lua provided by SkyAPI 
-- Game: Boom! Boom!
addappid(1038850)
addappid(1038851, 1, "3fdd83904911eb58aad19859a739885db6211bf5db9faafd0c62835fe7e28387")
