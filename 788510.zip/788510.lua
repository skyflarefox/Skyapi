-- Lua provided by SkyAPI 
-- Game: AppID 788510
addappid(788510)
addappid(788511, 1, "c19509e724c03aeca61360bf9d7f65c3d893e2d16357560f1b2096399acb057a")
