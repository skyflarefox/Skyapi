-- Lua provided by SkyAPI 
-- Game: AppID 1549890
addappid(1549890)
addappid(1549891, 1, "a6830e2dc13e18b410fc25eb1b32727a0fe0126230435279553f7acb44f70e64")
