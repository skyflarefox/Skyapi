-- Lua provided by SkyAPI 
-- Game: Rogue Waters
addappid(1691190)
addappid(1691191, 1, "76f9add990b1becf8fea2ff19733ccb4bfda9e41437de3163903cc515d8d109d")
