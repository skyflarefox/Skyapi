-- Lua provided by SkyAPI 
-- Game: AGNI
addappid(1822340)
addappid(1822341, 1, "aab5a9033a7f4c7872a457b6a0455e6dba1aafd8b73f01735f9b65072cde438a")
