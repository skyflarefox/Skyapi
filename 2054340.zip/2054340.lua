-- Lua provided by SkyAPI 
-- Game: Witch Story
addappid(2054340)
addappid(2054341, 1, "a73d21f7a625cc3e316f4af9ec8b4b4bc060b7ea2f35990d59e7915693b59894")
addappid(2119970)
