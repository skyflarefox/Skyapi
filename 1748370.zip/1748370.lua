-- Lua provided by SkyAPI 
-- Game: The Hunt
addappid(1748370)
addappid(1748371, 1, "dbb051ee79d544613d7df7a2f3c3d9cbb7ad89e1cfd224757e3ce6fce6708b7b")
