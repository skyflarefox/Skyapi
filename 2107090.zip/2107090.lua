-- Lua provided by SkyAPI 
-- Game: AppID 2107090
addappid(2107090)
addappid(2107091, 1, "f24026503c394aea48563a537be4295a30d6192cc326a3588740fae8f7a2194e")
