-- Lua provided by SkyAPI 
-- Game: Doomsday Cleaner Demo
addappid(3158530)
addappid(3158531, 1, "768b334d55f7e8c5a68e9a5fa01317f5ef887082f3d7d490011a44f6756de6d9")
