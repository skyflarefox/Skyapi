-- Lua provided by SkyAPI 
-- Game: Box To The Beat VR Demo
addappid(2413420)
addappid(2413421, 1, "c8a5560444b569feb3dc63f75c5f843ebe0738eef11246c33dd09dd695a605b2")
