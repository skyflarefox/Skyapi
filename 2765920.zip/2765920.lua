-- Lua provided by SkyAPI 
-- Game: AppID 2765920
addappid(2765920)
addappid(2765921, 1, "4283706606571dc484fdd71f1cda4ffa9da0c1c83656993392cb5498da19f934")
