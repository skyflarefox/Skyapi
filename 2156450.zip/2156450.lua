-- Lua provided by SkyAPI 
-- Game: Sweety Kitty
addappid(2156450)
addappid(2156451, 1, "24d570b30d62d77f3338452bc5bd12f31ebc3ce8f5bf055bc83daa952da4053c")
