-- Lua provided by SkyAPI 
-- Game: AppID 510910
addappid(510910)
addappid(510911, 1, "85abd30b1032f15fc27aa787723edb199b345531e72a944d520616ba57298197")
