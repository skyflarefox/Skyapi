-- Lua provided by SkyAPI 
-- Game: Tap Adventure: Time Travel
addappid(596650)
addappid(596651, 1, "4d335011609e87b2557801f4a34ab09759bb7e0a8ec0a190a834d313803cdf07")
addappid(596652, 1, "b6106e8c2eaa56fd9c363fc566bd87be058d3e0e4b8ae3e0371f32d4dbbb4bb7")
addappid(596653, 1, "7fa88d44d3f966dd6b74f012cb4917b3d005009d261711b2dfc93e19f5735136")
