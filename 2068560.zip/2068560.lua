-- Lua provided by SkyAPI 
-- Game: Cooper's Cleanup
addappid(2068560)
addappid(2068561, 1, "62de2d3f9d4a7441f14c19e221358be6bd523c427b96a728b994c5f525aae7be")
