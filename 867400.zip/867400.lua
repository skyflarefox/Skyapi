-- Lua provided by SkyAPI 
-- Game: Out of Reach: Treasure Royale
addappid(867400)
addappid(867401, 1, "4620a9462076fa9c549aae17cf34e25656e9f047754d39ce482665feeeef902a")
