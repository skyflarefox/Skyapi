-- Lua provided by SkyAPI 
-- Game: 禁忌taboo
addappid(1989740)
addappid(1989741, 1, "a3ce78c9286b2cf581e9d4601e605e2a1e49aed0d58b805087af1d4cf601f4f0")
