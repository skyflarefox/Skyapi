-- Lua provided by SkyAPI 
-- Game: SuperPantsu Tentikun
addappid(2345770)
addappid(2345771, 1, "c767b294525f2fe481b34278f8d88e684e7e87b9539fc80ab9091d31a3af7960")
