-- Lua provided by SkyAPI 
-- Game: Ultimate Epic Battle Simulator 2
addappid(1468720)
addappid(1468721, 1, "c0d10ec1395dc0ba8f71593641ac527d1770463e9788a1f0e4a2b27f14dda7f6")
