-- Lua provided by SkyAPI 
-- Game: AppID 1184420
addappid(1184420)
addappid(1184421, 1, "0396f7922a7fe03e54969b9235df8021636e253dbd09ae39e1ef7abc8b713dfe")
addappid(1184422, 1, "9536774a3b2df481795c8b7f063cead8831d50ebbf2c2c5a6dc101534e49e814")
