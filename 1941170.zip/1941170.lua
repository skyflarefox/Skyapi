-- Lua provided by SkyAPI 
-- Game: The Jelly Adventure
addappid(1941170)
addappid(1941171, 1, "bccc79c8e79ca43debc28bed15aea30b57bed6f6509cee5fe79667d4dc1674cc")
