-- Lua provided by SkyAPI 
-- Game: Sunset Humanity
addappid(2841470)
addappid(2841471, 1, "d414aa62f85541109ad12bdf9df7253b84952d6b16c7c90a452568cda62f448b")
