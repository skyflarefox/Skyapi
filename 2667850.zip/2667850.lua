-- Lua provided by SkyAPI 
-- Game: Scary School Simulator 2
addappid(2667850)
addappid(2667851, 1, "e395580599a232556ced73e40d09be27f042592c10a2a3a9c498f4b1105a1a77")
