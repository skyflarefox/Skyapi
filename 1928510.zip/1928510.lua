-- Lua provided by SkyAPI 
-- Game: 未知记录
addappid(1928510)
addappid(1928511, 1, "da27e7005561e9432b323aa2f176ef312198e067788ac9920a026248706e07f3")
