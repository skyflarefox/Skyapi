-- Lua provided by SkyAPI 
-- Game: Epic Astro Story
addappid(2072140)
addappid(2072141, 1, "0bb9e90908589553133171a680876c7c807d778658ae7def234ea3737a6b77d5")
