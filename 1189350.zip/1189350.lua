-- Lua provided by SkyAPI 
-- Game: Town Defence
addappid(1189350)
addappid(1189351, 1, "785dfb262de8d700f9fcc02668af9c5fa5a345b4882b0271113761964ac75cf9")
