-- Lua provided by SkyAPI 
-- Game: Battles of Norghan
addappid(531110)
addappid(531111, 1, "4ad5e00f212cebd22306d152b1639682aa06c4b13fcd8f7f358c5b9f845b6224")
addappid(534830, 0, "253787c01afbb05242edf28bbdc9b4635c33fa544b3d06b72277919ad193b2df")
