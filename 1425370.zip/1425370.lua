-- Lua provided by SkyAPI 
-- Game: Razenroth 2
addappid(1425370)
addappid(1425371, 1, "63028b3cf5153ecee8d28959dec0af2f480b5c5f93ef1976ec44e9372d2207fc")
