-- Lua provided by SkyAPI 
-- Game: AppID 2875760
addappid(2875760)
addappid(2875761, 1, "e27d2748abd39c826aaacf4412bfbd63483b0e70d47278fa75192c08ed726987")
