-- Lua provided by SkyAPI 
-- Game: Flyist
addappid(1333980)
addappid(1333981, 1, "fd7b9352f2c3c89d40cae8e0adddecdb1f472124be63d71cee06cb37657dd15a")
