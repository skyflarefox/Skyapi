-- Lua provided by SkyAPI 
-- Game: Invincible Presents: Atom Eve
addappid(2060870)
addappid(2060871, 1, "3e91e0a1305afee8a04ef84df0661fcb91626772e4191e1fe7329fa404194d4b")
