-- Lua provided by SkyAPI 
-- Game: Agartha
addappid(1002420)
addappid(1002421, 1, "c76acd9a7172c2f3740a226c1866982dfc24ed775be55f33ef2f9163c023425f")
