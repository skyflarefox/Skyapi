-- Lua provided by SkyAPI 
-- Game: functional Demo
addappid(1693810)
addappid(1693811, 1, "f781192cc6d074d1120f235c1e68183d249eaf9ee1c3fd5adc1a33ae1f7855ec")
