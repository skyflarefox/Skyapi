-- Lua provided by SkyAPI 
-- Game: AppID 862160
addappid(862160)
addappid(862161, 1, "7d40f6faa689d83600326d25cab13a9e83ed0a855f7c1818d1291a270a6983ae")
addappid(862162, 1, "f9be1892023a0e09627eb6ccbad8129405c0f9c90688d4b5f8a1606e8b81d554")
