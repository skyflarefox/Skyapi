-- Lua provided by SkyAPI 
-- Game: Bubble Ghost
addappid(781230)
addappid(781231, 1, "434425846905779b0044b0f1ddb09bfde6c1179c03cdcc965bca96e6d75dbf0e")
