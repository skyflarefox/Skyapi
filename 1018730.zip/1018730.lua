-- Lua provided by SkyAPI 
-- Game: AppID 1018730
addappid(1018730)
addappid(1018731, 1, "557a497c4f46de1b6dac7a5d5e4981a7f0ee9f538697d62888be4eab876f74e3")
