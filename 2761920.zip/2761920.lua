-- Lua provided by SkyAPI 
-- Game: Gunpowder Cocktail - Chapter 1
addappid(2761920)
addappid(2761921, 1, "637eb814cf0ca1d5d1af1387a72755459c8a75726b76f428447c8f4a797a4b60")
