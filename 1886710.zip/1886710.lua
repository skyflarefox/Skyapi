-- Lua provided by SkyAPI 
-- Game: Karagon Demo
addappid(1886710)
addappid(1886711, 1, "ccc4d71f3258634d98b3a0eba1b3360dfc21db37e753d36bb782ce50f0df3c05")
addappid(1991021, 0, "db0f258cc17c498fe5b7fa60ac04d4c33c41638d01528802abb352e07e63e298")
