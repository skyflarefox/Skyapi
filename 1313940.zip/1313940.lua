-- Lua provided by SkyAPI 
-- Game: My Holiday 2
addappid(1313940)
addappid(1313941, 1, "f50b6fe2e931b4426f31686d8fa903907fe63734b51ddf4c7f8dea84d3b4083a")
