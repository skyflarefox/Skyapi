-- Lua provided by SkyAPI 
-- Game: Prisoners
addappid(2725200)
addappid(2725201, 1, "1e025fd35e40eac3fa13bf88fb8777b9adb426070df49a4a1622461d2da2e5b9")
