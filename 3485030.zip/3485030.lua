-- Lua provided by SkyAPI 
-- Game: The Curse of Beatriz
addappid(3485030)
addappid(3485031, 1, "2b2ad9e3dedcb93cc85097e30c720ee5d2d873bf07cb022c36a9ff0d6f036c29")
