-- Lua provided by SkyAPI 
-- Game: AppID 2498770
addappid(2498770)
addappid(2498771, 1, "350ca4600d274421e17f91e0144c20608e8d0d2a85f32ef008fa5960ad2a05ce")
