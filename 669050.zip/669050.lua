-- Lua provided by SkyAPI 
-- Game: AppID 669050
addappid(669050)
addappid(669051, 1, "2cdd30e0db75ea9150953c8fdae360fa062c287f26961e138b3c54c4e51d40e1")
addappid(669052, 1, "8a13bfc9e5313ba059bd685f1e8a75a5b04aaa7899db5bea980340cc6616f994")
addappid(669053, 1, "54c2bc1cd3c92ad51e4ad5cbdb270e4a118aaf5ed2d9f53ca0e6bcc3afc8dd5e")
addappid(669054, 1, "b6f7c73fd4129f60d4a6cedd44147dfdafb720d56303b5d6cdbb6dd935e881a7")
addappid(728780)
addappid(728781)
addappid(728810)
