-- Lua provided by SkyAPI 
-- Game: Orphans
addappid(2722400)
addappid(2722401, 1, "9614e79eec1537f48858a0abf22bc642143b423d05c4d9874872cc19eb20507a")
