-- Lua provided by SkyAPI 
-- Game: Active Neurons 2
addappid(1274910)
addappid(1274911, 1, "e7c39978c0f255c24c098d36337b12f32770c6354a6160d26f4d06d8a45ab158")
