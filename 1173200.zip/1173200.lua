-- Lua provided by SkyAPI 
-- Game: AppID 1173200
addappid(1173200)
addappid(1173201, 1, "d92a85215178796eaeb6c602c12f01b2ce42d363fc3ba1dcadaf162bdbb5c55c")
addappid(1869080, 0, "5f98160187b3d52e3ed944da8958bd337b8f02e29395d7be5701fa071a0f3f06")
