-- Lua provided by SkyAPI 
-- Game: Aztecalypse
addappid(517010)
addappid(517011, 1, "77fdc6f11d0e3d8681b258e915882bc6e83c1793020b6a4739f63a0b97b26e14")
