-- Lua provided by SkyAPI 
-- Game: BLOKI
addappid(2585380)
addappid(2585381, 1, "65e5b255f859477ec3be9ad8a79db0dcd6252e062a1395cf6fa17c9f2f095e18")
