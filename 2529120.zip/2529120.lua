-- Lua provided by SkyAPI 
-- Game: Old School
addappid(2529120)
addappid(2529121, 1, "7b596a9f1c177977de7a3626a7bc624007bbc310a506eadbf0b904de1cf6a5ef")
