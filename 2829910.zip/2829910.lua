-- Lua provided by SkyAPI 
-- Game: Ruiga Pirates: First Survivors
addappid(2829910)
addappid(2829911, 1, "90d76e9dedc2623d66cb9878c4f7333a9dd2f3fabcbff8f857ba809c6dd1acc4")
