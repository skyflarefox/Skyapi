-- Lua provided by SkyAPI 
-- Game: AppID 790800
addappid(790800)
addappid(790801, 1, "86eb263f5e72a26ac1f4de6486f1d809324edffa3f8c9e946d288f247ef60847")
