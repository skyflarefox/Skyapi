-- Lua provided by SkyAPI 
-- Game: Street Fighting Simulator
addappid(2835060)
addappid(2835061, 1, "b48283cd996f55c670b20a342606b80370ee870a9a90e81b1bf988b9cc561b5e")
