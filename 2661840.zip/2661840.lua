-- Lua provided by SkyAPI 
-- Game: Path of Kung Fu Playtest
addappid(2661840)
addappid(2661841, 1, "ab727ae4ea3a78b0dfc457f05895bcb0241c0de0aed9c71d30eccc3fa2875b2b")
