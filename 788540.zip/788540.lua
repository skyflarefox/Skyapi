-- Lua provided by SkyAPI 
-- Game: Vivez Versailles
addappid(788540)
addappid(788541, 1, "4df8b2fdbc5ccca04e70f93da1d8a18279c65ef71352802e6f1ac8ca7bb00c7a")
