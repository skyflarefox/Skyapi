-- Lua provided by SkyAPI 
-- Game: Mystwood Manor
addappid(1863670)
addappid(1863671, 1, "48f0861f50d491d54e04a73a1c18681e5ac8ab1f8d2f7e5ee3e8be1e3d6de26d")
addappid(2170070, 0, "074c968debe442b6e36b663082160a3a772eac1dbb79a66dab92fce4fd916533")
