-- Lua provided by SkyAPI 
-- Game: Final Stand
addappid(3769120)
addappid(3769121, 1, "0d84d01134c49607664f642a54a342c3acc5b921f14316324a67d100c8cd8955")
