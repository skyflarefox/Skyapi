-- Lua provided by SkyAPI 
-- Game: A Strange City
addappid(1564940)
addappid(1564941, 1, "95f617bd36ba4ed42279345c0003968f8f5205bd73e6b1f9d7439a65dc6381a5")
