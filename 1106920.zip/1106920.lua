-- Lua provided by SkyAPI 
-- Game: Nyanco
addappid(1106920)
addappid(1106921, 1, "da63b1c21c8765cbc7775ecbad77c989cc026ffc32d4e262b21b58e58839ddc9")
addappid(1107380, 0, "17737f9ff408613abe64a915767f910c1b18234d9eaf34376eac8a2c3907a037")
