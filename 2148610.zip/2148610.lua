-- Lua provided by SkyAPI 
-- Game: Sex Adventures - Modeling Audition
addappid(2148610)
addappid(2148611, 1, "800e62f7a0e26410cb4fca2ee72c8dec440eadeece24e2031120728f27e1540c")
