-- Lua provided by SkyAPI 
-- Game: Terror in the Kitchen
addappid(2443790)
addappid(2443791, 1, "7ea86b33456231d7612373a2b5c4cbf6e759532126c624ee4dd480fbdf3b4542")
