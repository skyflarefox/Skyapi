-- Lua provided by SkyAPI 
-- Game: Mixx Island: Remix
addappid(1492640)
addappid(1492641, 1, "ee845e975487b33c375e0e67c21745f918f44eb37462ace1cb8ed43a73864ea7")
