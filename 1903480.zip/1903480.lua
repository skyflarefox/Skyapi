-- Lua provided by SkyAPI 
-- Game: Banana Hunter
addappid(1903480)
addappid(1903481, 1, "4d9e4e0e09640c1444fb921d76d9d026970f11bbaa278dee715c4b6886c93195")
