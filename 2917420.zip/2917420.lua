-- Lua provided by SkyAPI 
-- Game: SysOps Saga Demo
addappid(2917420)
addappid(2917421, 1, "781c080cd8a48eff590863f2210d9c19109812409ca3a0f248cadc14f994760f")
