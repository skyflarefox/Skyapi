-- Lua provided by SkyAPI 
-- Game: What Lies in the Multiverse
addappid(1721170)
addappid(1721171, 1, "2384f8deb443147284cb2d0093e12e3e6c89571ccc48e47057346e9c10588d8d")
