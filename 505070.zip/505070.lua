-- Lua provided by SkyAPI 
-- Game: AppID 505070
addappid(505070)
addappid(505071, 1, "f98294675d32c0189bf2bb9510532db78d9563f629090440c8de77e1c0cc4555")
