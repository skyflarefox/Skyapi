-- Lua provided by SkyAPI 
-- Game: AppID 1173810
addappid(1173810)
addappid(1173811, 1, "5dee0fcdeaae9b85696d06c22f4adc054f1c6384f62e0bf2b3081bb1bb57cad9")
addappid(1638400, 0, "04759f0d604e673e9bf564bc2572bdacb3ad61e7a887f7f629953aa88bbeca4c")
