-- Lua provided by SkyAPI 
-- Game: Western Girls
addappid(2099000)
addappid(2099001, 1, "2e919b0841eb46416c6aecbc19dd467f2a6c35eaba542f3896f3872d5d15212f")
