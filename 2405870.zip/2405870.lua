-- Lua provided by SkyAPI 
-- Game: The Infinity Road
addappid(2405870)
addappid(2405871, 1, "eefd38ec3ac3c598ac87ee0994da1164bb6363954ccbf074aaaa98502be9af99")
