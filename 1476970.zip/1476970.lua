-- Lua provided by SkyAPI 
-- Game: AppID 1476970
addappid(1476970)
addappid(1476971, 1, "e922d073b8279666458207572cbcb8aaec1002653d68c97ce3c2bd8f56e43a55")
addappid(1476972, 1, "8baf43b04d99608238ff2f1bda7dfb3f23026f08531a8d68936c8e80b083caee")
