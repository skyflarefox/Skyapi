-- Lua provided by SkyAPI 
-- Game: Superliminal Double-Album Soundtrack
addappid(1440610)
addappid(1440611, 1, "9fb8ff38a7860a864e58c69f554b6713c4820ec069b16e6f1e654971432c1179")
