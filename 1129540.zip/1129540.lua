-- Lua provided by SkyAPI 
-- Game: Orc Massage
addappid(1129540)
addappid(1129541, 1, "b1352d91104d7a3c4a4402d664ca5eaf0471b69d4483c5e37ca40d47416ae6ae")
