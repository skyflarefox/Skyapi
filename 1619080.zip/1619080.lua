-- Lua provided by SkyAPI 
-- Game: Cake Invaders
addappid(1619080)
addappid(1619081, 1, "039d20c10244e9f9845569c83db005f926bd07ed8df05dbddd27065c0d2c560b")
