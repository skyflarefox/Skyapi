-- Lua provided by SkyAPI 
-- Game: Tennis Club Story
addappid(2054810)
addappid(2054811, 1, "0fce977a8b02fe6140316d65bb541059a4b42edf89f111a06d7daa0799027724")
