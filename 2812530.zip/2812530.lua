-- Lua provided by SkyAPI 
-- Game: Versus Dev
addappid(2812530)
addappid(2812531, 1, "4db1a41cd3f0309ba1a1058a79d03c9632336c5f11c3d0eaad83acab2975ce5a")
