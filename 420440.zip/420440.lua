-- Lua provided by SkyAPI 
-- Game: Atlantic Fleet
addappid(420440)
addappid(420441, 1, "881e2e25382688f6042b7ef1429137ff0263e7bb7d8120e0be6928e88090b94e")
addappid(420442, 1, "f51013d532ba006852223440ad8968c08dadb4dd59079e0552188c2841a845da")
