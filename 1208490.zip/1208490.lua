-- Lua provided by SkyAPI 
-- Game: AppID 1208490
addappid(1208490)
addappid(1208491, 1, "824c6c2e27e3496238c3251708de375d6370ca5a84e95968b8dbf899928021d3")
