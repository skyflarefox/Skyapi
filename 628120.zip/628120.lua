-- Lua provided by SkyAPI 
-- Game: AppID 628120
addappid(628120)
addappid(628121, 1, "dfa1d64337919b2a86255f5fe61305f88f600e0cfa16ada5cf19414010f9019c")
