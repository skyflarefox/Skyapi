-- Lua provided by SkyAPI 
-- Game: Neon
addappid(1505460)
addappid(1505461, 1, "abc1747a0189368eb9e47b98f9804967a412de038ecebe00afe122637c9c8718")
