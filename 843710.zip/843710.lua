-- Lua provided by SkyAPI 
-- Game: AppID 843710
addappid(843710)
addappid(843711, 1, "06de6ff854158ed9b882fbdcf57e2fd6ae24570baad81c13e1ceea6655885e90")
