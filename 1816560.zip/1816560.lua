-- Lua provided by SkyAPI 
-- Game: Sperm Runner
addappid(1816560)
addappid(1816561, 1, "5ff2e3935421c66223dda62fef13a0b4b0e929afea04c041af9e7e0a02294d2a")
