-- Lua provided by SkyAPI 
-- Game: Paperbark
addappid(916900)
addappid(916901, 1, "eb8a979e62666d8cbf99f0b3465f8b55c1f243a1e755db5780e749500f72acc0")
