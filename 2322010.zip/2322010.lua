-- Lua provided by SkyAPI 
-- Game: God of War Ragnarök
addappid(2322010)
addappid(2322011, 1, "78758c85a2a8b04770fb4fe430ac7a215a959b72e496d94f6a0ec5ac38066f49")
addappid(2974310)
addappid(2974320)
addappid(2974330)
addappid(2974340)
