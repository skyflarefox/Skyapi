-- Lua provided by SkyAPI 
-- Game: DYMENSION Prologue:Scary Horror Survival Shooter
addappid(1869220)
addappid(1869221, 1, "dae947f7a81f69a68163129505f66681c08868d741f1d60fe5007f2950f407a5")
