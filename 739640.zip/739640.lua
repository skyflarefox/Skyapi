-- Lua provided by SkyAPI 
-- Game: AppID 739640
addappid(739640)
addappid(739641, 1, "c84aaa35cc35e3e17a56dbef9bda2055cc2024a5fedcd578565dff88b127044a")
