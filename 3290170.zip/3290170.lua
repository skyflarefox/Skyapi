-- Lua provided by SkyAPI 
-- Game: Treasure 'n Trio Demo
addappid(3290170)
addappid(3290171, 1, "08544adc56367f0aa872019a258f7f32fb5e786b1fb8c18e3749fd9ffc73d20c")
