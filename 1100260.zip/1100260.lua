-- Lua provided by SkyAPI 
-- Game: AppID 1100260
addappid(1100260)
addappid(1100261, 1, "72e630090ab1b007939369628e7f18495db49b39539f9673f4c36ac8d6b6d2fa")
addappid(1324060, 0, "9772cfaa257024a0e0ae59d7f0da28b662234deebccfdfb26e44e1282528099f")
