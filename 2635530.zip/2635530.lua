-- Lua provided by SkyAPI 
-- Game: Tidal Therapy
addappid(2635530)
addappid(2635531, 1, "87bb21b950f1db8c6fa4187061fba88677cd20aab9f5132730dba6e0c087e401")
