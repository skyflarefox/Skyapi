-- Lua provided by SkyAPI 
-- Game: Grand Theft Auto: Vice City
addappid(12110)
addappid(12111, 1, "a7ad1f1b98647e90ed852384deda16f4822fd85665445503aa576ca6f82bdcb5")
