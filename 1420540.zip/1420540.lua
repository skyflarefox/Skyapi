-- Lua provided by SkyAPI 
-- Game: CATch the Stars
addappid(1420540)
addappid(1420541, 1, "b7ab3e7c08a6f64ec54ede13c8c5cbab519d2dee02b98b417a50300abcece42e")
