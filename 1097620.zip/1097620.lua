-- Lua provided by SkyAPI 
-- Game: Fast and Low
addappid(1097620)
addappid(1097621, 1, "6100da7a3d68eac914d9479b7a776d917e688cc1414b490021096bc2a1bb64cb")
addappid(4513870)
