-- Lua provided by SkyAPI 
-- Game: Hirilun
addappid(1407300)
addappid(1407301, 1, "b34ed4add9b46ff5ae00c2f69d24c5fe10d8594d005e919c1b0366ad145a3e79")
