-- Lua provided by SkyAPI 
-- Game: Spinodrum
addappid(1377350)
addappid(1377351, 1, "dcc9d7220706adf4131113681e3436e74fa8f6b0b6b8e1572ba82b488cd25b58")
