-- Lua provided by SkyAPI 
-- Game: AppID 338050
addappid(338050)
addappid(338051, 1, "16a61a2e03890fab175924f58661703236c4ceacc84d14b14be1af7a44ce862b")
addappid(338052, 1, "3a0044dc6ec467d77c1e90e79a696bf6e97c47eb503480e1ae5c9a28da58a800")
addappid(338053, 1, "3a120e783a02b62e565a4cbd9a28065eebd46e5b7d288402b6f0cccebaf97a6a")
addappid(404670)
