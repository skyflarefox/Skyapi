-- Lua provided by SkyAPI 
-- Game: Cat Adventure 2
addappid(1913320)
addappid(1913321, 1, "d56feadc2eb8f3c3abfb79d5cf8b540f2143857affb3c93570df2fd2005525f8")
