-- Lua provided by SkyAPI 
-- Game: Bushside Rangers
addappid(3054410)
addappid(3054411, 1, "f3d4245e90daabdf8d1139fd3fc806309720faaf24a60902e2331d579126f314")
