-- Lua provided by SkyAPI 
-- Game: AppID 823530
addappid(823530)
addappid(823531, 1, "acf8fccbb4f45349b0ff8e655c3e9fc0b4fb7a611dc8988f39c446d1958318cd")
