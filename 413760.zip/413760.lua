-- Lua provided by SkyAPI 
-- Game: AppID 413760
addappid(413760)
addappid(413761, 1, "4ec3698d7805f7d2a1686353a3f641e2e67f860aed824cc2f47a7de0efc72f40")
