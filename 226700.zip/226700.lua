-- Lua provided by SkyAPI 
-- Game: AppID 226700
addappid(226700)
addappid(226701, 1, "89dccd4ca0cb554eabac3bd6c26e9c5f9c7e3a65e0f91ad05350b55aca6ce47d")
addappid(228985, 0, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c")
addappid(228988, 0, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
addappid(228990, 0, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
