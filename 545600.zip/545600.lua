-- Lua provided by SkyAPI 
-- Game: AppID 545600
addappid(545600)
addappid(545601, 1, "3cbb4f85de33c06c08005b847f9108fbdfff714c22094228907576dc9293e82f")
