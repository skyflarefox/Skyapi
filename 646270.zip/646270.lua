-- Lua provided by SkyAPI 
-- Game: 60 Parsecs!
addappid(646270)
addappid(646271, 1, "348f98db5b5aaa9970a2b7decbec70782c36bb7248d165ef02d8c84eb848f778")
addappid(646272, 1, "77f4c8583634994b677f2c4b0724eee4926d02448823488cc74dfd7a1748a5ac")
