-- Lua provided by SkyAPI 
-- Game: PANICORE Demo
addappid(2809040)
addappid(2809041, 1, "cea8d7784aa9be0c739eea90aa65d5227d4351360a4a961f377fd87e46695636")
