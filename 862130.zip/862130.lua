-- Lua provided by SkyAPI 
-- Game: AppID 862130
addappid(862130)
addappid(862131, 1, "f56aa4840c37d77064417d0403b46a6a2c7c1eec0584fd95923933cc93656704")
