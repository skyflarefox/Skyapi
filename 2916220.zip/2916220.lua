-- Lua provided by SkyAPI 
-- Game: Warlords III: Darklords Rising
addappid(2916220)
addappid(2916221, 1, "28f6f7cead35c4735f111b8e6fcd98b336bb903633b11d42303d34feaa3e2ff2")
