-- Lua provided by SkyAPI 
-- Game: AppID 879610
addappid(879610)
addappid(879611, 1, "65a7dc467c1e61873fdad41507a6af8d58aea04d800f5b3aa681785e1083125f")
