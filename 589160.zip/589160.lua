-- Lua provided by SkyAPI 
-- Game: Zombie Apocalypse
addappid(589160)
addappid(589161, 1, "dd8f51cd3c474620a1d482dc689b4ed5627a8b84606fabc7fd383f8a071be9e3")
