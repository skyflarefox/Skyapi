-- Lua provided by SkyAPI 
-- Game: TIMEGAL HD-Remaster
addappid(3050490)
addappid(3050491, 1, "7cb06610c52b6a112b27813a7e418bca13fba0be1a93c0c2977e2b3444416aaa")
