-- Lua provided by SkyAPI 
-- Game: Annual
addappid(710090)
addappid(710091, 1, "024d287e9b3562d6a09391541102a02b9ef0ab8b1b3d5ab0060c382337fd7487")
