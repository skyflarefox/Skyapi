-- Lua provided by SkyAPI 
-- Game: Fall into decay
addappid(2406110)
addappid(2406111, 1, "d202733054e5f8bc9c1dc81025d5bf7a401f0a3eb39f2d363a0ef0a3c466f8ba")
