-- Lua provided by SkyAPI 
-- Game: AppID 3172220
addappid(3172220)
addappid(3172221, 1, "420c56109db1519fc24b75968bfeb19a77a69e7391b47125420aeae63bc2c6b3")
