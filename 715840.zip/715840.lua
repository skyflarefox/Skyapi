-- Lua provided by SkyAPI 
-- Game: PooSky
addappid(715840)
addappid(715841, 1, "b27043599575b626c2fb9c3aafec39e107204d26b0d9cb6cea8fb79574c15917")
addappid(725420, 0, "60dde9e1398564669aa62fa658a964cfd5ada772193a93d8abd942aaa35dafec")
addappid(741020, 0, "85c25a6060c4f819835ea0b19a72c1b23b1f07db5bd1b2711019d6b067a200fa")
