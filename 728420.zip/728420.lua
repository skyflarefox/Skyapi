-- Lua provided by SkyAPI 
-- Game: Rogue Quest: The Vault of the Lost Tyrant
addappid(728420)
addappid(728421, 1, "2a43a8f3e5ee9a4965d9b5f6d747963eb64ef574ca047cff71233c80279adc3e")
