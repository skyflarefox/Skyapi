-- Lua provided by SkyAPI 
-- Game: AppID 2484110
addappid(2484110)
addappid(2484111, 1, "b3a968d9a6cc78c6beb8210974b098248155fb4c1381c8ee468f6dc99d7f0a9d")
