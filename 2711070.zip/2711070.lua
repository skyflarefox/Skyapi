-- Lua provided by SkyAPI 
-- Game: Casino Boss Simulator
addappid(2711070)
addappid(2711071, 1, "ca4e34d4c43dbb1258d12072ebe2bdbb5101e59d5b8dd02322eb9f48436b94f1")
