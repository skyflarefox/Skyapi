-- Lua provided by SkyAPI 
-- Game: Furry Love
addappid(1334590)
addappid(1334591, 1, "1e97eafaac6e5c5c87a3b3787b3de63201e9b7be907e705c7ea4669d38d3ac43")
addappid(1356100)
