-- Lua provided by SkyAPI 
-- Game: Spirit Swap Demo
addappid(1759570)
addappid(1759571, 1, "39bf22d23b499f9b04bf96c384f2d893603f2550f03dc4254e2a60e00d5cc239")
