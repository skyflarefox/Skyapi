-- Lua provided by SkyAPI 
-- Game: Path of Vidya
addappid(1676450)
addappid(1676451, 1, "81e84430a96928c58dd38d1ec5a512f3e45ea999f683e3b05571bafda03ce34b")
