-- Lua provided by SkyAPI 
-- Game: Grammarian Ltd
addappid(1578880)
addappid(1578881, 1, "d5b64ebad550f19a209edfd666fab535c9f0d084d307b4f680dd05b9241c64dc")
