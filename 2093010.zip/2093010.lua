-- Lua provided by SkyAPI 
-- Game: Supernatural
addappid(2093010)
addappid(2093011, 1, "b6637ddb087b756038dd8de272d0ba61ee65613ef691deb09b2e2570628e8c1e")
