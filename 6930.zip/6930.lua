-- Lua provided by SkyAPI 
-- Game: Just Cause Demo
addappid(6930)
addappid(6931, 1, "6ae483ddfa8974e39d6af7ae6a5243416d3d1a8984fb1ed61ec153c390361cb4")
