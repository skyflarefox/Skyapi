-- Lua provided by SkyAPI 
-- Game: AppID 603360
addappid(603360)
addappid(603361, 1, "f355ad3abe80142651b7277ec738b2aafb9a0bd18fd3c4de71b36c02036ddc09")
