-- Lua provided by SkyAPI 
-- Game: Saimin Gakushū: Secret Desire
addappid(1788100)
addappid(1788101, 1, "e4d856a9bd00b91530103247f866146a05fc9ccc7a3a2df03dfea9e794c8fa9d")
