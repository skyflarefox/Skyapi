-- Lua provided by SkyAPI 
-- Game: It's Spring Again
addappid(434210)
addappid(434211, 1, "413305cbe1fcf38c08174a2a69b239b1ec701ae3817f8951e9a292b5dd6e74fe")
addappid(434212, 1, "fd719c12fc8b43ee92b9db2d1ecd9b0b1b47c040f8f4e00e089d8f77cee18583")
addappid(434213, 1, "85a16c797f918fde93b80a287e71843779a556260ebafc11c43598bda1d72d9b")
addappid(434400)
