-- Lua provided by SkyAPI 
-- Game: 6 Seasons and a Game
addappid(1460830)
addappid(1460831, 1, "a10998deee07c1d093d138d5a8b1319325c09d3b6c26e2e38669093698fa1363")
