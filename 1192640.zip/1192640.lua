-- Lua provided by SkyAPI 
-- Game: Mosaique Neko Waifus
addappid(1192640)
addappid(1192641, 1, "97f9f9d4279bcc116a1fcc2edec5c1b0de04bd07313262a27746905cb3ced919")
addappid(1206820, 0, "776b62fdca6d56286f9b01728c739137345a1653ca762c2de3d6fcbfe44ba599")
addappid(1206821, 0, "1f5f1bf8641c0e6f11ff4b81814f3cf697d2086a0058723b41c249511f5d3ca2")
