-- Lua provided by SkyAPI 
-- Game: Helmetman
addappid(2286790)
addappid(2286791, 1, "133f337bb317c65688962815b5e6d3c573985f4f2cdae4f8460e7f16da28ce55")
