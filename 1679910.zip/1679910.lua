-- Lua provided by SkyAPI 
-- Game: Blow & Fly
addappid(1679910)
addappid(1679911, 1, "7d603c51c5326812ed8bf50bc2e483d13c135cc94be6a411b1ddb80ea5bd3725")
