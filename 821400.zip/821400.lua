-- Lua provided by SkyAPI 
-- Game: Packed Train
addappid(821400)
addappid(821401, 1, "8f7f41c4c7eaf1990cd4cd2f6b76443cd4e3f4d566ae4e8ac39d0ae3e2cc7d44")
