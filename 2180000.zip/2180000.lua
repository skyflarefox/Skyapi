-- Lua provided by SkyAPI 
-- Game: Elemental Survivors
addappid(2180000)
addappid(2180001, 1, "5ae3ca0c96cb7ca3bded9692436a3f1e6e6d1dc1d40e63ae78d0a0f4793b3a5d")
