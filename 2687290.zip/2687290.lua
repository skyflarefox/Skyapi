-- Lua provided by SkyAPI 
-- Game: AppID 2687290
addappid(2687290)
addappid(2687291, 1, "66224c2fa0df009cb7e8699b64046110b6edc0464b50cddbc349cfd149685aac")
