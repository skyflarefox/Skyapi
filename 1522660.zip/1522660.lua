-- Lua provided by SkyAPI 
-- Game: Introvert: A Teenager Simulator
addappid(1522660)
addappid(1522661, 1, "a72ded25c4d9e15cdfe76707d8c9b93566b6e639a75e760f03db0df81edaf710")
addappid(1522662, 1, "cadd8952ef7e8c93f2dca72fb8ef0494fb6dfe6d2b952515cf0b0a872487e0d1")
addappid(1522663, 1, "fdf4db4e9b7546465a2b6087f7258e89ea01baf99f42b4aaf620b9fe58d31e74")
