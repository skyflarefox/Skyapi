-- Lua provided by SkyAPI 
-- Game: Elevator Ritual
addappid(813150)
addappid(813151, 1, "84a93168e55ea516ada3c3474308aed31d0a2f9614c41aee579e42b6c62e7539")
