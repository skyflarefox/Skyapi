-- Lua provided by SkyAPI 
-- Game: AppID 634230
addappid(634230)
addappid(634231, 1, "7b03c91a1e34b622e1cc702f88657fc8f5b58081f772d9d8468efd6772a573b9")
