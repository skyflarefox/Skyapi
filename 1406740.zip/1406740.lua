-- Lua provided by SkyAPI 
-- Game: DumbBots: Hello World
addappid(1406740)
addappid(1406741, 1, "35abb9e3609aa2f2c268c09edb1deccc564514ec2e6a6bdd549e240e17a3176f")
