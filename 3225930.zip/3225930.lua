-- Lua provided by SkyAPI 
-- Game: Rotate or Die
addappid(3225930)
addappid(3225931, 1, "70cbee93418df1506bf3bf3fce2fa89091d6056a40137fc771c7aaad4f0b19d4")
