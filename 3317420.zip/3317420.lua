-- Lua provided by SkyAPI 
-- Game: AppID 3317420
addappid(3317420)
addappid(3317421, 1, "7500875f45c7b4608e78182e555b36c2173727d09c3885502ca8c3a83c741d27")
