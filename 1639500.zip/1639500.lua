-- Lua provided by SkyAPI 
-- Game: AppID 1639500
addappid(1639500)
addappid(1639501, 1, "f031212773cdb62ad1f779da3f5ceaf02094997fdcd567cc86b26ba955f235b6")
