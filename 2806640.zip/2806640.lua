-- Lua provided by SkyAPI 
-- Game: The Talos Principle: Reawakened
addappid(2806640)
addappid(2806641, 1, "7608c9835511431b6d95c5aa29bcb269f2cc727e99109c084e19dadb256a25a5")
