-- Lua provided by SkyAPI 
-- Game: Lucius Demake - Soundtrack
addappid(538460)
addappid(538461, 1, "667a7e4371876762105a75bc743b43a36c28ae2cf69b82753d8800f2c10db264")
