-- Lua provided by SkyAPI 
-- Game: Sasha's Stupid Coffee Shop
addappid(2598730)
addappid(2598731, 1, "15a3ff37fad57bf40d11ba9fb74ee22ca0a7806c82b5f8f44ad9f2a6c0d37f55")
