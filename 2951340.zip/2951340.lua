-- Lua provided by SkyAPI 
-- Game: Moonless Moon
addappid(2951340)
addappid(2951341, 1, "e5ec31bf76f5b0fdf48d86c41d9cf32fd29ed56b24cd14cbced556b67283adca")
