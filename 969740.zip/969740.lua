-- Lua provided by SkyAPI 
-- Game: AppID 969740
addappid(969740)
addappid(969741, 1, "070ca1eb1e3534e520717e0577cf1551aa4a59f80b56cf97091e23fa06fd23ef")
