-- Lua provided by SkyAPI 
-- Game: Clouzy!
addappid(1493360)
addappid(1493361, 1, "268ea441078e3a4682d6e7c0350b42a335f4461322c94c253227ba0ad6e8ace2")
