-- Lua provided by SkyAPI 
-- Game: My Cute Girls
addappid(1844260)
addappid(1844261, 1, "b408a1d36ea2bc95b7f999fb22efbc51f120ab5341db01e60e0c2dc7c50b3d76")
