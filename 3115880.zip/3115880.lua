-- Lua provided by SkyAPI 
-- Game: Jumpscare Scare Jump
addappid(3115880)
addappid(3115881, 1, "3c5305ee5c06cb5f07edb98d63bf5b49774b12e8c0f15986c9339a1f34a3ce98")
