-- Lua provided by SkyAPI 
-- Game: HORSE
addappid(977160)
addappid(977161, 1, "4cb224595c254b6d9ab47a22e1ee47f2a64e0f3f7a5c3ad385d4e942d34ecbc5")
