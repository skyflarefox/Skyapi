-- Lua provided by SkyAPI 
-- Game: Sex & Blood: Vampires
addappid(2657030)
addappid(2657031, 1, "dc8f57e2a2cbbd44724b851b708ca646c6c3872b45602ff4f45efb9e36613e41")
