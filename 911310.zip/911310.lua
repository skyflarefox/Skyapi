-- Lua provided by SkyAPI 
-- Game: Kz NTools : Fix Your Network
addappid(911310)
addappid(911311, 1, "3379c517110ef7d00ef3640f1dabd6f7e4c8ec3af96964e8adb0162e06d2eed3")
