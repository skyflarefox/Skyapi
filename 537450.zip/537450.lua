-- Lua provided by SkyAPI 
-- Game: AppID 537450
addappid(537450)
addappid(537451, 1, "2ea7d90edcb0c55d7706e342460e7d67fd76700db21fb9d3e602f6f82ed834b4")
