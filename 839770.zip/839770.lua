-- Lua provided by SkyAPI 
-- Game: Phoenix Point
addappid(839770)
addappid(839771, 1, "332cfa106a9342d144de52e56d95ebe11b1bf5415e689c29c215f712db05bea2")
addappid(1357480, 0, "aa477376a0154312123af1c97856b852a6917ca69bf759537ffa6c36ac700550")
