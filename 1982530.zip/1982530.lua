-- Lua provided by SkyAPI 
-- Game: The DioField Chronicle Original Soundtrack
addappid(1982530)
addappid(1982531, 1, "a22d40dfa895def1c6c712eb1550f8fcb7c1783bbef1ff5c710ce2e0d7e2010e")
