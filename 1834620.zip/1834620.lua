-- Lua provided by SkyAPI 
-- Game: AppID 1834620
addappid(1834620)
addappid(1834621, 1, "6e033420561f62e6df3fc9c4a7eb7657ddafacd195a3c0c73b84c0552ad5e7fa")
