-- Lua provided by SkyAPI 
-- Game: Dreams: Unlimited links
addappid(2569580)
addappid(2569581, 1, "9027128ce8f94914ebed4d6726273146e9c974346cf17fdada2fa0c4e630c497")
