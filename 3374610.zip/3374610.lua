-- Lua provided by SkyAPI 
-- Game: AppID 3374610
addappid(3374610)
addappid(3374611, 1, "9e988009a5656df132b3191f3a12f1a8723781b17fd8bfe2a689ae18a22d2735")
