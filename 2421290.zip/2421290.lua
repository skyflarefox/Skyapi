-- Lua provided by SkyAPI 
-- Game: Weapons Party
addappid(2421290)
addappid(2421291, 1, "f29fc84a0025a963d154ba591267dc3b8354bd716dc71c72992145f67a7c3e9c")
