-- Lua provided by SkyAPI 
-- Game: RealmCraft
addappid(764580)
addappid(764581, 1, "d1755bdb18e745301c7a9f90d8836c770aad4746aa16312537093fe1b52c6683")
addappid(764582, 1, "495f4daa296e4a9460a8675c395dd4cf2b829e303abcde0a0330f27dbee0b7d3")
