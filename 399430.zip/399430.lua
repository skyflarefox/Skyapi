-- Lua provided by SkyAPI 
-- Game: Tinboy
addappid(399430)
addappid(399431, 1, "065ac13284add4e74ca5cc6a425f926c2fe7368401d5a83c8acafca3dc95afba")
addappid(399432, 1, "788db5a5301a1ee3ea43146ccdeec243395920152f5b265169e5a17874d97b67")
addappid(399433, 1, "7fda84c81271e3d11301a3f81b91e7aafe987bebf145a65b555c68889f9eef93")
