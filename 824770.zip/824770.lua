-- Lua provided by SkyAPI 
-- Game: AppID 824770
addappid(824770)
addappid(824771, 1, "3a152024bfde84c458c88a820e40af73161228ba92785ef067a5463078d18358")
