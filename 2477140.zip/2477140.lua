-- Lua provided by SkyAPI 
-- Game: Twilight Town: A Cyberpunk FPS
addappid(2477140)
addappid(2477141, 1, "0100839f74bd14eed5d79657f8665d6c2f27e21b7df928e69b45b0636a8def0d")
