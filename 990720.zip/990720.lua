-- Lua provided by SkyAPI 
-- Game: AppID 990720
addappid(990720)
addappid(990721, 1, "c1b3092dc24c1186b0a5a61232c24b327169ce61fe34907960716f7f78d981d4")
