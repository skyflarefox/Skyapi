-- Lua provided by SkyAPI 
-- Game: Nyaruru Fishy Fight
addappid(1478160)
addappid(1478161, 1, "0b31a1bb4d834f46c37bd1b54b48127e24153c121da8b990eed3d22bfe55c812")
addappid(2495690, 0, "d37c959d4f78ef15c8647f82355c8f8cd155500049e39df6a36963933d1d558b")
