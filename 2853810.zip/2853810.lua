-- Lua provided by SkyAPI 
-- Game: AppID 2853810
addappid(2853810)
addappid(2853811, 1, "275174fba1621bc5a92121a561858b905bf9ef4e6224bc9abeaaa8636e6b5ad9")
