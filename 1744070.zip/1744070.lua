-- Lua provided by SkyAPI 
-- Game: Solomon Snow: First Contact
addappid(1744070)
addappid(1744071, 1, "81993f7c48cd4c51a79466b869649ecc43c14db00638e9bd9c8bfe3aa1d493c9")
