-- Lua provided by SkyAPI 
-- Game: Root Letter - Artbook
addappid(579650)
addappid(579651, 1, "241449cd66dccc7e7a7b100ee3e726ee9792b7e97faf5584cd9f9b03904371bf")
addappid(579653, 1, "6dbd65b2de608d3f7546535296d6b80cfe0e428fa5b0d4883475a383c6877bef")
