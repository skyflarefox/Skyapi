-- Lua provided by SkyAPI 
-- Game: AppID 424840
addappid(424840)
addappid(424841, 1, "1823f166b7f7161144cc3fb35ba96c0c8526183cf77e66127c44b152c1fcad7e")
addappid(584090)
addappid(584091)
addappid(584092)
addappid(584093, 0, "55a230ea8309169f6d9a419934d5451c5a403fd07d721794c43e2ec41317d9ea")
addappid(584094)
addappid(584095)
addappid(584096)
addappid(584097)
addappid(601710, 0, "6ef5cd05ac17d226a1897c8bd1cee696e7ecd67372f84f357a61b1df8aa69949")
addappid(640920)
