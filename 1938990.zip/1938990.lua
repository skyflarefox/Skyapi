-- Lua provided by SkyAPI 
-- Game: DogeFight
addappid(1938990)
addappid(1938991, 1, "2cbca77dc9b4f97b5ed74b966107e38cbc38e1c1b495ff5ce619fc6dc1019f97")
