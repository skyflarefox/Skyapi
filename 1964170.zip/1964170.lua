-- Lua provided by SkyAPI 
-- Game: Putty Putter Demo
addappid(1964170)
addappid(1964171, 1, "a4a5bcc69013fb9cb0b58d1a6059b7e132b3da74b699ef1bbd57aa4963ff798b")
