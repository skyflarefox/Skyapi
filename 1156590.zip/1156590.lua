-- Lua provided by SkyAPI 
-- Game: AppID 1156590
addappid(1156590)
addappid(1156591, 1, "edd8c322a4ce6c713c02e1917c4e7267e7340c74da58a902d2adfcfaddee3264")
