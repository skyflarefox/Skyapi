-- Lua provided by SkyAPI 
-- Game: Railbound
addappid(1967510)
addappid(1967511, 1, "1f47788a2e63ce7847ef2a3c02bfca10485668e72db9a6f8297a3950f63d7156")
