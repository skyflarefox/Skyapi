-- Lua provided by SkyAPI 
-- Game: REVOLVER360 RE:ACTOR
addappid(313400)
addappid(313401, 1, "23e1c7f322ced5fe6ab88e353208c021ae829741126a0a5fff150e720746167a")
