-- Lua provided by SkyAPI 
-- Game: Crusader Kings Complete
addappid(204940)
addappid(204941, 1, "5b174cd7b5f2abe3b7b05e340c357d7fa227f5c6183f72557647c67feaf7bfa3")
