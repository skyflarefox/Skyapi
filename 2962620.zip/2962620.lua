-- Lua provided by SkyAPI 
-- Game: Sift Heads Legendary Pack
addappid(2962620)
addappid(2962621, 1, "39449b1d13b254ca6817995fe37acab9071109fb740ef5a95da41cd8dee1099d")
