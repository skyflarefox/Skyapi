-- Lua provided by SkyAPI 
-- Game: Slay or Fall
addappid(3170730)
addappid(3170731, 1, "286f0ddb5e0ed5b62a2f18694688407dc146712632fbfa205e22cc72a01f98c9")
