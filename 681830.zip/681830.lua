-- Lua provided by SkyAPI 
-- Game: AppID 681830
addappid(681830)
addappid(681831, 1, "6fec93a9ec26498aa4786b1ae814144303b065803457e5f7e92575cf0daeb18d")
