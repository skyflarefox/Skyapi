-- Lua provided by SkyAPI 
-- Game: Roguebook
addappid(1076200)
addappid(1076201, 1, "50ee1eeed9965f82ead8a6be6c534afef4ac5991a57be019e7c2f479e1442d14")
