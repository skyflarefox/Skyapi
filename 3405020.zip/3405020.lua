-- Lua provided by SkyAPI 
-- Game: That Village
addappid(3405020)
addappid(3405021, 1, "3a68ac6e036d5356dd24e7487ec4d2d44ed74510136faa3552203bded12d5b3e")
