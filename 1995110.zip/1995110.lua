-- Lua provided by SkyAPI 
-- Game: Slime Dungeon
addappid(1995110)
addappid(1995111, 1, "6b1ce13bcb5347b0e81962dee8e07c9980a542e679a8b5f5e5cf7c5afa4a2076")
