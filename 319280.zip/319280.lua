-- Lua provided by SkyAPI 
-- Game: Yatagarasu Attack on Cataclysm
addappid(319280)
addappid(319281, 1, "f9976490fdc76047ef10daebdc0dea027210fc9227360609e9d2ead453646633")
addappid(338210)
addappid(382510)
addappid(385640)
addappid(385650)
addappid(385660)
