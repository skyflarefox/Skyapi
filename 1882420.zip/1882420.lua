-- Lua provided by SkyAPI 
-- Game: Learn Programming: Python - Remake
addappid(1882420)
addappid(1882421, 1, "7983a87acc0dfe74b066567c8886a3a51fc7bd501c3b073d8694026ba2d5e364")
