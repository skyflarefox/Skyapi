-- Lua provided by SkyAPI 
-- Game: Harem Inn
addappid(3333360)
addappid(3333361, 1, "9ac11bd4159f8498c395295fb035e0d13b60de9445deca014a27938537396c82")
