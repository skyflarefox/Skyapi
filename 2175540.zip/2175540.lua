-- Lua provided by SkyAPI 
-- Game: AppID 2175540
addappid(2175540)
addappid(2175541, 1, "bb34a035fea6b37fef9b6e478eca854e431df2efbe4dfdbb05f78cea963fc4a1")
