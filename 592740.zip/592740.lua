-- Lua provided by SkyAPI 
-- Game: Drift 7 Islands (survival)
addappid(592740)
addappid(592741, 1, "5fd2bbac27d668538984e6f3789ee7578465147440f14d567185c7c0edd5805c")
