-- Lua provided by SkyAPI 
-- Game: AppID 364770
addappid(364770)
addappid(364771, 1, "f57b32b5d70237555e34e19609ba48e28c05e9a87704e9748973c3c05af2df11")
