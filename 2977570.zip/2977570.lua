-- Lua provided by SkyAPI 
-- Game: REVEREND
addappid(2977570)
addappid(2977571, 1, "c3757ad930973de2f3736add1820e989cc17f7489fcccbd954271c9158031f16")
