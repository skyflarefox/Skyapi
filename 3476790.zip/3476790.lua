-- Lua provided by SkyAPI 
-- Game: Cozy Aquarium
addappid(3476790)
addappid(3476791, 1, "1c90ae0aa93a71554ac4a07089a0f70e8149c6c357b2392451329e2c73eb0ae4")
