-- Lua provided by SkyAPI 
-- Game: AppID 47920
addappid(47920)
addappid(47921, 1, "846f2d62beedbc12d6c738867186935dc391a891a1705803f4d04d0fbbd40c3a")
