-- Lua provided by SkyAPI 
-- Game: AppID 1321670
addappid(1321670)
addappid(1321671, 1, "4b76284dd805fec94ad7185d442ec522428b65b7a11efaf956e510866f104819")
