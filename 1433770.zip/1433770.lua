-- Lua provided by SkyAPI 
-- Game: Chesnakisnak
addappid(1433770)
addappid(1433771, 1, "1468d45ee9adafae6651a8ecb8b72f801149a22dec644e708e1237d42615e5e4")
