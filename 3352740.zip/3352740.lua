-- Lua provided by SkyAPI 
-- Game: Mandragora: Whispers of the Witch Tree — Soundtrack
addappid(3352740)
addappid(3352741, 1, "8c65db2d076750a97e5ce3d2e1bf86f3e80a87f8417081fda1412592a30e9893")
