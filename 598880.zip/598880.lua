-- Lua provided by SkyAPI 
-- Game: Domiverse
addappid(598880)
addappid(598881, 1, "608cc0dd562ff8caed61cd3d85d004131601edd60ce5734dbdca234b96377ba6")
addappid(598882, 1, "772c392f23e9da384e237b91adc6ef0927259e523cd66bfc8f615bc2083caa76")
addappid(598883, 1, "c22d7f14370cd0c1c24a628550a2004b62a9984c3c8820e6c8232db45f692d85")
addappid(813510)
