-- Lua provided by SkyAPI 
-- Game: MEMASIKI
addappid(3629210)
addappid(3629211, 1, "d672c6a88c35d9f0869360dd507a85f64f792a7fcc1567429e2129be6d3b3306")
