-- Lua provided by SkyAPI 
-- Game: Destiny of the World
addappid(1264790)
addappid(1264791, 1, "a9c2b0e948936c11050401ed5408be66f18cd8158ed46f7543423656e4385d91")
