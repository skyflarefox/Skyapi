-- Lua provided by SkyAPI 
-- Game: RUMP! - It's a Jump and Rump!
addappid(348160)
addappid(348161, 1, "8269992929378edb1230425822369c96537f1a5439665f0616b558452529af46")
