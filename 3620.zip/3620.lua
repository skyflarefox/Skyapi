-- Lua provided by SkyAPI 
-- Game: Zuma's Revenge!
addappid(3620)
addappid(3621, 1, "9ee6d5a509a1e506ec9631b44cfc944bf31221765ac1d5f10d4adc93ec61cd94")
