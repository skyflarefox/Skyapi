-- Lua provided by SkyAPI 
-- Game: Tequila Sunrise
addappid(1361260)
addappid(1361261, 1, "932932179edc3af19c65eec831ee7eca2b7a5ea18531c867ef8c83089ebbb975")
addappid(1361262, 1, "ea396baa8b7c72708ac923a127be83e6e93ef4d71fb2cfe439c996ba0ca5ce3b")
