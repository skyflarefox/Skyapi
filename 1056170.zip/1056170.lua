-- Lua provided by SkyAPI 
-- Game: SUPERVERSE
addappid(1056170)
addappid(1056171, 1, "88bea39f06ccb4023a36af06f468011d7fcdb4a2544ff5c5fc4a180678f8138e")
