-- Lua provided by SkyAPI 
-- Game: Absinthia
addappid(1848070)
addappid(1848071, 1, "c2f2dd75363dd2abb3d82907c88c92562aa721987d74c63ef61711e854a8ac53")
