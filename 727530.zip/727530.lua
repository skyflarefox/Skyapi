-- Lua provided by SkyAPI 
-- Game: Expelled
addappid(727530)
addappid(727531, 1, "982dc2b57f2719c8196645bd0ba93bb4baf15c7f9a30c205814363fc89d24638")
