-- Lua provided by SkyAPI 
-- Game: Spellweaver
addappid(429680)
addappid(429681, 1, "83261eb0656848c3fa32bf2f9306ef1e66871c8a44381ab9ad6ca2147c4d0010")
