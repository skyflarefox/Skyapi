-- Lua provided by SkyAPI 
-- Game: Regiments Demo
addappid(1313900)
addappid(1313901, 1, "87ae209ebe193081f534221fc36621e199e5da03244330d2de48c73ca68d51f7")
