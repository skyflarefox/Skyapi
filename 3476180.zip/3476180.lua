-- Lua provided by SkyAPI 
-- Game: Chlorofell
addappid(3476180)
addappid(3476181, 1, "f3fe17a4f43784295f26499a187d94d30b804df7a361ddb2934388d91e2342fd")
