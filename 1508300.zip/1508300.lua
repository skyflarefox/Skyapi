-- Lua provided by SkyAPI 
-- Game: OMORI Soundtrack
addappid(1508300)
addappid(1508301, 1, "81b70e44a08d789f079b60eeeabad4f2d100a95e3de7cf8ac62bef2512e76da0")
