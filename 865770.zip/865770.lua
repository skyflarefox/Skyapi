-- Lua provided by SkyAPI 
-- Game: Caffeine
addappid(865770)
addappid(865771, 1, "f0ca7f46d470a75cb8586e0d796e3909c118b9260410b9bf2cf259837ddd10ad")
