-- Lua provided by SkyAPI 
-- Game: Game Localization
addappid(1438940)
addappid(1438941, 1, "6a1a157f975fe22cb240ffd82dda46dd24b0e8e362deb7933034a665f56428cc")
