-- Lua provided by SkyAPI 
-- Game: Bard Idle
addappid(1803580)
addappid(1803581, 1, "2132e6ea79d0b392a67659caf62abcae1a1a51121f7c7f7ade23d4b735081616")
