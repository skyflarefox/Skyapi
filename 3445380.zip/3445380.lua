-- Lua provided by SkyAPI 
-- Game: Something Took Her
addappid(3445380)
addappid(3445381, 1, "7e414e8d08bb8aad0cf48efa67825e114e049e21d77b14928fd4a5e91c8f1369")
