-- Lua provided by SkyAPI 
-- Game: OMFG: One Million Fatal Guns
addappid(1555710)
addappid(1555711, 1, "a812e752bcf321fafa49029dcbded501f69727afaf47b818ac27d76a5cb3f717")
