-- Lua provided by SkyAPI 
-- Game: AppID 1497520
addappid(1497520)
addappid(1497521, 1, "d056721f6218812947511fd9b54d73ef4382c2abe9b3852d3de507aa9b3dc26c")
