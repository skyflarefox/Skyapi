-- Lua provided by SkyAPI 
-- Game: Last Sighting
addappid(3294620)
addappid(3294621, 1, "6826c68479ea6d6b514992b43c084510036451c89f5e0e560147aa404118eaba")
