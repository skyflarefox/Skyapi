-- Lua provided by SkyAPI 
-- Game: AppID 887720
addappid(887720)
addappid(887721, 1, "27042f0b9353a83d5f5650d2ef58741aa50cde4a136b7686b14a130616959f60")
