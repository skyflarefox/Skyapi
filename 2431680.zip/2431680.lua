-- Lua provided by SkyAPI 
-- Game: AppID 2431680
addappid(2431680)
addappid(2431681, 1, "8f3475dbf59cb54d430f76325cedc36a35bbec63ad5fda19fe554ad8044c4ce1")
