-- Lua provided by SkyAPI 
-- Game: Starry Nights : Helix
addappid(546180)
addappid(546181, 1, "ef9777f922228848cb53c60fc618b1bc99008de5e2bf9a2eb30b1b1906ecd80f")
