-- Lua provided by SkyAPI 
-- Game: Demonologist
addappid(1929610)
addappid(1929611, 1, "17c7cca3b4b0c06f525fe2745e8d2ff64f80b66ca39321e251d0a89c66dd6164")
