-- Lua provided by SkyAPI 
-- Game: Backrooms Exploration
addappid(1730930)
addappid(1730931, 1, "ed8eff423bbcde2e6e53bda4609a34d5a8d4298d12ab5b225ef7721119432525")
