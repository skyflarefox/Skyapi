-- Lua provided by SkyAPI 
-- Game: Tails of Iron
addappid(1283410)
addappid(1283411, 1, "9088237d7b955a99fcfb88a0fe335ea74903e34559c6e2fdcc8140a7612c9f85")
