-- Lua provided by SkyAPI 
-- Game: BANCHOU TACTICS
addappid(1981160)
addappid(1981161, 1, "d4341c26cb8f412f53409d56b3d9e9e666b0231f9e3e866c4298c4e1245c5e7e")
