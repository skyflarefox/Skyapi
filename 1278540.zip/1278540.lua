-- Lua provided by SkyAPI 
-- Game: AppID 1278540
addappid(1278540)
addappid(1278541, 1, "d21f5b076b6db9da7c37edfedf5a2ad0796b5dbbb932e64221e350380c0a6aba")
addappid(3379820, 0, "a7c2de730c281be6bfb6fe56721d89855b2de0ffd3b85c92a4ed0ccd3aa38649")
