-- Lua provided by SkyAPI 
-- Game: Bunker Invaders
addappid(2780470)
addappid(2780471, 1, "9f6fd8fe81cad0b0a76da19c447b4be1639cd14b8223fe65e50494f4da469830")
