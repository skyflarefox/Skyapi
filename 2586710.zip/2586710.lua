-- Lua provided by SkyAPI 
-- Game: Futanari Tales 💕🔞
addappid(2586710)
addappid(2586711, 1, "e7a2a101d563bc845dfacff78e67bce69307f5bc85afd1ae3dfea7a17d62a8b1")
