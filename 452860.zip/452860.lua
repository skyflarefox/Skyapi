-- Lua provided by SkyAPI 
-- Game: Mad Bullets
addappid(452860)
addappid(452861, 1, "e81809bef340afadf771a30cc757170257c611846cb7e884462914b6cd7ab55c")
