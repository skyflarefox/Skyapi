-- Lua provided by SkyAPI 
-- Game: AppID 1136870
addappid(1136870)
addappid(1136871, 1, "00c25f5411a3ceccc957fcc0f9d187c1a608fdcb47757908b49c2f57ab2dc25a")
