-- Lua provided by SkyAPI 
-- Game: Niktophobia
addappid(2398680)
addappid(2398681, 1, "75f299f74364e98706fcb69e2fe5234d60ea1055c35857b52a27228ac3f419b3")
