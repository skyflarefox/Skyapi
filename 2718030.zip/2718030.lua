-- Lua provided by SkyAPI 
-- Game: Sea under the sea under the sea
addappid(2718030)
addappid(2718031, 1, "1582f2f993b8eb933943dfcbec842f0ddcf403f652ab73f131f58323fce739a4")
