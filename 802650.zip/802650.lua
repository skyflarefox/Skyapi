-- Lua provided by SkyAPI 
-- Game: AppID 802650
addappid(802650)
addappid(802651, 1, "0f3d141fda2046b66aa0c4045289391b4935d656e882adccc9a785d698aea572")
addappid(805510, 0, "5cf10a284b2abad6cf92a91f2c938921bbccb06c02bc9edd9136f212527a7265")
