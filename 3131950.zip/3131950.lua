-- Lua provided by SkyAPI 
-- Game: AppID 3131950
addappid(3131950)
addappid(3131951, 1, "501abf945ea576d34696753d6f0629855b693a4d731a8a9a1cfd618c363dc171")
