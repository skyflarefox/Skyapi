-- Lua provided by SkyAPI 
-- Game: She Will Shoot
addappid(1753790)
addappid(1753791, 1, "d88d43e224731319693048f0cf5810a45162a87e9d1276a9eeb1103266fc8df1")
