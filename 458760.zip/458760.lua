-- Lua provided by SkyAPI 
-- Game: AppID 458760
addappid(458760)
addappid(458761, 1, "e2ef80f1699d8267fb75d7b3abc4d36d568eb76c036ad8c42467e5e2ebf34124")
