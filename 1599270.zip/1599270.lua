-- Lua provided by SkyAPI 
-- Game: AppID 1599270
addappid(1599270)
addappid(1599271, 1, "97386e1105cbc2991ce4846d7aeb4c65ed78608f828e99031a75e8e3b4e6545a")
