-- Lua provided by SkyAPI 
-- Game: Miko Gakkou: Second Year
addappid(331290)
addappid(331291, 1, "07356931333434b06841d7d6863889b5269177fe191a62f380e7aee14f602939")
