-- Lua provided by SkyAPI 
-- Game: Anno Online
addappid(336510)
addappid(336511, 1, "bcac9025daaa4709134c5c9ca6be71429ce1e4a9cdc23db94c6a002fbb21db5b")
addappid(336512, 1, "6708a550aa91b6f08eca6e5ce2f14690599d2696ca266d23d51fcb3a15fb452a")
addappid(336513, 1, "cfff839ce4b4d62ebfca505b63fcd56f119b900e16df270f3d71f286bfaf8c32")
