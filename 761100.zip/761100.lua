-- Lua provided by SkyAPI 
-- Game: Jump! Jump! Jump!
addappid(761100)
addappid(761101, 1, "5f74d9dc37a1d94decfc8486e16afa0b7cc482c121942d1d8dbe45cb30aece24")
addappid(793330, 0, "ecc7265d67384e70b20307141682fc0fec1e01559310c9848baa50fc93411086")
