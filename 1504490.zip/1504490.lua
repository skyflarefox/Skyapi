-- Lua provided by SkyAPI 
-- Game: bridg
addappid(1504490)
addappid(1504491, 1, "4198fd98bd83aa665bd371f867579bb8c28bfdf0109e06d9a574064500f2887e")
