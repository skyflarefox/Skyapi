-- Lua provided by SkyAPI 
-- Game: AppID 561970
addappid(561970)
addappid(561971, 1, "21d9066a708a2f36d5d64d72f82ab8d660b9fef5c702ee9c1336eea72a072d1a")
