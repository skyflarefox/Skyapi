-- Lua provided by SkyAPI 
-- Game: AppID 1209410
addappid(1209410)
addappid(1209411, 1, "7af6081af1c233f9443cdbfdeefe9aae2f393706abe584b8366adad3834ac05f")
