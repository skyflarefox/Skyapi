-- Lua provided by SkyAPI 
-- Game: C.A.R.D.S. RPG: The Misty Battlefield - Original Sound Track
addappid(2684330)
addappid(2684331, 1, "fc2a9d3f50f95b4a42414b3f6a86b4808432e687ec228af6e0351053cf988d47")
