-- Lua provided by SkyAPI 
-- Game: BOKURA: planet
addappid(3126150)
addappid(3126151, 1, "a1229d225c3d9ff8b5910f0c023a48eddb981d3d45ea1bd4b13c9d63868c9950")
