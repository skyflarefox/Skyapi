-- Lua provided by SkyAPI 
-- Game: LOST EPIC
addappid(1426490)
addappid(1426491, 1, "4f03c981cb3de5cf826d1ad57de0ebb52a091bfedfc8cf4472a073314f91d7f9")
