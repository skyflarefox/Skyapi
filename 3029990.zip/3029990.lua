-- Lua provided by SkyAPI 
-- Game: Girls on Campus, from Freshmen to Faculty, All Fall for Me!
addappid(3029990)
addappid(3029991, 1, "67f56b5fbff43888a3b8333cbf8d02c30c55f3611de0e82fb9204f61d865ff08")
