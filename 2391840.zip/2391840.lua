-- Lua provided by SkyAPI 
-- Game: NejicomiSimulator TMA01
addappid(2391840)
addappid(2391841, 1, "3d8686206e4915319f0c67a0509fc419791520e722e6bfee22211d41c727ef54")
