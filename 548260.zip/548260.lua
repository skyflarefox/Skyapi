-- Lua provided by SkyAPI 
-- Game: Backfire
addappid(548260)
addappid(548261, 1, "ca1768fdb68b19eba9a520e771797dd6fa177b98a21c07af6aefeb820e2cd7d7")
