-- Lua provided by SkyAPI 
-- Game: Runa Illustra
addappid(2854360)
addappid(2854361, 1, "fd4f87779e04e8fe198f42557aa78e7e1029233155933c2be9a9fa49d0305009")
