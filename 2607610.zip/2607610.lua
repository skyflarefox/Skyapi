-- Lua provided by SkyAPI 
-- Game: Polygon Arena
addappid(2607610)
addappid(2607611, 1, "2ca51c6c22abc7fbe6ee9c363aab762c13d0b09ad441e37b9dd8b274b78f8643")
