-- Lua provided by SkyAPI 
-- Game: Hexa Path
addappid(1052760)
addappid(1052761, 1, "88b2a78ef98fa30b79e729712a6938a4e895358b4b4b4ee7cfe76b796251d5cb")
addappid(1052762, 1, "05c4a2e14549d7299ecf508792c76ecfaadb0d9199c7aa2c71d77ef3d349acb6")
addappid(1055790)
