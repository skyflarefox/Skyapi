-- Lua provided by SkyAPI 
-- Game: AppID 1036120
addappid(1036120)
addappid(1036121, 1, "cc73bf5687484b054156d350182de714cc0f63b9571f1f04d3a3b507c48fac0b")
