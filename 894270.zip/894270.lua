-- Lua provided by SkyAPI 
-- Game: Beware of Trains
addappid(894270)
addappid(894271, 1, "2f965968678ba9006a185fa02f59bdb194f01f94363ae11ea6c84ee4bb0e7d93")
