-- Lua provided by SkyAPI 
-- Game: AppID 2754200
addappid(2754200)
addappid(2754201, 1, "7636fbc0343c3dd00b6366f47872224816b322ea9a4258b580b377f15ab3cfab")
