-- Lua provided by SkyAPI 
-- Game: Void Collector - Snow Day Demo
addappid(3410130)
addappid(3410131, 1, "f581e2ef5241179970ab8d2fc3f0ffc873363cc5783d44bb7b7cbc0c60cc9875")
