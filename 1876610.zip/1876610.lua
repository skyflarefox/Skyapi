-- Lua provided by SkyAPI 
-- Game: Verne: The Shape of Fantasy Demo
addappid(1876610)
addappid(1876611, 1, "10a708aaa538bdbd6c31b6b338994a67b32935ee2f99aff937a59bcc96366007")
