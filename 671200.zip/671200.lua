-- Lua provided by SkyAPI 
-- Game: AppID 671200
addappid(671200)
addappid(671201, 1, "930c958c05d9b4ce781697dae98eb69064961a14785dbf2082760daf4853309d")
