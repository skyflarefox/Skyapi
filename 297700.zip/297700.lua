-- Lua provided by SkyAPI 
-- Game: AppID 297700
addappid(297700)
addappid(297701, 1, "2bd565ffaa1a77e35153b9315656822ded6abb8fa37ddae1010a2d0a04e0ce97")
