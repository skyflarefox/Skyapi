-- Lua provided by SkyAPI 
-- Game: AppID 874930
addappid(874930)
addappid(874931, 1, "9bcb3910156ab37ade106d90897f5bc6abf7e6c0b30051fa50b9f6e4af769518")
