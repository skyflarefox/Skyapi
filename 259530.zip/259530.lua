-- Lua provided by SkyAPI 
-- Game: Savant - Ascent
addappid(259530)
addappid(259531, 1, "7973ef250d5b698a5c28361c07b97a589d05cabead4114d6894808a2490fa763")
addappid(259532, 1, "dd99f8b4fa6272c560de391923b16391616248bfbfa97e905bf46ea4de49c154")
addappid(259533, 1, "514c13f801b71e8c69d1be6f274ae038bec19154f6d92fd696103b58f5bf51f7")
addappid(656760)
addappid(656810)
addappid(657270)
addappid(657360)
addappid(657361)
