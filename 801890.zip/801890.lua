-- Lua provided by SkyAPI 
-- Game: Christmas Race 2
addappid(801890)
addappid(801891, 1, "47e2c848b07a3d13a48377f39789b7c9eac49aed4ac03e3ed3d6f7a06af1c08b")
