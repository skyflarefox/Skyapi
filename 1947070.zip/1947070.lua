-- Lua provided by SkyAPI 
-- Game: Broken Edge
addappid(1947070)
addappid(1947071, 1, "13f2d30285532ba2d6915154b9985dba46aee333ab227e30845ea035f19b737f")
