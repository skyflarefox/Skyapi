-- Lua provided by SkyAPI 
-- Game: Get Tanked!
addappid(1679800)
addappid(1679801, 1, "2807fd433a05e161b30774b451dde49babd6c9942ce0c745094938104b80c4a7")
