-- Lua provided by SkyAPI 
-- Game: Endlanders : First Encounter
addappid(2010450)
addappid(2010451, 1, "f8e4fb669272b97bece7edf64d29b67f71d6e60bfcc11172c9a7cb5f26626c7f")
