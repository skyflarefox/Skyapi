-- Lua provided by SkyAPI 
-- Game: Tribute
addappid(3453360)
addappid(3453361, 1, "47efc1103e385a139c9e406c6cc566e5bf71df331cd91e580bf5977b3dd0b0b3")
