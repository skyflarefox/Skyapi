-- Lua provided by SkyAPI 
-- Game: Clash of Castle
addappid(787250)
addappid(787251, 1, "5579ccda97b0f649f403e47f050b2801f9ff0facff536a97f9882aede42fabf9")
