-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(977720)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(977721,0,"dd0736bb8b095b2a17ac137d03ee3855b06a7fbe60f2ebb4a9b0f6cc0e3c65b5")
setManifestid(977721,"4612923825224505954")
addappid(1127600,0,"179add4605b52e0cbca81fed1e5f2819a5f7bc69bdf719afc7debd061542df96")
setManifestid(1127600,"6380967032382018983")
addappid(1230190)