-- Lua provided by SkyAPI 
-- Game: AppID 1121420
addappid(1121420)
addappid(1121421, 1, "726e12848fd329a4db013eb0b519b3d79f0e072c21b517934f11cd0ae6c5c085")
