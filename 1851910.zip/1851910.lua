-- Lua provided by SkyAPI 
-- Game: A Flicker of Light
addappid(1851910)
addappid(1851911, 1, "bfd8d56213121a5cbeb6a5c3a3a82b33d438117fe52633b919292a61e1105d34")
