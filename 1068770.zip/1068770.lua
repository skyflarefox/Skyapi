-- Lua provided by SkyAPI 
-- Game: The Tower - The Order of XII
addappid(1068770)
addappid(1068771, 1, "cc7919ddc8458d05328f4d51dccaf654828a705bd9f60344d070abf29394b1bc")
