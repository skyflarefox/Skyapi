-- Lua provided by SkyAPI 
-- Game: AppID 1099500
addappid(1099500)
addappid(1099501, 1, "b7d2e3e52d67b9b7197c149bfe997777ce26c068c15264d5f421d9b26c62464d")
