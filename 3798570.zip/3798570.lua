-- Lua provided by SkyAPI 
-- Game: Capcom Fighting Collection 2 - Vol.4(Power Stone2 ver.2K25)［Original Soundtrack］
addappid(3798570)
addappid(3798571, 1, "1daf69e755a9c9f4176c8212858e53cf5dc989d468b23775fbc17afc70d97b18")
