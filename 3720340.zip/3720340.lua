-- Lua provided by SkyAPI 
-- Game: your wife, mother and daughter
addappid(3720340)
addappid(3720341, 1, "faf3e011c1cf43d15dd428305db68c7c70d8de9b992183daee8305f1cca2e994")
