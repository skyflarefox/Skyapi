-- Lua provided by SkyAPI 
-- Game: Paw Patrol: On A Roll!
addappid(758730)
addappid(758731, 1, "3c5826f5cbacf859082e89706ae3b2cde1318f999daca9bada4d1a57a9b6c364")
