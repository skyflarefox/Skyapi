-- Lua provided by SkyAPI 
-- Game: My Dangerous Life
addappid(1253580)
addappid(1253581, 1, "630c528b38f23b8511609f19494f7fcd3ca3c042b5bbcb66588b721b10932ddb")
