-- Lua provided by SkyAPI 
-- Game: AppID 752490
addappid(752490)
addappid(752491, 1, "b9c26d676a87a2adb2d21013bcd98bd7412c0e146c88e9a8761d1f9a185171d2")
