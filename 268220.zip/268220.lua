-- Lua provided by SkyAPI 
-- Game: Meltdown
addappid(268220)
addappid(268221, 1, "0953666b7fd5e0c661565dd2c11d129f3c6098ae3fb7e8c526afe71c1bdc61f4")
addappid(268222, 1, "2f536d7e978e1d8b75c0ee9f58751c95dc5b7ef76b57b52e7ad59c0a295b1d21")
addappid(268223, 1, "398ddcfa6c6008456a00623a16e10415b39aa615606b30a685f5cd4b35fc7cf4")
