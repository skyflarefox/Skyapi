-- Lua provided by SkyAPI 
-- Game: Love Esquire - RPG/Dating Sim/Visual Novel
addappid(849740)
addappid(849741, 1, "f54af8a462993921ff5eab9b4812376dc256c871a55ae0065939fa0539eb00c1")
addappid(1173031, 0, "3953b9ddd5037162913e78b18b772bb2215e79f4d520a79eba2aa92d18243ae3")
addappid(1173050, 0, "f51e85f4794aee66d2a9c6321dd224a0b666dfbbdcb79b2a9e84e4ac54dc85f3")
addappid(1503230, 0, "038744379636de298a939f99cff28a8defc4d7335c2a475a961e81b768559713")
