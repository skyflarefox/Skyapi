-- Lua provided by SkyAPI 
-- Game: Armchair Commander
addappid(2598940)
addappid(2598941, 1, "bb26403d3b87649687ea44e5d8996eac0e4d65271cb9c24aac9e242e1283c1f1")
