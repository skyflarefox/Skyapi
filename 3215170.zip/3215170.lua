-- Lua provided by SkyAPI 
-- Game: NEEDY STREAMER OVERLOAD: Typing of The Net
addappid(3215170)
addappid(3215171, 1, "983ceef418a421992aa7d6d884623b194adade1c6fcd2e42d12719632356d21f")
