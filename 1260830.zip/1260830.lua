-- Lua provided by SkyAPI 
-- Game: Metallic Metronome
addappid(1260830)
addappid(1260831, 1, "86c4a57cc1378727ad95246b38778d8b4f768b7f4628a94785d12ca02a50a2c3")
