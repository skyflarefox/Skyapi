-- Lua provided by SkyAPI 
-- Game: Royal Quest
addappid(295550)
addappid(295551, 1, "7eb1a222e6678c549fc2f4cb75bd93f0b08bfab98785ef66d43610daa75b894e")
addappid(295552, 1, "d44104399f95cf5ed2265d04309d98924dfc67e61222b94760bc53b8a8811f74")
