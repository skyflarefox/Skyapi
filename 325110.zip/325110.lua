-- Lua provided by SkyAPI 
-- Game: Save the Furries
addappid(325110)
addappid(325111, 1, "005443c0e21e79883e6bd16fe6e70109b033c4188e1c4070cc2291e2c290ddcf")
