-- Lua provided by SkyAPI 
-- Game: Cellveilance-4K
addappid(3473290)
addappid(3473291, 1, "12fda598f18084cc80b235ceed79c764d5002485aa7b6c0ec451ccc8d379b257")
