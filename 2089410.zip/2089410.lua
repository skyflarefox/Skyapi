-- Lua provided by SkyAPI 
-- Game: AppID 2089410
addappid(2089410)
addappid(2089411, 1, "49029e5a0b79ee9806a3b3bb83208197a7182aa83684ed8d81bb7be89b0d2ab6")
