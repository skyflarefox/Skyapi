-- Lua provided by SkyAPI 
-- Game: AppID 2300410
addappid(2300410)
addappid(2300411, 1, "42c7afbdb920fd57db4c89630c47dc5ab8195bd35b7797152f59d7ea43a695c1")
