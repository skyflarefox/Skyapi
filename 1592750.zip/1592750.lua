-- Lua provided by SkyAPI 
-- Game: Anode Heart
addappid(1592750)
addappid(1592751, 1, "19394723d56e6c05bf076d51f1c3f4325ffbd0a0cccf5fc9fec54174bc937c1c")
