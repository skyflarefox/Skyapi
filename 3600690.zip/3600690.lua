-- Lua provided by SkyAPI 
-- Game: Midnight GT: Primary Racer
addappid(3600690)
addappid(3600691, 1, "c85889b8921e099724fbc94e87d126815c0c8e15e3f855e12e8e5afe56c2336f")
