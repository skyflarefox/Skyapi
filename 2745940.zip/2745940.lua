-- Lua provided by SkyAPI 
-- Game: AppID 2745940
addappid(2745940)
addappid(2745941, 1, "af87399038163685b1bbc5980275a766ca69412a33ae88567afd531706f437a2")
