-- Lua provided by SkyAPI 
-- Game: Girls Guns and Zombies
addappid(1580480)
addappid(1580481, 1, "fb75b3401c263bf6cd4b4d10ece648021ccbb68dba5056bca5ae782a6591d3f3")
