-- Lua provided by SkyAPI 
-- Game: Miner Ultra Rag Smash
addappid(1427480)
addappid(1427481, 1, "9fc3c796417b70a0940d12a8b868832f94b26312be9754c1bc18c16549f1548d")
