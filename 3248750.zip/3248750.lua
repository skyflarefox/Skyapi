-- Lua provided by SkyAPI 
-- Game: AppID 3248750
addappid(3248750)
addappid(3248751, 1, "eaced425cecb1abaffd1bde8a89865ce716d31ea17eda307002682b0c7c5cab1")
