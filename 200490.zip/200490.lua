-- Lua provided by SkyAPI 
-- Game: Memento Mori
addappid(200490)
addappid(200491, 1, "36fc06e90d4ef2bcabac46a367a76f0e67ff837cdddb0e0b63d968bcc7eab1c6")
addappid(200492, 1, "b7e9f3de260deb197838746293a62ed99b8f7e9c3379307e31dd1aaf69a4a6fb")
addappid(200493, 1, "3fbb042c54df4f40887431cf410c9ee3dc6d6c96dda49383d9adf7f6badd23a6")
addappid(200494, 1, "dba6db82e5c835d70651208c9f4b27054c8c44d831b7f6d035e6e8d180abae6a")
addappid(200495, 1, "6bb942377bf2caac0072d1ad67c9edbd4712488e3d6d870d3c7b4b388e5525ff")
