-- Lua provided by SkyAPI 
-- Game: AppID 3165410
addappid(3165410)
addappid(3165411, 1, "5bb8d75eb4dcee9afa1ac69661f886f6c5344970e227ebbfb4c4b7c9991c9972")
