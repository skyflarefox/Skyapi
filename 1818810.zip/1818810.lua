-- Lua provided by SkyAPI 
-- Game: Maze Art: Purple
addappid(1818810)
addappid(1818811, 1, "d3a762e822b40be9f50f740c5236240e44f55b370a805e98ed7a10f3c3cd5698")
