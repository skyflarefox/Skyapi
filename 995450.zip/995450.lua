-- Lua provided by SkyAPI 
-- Game: Geeksos
addappid(995450)
addappid(995451, 1, "f2d38ffec75b87766853ce99f1245208f2852a2d18e009b5acc70df12b9b4f5c")
