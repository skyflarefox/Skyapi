-- Lua provided by SkyAPI 
-- Game: Angelstruck
addappid(2576460)
addappid(2576461, 1, "d6fde851f8919b4662afa057725a6a0798a73b2ee51fc8889e073c8f91ed27ad")
