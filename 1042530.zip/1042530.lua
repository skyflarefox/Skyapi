-- Lua provided by SkyAPI 
-- Game: POWER
addappid(1042530)
addappid(1042531, 1, "f61fe3a016e5db1f4720efe3e6b2549e17c6e4533ed9d133bc4cf055ee050e42")
