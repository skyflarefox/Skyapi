-- Lua provided by SkyAPI 
-- Game: 回纹平台跳跃
addappid(1409600)
addappid(1409601, 1, "a3cb0ee8b7c19beb7178623a08e2efaa9d136c6e01f943434f51d2769a991d25")
