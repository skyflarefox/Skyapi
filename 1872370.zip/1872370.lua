-- Lua provided by SkyAPI 
-- Game: BLIND dreams Demo
addappid(1872370)
addappid(1872371, 1, "ebfd276d327131b47b0bab606031681996fdaae2087cd1997808962551221acb")
