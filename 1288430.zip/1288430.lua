-- Lua provided by SkyAPI 
-- Game: AppID 1288430
addappid(1288430)
addappid(1288431, 1, "787cde0ea9bbc7392c644f8a1a193f8c10e50f5556cdafa8d5430dcf9a13c900")
