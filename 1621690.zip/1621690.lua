-- Lua provided by SkyAPI 
-- Game: Core Keeper
addappid(1621690)
addappid(1621691, 1, "a2bb442f3eecb2b4c84232418b1d1b417a033b4c3ec1dca7caa4943d477026af")
