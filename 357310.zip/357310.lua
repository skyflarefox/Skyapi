-- Lua provided by SkyAPI 
-- Game: Oriental Empires
addappid(357310)
addappid(357311, 1, "bcf05698fa4e83f7406c997a27f6f01d60c1d31b3ef3b73ac0267ab4d99a2670")
