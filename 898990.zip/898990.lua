-- Lua provided by SkyAPI 
-- Game: Philosophic Love－Original Soundtrack
addappid(898990)
addappid(898991, 1, "2ddcc371616c01ba8ff431e90696c3912e8bc52cbf31ab2f76ff9aabb557444f")
