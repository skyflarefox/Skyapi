-- Lua provided by SkyAPI 
-- Game: AppID 2861940
addappid(2861940)
addappid(2861941, 1, "c6575d6a06fd37d3ca2b13b75fbdae8b48c6990e33b2ac280839ec69a7eda4cf")
