-- Lua provided by SkyAPI 
-- Game: AppID 673140
addappid(673140)
addappid(673141, 1, "33b77b082f7becb97ed7d685dcb6a9949b27434219dd3c43d99489a14e952639")
