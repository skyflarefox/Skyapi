-- Lua provided by SkyAPI 
-- Game: Punishment NyanNyan
addappid(2860950)
addappid(2860951, 1, "036ccbd25aa768b32d1e1e863c267761c3f081a727e2dea3e879d1858ee0c766")
