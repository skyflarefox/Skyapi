-- Lua provided by SkyAPI 
-- Game: Subluminal
addappid(1594110)
addappid(1594111, 1, "02426ca97f44273c567537a06bd397ce9c9ebb453d9b9cf924a7defece4d0300")
