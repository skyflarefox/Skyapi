-- Lua provided by SkyAPI 
-- Game: AppID 345090
addappid(345090)
addappid(345091, 1, "438c6c6b137cd525118cb067e2d4150790bd2917b14c0aac7df3a892632fe16c")
addappid(345092, 1, "c96b2e0f25df5b9d814fe2cc35f962204892ad0485d6e6d03d4a5f98563542af")
