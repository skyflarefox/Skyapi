-- Lua provided by SkyAPI 
-- Game: Fish Shop Simulator
addappid(3298720)
addappid(3298721, 1, "3a588c3230c008e9b4e2146d016f727727c257b4b6b89da44a23338f18ea14cf")
