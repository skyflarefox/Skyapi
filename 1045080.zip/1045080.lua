-- Lua provided by SkyAPI 
-- Game: Curious Cases
addappid(1045080)
addappid(1045081, 1, "7be8f7d7fb090af02429d98129d64770a2807c89f0a4523d60d7ab0d46556808")
