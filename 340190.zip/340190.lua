-- Lua provided by SkyAPI 
-- Game: Night Crisis
addappid(340190)
addappid(340191, 1, "df3291ba28990177e41625bf85130e6789b3edddd05cfa5b7f70089209b2b223")
