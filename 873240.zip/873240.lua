-- Lua provided by SkyAPI 
-- Game: AppID 873240
addappid(873240)
addappid(873241, 1, "d1c43a0f66e114fd86783492918d8d0482faae96a28823c853d2921175b88527")
