-- Lua provided by SkyAPI 
-- Game: Hotel Owner Simulator Demo
addappid(3468150)
addappid(3468151, 1, "d4a56509e57622b56f2ae6cc468495166bb3368b3086712e8f3a56fd1b58e335")
