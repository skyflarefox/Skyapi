-- Lua provided by SkyAPI 
-- Game: DYSMANTLE
addappid(846770)
addappid(846771, 1, "c345ec3e46cd18e15a4f18b0c8e1c099ab995829330b6a66d5a8f47894be732f")
