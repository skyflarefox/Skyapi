-- Lua provided by SkyAPI 
-- Game: SCORCH
addappid(1606580)
addappid(1606581, 1, "a52fd41dd35e861c67ca09ff72d12306596457194ca9ae94e2d57ba8e7a22896")
