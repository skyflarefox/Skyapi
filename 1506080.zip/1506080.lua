-- Lua provided by SkyAPI 
-- Game: Fuzz Dungeon
addappid(1506080)
addappid(1506081, 1, "554aeb079341ffc10ddb3f55246531a2965b6a11db79ed38fd097ff4f604dd7b")
