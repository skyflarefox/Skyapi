-- Lua provided by SkyAPI 
-- Game: Pretty Angel
addappid(1148510)
addappid(1148511, 1, "e854d22769c53ac99653fae14949796487dfba3870da7c830662d722a336acc8")
addappid(1195990, 0, "936a88cc255d57e7f207f626a7f79a3eed06123f2080e34e28faa7425059cb1a")
