-- Lua provided by SkyAPI 
-- Game: Mazepocalypse
addappid(2553180)
addappid(2553181, 1, "5a79696b3c9033504bf9bd31141e9b32f079a3816a2719e5f0cdc2af5d194864")
