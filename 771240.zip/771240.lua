-- Lua provided by SkyAPI 
-- Game: YumeCore
addappid(771240)
addappid(771241, 1, "1a0ed92dd34b41b12f8c0e7e5e2efb26be1284b5056bdc23408da816fd8cce73")
