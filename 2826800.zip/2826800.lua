-- Lua provided by SkyAPI 
-- Game: AppID 2826800
addappid(2826800)
addappid(2826801, 1, "e0d7d9f87ac41ba6feaea2ac279cd90853990f9df6fccb2308e58d5a0eae1533")
