-- Lua provided by SkyAPI 
-- Game: Eremidia - Archivist's Curse
addappid(2077550)
addappid(2077551, 1, "772253432d8310b1d7586ddfa95d1d95b5c505e3171303eb1d60b15bdd567c5d")
