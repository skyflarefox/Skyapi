-- Lua provided by SkyAPI 
-- Game: Syberia: The World Before
addappid(1410640)
addappid(1410641, 1, "b0484403336404a568c289234bdcc12b055e42f8d0a10764f947281a11ac67b0")
addappid(1724920)
