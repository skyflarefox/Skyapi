-- Lua provided by SkyAPI 
-- Game: Bounty of One
addappid(1968730)
addappid(1968731, 1, "653961ccb71f520811a5539d5876483977189cb87e7603d5b363ff8740d96426")
addappid(2900140, 0, "b219759bad0b202c84f226553ea7ea6db657186eb3c9e4850c75c7c369d65dac")
