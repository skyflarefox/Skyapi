-- Lua provided by SkyAPI 
-- Game: AppID 1128810
addappid(1128810)
addappid(1128811, 1, "9ccb2ca7005a41c1f75d8ac291405a92f2b86bc6c67d12bfe10c8c6e716cf703")
