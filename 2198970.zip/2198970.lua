-- Lua provided by SkyAPI 
-- Game: Land of Towers
addappid(2198970)
addappid(2198971, 1, "d300b501c9e295ef7a86d49aac3d75a22dc3af3f41c71f52a02ae0c3802142cc")
