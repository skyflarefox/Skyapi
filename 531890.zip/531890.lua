-- Lua provided by SkyAPI 
-- Game: AppID 531890
addappid(531890)
addappid(531891, 1, "87804ec6a2a40a6ae33b470ab8eac7edc03dcebc0f3eb662d94a25b7eab4a39e")
