-- Lua provided by SkyAPI 
-- Game: AppID 2515210
addappid(2515210)
addappid(2515211, 1, "b6c4750d9faba5987189c185195617b7d70e3efa7808a8f481279b449305df48")
