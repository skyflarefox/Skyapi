-- Lua provided by SkyAPI 
-- Game: Pixel Cafe
addappid(2409360)
addappid(2409361, 1, "62635b492772cf0976355d530651f351dbbdec37f293336346535e3a404d3f2d")
addappid(3247110, 0, "65bab8b8e26412988820d5816e822c48ef0a4ec18f4e4c838cb1c7efc83c0616")
