-- Lua provided by SkyAPI 
-- Game: Lil Johnny Goes Home
addappid(2486400)
addappid(2486401, 1, "bdca5203948f967d96d8d5b12cc3b657c46fb2da4ba9a62d6f06d5c9a7da40af")
