-- Lua provided by SkyAPI 
-- Game: Image
addappid(2193380)
addappid(2193381, 1, "b45b4893d2ab2d432221cd6782f86b76bbe08e616c21845926803b00b3036c58")
