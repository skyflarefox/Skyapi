-- Lua provided by SkyAPI 
-- Game: Kogarashi
addappid(2010170)
addappid(2010171, 1, "eabc855bb135fc9f5c22f90e3a416b5a0c59188e0af0da58faf8686fcf395aed")
