-- Lua provided by SkyAPI 
-- Game: AppID 1100720
addappid(1100720)
addappid(1100721, 1, "a1fa7154bb3944b338b0a4d3968de6999cbeebd4378347dde19aae7fc489a13c")
addappid(1100722, 1, "9be2edd85fea15862d26e975781b67091defb71afca3c0345d52d32c7e79cf74")
