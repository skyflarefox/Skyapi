-- Lua provided by SkyAPI 
-- Game: Magic Borderless
addappid(1022230)
addappid(1022231, 1, "0cb12a745d788fe018c5b348b2b4feaeef10797245c3652d345138b9a63f02ba")
