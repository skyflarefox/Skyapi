-- Lua provided by SkyAPI 
-- Game: War of Wizards
addappid(2009460)
addappid(2009461, 1, "05a8e81700e47a3c1ce9bef4fd8c8ad95329d76e93a07bdbaed355bd5d1941a3")
