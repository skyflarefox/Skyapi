-- Lua provided by SkyAPI 
-- Game: Malignant Survivors
addappid(2783610)
addappid(2783611, 1, "03aaf63f91db64d853f421a5ebd04a91a9f5834581ff5853c2aab6c8170e69df")
