-- Lua provided by SkyAPI 
-- Game: Raiden III Digital Edition
addappid(315670)
addappid(315671, 1, "8618f56348c4466803cd62ac10a446a199c09265330c6eebfe76fc5e9799504e")
