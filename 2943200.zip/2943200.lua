-- Lua provided by SkyAPI 
-- Game: Dr. Murph
addappid(2943200)
addappid(2943201, 1, "450e8c80cfa66811618dbce42284999478bf9b03ab8e9f7246a56b32562c8e18")
