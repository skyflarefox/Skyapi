-- Lua provided by SkyAPI 
-- Game: VR Ping Pong Pro
addappid(1029730)
addappid(1029731, 1, "5ad38136b6952e8b3894f097f700d3b1c1757cf3f57e384d220dffe207ca8a73")
