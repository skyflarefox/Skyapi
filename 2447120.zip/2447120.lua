-- Lua provided by SkyAPI 
-- Game: AppID 2447120
addappid(2447120)
addappid(2447121, 1, "e08a419241f28c016e9bb88a00e1f10ab7c6903f6c4b3f5d309442efc76d7ba3")
