-- Lua provided by SkyAPI 
-- Game: Wolcen: Lords of Mayhem - Original Extended Soundtrack
addappid(1254730)
addappid(1254731, 1, "1c2290d4f291c5c7d1e4bb82faee823b97ff937b1fca5cd2ffc196421276dec8")
addappid(1254732, 1, "d9b1c0d1ed1227e8146cf74fec599e0a1ecbdce3f8e4f4a999770c73eafe62f1")
