-- Lua provided by SkyAPI 
-- Game: Three Kingdoms：Ancient battlefield | 三国古战略
addappid(985020)
addappid(985021, 1, "d7f29ceed1aabebed7bc4539df0066c8c6796bea0c1a0ea212d299ca58824cea")
