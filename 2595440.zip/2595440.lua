-- Lua provided by SkyAPI 
-- Game: Testimony of HELP
addappid(2595440)
addappid(2595441, 1, "7441583975099227f1692e5996d4569681142116d3a1f8d37731c84b709bf7d1")
