-- Lua provided by SkyAPI 
-- Game: Feed the Deep
addappid(2332260)
addappid(2332261, 1, "ddaa9aa06c57167a0b2212b012c30021a24faee3ce0e0603bf5907092bb42191")
