-- Lua provided by SkyAPI 
-- Game: Deadbeat Heroes
addappid(614090)
addappid(614091, 1, "c891ed4f9e838d93c30e3898bf6a891a59afbe7ef5b6303f5a28fd66d3b7fca0")
addappid(614092, 1, "1e1b228db06910c96d00f7ea5bfb7e71bc6e6ea52c1a5ce21ef490ff0297b761")
