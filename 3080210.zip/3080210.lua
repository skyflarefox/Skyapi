-- Lua provided by SkyAPI 
-- Game: AppID 3080210
addappid(3080210)
addappid(3080211, 1, "38ffe9dc78feef153c36bd0e0f63eef6ed575e5f21cad53b09a0db469fc658fa")
