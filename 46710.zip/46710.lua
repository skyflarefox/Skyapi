-- Lua provided by SkyAPI 
-- Game: Ironclads: High Seas
addappid(46710)
addappid(46711, 1, "282fb43aa58d2c28405f1f681284a8ec9ebc14c60638e7eff0a492f14f536e4a")
