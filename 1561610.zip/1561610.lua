-- Lua provided by SkyAPI 
-- Game: AppID 1561610
addappid(1561610)
addappid(1561611, 1, "5d518d9323fe9278f8700e466a39551cd0eecb552d23e7102c006f420d192854")
