-- Lua provided by SkyAPI 
-- Game: Race & Destroy
addappid(466210)
addappid(466211, 1, "85f99dbdd1072ecdc91eec7f8cc2dceacd2b4a059699db0b33ad5a4b9178402b")
