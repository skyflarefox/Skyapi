-- Lua provided by SkyAPI 
-- Game: Sprint Vector
addappid(590690)
addappid(590691, 1, "9d2aabc21b774883c5fe6725558bb734d9a18ceda67a6282da54179d55433eb6")
