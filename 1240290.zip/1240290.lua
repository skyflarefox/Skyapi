-- Lua provided by SkyAPI 
-- Game: Infestation: Battle Royale
addappid(1240290)
addappid(1240291, 1, "78af79c864f62ee2c9532f77d09e1f9e650c764bd5826928609cacb9d2d3a254")
