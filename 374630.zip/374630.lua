-- Lua provided by SkyAPI 
-- Game: AppID 374630
addappid(374630)
addappid(374631, 1, "101b393b02b060e4b5a43c7e099224228b723391516c86e3490300d30662030a")
