-- Lua provided by SkyAPI 
-- Game: Road Rage
addappid(499210)
addappid(499211, 1, "39921ace9fdacf652caf29d0560a7f7ae739601ff7b29ebec6061afa5b7715d3")
