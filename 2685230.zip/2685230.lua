-- Lua provided by SkyAPI 
-- Game: AppID 2685230
addappid(2685230)
addappid(2685231, 1, "d71605ec7e4cfab0063ceede96c35461bb41469034ce0b550dc269aace0ad3af")
