-- Lua provided by SkyAPI 
-- Game: XLaunchpad
addappid(995660)
addappid(995661, 1, "c407ea0e599ecf7ed346d50656c2baa5811b166c7dffaaca8b59a842dd309a5e")
