-- Lua provided by SkyAPI 
-- Game: AppID 933080
addappid(933080)
addappid(933081, 1, "ae5412feaade5a01e04db3029595aedc71dd80ee4e6a03c61f04362a812e43b7")
