-- Lua provided by SkyAPI 
-- Game: WhichWayOut?
addappid(2837300)
addappid(2837301, 1, "b75ad83ddf3d4b3f95773676aec68c45aa2de216cb558f3015c756faa70bdf2c")
