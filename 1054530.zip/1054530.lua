-- Lua provided by SkyAPI 
-- Game: Little Witch Nobeta Demo
addappid(1054530)
addappid(1054531, 1, "24fccd3ec6d23ec5c8eed645f0334995848aee542101de3214167efe50c6fca9")
