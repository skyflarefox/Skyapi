-- Lua provided by SkyAPI 
-- Game: Zombie Survival Game Online
addappid(2268560)
addappid(2268561, 1, "e4d6af434888e2da6177fb3a412e7e2ad3a19966d33a6539262a9b8f7805c880")
