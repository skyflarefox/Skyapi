-- Lua provided by SkyAPI 
-- Game: AppID 2678950
addappid(2678950)
addappid(2678951, 1, "4874bd7daf497b67eaebfc38ed1e9a034b56009d16929c42cbbc7c2ac00e4771")
