-- Lua provided by SkyAPI 
-- Game: PALM BLOCKS
addappid(2385280)
addappid(2385281, 1, "af7304015622174d2cb67200306a297ba8103dc40604a88974d9398ae0032fde")
