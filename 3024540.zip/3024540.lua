-- Lua provided by SkyAPI 
-- Game: GOOOOOOAL!
addappid(3024540)
addappid(3024541, 1, "1528a0036a27e7b0d5096b901a8fef83c7f43b88aa0d2d69d2931590cfb1a7ad")
