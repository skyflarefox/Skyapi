-- Lua provided by SkyAPI 
-- Game: Hentai Maid Club
addappid(1441590)
addappid(1441591, 1, "4e639131abe9ce8445ccbc1c1160877a608ced54087b9dd9c352ca46e11d24c7")
