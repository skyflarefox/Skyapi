-- Lua provided by SkyAPI 
-- Game: Another World Series -Slit Mouth Woman VS AOONI-
addappid(3586070)
addappid(3586071, 1, "c06e0993cf5e60ec98fbce732ab849114804f6dc689044ec9096d34aead53b3e")
