-- Lua provided by SkyAPI 
-- Game: KUNKUNKUN
addappid(2791570)
addappid(2791571, 1, "895abd54517ece0fea57aed7d07b3bdc4611d2eed7a99b78727c1cdad4866a78")
