-- Lua provided by SkyAPI 
-- Game: AppID 657020
addappid(657020)
addappid(657021, 1, "2439046006707285caadf743779389e857c8ee9f17095902c30860e4c21b969f")
