-- Lua provided by SkyAPI 
-- Game: AppID 3443980
addappid(3443980)
addappid(3443981, 1, "0db2b650d8512bd64088304c795ee16fb97f3dcc0e09ec52dd0bd98b7b163d31")
