-- Lua provided by SkyAPI 
-- Game: AppID 589300
addappid(589300)
addappid(589301, 1, "8d248128d2b20ebbc4ba046dd08b727a73d022edc20a107823d59e987f9b19d6")
addappid(589302, 1, "8f412a6cac1d0ddbb45e99e15e6612efd6ddb29703d5daad2ff4ab6bde1cf946")
addappid(589303, 1, "8eb83662dfbc7ed89f174fd48083ddb981e267298f97e3d3a9760e0f9a42e6b8")
