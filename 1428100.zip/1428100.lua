-- Lua provided by SkyAPI 
-- Game: Instruments of Destruction
addappid(1428100)
addappid(1428101, 1, "28bcde7abdd9c002e7aa944b4cb36d53e9e04a4358721d763f82ae6ef4be18bf")
