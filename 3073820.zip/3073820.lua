-- Lua provided by SkyAPI 
-- Game: AppID 3073820
addappid(3073820)
addappid(3073821, 1, "5995fafb61495cf4f0d3e7346e839e24c67699a8d0532177da37fba3177078ee")
