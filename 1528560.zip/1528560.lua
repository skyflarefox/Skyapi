-- Lua provided by SkyAPI 
-- Game: Living together with Fox Demon
addappid(1528560)
addappid(1528561, 1, "8cefcac931f4343c5e9cf54bbfba7b1d25679404d89fd7011664471498f3ec92")
