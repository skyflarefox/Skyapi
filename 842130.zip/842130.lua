-- Lua provided by SkyAPI 
-- Game: AppID 842130
addappid(842130)
addappid(842131, 1, "ddcb37d62af93b9afb7da90a6b61411048a726593534249f04ffe410c555d4f2")
