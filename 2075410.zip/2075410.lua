-- Lua provided by SkyAPI 
-- Game: 初夏倾语 - Summer Whisper
addappid(2075410)
addappid(2075411, 1, "3e7ab5577f0e31888f51f19449c7fecab29482da7f7a2eb30383271319d8248a")
