-- Lua provided by SkyAPI 
-- Game: AppID 3115910
addappid(3115910)
addappid(3115911, 1, "ea4e2e7f77fd1e56913aebea1640da0b77ebfe4947f25dc103fb2affa7c3e822")
