-- Lua provided by SkyAPI 
-- Game: Unbearable
addappid(1990060)
addappid(1990061, 1, "f37b750e06f96e6aac549a33e7ebcc14d8e766cfb3d10c757ebc0868c28d8869")
