-- Lua provided by SkyAPI 
-- Game: AppID 1274600
addappid(1274600)
addappid(1274601, 1, "07ff7574977d57fd084377ff691488430aaac2e53ff9f19b703e69b505ea91fd")
