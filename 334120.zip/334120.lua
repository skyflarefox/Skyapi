-- Lua provided by SkyAPI 
-- Game: Armikrog
addappid(334120)
addappid(334121, 1, "2103c1a07f72840eeabf5bc343538445fe92a9219594e3ad2d185e87715f64a2")
addappid(334124, 1, "09ca6c644b1ce06071f09946afe710d1647a83c7c9f123808aa37f699ef174dc")
