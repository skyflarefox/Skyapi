-- Lua provided by SkyAPI 
-- Game: AppID 1704250
addappid(1704250)
addappid(1704251, 1, "120417faa6240f43ab4943d096cf038317a4853ef6048bb65f75c516f7ab011c")
