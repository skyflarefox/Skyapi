-- Lua provided by SkyAPI 
-- Game: AppID 1225660
addappid(1225660)
addappid(1225661, 1, "bbf7ff1cc084c7cd5f4fc99577efb4c02635ceb8dbb4da6cb8f0f9da0822fe61")
addappid(1650940, 0, "e646045b1a139aeaf656c266efaec47a9a51880c9618cbb4c22a505e5b2e95f4")
