-- Lua provided by SkyAPI 
-- Game: CORGI
addappid(2000360)
addappid(2000361, 1, "f76d6d80ca7b66ecc0da4718d9210eaabc0b17ddb1015f65437f459d6dd7b786")
