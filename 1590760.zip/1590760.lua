-- Lua provided by SkyAPI 
-- Game: Metal Slug Tactics
addappid(1590760)
addappid(1590761, 1, "582787963ed712941b80876d6bf558142ecd14682722438b0b64d3bfe68be66d")
