-- Lua provided by SkyAPI 
-- Game: Machinika: Atlas
addappid(2817620)
addappid(2817621, 1, "6f999510e0319de0fa5c57dfebb31ccbbfa59fcac892e17b985561da7970cf9a")
