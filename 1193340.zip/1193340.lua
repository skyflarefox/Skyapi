-- Lua provided by SkyAPI 
-- Game: AppID 1193340
addappid(1193340)
addappid(1193341, 1, "102721171675aa074391f11007ab59dea0ab596ade6d7bf17bf8c6f7a416d712")
