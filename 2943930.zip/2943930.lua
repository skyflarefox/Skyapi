-- Lua provided by SkyAPI 
-- Game: BOBR KURWA
addappid(2943930)
addappid(2943931, 1, "9a8295462d215b03c99abb084288d93fa8f300454f3b55a33e55e95d92709e0c")
