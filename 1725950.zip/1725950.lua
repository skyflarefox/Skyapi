-- Lua provided by SkyAPI 
-- Game: 魔塔地牢
addappid(1725950)
addappid(1725951, 1, "84a861d76b157b4729f0bffbd15255b98bad47300252ab0e88221f7a375eb3f5")
