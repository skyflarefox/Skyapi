-- Lua provided by SkyAPI 
-- Game: AppID 3035410
addappid(3035410)
addappid(3035411, 1, "8c371c65ccd99265a85a6f66e932e10c2de6c61dc5f24f363a02e9dd72611e0d")
