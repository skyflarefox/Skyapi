-- Lua provided by SkyAPI 
-- Game: Airport Madness 3D
addappid(445770)
addappid(445771, 1, "131020065b764f537d82aca92f4d8624c893c6bd4a2fd7bd2a85f726ee0e0e67")
addappid(445772, 1, "af9536c5af9ff409c256e2ee46c34e24b26867c498448d2a262046d4cb1b77e2")
