-- Lua provided by SkyAPI 
-- Game: Morkull Ragast's Rage Demo
addappid(2643440)
addappid(2643441, 1, "bf6818dff0cbf9d73cdc5cc460cdc687cba6e9944d00c522f087e38bc2be9202")
