-- Lua provided by SkyAPI 
-- Game: AppID 1893270
addappid(1893270)
addappid(1893271, 1, "350e75b7b7eb161bdbe137c645a690e2704ebe9d2a388721fbcf226451860a0b")
