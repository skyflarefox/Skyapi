-- Lua provided by SkyAPI 
-- Game: Project Castaway
addappid(1713350)
addappid(1713351, 1, "8f056aa2c3a1d13bfc6351baccb81a89837649ae52d64450bd1f452ba40cd61d")
