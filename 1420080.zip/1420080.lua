-- Lua provided by SkyAPI 
-- Game: Wonder Boy: Asha in Monster World
addappid(1420080)
addappid(1420081, 1, "84c89f7bea7fcff461be45b60b76dcc27a5551b39dff8f718e0a52cb3523eac9")
addappid(1755160, 0, "a3e9fd8643bdf83c924e16784a7bfa566a990deed235cbe8e6305f20ff7778ab")
