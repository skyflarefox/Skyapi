-- Lua provided by SkyAPI 
-- Game: Quirky Crook
addappid(765350)
addappid(765351, 1, "cb7d20b93ced36c96aef171e0195ba4ee46d05c4cc98c6127e6135277241a512")
