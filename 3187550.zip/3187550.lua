-- Lua provided by SkyAPI 
-- Game: Cape Hideous
addappid(3187550)
addappid(3187551, 1, "04c389c0f32d71cf8f20165556a54128fa453654e7b970eefef9275e9aad7877")
