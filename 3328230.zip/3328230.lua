-- Lua provided by SkyAPI 
-- Game: AppID 3328230
addappid(3328230)
addappid(3328231, 1, "ab1c1c9f5143b956d54547c6fa3177455f06292f91fc6c1d59e94f708f533008")
