-- Lua provided by SkyAPI 
-- Game: SUPRACORE
addappid(2433820)
addappid(2433821, 1, "890f9607f11fd8ab3085a2958e866b08466ea20e9556652cfdc846f0369170e2")
