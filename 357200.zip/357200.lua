-- Lua provided by SkyAPI 
-- Game: 500 Years Act 1
addappid(357200)
addappid(357201, 1, "f39038ab71dda9be498f7558263a783c886414d436dedd809717e3521e6c00ad")
