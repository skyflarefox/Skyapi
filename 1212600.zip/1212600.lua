-- Lua provided by SkyAPI 
-- Game: AppID 1212600
addappid(1212600)
addappid(1212601, 1, "361ac9f19cb246f06b278797776b4289516f349a2a8666997998dce50d113f51")
