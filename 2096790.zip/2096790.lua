-- Lua provided by SkyAPI 
-- Game: AppID 2096790
addappid(2096790)
addappid(2096791, 1, "36c98e4da6217af5dace4ba27317e5c1f7b75480b71a71600348ced93c076cbd")
addappid(2164560, 0, "1dd295c7b6cddd56429bbe8c7b4f58eebabfa03f0e331b8057c98cc8d958db16")
