-- Lua provided by SkyAPI 
-- Game: It Moves
addappid(1028930)
addappid(1028931, 1, "a065abc64f9398af187eab0939c4cb116e6d9f0b5da9d3fc6fcaf2999a3c9186")
