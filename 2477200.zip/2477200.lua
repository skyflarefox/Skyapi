-- Lua provided by SkyAPI 
-- Game: ZOMBIE ARENA SURVIVAL
addappid(2477200)
addappid(2477201, 1, "01737fe742b2a902fd6007581b83007d4abd6c2fab2dc28d919ed9418c08b1b4")
