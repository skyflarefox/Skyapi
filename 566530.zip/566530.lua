-- Lua provided by SkyAPI 
-- Game: AppID 566530
addappid(566530)
addappid(566531, 1, "46c61cb14ff4b82a97b73710b99cfa43b22f3ffd7fe287f21992b5b0a8d899e9")
addappid(566532, 1, "6898bfe587c9ff4f75290423f896ad874b8a3447973aea22fa2c930f5562b2ea")
