-- Lua provided by SkyAPI 
-- Game: Brick Building
addappid(1352440)
addappid(1352441, 1, "c455c05e071c509698a1b624d3c3b8d639b98f05242efd736e7ac4e41504a13b")
