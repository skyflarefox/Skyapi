-- Lua provided by SkyAPI 
-- Game: Vaygren - Lustful Temptation
addappid(1771700)
addappid(1771701, 1, "59a1fc62e34fe007d5c485f46989980cb731d3f87219d035efe5db869bff31bc")
