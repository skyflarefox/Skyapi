-- Lua provided by SkyAPI 
-- Game: Jacob's Quest Anniversary Edition
addappid(1981700)
addappid(1981701, 1, "581dcaeb951a0df6b9cfed55124a5b588e9d0c56919b306617d1bbd2240d2ebf")
