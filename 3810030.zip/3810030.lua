-- Lua provided by SkyAPI 
-- Game: Dark Resolve
addappid(3810030)
addappid(3810031, 1, "fdf18df527a55ea99eb8c19117f3b5612654e4cecebee14b552648b76ca18b97")
