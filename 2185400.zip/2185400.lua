-- Lua provided by SkyAPI 
-- Game: Of Moons and Mania
addappid(2185400)
addappid(2185401, 1, "b27cd4385275eebd33116908cdcdd31789b35897f6a5f7082004bad9c3e828ae")
