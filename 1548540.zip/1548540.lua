-- Lua provided by SkyAPI 
-- Game: Z.O.M.B.I.E.
addappid(1548540)
addappid(1548541, 1, "d253c43d8a729f8f16ac4eaed9d42b76432b429426cd0283f5b5472112b391ba")
