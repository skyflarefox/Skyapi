-- Lua provided by SkyAPI 
-- Game: Boss Of The Mafia
addappid(1864620)
addappid(1864621, 1, "f1e733d0d155b3fe61a092faf1d402f04586296a9496cd37eb43a84c768cd62c")
