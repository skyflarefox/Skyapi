-- Lua provided by SkyAPI 
-- Game: Mineral Defense
addappid(3125890)
addappid(3125891, 1, "a7a9b39f854c3b38cfd2c6605ee1b6926b5799dd7e2f03d3b5a17c9d27f4c7f9")
