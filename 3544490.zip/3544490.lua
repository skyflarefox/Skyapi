-- Lua provided by SkyAPI 
-- Game: Re: GSpot Master
addappid(3544490)
addappid(3544491, 1, "45e6d7ba1541213d47e3222d77c61f2b8b4be26cd0c95b374e9317f49e8dbecf")
