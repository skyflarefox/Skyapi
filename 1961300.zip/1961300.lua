-- Lua provided by SkyAPI 
-- Game: Is Simon There?
addappid(1961300)
addappid(1961301, 1, "1760604af1b8f380bf0f73c43515840e142fb58230409e2b52104f4f56a8d854")
