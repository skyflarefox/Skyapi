-- Lua provided by SkyAPI 
-- Game: CAGE-FACE | Case 2: The Sewer
addappid(1739500)
addappid(1739501, 1, "366cfc2684193675848490ac7b6ab96be3c7ed871c3c34eb5014a01068a3cc36")
