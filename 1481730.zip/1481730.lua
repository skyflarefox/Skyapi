-- Lua provided by SkyAPI 
-- Game: Cosmo Clash
addappid(1481730)
addappid(1481731, 1, "5afd3f4601f97cf23a7a55e8237d94be558ce2b7c67f041b20c158612c5818e3")
