-- Lua provided by SkyAPI 
-- Game: Go To Hell Must
addappid(2797440)
addappid(2797441, 1, "f2b2161fecb035e6125ac73bb92c7a3abc03a2a84bc4843296bb4cce2453178b")
