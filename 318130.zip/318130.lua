-- Lua provided by SkyAPI 
-- Game: Doom & Destiny
addappid(318130)
addappid(318131, 1, "0ff6fbe8dd768d0ec0a555b41f6d0016bddb9b954c18143ef0a65cfa5831d736")
addappid(318132, 1, "7239efe62b39906339340680264b4906a09f962fae431752e74c719bfbe5d22f")
addappid(318133, 1, "8fe734517bef11c2fbfa8871193bef8cba872f05e15cc8582f9f8d2cb609943b")
