-- Lua provided by SkyAPI 
-- Game: Liuyin's world
addappid(3689510)
addappid(3689511, 1, "dc05b39be2d37984e29901be3f6ca492ee05d4e713d6fcdaed4dfb5d0e828ba2")
