-- Lua provided by SkyAPI 
-- Game: THE JUSOU
addappid(2380230)
addappid(2380231, 1, "3346f8537b5df3cf61a7d32e9595908d4a764621628a3ece3074856746b3f558")
