-- Lua provided by SkyAPI 
-- Game: Wheelie King 5
addappid(2304550)
addappid(2304551, 1, "5a50657d6eb2498842e1ac0708ae2df26c99fbce886ce65b681b6a56c0a94bd7")
