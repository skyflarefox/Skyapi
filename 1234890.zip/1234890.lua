-- Lua provided by SkyAPI 
-- Game: AppID 1234890
addappid(1234890)
addappid(1234891, 1, "b41dd3d011b2b7e93a8e0cb7701804caa2b79893c93bf9340df889a8d6ba6d25")
