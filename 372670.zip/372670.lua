-- Lua provided by SkyAPI 
-- Game: AppID 372670
addappid(372670)
addappid(372671, 1, "305f79aed15b835de079524b7244ca31bdba6af3b81b94e8183e18200af1406a")
