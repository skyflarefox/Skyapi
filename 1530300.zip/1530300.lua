-- Lua provided by SkyAPI 
-- Game: Auto Chess
addappid(1530300)
addappid(1530301, 1, "8aa8a9c97cafeb4176f032a6af14383f6e45116f3426dbf6b3780c778cc8d9f1")
