-- Lua provided by SkyAPI 
-- Game: Gunner-chan! Original Soundtrack
addappid(2934130)
addappid(2934131, 1, "ff623902c73627b8ba5dfc1293e02583fd326e3631c19d45c9008a767d6d4639")
