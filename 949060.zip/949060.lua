-- Lua provided by SkyAPI 
-- Game: AppID 949060
addappid(949060)
addappid(949061, 1, "b79ea68171323db3fc8162c722de0ed6b04532eeae16596083c62e63de1b17c6")
addappid(1087900, 0, "3da7785bc3298e829a39b3eca055a170ea7e48f6d453171b57dc79b961b5831d")
