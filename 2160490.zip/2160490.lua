-- Lua provided by SkyAPI 
-- Game: AppID 2160490
addappid(2160490)
addappid(2160491, 1, "9d6e4fc596cea35b7a22c40efa0b72e3a4f37fdbe2d8d6a4df47e133bb0b9954")
