-- Lua provided by SkyAPI 
-- Game: 1 to 1 humanoid edible toys
addappid(2976720)
addappid(2976721, 1, "4411262ea2ebacc16990d35aa9ebded7a5d36abeb4be5f77add4a9b325696cd6")
