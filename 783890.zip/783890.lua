-- Lua provided by SkyAPI 
-- Game: BRIGHTEST
addappid(783890)
addappid(783891, 1, "47d8ae9eefb074fbe5b402278bb9b81a9d1d579cd4f4cf2576675ab64bc3cd80")
