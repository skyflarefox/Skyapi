-- Lua provided by SkyAPI 
-- Game: Midnight Shift
addappid(2395260)
addappid(2395261, 1, "29c2b2e9bb5e0f1fdf802c71052622c6907ff977f461f3768eb8ccfe402fea24")
