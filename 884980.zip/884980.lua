-- Lua provided by SkyAPI 
-- Game: Code Romantic
addappid(884980)
addappid(884981, 1, "75d00da97f8955a2d4ad7eb92e237e4916eec8ddcecfe561a889a6745efab747")
