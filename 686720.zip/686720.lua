-- Lua provided by SkyAPI 
-- Game: SaGa SCARLET GRACE: AMBITIONS™
addappid(686720)
addappid(686721, 1, "93aef7b79e2e4c44fa14a46f749c53e1f69352d676dbccf37773ad036bbd41bb")
addappid(686723, 1, "4cb3cc6501416c3773d5dc319822d503859e92c71bab61eb303bfa3b5a9fac9f")
