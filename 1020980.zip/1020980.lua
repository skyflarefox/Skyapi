-- Lua provided by SkyAPI 
-- Game: AppID 1020980
addappid(1020980)
addappid(1020981, 1, "8f02768dba6f9fc3ff0e9c775d757f415a539c69bbd388e461ec5109f22a74c7")
