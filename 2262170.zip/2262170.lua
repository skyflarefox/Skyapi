-- Lua provided by SkyAPI 
-- Game: ROSE
addappid(2262170)
addappid(2262171, 1, "04e0a8d960d2429022ab3a9ccc4375976c53a1d8782e2527df1ffe6cb4c54418")
addappid(3234470)
