-- Lua provided by SkyAPI 
-- Game: AppID 1094720
addappid(1094720)
addappid(1094721, 1, "8a5a6194caac528647c30a38e95434081edf6dac9c7fa40880211a03f1579d53")
