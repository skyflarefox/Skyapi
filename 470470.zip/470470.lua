-- Lua provided by SkyAPI 
-- Game: Birdsketball
addappid(470470)
addappid(470471, 1, "b4f02b038ba3f8de0868c874eec39cbd64a4e4c271c37122f9740ed9d7ec7cef")
