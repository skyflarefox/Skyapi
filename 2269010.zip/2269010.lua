-- Lua provided by SkyAPI 
-- Game: Hentai Casual Slider
addappid(2269010)
addappid(2269011, 1, "2c98969d18f8ac27ca3748edf3898f86d083989864bf65ed7e31dddb5d369f06")
