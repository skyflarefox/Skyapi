-- Lua provided by SkyAPI 
-- Game: AppID 3471590
addappid(3471590)
addappid(3471591, 1, "1e645a28773a20dd3cdb79845dc0347330707bdc8f69b5295ff23b62f1b14f71")
