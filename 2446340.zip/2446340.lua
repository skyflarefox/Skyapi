-- Lua provided by SkyAPI 
-- Game: Garestia
addappid(2446340)
addappid(2446341, 1, "ad062fbe4f9d00db09d8be6d10d1b5dfee5c544f97d4ee3c06a08ae71ca801f6")
