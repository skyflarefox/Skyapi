-- Lua provided by SkyAPI 
-- Game: AppID 1221540
addappid(1221540)
addappid(1221541, 1, "27c31f2773eee29af11eb2376ee6a75a34049c3a260851b11bbc1bc9ab04ad52")
