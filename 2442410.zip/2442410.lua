-- Lua provided by SkyAPI 
-- Game: Colony City 27λ
addappid(2442410)
addappid(2442411, 1, "aa7c1ceb827fc6c0ab562c94f3c597b72668e12af60bf45a92c8462d70810054")
