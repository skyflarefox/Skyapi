-- Lua provided by SkyAPI 
-- Game: Blood Poker
addappid(2904800)
addappid(2904801, 1, "f7c5f6eb2f687d88c5a419e1bae65014dc9afeeda4507295a3ab05d4e7815083")
