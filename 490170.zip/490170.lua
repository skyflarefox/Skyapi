-- Lua provided by SkyAPI 
-- Game: AppID 490170
addappid(490170)
addappid(490171, 1, "e6e12127dc00be3d89f9241d525ffd136086348d206824b0b24b882cd31fdf3c")
