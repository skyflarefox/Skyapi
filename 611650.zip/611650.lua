-- Lua provided by SkyAPI 
-- Game: Mono Demo
addappid(611650)
addappid(611651, 1, "a52b75e21e12e3fbca5aadfebe5ff7455f370fa9f68aab0cad7f4f837ff84a1b")
