-- Lua provided by SkyAPI 
-- Game: AppID 1540590
addappid(1540590)
addappid(1540591, 1, "b47f3eb8d521832630f72b634ba983a34bc127b68e68438e1e4687ae39c09731")
