-- Lua provided by SkyAPI 
-- Game: 最后的大法师 光明之旅(Last Archmage Journey of Light)
addappid(1338830)
addappid(1338831, 1, "5a770c99f09ed5a2978cd4cceab9b94a8ea2f7eb709d5b80f33aaf8f63e8b307")
addappid(1338832, 1, "93a5424f0b2704e24fb528a8247dba5e0ddf550c38c10e8ce82e0005ef2096b5")
