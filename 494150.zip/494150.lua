-- Lua provided by SkyAPI 
-- Game: AppID 494150
addappid(494150)
addappid(494151, 1, "937565aad52492498a0fb91cf9508ca5628c65c3198d0ba049ee8d3bab4b0489")
