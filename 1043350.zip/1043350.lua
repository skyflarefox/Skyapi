-- Lua provided by SkyAPI 
-- Game: AppID 1043350
addappid(1043350)
addappid(1043351, 1, "2070eba01221e2772d41e12b30d1319ee592713d5592ee511fa78a5ee57f36de")
