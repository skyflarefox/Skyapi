-- Lua provided by SkyAPI 
-- Game: VR Ultimate Paintball: Heartbreak, Regret & Paintbots
addappid(511830)
addappid(511831, 1, "0bbe9956e136c04cb28f1ecba3c7069c3e367c886ae8ed57aa4259c5ea702cac")
