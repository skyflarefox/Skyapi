-- Lua provided by SkyAPI 
-- Game: Pitfall Planet
addappid(464900)
addappid(464901, 1, "c3740ea223892b14c04492c865225664744ae1e4b135a79379cf1b12673d74b1")
