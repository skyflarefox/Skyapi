-- Lua provided by SkyAPI 
-- Game: AppID 460950
addappid(460950)
addappid(460951, 1, "76672e24adb8b313cdc23f79a51982c3fd243414f79426ed46e8bbae264cb202")
addappid(460952, 1, "d0715cdb92b3e7017a3e6378d03cee9db4e669dbe34639616706f0a336e1c540")
