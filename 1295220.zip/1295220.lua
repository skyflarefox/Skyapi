-- Lua provided by SkyAPI 
-- Game: Super Buff HD
addappid(1295220)
addappid(1295221, 1, "3324b9aa6b4ae5975c0c8a28799aaa32bfb486d6e05f2b550d1cbb1a40ad5e5f")
