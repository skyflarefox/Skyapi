-- Lua provided by SkyAPI 
-- Game: Float Night
addappid(958280)
addappid(958281, 1, "a490fd021cbc286b525c8c3815825f90447c9cc488a8f8e413518fe9590edcf2")
