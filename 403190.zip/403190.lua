-- Lua provided by SkyAPI 
-- Game: AppID 403190
addappid(403190)
addappid(403191, 1, "a043be27ee71135a6635e7578da9ea0e617ee4724adfbc12ffacf28d80cbd019")
addappid(403192, 1, "ab730985e19e31713ca4e68a054650b7b35fa677c419bddf6aaaeafa90835b12")
