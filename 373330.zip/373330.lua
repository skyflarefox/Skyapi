-- Lua provided by SkyAPI 
-- Game: All Is Dust
addappid(373330)
addappid(373331, 1, "3c7f53aab5963ebd26143339fd8b6a459ee626d9b3578580421344aba9f42a66")
