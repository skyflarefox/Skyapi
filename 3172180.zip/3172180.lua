-- Lua provided by SkyAPI 
-- Game: AppID 3172180
addappid(3172180)
addappid(3172181, 1, "3b0910532b942a88680dd71443b4402c55b1baaa7ead95d4af1fb15217537ac9")
