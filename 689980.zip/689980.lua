-- Lua provided by SkyAPI 
-- Game: Car Trader Simulator
addappid(689980)
addappid(689981, 1, "7d4bc7959a787db4b343162211210bca845cfd2d3fa93124c97f36d369ed509b")
