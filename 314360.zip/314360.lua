-- Lua provided by SkyAPI 
-- Game: AppID 314360
addappid(314360)
addappid(314361, 1, "43fbc5bda6b1133e359356ca9517cf2ecfe65a6fd15cd653d31fdb1607d07a5e")
addappid(314362, 1, "9f30e055724728d0cbb7685d07a34b2b2108fcad195eec5ce9a29b40583688d3")
