-- Lua provided by SkyAPI 
-- Game: AppID 791930
addappid(791930)
addappid(791931, 1, "2b19031940641b1f61e6d338f4fc8d73c944da5b3e38ae72bb57c60bd9f40db9")
addappid(792110)
