-- Lua provided by SkyAPI 
-- Game: 桃色武林
addappid(2421310)
addappid(2421311, 1, "03fb0539c3ef8995829ad192299a6995b8fe4ecf33aa096e4be83d61c34b4780")
