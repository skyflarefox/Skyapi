-- Lua provided by SkyAPI 
-- Game: Ooga Demo
addappid(2706240)
addappid(2706241, 1, "f0a5682b010d5da4a81bc9da97c9ee9335b4848ec4da705f705cf384a7cfc5aa")
