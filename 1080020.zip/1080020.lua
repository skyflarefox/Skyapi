-- Lua provided by SkyAPI 
-- Game: AppID 1080020
addappid(1080020)
addappid(1080021, 1, "2a785b96ae4d7f957ce7987495ffe9cec7ff7a456600763ed68b6bd0ed111dad")
addappid(2329870, 0, "50c259e5299223757808b3956cdeda82fb3d3c49cb6e0ea21e1f6ffda10e42d7")
