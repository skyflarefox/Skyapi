-- Lua provided by SkyAPI 
-- Game: SLUDGE LIFE 2
addappid(2275150)
addappid(2275151, 1, "f883a0d69ecc31bf66a7d4ca52cc62ef61d7a8c9442e78b29016746655f2e030")
