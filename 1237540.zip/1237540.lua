-- Lua provided by SkyAPI 
-- Game: AppID 1237540
addappid(1237540)
addappid(1237541, 1, "9037abaea40747709cc5e35d0fcc05f2fba2e2d1b51f6cc785b2af79c61f7e0d")
