-- Lua provided by SkyAPI 
-- Game: LINGKARAN：リンカラン
addappid(3340240)
addappid(3340241, 1, "7a8c031d9766ca7228ab07eab92a0204323369dc39924e82da2ba7bc3313a241")
