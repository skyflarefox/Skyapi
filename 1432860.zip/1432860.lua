-- Lua provided by SkyAPI 
-- Game: Sun Haven
addappid(1432860)
addappid(1432861, 1, "699136c056b2ebdf81900c0ca6bffabdf5b83899c1d451837b3fbc945c986d86")
addappid(2305662, 0, "fd3834626fe0fb254f567e19c07831ea4684b5b1dc4360fdd0fd76a99491acd5")
