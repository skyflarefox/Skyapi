-- Lua provided by SkyAPI 
-- Game: Stream Slugger
addappid(2218430)
addappid(2218431, 1, "f38e7cb77062ce4b827ceb945c0090e9885625a146bda5b90553ba7efaf65e2b")
