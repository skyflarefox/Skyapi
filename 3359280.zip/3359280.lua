-- Lua provided by SkyAPI 
-- Game: Coolmath Games: The Game
addappid(3359280)
addappid(3359281, 1, "8d1c76f010f6f613db3ec5e9d7aa3036cf92cf49e0eb654dae085d004fccc743")
