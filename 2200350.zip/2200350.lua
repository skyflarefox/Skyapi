-- Lua provided by SkyAPI 
-- Game: AppID 2200350
addappid(2200350)
addappid(2200351, 1, "f65bc1286a8277a83893d855c70d6a7b5dce764f22c2298d172bcc89010baf5c")
