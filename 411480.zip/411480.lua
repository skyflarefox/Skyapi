-- Lua provided by SkyAPI 
-- Game: AppID 411480
addappid(411480)
addappid(411481, 1, "cada994e419c3db0dfb475b9f3fe13610f7ec5dda0f219f14c53c1d4e5b480ab")
