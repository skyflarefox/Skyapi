-- Lua provided by SkyAPI 
-- Game: AppID 603100
addappid(603100)
addappid(603101, 1, "e89b8be1edc861a04e5b1b75af419e6f4090f86e03c8475b8d0facc5be27a4b2")
