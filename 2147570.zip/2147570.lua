-- Lua provided by SkyAPI 
-- Game: AppID 2147570
addappid(2147570)
addappid(2147571, 1, "b1b0db36c313067d29d1df72d0a97e7532b5e5174482253f50dc7e9f2b2e3460")
