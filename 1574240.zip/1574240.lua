-- Lua provided by SkyAPI 
-- Game: AppID 1574240
addappid(1574240)
addappid(1574241, 1, "24198f4dd13fc1fa93fb7dafc67b633f9d41e7b8c13bcb20fccd46bce08f940f")
