-- Lua provided by SkyAPI 
-- Game: AppID 2843760
addappid(2843760)
addappid(2843761, 1, "86e2b51c88c0d94cca6a806d358a3c77cb4aacf879ffc81ca87890eb7bb63ab2")
