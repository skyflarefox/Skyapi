-- Lua provided by SkyAPI 
-- Game: Hello Neighbor VR: Search and Rescue
addappid(2206320)
addappid(2206321, 1, "01b1ee5730664096c3d70ed486a4147f426f4c5f2d6501225d4707120c598f43")
