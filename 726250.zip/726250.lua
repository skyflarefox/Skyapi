-- Lua provided by SkyAPI 
-- Game: AppID 726250
addappid(726250)
addappid(726251, 1, "dd437a770e9915fdf62e23b64e2da9593c166e4c79b8821b0f936ce101ce12dd")
