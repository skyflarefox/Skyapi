-- Lua provided by SkyAPI 
-- Game: Starship Disco
addappid(503690)
addappid(503691, 1, "debc64d4a82d82f3225611d7b3dcd1a3d929ba0f726ad799609b0c7bdddfecd8")
