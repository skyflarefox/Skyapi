-- Lua provided by SkyAPI 
-- Game: The Designer's Curse Chapter 2 - Forgotten Horrors
addappid(3606160)
addappid(3606161, 1, "2AD7353DD21ACB00FB6E9FF779E0D9D49C3D786755BA6F05E24FE41A2AB5B310")
