-- Lua provided by SkyAPI 
-- Game: Toree 2
addappid(1722620)
addappid(1722621, 1, "dd5f689ed459c480dc387e15f5707557f29bee2b69eb2928aa2086cf9b4dc536")
