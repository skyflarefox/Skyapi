-- Lua provided by SkyAPI 
-- Game: Femdom Waifu
addappid(1024800)
addappid(1024801, 1, "412168f03b64cba4d01c9d1dd4e9a1fdd4142a0a491e2e62c2a6eaf542e378bd")
