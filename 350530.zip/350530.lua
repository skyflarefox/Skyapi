-- Lua provided by SkyAPI 
-- Game: Airport Firefighters - The Simulation
addappid(350530)
addappid(350531, 1, "5c1ca5ace31b214acb054cff1d8b8191fb1b471322bdfccee5f31ae22d1a1679")
