-- Lua provided by SkyAPI 
-- Game: Eastwood VR
addappid(612250)
addappid(612251, 1, "4fd789747d6aa420721f55943cc2c5d490b2685b00482a169e406455eda1a4ea")
