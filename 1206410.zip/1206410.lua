-- Lua provided by SkyAPI 
-- Game: AppID 1206410
addappid(1206410)
addappid(1206411, 1, "cf2bd5df49a3f883f86249fe67c2df69341c652a568081cd0cf38f3932a89067")
