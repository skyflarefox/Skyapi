-- Lua provided by SkyAPI 
-- Game: AppID 657510
addappid(657510)
addappid(657511, 1, "61851e8e38fac935b0a3e3ac8c2417fc42c90058e0e5680a9c89703b4fd2a0e9")
