-- Lua provided by SkyAPI 
-- Game: AppID 3280170
addappid(3280170)
addappid(3280171, 1, "77db591899179991333cbb9ed2dd724cbdcf8c2cd5e962f4477789f96936b254")
