-- Lua provided by SkyAPI 
-- Game: Monkey King Saga
addappid(417350)
addappid(417351, 1, "68d06eac14272b16a846e90b9ab67ef50ce057bb2ae66e65c04994099c75b7de")
