-- Lua provided by SkyAPI 
-- Game: Book of Korvald
addappid(2132380)
addappid(2132381, 1, "8782de171969f1be81976a6c3562295da523b11c1d60f4ddf42e5d91e2ab6fe1")
