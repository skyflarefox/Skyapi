-- Lua provided by SkyAPI 
-- Game: Brunch Club
addappid(1045120)
addappid(1045121, 1, "31fb858a6a39de5a1c526dbb15fbb65537cd1b5b2340fe16a5a53b86e39252e4")
