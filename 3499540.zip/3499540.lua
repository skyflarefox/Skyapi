-- Lua provided by SkyAPI 
-- Game: AppID 3499540
addappid(3499540)
addappid(3499541, 1, "cceab1f49fd6473243020151af5143be7aa30f4207b794c0427e738146491d9b")
