-- Lua provided by SkyAPI 
-- Game: Rad Rodgers - Radical Edition
addappid(805660)
addappid(805661, 1, "c1435e899d1aa755449c14b20c61b216738bc0135c05f8c8a2ceedb8929f9276")
