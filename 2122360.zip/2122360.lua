-- Lua provided by SkyAPI 
-- Game: Giant Wishes
addappid(2122360)
addappid(2122361, 1, "d8eb8bd478366a8ab4a0818f2de9d438e286548fd94161f3f6ba0ad68c18697b")
