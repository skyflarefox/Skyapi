-- Lua provided by SkyAPI 
-- Game: Content Creator Simulator
addappid(811250)
addappid(811251, 1, "36d8eeed18c556f17c9895c0a7a453fde04b3f7c26b4fa388edfc399432c1080")
