-- Lua provided by SkyAPI 
-- Game: Adabana Odd Tales Original Soundtrack
addappid(1357970)
addappid(1357971, 1, "011e568e8630aa81e637fb83a1e113699776abb2db0401bd0df46384330163a6")
addappid(1357972, 1, "5740ac783adf04bccb7d4cfce5968a048d3a643977c31a6fbdc8ba8a531762dd")
