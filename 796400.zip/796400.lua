-- Lua provided by SkyAPI 
-- Game: AppID 796400
addappid(796400)
addappid(796401, 1, "03593ea0a2f4c9979c3513097507d2f91fbe8d1f0795a23499a689863a7f80bd")
