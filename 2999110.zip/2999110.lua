-- Lua provided by SkyAPI 
-- Game: AppID 2999110
addappid(2999110)
addappid(2999111, 1, "c06659298179d462835d41702a57714a76beb599def4efbfdc17a3cc56703164")
