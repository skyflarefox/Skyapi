-- Lua provided by SkyAPI 
-- Game: AppID 1669320
addappid(1669320)
addappid(1669321, 1, "9f211165c83d14cd29e42a4e5caaac3b339a4a844d2ec8e7e601361fc938e261")
