-- Lua provided by SkyAPI 
-- Game: Mashed
addappid(281280)
addappid(281281, 1, "c735c3da01167faf6eacef2630e874c36f95bda2766d5e29b94de6828f0a31c1")
