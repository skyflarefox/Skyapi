-- Lua provided by SkyAPI 
-- Game: Raven's Hike
addappid(1689270)
addappid(1689271, 1, "c9d68d8715040e022a47f9c44ac56caf5df7da9fb478b68415872b0a42d6772e")
