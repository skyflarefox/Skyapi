-- Lua provided by SkyAPI 
-- Game: No throwing
addappid(3467620)
addappid(3467621, 1, "2aa9e842b67acd1973c8ef4f1c8c32cacff0142a6a9a91c1ac2fb0aef2d19447")
