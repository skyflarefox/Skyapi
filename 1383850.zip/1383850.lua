-- Lua provided by SkyAPI 
-- Game: Gurobu
addappid(1383850)
addappid(1383851, 1, "6cb238a9cdb8ab1b2ac37ee77e5d262aba7cd84f5f1b7045ed6d168056910ade")
