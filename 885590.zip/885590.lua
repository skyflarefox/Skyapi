-- Lua provided by SkyAPI 
-- Game: AppID 885590
addappid(885590)
addappid(885591, 1, "4426b5e0f0f965be0e9a02f3b2146596d824f92d74a949d247d6bd24585cd5b2")
