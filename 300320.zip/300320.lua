-- Lua provided by SkyAPI 
-- Game: The Few
addappid(300320)
addappid(300321, 1, "5b2b76c9cb1a55f719e306d0be4effa71a046bfa8d03bc11eabe091f258a61a1")
