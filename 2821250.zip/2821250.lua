-- Lua provided by SkyAPI 
-- Game: AppID 2821250
addappid(2821250)
addappid(2821251, 1, "bc48984220c7ab6d083282ee8482bb3e12f404648876d6c056cfaec40cbe6d99")
