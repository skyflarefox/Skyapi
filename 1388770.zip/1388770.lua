-- Lua provided by SkyAPI 
-- Game: Cruelty Squad
addappid(1388770)
addappid(1388771, 1, "3cdfc9db282b7c09a51a2b71319178f5f099d61e8d80d76936ec2c3ef503541e")
