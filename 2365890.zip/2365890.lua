-- Lua provided by SkyAPI 
-- Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.12「泣かない依頼人」
addappid(2365890)
addappid(2365891, 1, "7ee3f59d4e18f08d1af65680770137b1ca0cb1c1070b2f328fc68b6e2e852937")
