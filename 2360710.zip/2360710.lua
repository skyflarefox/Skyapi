-- Lua provided by SkyAPI 
-- Game: Cruo Domine
addappid(2360710)
addappid(2360711, 1, "453da5bd1a52b3157b555cadb84f52770162065a46b71d360fcea7e3684c9860")
