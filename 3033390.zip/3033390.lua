-- Lua provided by SkyAPI 
-- Game: AppID 3033390
addappid(3033390)
addappid(3033391, 1, "f3debf319ceb965868df0b8a9bc0aa19a52e12da6c4cf6799ad42107399e7dd7")
