-- Lua provided by SkyAPI 
-- Game: AppID 462200
addappid(462200)
addappid(462201, 1, "7a58dd6bcedd478d9ffa0eec4a66429b545bf9ac44452e0f01d287f6575b5a0d")
addappid(537250, 0, "9ce58e8953752e4464669557ba20f2837f4b43c9cad309cab5ecf159fd1a47ef")
