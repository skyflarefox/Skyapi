-- Lua provided by SkyAPI 
-- Game: Warlocks Quarry
addappid(2116790)
addappid(2116791, 1, "d6ca0a4b1a99a4c8a9ea11a5eb18d28ee8449c4b60423c5eefccbf39735d8afc")
addappid(2381490)
