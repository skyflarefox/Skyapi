-- Lua provided by SkyAPI 
-- Game: Stick It to the Stickman
addappid(2085540)
addappid(2085541, 1, "770f40e40d880628981e51726a0b14c9516704fc8154041d894b7fd0257b4050")
