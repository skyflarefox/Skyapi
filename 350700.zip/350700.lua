-- Lua provided by SkyAPI 
-- Game: AppID 350700
addappid(350700)
addappid(350701, 1, "9e8844b50ea78e55802f8461d5384a7b085c0963387fe59a56207eef58244405")
