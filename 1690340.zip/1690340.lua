-- Lua provided by SkyAPI 
-- Game: Stand Of Arms
addappid(1690340)
addappid(1690341, 1, "cf57e5b1bc62d0d4ea25e87c5b5f69f30961477e5b80c2ade9c1d910ee954b78")
