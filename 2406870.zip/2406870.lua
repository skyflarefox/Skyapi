-- Lua provided by SkyAPI 
-- Game: BATTLEPOPES
addappid(2406870)
addappid(2406871, 1, "5db7dd78407cc8c22f304dbdb997f06e67e6773633dc31413862b2800254ebe1")
