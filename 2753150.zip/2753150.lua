-- Lua provided by SkyAPI 
-- Game: AppID 2753150
addappid(2753150)
addappid(2753151, 1, "164f6dc850c3e8c16f4b520f4eadeee5102841a2fe83e29cb37363b11d1e6f8a")
