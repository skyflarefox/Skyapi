-- Lua provided by SkyAPI 
-- Game: Retail Company Simulator
addappid(3089130)
addappid(3089131, 1, "5786ccb1d1879ab3e1ea79533b18f26a2738a511b8085872aef7a6a38e8a19bd")
