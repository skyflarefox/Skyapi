-- Lua provided by SkyAPI 
-- Game: AppID 581910
addappid(581910)
addappid(581911, 1, "9bc9170f7e5ed8724f661e3e4564d92c501316d8e1a3e634db33ae8216576078")
addappid(770341, 0, "d9211c1b50c17e0e7e701912faf14130acaa44cfb93d2b35e74d47a3aa89ac82")
