-- Lua provided by SkyAPI 
-- Game: Taxi Simulator in City
addappid(2568860)
addappid(2568861, 1, "c35ffc24012e50183cfd80c9e17a906e07ff5ed30dabb7d89043383d0705f1d1")
