-- Lua provided by SkyAPI 
-- Game: Slave Lord: Elven Conquest
addappid(2399670)
addappid(2399671, 1, "6e2ed5e2240bcad0d9737c4686f533c897bcb6c25436f283a144e6dde66bc9a1")
