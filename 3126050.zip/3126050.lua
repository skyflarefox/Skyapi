-- Lua provided by SkyAPI 
-- Game: AppID 3126050
addappid(3126050)
addappid(3126051, 1, "a3fa12616a3445a7634fe2f8aecaf7dc9116573c8d30d24b807c71657fed9ba0")
