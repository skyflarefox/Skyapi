-- Lua provided by SkyAPI 
-- Game: AppID 590850
addappid(590850)
addappid(590851, 1, "1fb6a0aa949b0bd36d376feab738cd7603447369b7ffe9aad4a5903e2c009a9d")
