-- Lua provided by SkyAPI 
-- Game: Lords Of The Fallen Soundtrack
addappid(1247000)
addappid(1247001, 1, "2e3949549f50a5654bd1456bf521e122ff26b570dd440a6ea3c6c12b7cda89e6")
addappid(1247002, 1, "c52f94303d06cdbe4980c50c792eba0d00c9acec6ca70f94f387c57dbfbc0daf")
