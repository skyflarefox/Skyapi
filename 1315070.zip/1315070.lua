-- Lua provided by SkyAPI 
-- Game: Vaccine19
addappid(1315070)
addappid(1315071, 1, "d77036901e1cafb6bafe981b7ea007bfcd029645f4ed61ff0d062700ac1f6e82")
