-- Lua provided by SkyAPI 
-- Game: Melodramatica
addappid(1497110)
addappid(1497111, 1, "1d33bd3072560967e45921468c36a00ebb82143e32e986b0bb1a95ac2f816e5e")
