-- Lua provided by SkyAPI 
-- Game: Train Station Renovation
addappid(914010)
addappid(914011, 1, "9bb04975b8da7b3a66169aca8aee0056b28a933d964f110d98752c924d964954")
addappid(1610540, 0, "ab18d951824e55b180f42ec00d5b07e235bf2af54a3459f33dec33f2e1cf4542")
