-- Lua provided by SkyAPI 
-- Game: AppID 2912570
addappid(2912570)
addappid(2912571, 1, "a11131f4db1404eb6575be8a8f9249a4d3f05e0a5175258215cfaf7ed0272bca")
