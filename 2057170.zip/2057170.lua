-- Lua provided by SkyAPI 
-- Game: AppID 2057170
addappid(2057170)
addappid(2057171, 1, "9937e0d0bef338ccd02d6179255f7f613dd5c93cd540f7ac230b08858439ca68")
