-- Lua provided by SkyAPI 
-- Game: AppID 2585620
addappid(2585620)
addappid(2585621, 1, "574ef03d34ce17f7e5179d15328fecc4ffdc10f9a39364e74c5ea67668b0f41f")
