-- Lua provided by SkyAPI 
-- Game: AppID 1033110
addappid(1033110)
addappid(1033111, 1, "c82ecb554cbf2bf0dd716a7d8f6d98d07b178a5b0499afaf11c26841755f8407")
