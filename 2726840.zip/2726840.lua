-- Lua provided by SkyAPI 
-- Game: AppID 2726840
addappid(2726840)
addappid(2726841, 1, "031e71e928029bd29babfad2de2869c5345e8e11263caddec67d73c3fd202467")
