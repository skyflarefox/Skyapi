-- Lua provided by SkyAPI 
-- Game: Best Mayor
addappid(3048790)
addappid(3048791, 1, "8eeb9b1d024d3287aa335e96c1c966f8521fb2096c9559692ad78fa5977126dd")
