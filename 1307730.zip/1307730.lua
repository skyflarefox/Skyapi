-- Lua provided by SkyAPI 
-- Game: Rogue Robots
addappid(1307730)
addappid(1307731, 1, "09f9db9a7a124377205f6a5093651bc848aebe72339b62653cd16d84eabf5635")
