-- Lua provided by SkyAPI 
-- Game: Times Of War
addappid(2444600)
addappid(2444601, 1, "6c9caf638bbe5c0bc0d08dfeac434c67752097354af565a27819acc0f39957ca")
