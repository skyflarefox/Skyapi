-- Lua provided by SkyAPI 
-- Game: The Occupation
addappid(765880)
addappid(765881, 1, "ede560b431348bd708325ed9f25c8816263393a782cd0444b33339a1573edaa5")
addappid(1172700)
