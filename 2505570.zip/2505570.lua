-- Lua provided by SkyAPI 
-- Game: Burger Shop 3
addappid(2505570)
addappid(2505571, 1, "37130c3d1cef8499046837217b86c1be5fc653ca4a8065c063b9e22f32bd15cc")
