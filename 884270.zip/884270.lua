-- Lua provided by SkyAPI 
-- Game: AppID 884270
addappid(884270)
addappid(884271, 1, "b56fc1049d41d96b4d965f60e74a20d0f5c4ecd83bf0a2339c73554075310d37")
