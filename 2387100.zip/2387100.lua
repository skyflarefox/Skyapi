-- Lua provided by SkyAPI 
-- Game: Derpy Dino
addappid(2387100)
addappid(2387101, 1, "50fc3385f9806645781b7c506db0113c14ce4c2ac25de673215f41427d80d6a7")
