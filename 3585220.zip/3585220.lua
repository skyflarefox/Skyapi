-- Lua provided by SkyAPI 
-- Game: Monster Mayhem
addappid(3585220)
addappid(3585221, 1, "04a9d337f6f0d6ae80f122f995b7148210d4bd3aa7bdee383d8102fa744c21f3")
