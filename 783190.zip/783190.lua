-- Lua provided by SkyAPI 
-- Game: AppID 783190
addappid(783190)
addappid(783191, 1, "c3218dfa8f2a3486ee6f90f3f6434250805d7a4766deccbb90e0f275ad68f9fc")
addappid(783192, 1, "5ecd55c864f09b03c83c08b6ea19cf6c8debe76b96041380c6f76449fdf85c4a")
addappid(783193, 1, "0bc96b439a8e46b88ab6e551badc1392ce447848dd0effafb43a57f11718f0ac")
addappid(783194, 1, "9bf1157ac1d6ca7517121974a1aa24575387e61643c1791544eaafafb6da6a5e")
addappid(1165051)
addappid(1165052)
addappid(1170890)
