-- Lua provided by SkyAPI 
-- Game: Sexy New Year
addappid(2327790)
addappid(2327791, 1, "af7b7e57421f437c07024ea8f58dc19649b41f88a8e6a8e221b1524979e07862")
