-- Lua provided by SkyAPI 
-- Game: AppID 466500
addappid(466500)
addappid(466501, 1, "c06a1bd65a2698736c31050288fdacb76add39f5ac80ba82b88ba80e55be659e")
addappid(486210, 0, "e866364a3617ca91c4250078d117d56ef571d7fc5cfa7534b9750329e8b68bf6")
