-- Lua provided by SkyAPI 
-- Game: Sakura Isekai Adventure
addappid(2646050)
addappid(2646051, 1, "5063078418cc94616e99f8c453eb16a74b8b13770bde84af02111efc079eccb8")
