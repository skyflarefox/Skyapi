-- Lua provided by SkyAPI 
-- Game: AppID 2394540
addappid(2394540)
addappid(2394541, 1, "fd815dd54b7c356d634d425c19bf63c5af194df971354be7b714e7da2611d1cc")
