-- Lua provided by SkyAPI 
-- Game: GUNHEAD
addappid(704000)
addappid(704001, 1, "571a303fee1a42d1121bb33f4bfb5917f96ea44376f7044c780ee0050ec488ee")
