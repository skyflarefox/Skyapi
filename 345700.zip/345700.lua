-- Lua provided by SkyAPI 
-- Game: Echo Tokyo: An Intro
addappid(345700)
addappid(345701, 1, "2e9a394c79e8cc788f4bd5d96368e27182e8a17e9e1d7e675397504ff845040e")
addappid(372810, 0, "5093ac1b489763119a68c1cad27d087b53a4c0f442791b5440e6c89fde2d326b")
addappid(390490, 0, "7245a615574b27e9e3041d6aec22c5faa782d6004db60ac734891fba01db5dbd")
