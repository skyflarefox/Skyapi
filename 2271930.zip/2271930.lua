-- Lua provided by SkyAPI 
-- Game: IfSunSets
addappid(2271930)
addappid(2271931, 1, "a9c8ce48855c73a5fa7beb2422ba11ac8bd612529feb8e8bd8a06cb0004652f2")
