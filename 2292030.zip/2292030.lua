-- Lua provided by SkyAPI 
-- Game: Little Garden
addappid(2292030)
addappid(2292031, 1, "4252c5f3ecc91351a9f1ebd27f0146bc5c87beac51cd91a4cbeed48687e5ee93")
