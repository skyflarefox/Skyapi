-- Lua provided by SkyAPI 
-- Game: 迷离诡夜 blurred weird night
addappid(1448000)
addappid(1448001, 1, "0445234211b4ae1169c59a96c9b6663a4f1893494e0dcae848166d852425a8e4")
