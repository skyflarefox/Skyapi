-- Lua provided by SkyAPI 
-- Game: AppID 563200
addappid(563200)
addappid(563201, 1, "340b6df77bf09192b34332fce2cc94c1b5b51d253cc60749616383ca3980a696")
