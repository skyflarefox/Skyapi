-- Lua provided by SkyAPI 
-- Game: HotFloor
addappid(865190)
addappid(865191, 1, "1cf261f4c39cf7aab3ceec368a4caac9a2ab77b182c4627576d656dd6001e359")
