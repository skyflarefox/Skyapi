-- Lua provided by SkyAPI 
-- Game: Agent Intercept
addappid(1502710)
addappid(1502711, 1, "639d11a977b712d765bb0b3a91fcbcefa738cceb2a099be5d6b823ece02ff457")
