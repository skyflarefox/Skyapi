-- Lua provided by SkyAPI 
-- Game: London Detective Mysteria
addappid(627350)
addappid(627351, 1, "ab591be847338f5fca063dc9767a8de27852851f0aac0abee49f9c5e62b88ccb")
