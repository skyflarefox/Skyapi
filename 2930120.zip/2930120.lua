-- Lua provided by SkyAPI 
-- Game: AppID 2930120
addappid(2930120)
addappid(2930121, 1, "700728292236a24b02ee1beb9a3d6e1d9688f7a7941471248bc46ca1bf1d9b99")
