-- Lua provided by SkyAPI 
-- Game: AppID 2019340
addappid(2019340)
addappid(2019341, 1, "8b5f2a05225036542054d5984688bc5847be97fa49bb0fbbc4e9bb2171aad5de")
