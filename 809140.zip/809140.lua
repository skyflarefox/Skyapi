-- Lua provided by SkyAPI 
-- Game: AppID 809140
addappid(809140)
addappid(809141, 1, "346879f2be8e1a23573d0efd74fdae779a11ec685f5d6b5cd7ed809dd9591de5")
