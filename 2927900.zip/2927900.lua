-- Lua provided by SkyAPI 
-- Game: Runner
addappid(2927900)
addappid(2927901, 1, "aabf704c9e6bf3de86a04d9c2130ec6e600b5b10b79f8637c4c970864560858c")
