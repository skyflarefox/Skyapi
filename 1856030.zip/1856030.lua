-- Lua provided by SkyAPI 
-- Game: Fresh Start Cleaning Simulator
addappid(1856030)
addappid(1856031, 1, "678c5ef0751ec903cf33707a2597aa87c9f5463ec9571d7f358802fcddf871d9")
