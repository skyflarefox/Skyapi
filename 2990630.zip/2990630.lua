-- Lua provided by SkyAPI 
-- Game: AppID 2990630
addappid(2990630)
addappid(2990631, 1, "8212fa75782c894bc83dfd8d95a3c8b2cb2bf94810b8e1717b5ff6bff9d32125")
