-- Lua provided by SkyAPI 
-- Game: AppID 13250
addappid(13250)
addappid(13251, 1, "30de512fe1f57d38b1081a26c95b3f05416e656c19829d147fb4d5998c2a9ead")
