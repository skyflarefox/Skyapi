-- Lua provided by SkyAPI 
-- Game: AppID 727760
addappid(727760)
addappid(727761, 1, "3b97e3f7dd04c73cf463b2ba77a9486021f16038d18ad840b2014dee086b5d80")
