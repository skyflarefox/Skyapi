-- Lua provided by SkyAPI 
-- Game: Cthulhu: Death Escape / 克苏鲁:死亡逃脱 Prototype
addappid(1456230)
addappid(1456231, 1, "b1bb4a2eb4d408b49757585b486c2b24220743271af5a19f1cc7c67d5a485024")
addappid(1593540)
