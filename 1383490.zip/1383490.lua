-- Lua provided by SkyAPI 
-- Game: Run For Your Life
addappid(1383490)
addappid(1383491, 1, "c7626ba0f4fdca7f108d55378b9c9ac31ca0ef19ef23a633b79a0280610b8346")
