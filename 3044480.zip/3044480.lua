-- Lua provided by SkyAPI 
-- Game: AppID 3044480
addappid(3044480)
addappid(3044481, 1, "78f5f6390a1d2f35245b59742895ac443704e1fd1a83606045115370b5eb974f")
