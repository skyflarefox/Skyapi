-- Lua provided by SkyAPI 
-- Game: Seven Lovers In The House
addappid(2774830)
addappid(2774831, 1, "78325fc11eb25d943def824f0388dd4f468aaa36d9f7a2d0c2b06f83e46c7c32")
addappid(2901510, 0, "2ed089623e765682785e7e5d9e383bc1e4fbf925b7c83bd8187b2eb084117660")
