-- Lua provided by SkyAPI 
-- Game: Miko in Maguma
addappid(2877240)
addappid(2877241, 1, "1b092c7ade12a51dedddec5748b4e6fad0a4d6ec2d5e4bc0aba8fbe2093e9660")
