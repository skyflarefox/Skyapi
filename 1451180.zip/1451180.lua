-- Lua provided by SkyAPI 
-- Game: Yaga Soundtrack
addappid(1451180)
addappid(1451181, 1, "8562d34a8fc3fb203d6dee3b4b4924f7c614c9e724d7e410fc39c5b8da8005de")
addappid(1451182, 1, "36e91b73ec3787ef8b0f695862f0a7addf6518ddc4adea5b21f0bb3eeccb5f90")
