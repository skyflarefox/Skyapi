-- Lua provided by SkyAPI 
-- Game: Einstein's Cats
addappid(2857980)
addappid(2857981, 1, "4fdafd1e1a8472937c7f2a7a4958af5322af796df78c0f681e83cbfc471b6178")
