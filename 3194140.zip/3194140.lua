-- Lua provided by SkyAPI 
-- Game: Cozy Sudoku
addappid(3194140)
addappid(3194141, 1, "d9cb1d9252cb59c4d11609d4135650b1b5145d165f29e16d55d1f2e671a218c0")
