-- Lua provided by SkyAPI 
-- Game: Mr. Massagy
addappid(511350)
addappid(511351, 1, "391552eb44eddc603316d1fd68611b0a5a7e1c49785b4a5a72a29c6bd995dc5d")
