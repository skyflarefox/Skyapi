-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1332420)
addappid(1332421,0,"8753f2c35620c8b811315dfa7573fed19bc8f4a684e0a73b760ed3525d6d6fa3")
setManifestid(1332421,"5405633280674514121")
addappid(1332422,0,"489d4d3c9bcefa769d23ceaaf0789de21f974b57fdf42726605b19cc8ed4a497")
setManifestid(1332422,"3306334178854029144")