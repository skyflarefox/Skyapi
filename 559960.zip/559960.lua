-- Lua provided by SkyAPI 
-- Game: Power Hover
addappid(559960)
addappid(559961, 1, "1f77fc8068ce9bd22bd6dcf271b8926d5527f1ddb3c0161a1a1d6420a1b6b84d")
addappid(559962, 1, "f158cf7e39fbe09d8f378b393facd24441e9fe53cd390f52477ea18049999724")
