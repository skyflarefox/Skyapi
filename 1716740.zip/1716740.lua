-- Starfield
addappid(1716740, 1, "aadd49bba583a51f17cf343fa4ff71c77f30a51cc417490f7a35b8a3c2dc59ea") -- Starfield
addappid(1716741, 1, "14c0bdb25d858d05a7381ba67a373aa99b50c5bd4cf78f1895751d418de29ceb") -- Depot 1716741
addappid(1716742, 1, "f7ba0bf1fd70db2958682bc87fcab6dfe9a6f8ca774321df79b1d595d5be303b") -- Depot 1716742
addappid(1716743, 1, "d0a17417a778577c9edb2b58f5352ad326ba2def007a1e3eacd058ac4293907a") -- Depot 1716743
addappid(1716744, 1, "a2c8d4541f82fe48dd2252b967d0af91f36454f141840c7f18ce4904a1300a54") -- Depot 1716744
addappid(1716745, 1, "409f827297a516a03a1619f1f9c419da22001bf78297e4dcf3884af93b4b50c0") -- Depot 1716745
addappid(1716746, 1, "03e63b3a66513fc8232b0675af0269ae351370508e1f988cbca4f6324ab7d86e") -- Depot 1716746
addappid(1716747, 1, "bf59310131ad2859544a15359fc90c7dbdbd7c2fb1efb9e633a9044d6b07975f") -- Depot 1716747
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- Dlcs
addappid(2401180)
addappid(2401180, 1, "abb5f01b77e2f81e4b06049a0a17302bd7c9dacc7715b9536f6f3462ad51dd89") -- STARFIELD DIGITAL PREMIUM EDITION UPGRADE - Depot 2401180
addappid(2401181)
addappid(2401181, 1, "9382f0b0fee3c8ccb0cf9fc2389a52eab89fdf1c4e6f408635a82b30037aed9e") -- Starfield - Preorder - Depot 2401181
addappid(2721670)
addappid(2721670, 1, "34f5ffb0f43b8e1e3de155a0cea2f5e9f53c87b19431cf7e1bfe08e4d3806ff9") -- Starfield - Shattered Space - Depot 2721670
addappid(2721671, 1, "ccfca2d801690b92437b56892cc3f331c77d8e1688cb75485d6979d179e6aaa2") -- Starfield - Shattered Space - Depot 2721671
addappid(2721672, 1, "5e3835e229258b76be58c76fa52698064aaf2b04f7786a674ed7912b6556cf96") -- Starfield - Shattered Space - Depot 2721672
addappid(2721673, 1, "22841c1a633eccea581ca7b7c5fcf8b0e719cb757e2805d15fabd3ec6789267c") -- Starfield - Shattered Space - Depot 2721673
addappid(2721674, 1, "2444b0653ae7af96c558260ce936805ecda73dfe0a8647e5ff9c1e19d2669ecb") -- Starfield - Shattered Space - Depot 2721674
addappid(2721675, 1, "9c9897d73ba01838de4bad44e2487bd6f103fe70ae45c088c56aeda7e8b3e9e0") -- Starfield - Shattered Space - Depot 2721675
addappid(3763700)
addappid(3763700, 1, "2797c7863691541ceccebc7d44902968a889cb785cba5d945dc3a3d401bb813d") -- Starfield - Terran Armada - Depot 3763700
addappid(3763701, 1, "87fc0e1a6e04ccdaf6ba7032e260e714909066c3b004ded9e888381841190992") -- Starfield - Terran Armada - Depot 3763701
addappid(3763702, 1, "293949da123110d321949e93f49176fb4f7a67705f81b31f5a12febad68143ae") -- Starfield - Terran Armada - Depot 3763702
addappid(3763703, 1, "b0aa567554d37d5c075d428ccf1d9da7f8146073a6533829481a4f588f0f7f56") -- Starfield - Terran Armada - Depot 3763703
addappid(3763704, 1, "ddfd631e1b163e7d1e824c4516d317c73fc8e3a2e4313316b9e615651b2ab94d") -- Starfield - Terran Armada - Depot 3763704
addappid(3763705, 1, "f181f528c945f2317e1d9a29d82f2411c6979ddab73f7d6965c590a37c9bfa30") -- Starfield - Terran Armada - Depot 3763705addappid(2792440) -- Starfield - Creations