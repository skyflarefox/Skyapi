-- Lua provided by SkyAPI 
-- Game: AppID 376350
addappid(376350)
addappid(376351, 1, "78763edd8c7b09c0aa82bff7e59835023e13cd4e1465b0871d949f367bb0b083")
