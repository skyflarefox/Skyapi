-- Lua provided by SkyAPI 
-- Game: AppID 1252670
addappid(1252670)
addappid(1252671, 1, "b610d96dcb376f9d3270d3ea7ebf55dfd1d383b238b20410c9ae759d5fa4fb4c")
