-- Lua provided by SkyAPI 
-- Game: Horny Pixels
addappid(1834470)
addappid(1834471, 1, "2367f6a4f304a4aef267940d25b8e60583f8ad89e2ae32b23a54c49f03efc4d8")
