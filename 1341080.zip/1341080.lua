-- Lua provided by SkyAPI 
-- Game: AppID 1341080
addappid(1341080)
addappid(1341081, 1, "9beae01813f6ad7e63b83e27a276e587d4f5b7b6d06ba116d4d2a34a2e781c19")
