-- Lua provided by SkyAPI 
-- Game: Mind Over Magnet
addappid(2685900)
addappid(2685901, 1, "ad7cf548031b2d0ad2008123d9ecc39fa24cdf9306c64935caa688a332198c0b")
