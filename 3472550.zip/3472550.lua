-- Lua provided by SkyAPI 
-- Game: The Mr. Rabbit Magic Show
addappid(3472550)
addappid(3472551, 1, "fd23b3a246d36187c0480f5e56bfddfa3390cb404f41fece337e4ee8e729ec50")
addappid(3701380)
