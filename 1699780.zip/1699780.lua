-- Lua provided by SkyAPI 
-- Game: Splash Jump
addappid(1699780)
addappid(1699781, 1, "68def674549e52adfd6bfdab60a5d1b14bd53f13339f99a4e6eb83b5f2d2fcf8")
