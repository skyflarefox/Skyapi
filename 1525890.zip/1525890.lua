-- Lua provided by SkyAPI 
-- Game: Death Park 2
addappid(1525890)
addappid(1525891, 1, "860decafe72c377f69723bcf7f2a743293af372aae7888ca60c36f774311a3db")
