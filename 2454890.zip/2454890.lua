-- Lua provided by SkyAPI 
-- Game: DEATH IN UNISON
addappid(2454890)
addappid(2454891, 1, "79c08f047305cc5e13da78089edf4c6107ad436761e59708c76910911a82c856")
