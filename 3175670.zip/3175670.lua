-- Lua provided by SkyAPI 
-- Game: Defense Builder
addappid(3175670)
addappid(3175671, 1, "2cdbff526a6a1f6f52e680afd6d910b3e83895cde454ed5ace37f46dd0063e78")
