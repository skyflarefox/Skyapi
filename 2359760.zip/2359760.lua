-- Lua provided by SkyAPI 
-- Game: Wild Legion
addappid(2359760)
addappid(2359761, 1, "04c5c8957cddbd3e267aca53d891f7a0ddbba5ba0057ee7fa5bef2f460241d49")
