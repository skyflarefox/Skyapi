-- Lua provided by SkyAPI 
-- Game: ReHarmony
addappid(2692760)
addappid(2692761, 1, "531297183889a648ddfdc7d45c49c8974cc0a2e6511232c6bb897a2a07c358c0")
