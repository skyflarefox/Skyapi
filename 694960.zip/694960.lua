-- Lua provided by SkyAPI 
-- Game: Zenethics Lab : Outbreak
addappid(694960)
addappid(694961, 1, "dca518420c5f4ea3426a5575d3d996687ae2e920767b90a9c793773ca9ea0e77")
