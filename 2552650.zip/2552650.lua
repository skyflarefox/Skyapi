-- Lua provided by SkyAPI 
-- Game: AppID 2552650
addappid(2552650)
addappid(2552651, 1, "090c7f2fb659c31cda11888a6d9685e624140ca93a672b3095aa45960fd40f55")
