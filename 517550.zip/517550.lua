-- Lua provided by SkyAPI 
-- Game: The Enlightened League of Bone Builders and the Osseous Enigma
addappid(517550)
addappid(517551, 1, "3b36f35a4f1e3f2d1a841a3b0b4c19f1fa6af27b6e642c64a0b0d63ceb985187")
