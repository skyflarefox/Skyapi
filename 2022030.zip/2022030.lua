-- Lua provided by SkyAPI 
-- Game: Watcher Of The Abyss
addappid(2022030)
addappid(2022031, 1, "166041cf59e163405b81355f2a114f719b8da3a816177bc110d9325d000e63a8")
