-- Lua provided by SkyAPI 
-- Game: AppID 2780210
addappid(2780210)
addappid(2780211, 1, "49cc37b367da0e2d791ff763c248a7459f28d98d9533ad8c1a41605c07e9b3b7")
