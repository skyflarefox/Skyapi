-- Lua provided by SkyAPI 
-- Game: Noir Chronicles: City of Crime
addappid(756500)
addappid(756501, 1, "0451c7c90d35a313f7acbc8ec3273000d427bce7b1e8ce684f96249e489369c9")
addappid(756502, 1, "52dfadce13a032f12d4da7566d0bbfb23b29b14c87db617f468ff6f988d5a632")
addappid(756503, 1, "64cd1a60aa920af6e7f47825237dc0cdc168de505597d89770903ba355dfb0a8")
