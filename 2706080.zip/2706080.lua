-- Lua provided by SkyAPI 
-- Game: AppID 2706080
addappid(2706080)
addappid(2706081, 1, "4dd0e727425288068721afe25f00a6178fc9a783723fd48a4751131e83b4e6ea")
