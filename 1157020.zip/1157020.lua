-- Lua provided by SkyAPI 
-- Game: 1001 Hugs
addappid(1157020)
addappid(1157021, 1, "eb14803d665f61605ac48983b0d066eff3f226c927ef7e9cd6117d469ecc73d3")
