-- Lua provided by SkyAPI 
-- Game: AppID 410040
addappid(410040)
addappid(410041, 1, "4b25ec71a3fa304459e4215aa5c1765ec9e26ed0f9343e19832bcbeb25f89000")
