-- Lua provided by SkyAPI 
-- Game: Goosebumps: The Game
addappid(361360)
addappid(361361, 1, "5ce9e2fc4304e209789b9a0412b8047149da4f6df48203539a1ca4c424113858")
