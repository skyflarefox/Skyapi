-- Lua provided by SkyAPI 
-- Game: Kronorite
addappid(876780)
addappid(876781, 1, "0d909734dd05f96647b11df3a5e0bfbb97433a910575fc23c00f028151ee0076")
