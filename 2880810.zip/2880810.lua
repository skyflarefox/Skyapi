-- Lua provided by SkyAPI 
-- Game: Deception Demo
addappid(2880810)
addappid(2880811, 1, "116567998adda7626fbc9767c33688a62e7320bd80c84c44772da31c7bb4f70a")
