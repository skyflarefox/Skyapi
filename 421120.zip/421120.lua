-- Lua provided by SkyAPI 
-- Game: AppID 421120
addappid(421120)
addappid(421121, 1, "6804e651b30739c2f8fbd98cedd38461356a28532e94440adcdd7f11546091b4")
addappid(421122, 1, "a990e9ee5e46d09f1000dde05e2af48c90ec608e6a387849837f072b86dd9a92")
