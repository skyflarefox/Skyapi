-- Lua provided by SkyAPI 
-- Game: Perfect Poses
addappid(2758210)
addappid(2758211, 1, "ee4d400dfa9117a09b7abb2c18a07ddcbaad010f1e41f0b1ca97744b45f6fb29")
