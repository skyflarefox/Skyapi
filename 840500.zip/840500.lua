-- Lua provided by SkyAPI 
-- Game: Dictator's dreams
addappid(840500)
addappid(840501, 1, "f906647f90ec821b891dad332862350c0119888a5f47f2d93e5760519acebe71")
