-- Lua provided by SkyAPI 
-- Game: AppID 879000
addappid(879000)
addappid(879001, 1, "0cdee94be1f1cc3bf4c82dafc776e052384e783e9473b757367cf8f0ec1b9d44")
