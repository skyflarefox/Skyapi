-- Lua provided by SkyAPI 
-- Game: Dungeon Golf
addappid(2144040)
addappid(2144041, 1, "5a5accc55a440ea20890e415632fadf105ea95892a1d348ea419d16f5ba6fc38")
