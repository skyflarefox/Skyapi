-- Lua provided by SkyAPI 
-- Game: Tank Frenzy Survivor
addappid(3331640)
addappid(3331641, 1, "d390e07c9a3d3ad5aaa7beeec19a61fdb24c6f6477207af046c193695d34869c")
