-- Lua provided by SkyAPI 
-- Game: Don't cut your hand
addappid(603350)
addappid(603351, 1, "82a2f75c9726b03df60779fdfb4ce861304f42468e3caae99dc74dd10d04aa44")
