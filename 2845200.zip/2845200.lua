-- Lua provided by SkyAPI 
-- Game: SULFUR Demo
addappid(2845200)
addappid(2845201, 1, "3d47a63d0ff16cc964ca49da96b4da032ba8ddbb9af6f7cc55d57267be323d18")
