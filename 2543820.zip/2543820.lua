-- Lua provided by SkyAPI 
-- Game: Ants in Space! Demo
addappid(2543820)
addappid(2543821, 1, "90cbfa4d67fcca992650c71957a86372d35d3e101b13f52f4b932685e6e66e17")
