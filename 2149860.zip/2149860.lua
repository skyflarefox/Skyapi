-- Lua provided by SkyAPI 
-- Game: Sensual Haunting Demo
addappid(2149860)
addappid(2149861, 1, "a11f375fd2b3ddaea13b22134052d103db08506a9fe9d472149564864009be08")
