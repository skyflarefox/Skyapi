-- Lua provided by SkyAPI 
-- Game: AppID 1634750
addappid(1634750)
addappid(1634751, 1, "2c5bdac580fe49ac1ba92d521fbe30993cc99abf162cf79a7fbdea2422bd40d7")
