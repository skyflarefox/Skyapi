-- Lua provided by SkyAPI 
-- Game: Rewind Or Die
addappid(2329130)
addappid(2329131, 1, "a2d295a723c92f7c93eefa7770f7674971be0e5aee21dd93d6529ecdda82516a")
