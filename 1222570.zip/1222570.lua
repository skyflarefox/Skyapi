-- Lua provided by SkyAPI 
-- Game: Red Ronin
addappid(1222570)
addappid(1222571, 1, "1a4100751d5606dc38cd446da6328645d6ed02f1b6115bac536a2d0216e6ff02")
