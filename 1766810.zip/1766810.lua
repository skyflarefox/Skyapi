-- Lua provided by SkyAPI 
-- Game: SnOut 2
addappid(1766810)
addappid(1766811, 1, "fd7b3c4e747976b9104bd7d26c67fddd6a561034524f8027cba07d6112589c1e")
