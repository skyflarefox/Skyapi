-- Lua provided by SkyAPI 
-- Game: Snezhinka:Sentinel Girls2
addappid(2608350)
addappid(2608351, 1, "51c15c8e0818fac8b90ddc9550d06108dcad4ee82b9c44511bb39ed04c0c9b1b")
addappid(2826230, 0, "f7e07000577e64df641a5c4a6202654aa5ca9581838575b75ee714d03b7fa144")
