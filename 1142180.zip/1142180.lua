-- Lua provided by SkyAPI 
-- Game: AppID 1142180
addappid(1142180)
addappid(1142181, 1, "5be47fadf1450c609b218d82164e12926873af0e59d82661838e3cce95d0db30")
