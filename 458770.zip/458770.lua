-- Lua provided by SkyAPI 
-- Game: WRC 6 FIA World Rally Championship
addappid(458770)
addappid(458771, 1, "98497e050f445b61e899a6f618ef75a6384f5485eb3a9b5909739dca9387b2cb")
addappid(538080, 0, "fefe5598c34182378d6e310ae31806c64b080a081d7cd766ac73c1a0e7cbe8d6")
