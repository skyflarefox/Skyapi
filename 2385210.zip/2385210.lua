-- Lua provided by SkyAPI 
-- Game: Tulgey Wood
addappid(2385210)
addappid(2385211, 1, "a1058f4c78e885b20cb18798741a2e7ab65f3a8118d23799ab1610c20da3ebfa")
