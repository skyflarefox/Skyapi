-- Lua provided by SkyAPI 
-- Game: Machinarium
addappid(40700)
addappid(40701, 1, "37b5c7293653b02c677be46f10d154102e715fda6a2e0ccbbf7f8a11c5e7c91e")
addappid(40702, 1, "d1a795482b2ed2bc97591ba8a6020c1a1392da9794f3f0648611113f22f323ec")
