-- Lua provided by SkyAPI 
-- Game: Russian Front
addappid(385960)
addappid(385961, 1, "f5f58a8735c80789eeff7e49d9c5ee61b19e3e08fff34168be8cb47e3f1df436")
