-- Lua provided by SkyAPI 
-- Game: Neon the Ninja
addappid(698650)
addappid(698651, 1, "69fb3d462d82b12d647d632ed8972ce5ef14457fd47348eaf6542056b60e02ba")
