-- Lua provided by SkyAPI 
-- Game: Munch
addappid(2427050)
addappid(2427051, 1, "37fc263e5a9773e6494df5b4490ad4fa822390ad3a3c551a1da7fb3d18481b3a")
