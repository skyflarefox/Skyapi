-- Lua provided by SkyAPI 
-- Game: AppID 3435860
addappid(3435860)
addappid(3435861, 1, "67466bf9434ea477f42ccefbae4f6443b5f7f287946acd134d3d6e57b656d799")
