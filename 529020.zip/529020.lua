-- Lua provided by SkyAPI 
-- Game: AppID 529020
addappid(529020)
addappid(529021, 1, "a4de7472b7034326a6e3f5790f041e88e4f73736ed7b3d6005ea316cdf1b49b8")
