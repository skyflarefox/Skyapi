-- Lua provided by SkyAPI 
-- Game: Crazy Kung Fu
addappid(1340300)
addappid(1340301, 1, "1e5f55cbb8018ebb3e6dcf05c7d12592dfe09975832816b8b0bd5c157d4e7f47")
