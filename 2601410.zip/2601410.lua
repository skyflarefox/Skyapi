-- Lua provided by SkyAPI 
-- Game: Pixel Art Academy: Learn Mode Demo
addappid(2601410)
addappid(2601411, 1, "f02a4372b4a45675550379056fa1ebf392bec5c4301426c95455c293e1c1bda4")
