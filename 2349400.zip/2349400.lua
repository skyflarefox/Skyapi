-- Lua provided by SkyAPI 
-- Game: Clipbase - Clipboard History Manager
addappid(2349400)
addappid(2349401, 1, "7f3de0bf4c6f7c9bfc4e99c80c7d7ba8650f830914a7fb99a9fa225a9cfd37ea")
