-- Lua provided by SkyAPI 
-- Game: Aspectus: Rinascimento Chronicles
addappid(342250)
addappid(342251, 1, "c28a7eb858f99ee7cd22f9e37af9eb437b12544bcb4cb0e4ddf6a16aa4b1a91a")
