-- Lua provided by SkyAPI 
-- Game: GLUM
addappid(2235550)
addappid(2235551, 1, "4a3a833293d076add7bfbac51657b66e32afab7a33a40b173afef8d2d835cafb")
addappid(3693840)
