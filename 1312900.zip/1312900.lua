-- Lua provided by SkyAPI 
-- Game: Deep Dark Forest
addappid(1312900)
addappid(1312901, 1, "c61c80d332d48ad0b007208e6697311d3de94f48685dee62aecec591bb64252c")
