-- Lua provided by SkyAPI 
-- Game: AppID 3172950
addappid(3172950)
addappid(3172951, 1, "b8e861bf91ce765c276f22d9d63d79f571b8640650c7c8fcbb1fcadc644e8a97")
