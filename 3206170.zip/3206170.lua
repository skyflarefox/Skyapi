-- Lua provided by SkyAPI 
-- Game: Food Park Manager
addappid(3206170)
addappid(3206171, 1, "7758a329395bd443d3eeb962b4ea429dc8a8f6c68267efc8a873f635861a0995")
