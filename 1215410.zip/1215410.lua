-- Lua provided by SkyAPI 
-- Game: Sproots
addappid(1215410)
addappid(1215411, 1, "47c0f9a63a3973cca62b841da28bf7a462de5e065556b91784f8944c95fe5383")
