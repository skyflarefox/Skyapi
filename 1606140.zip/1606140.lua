-- Lua provided by SkyAPI 
-- Game: Trilogy KING MAN
addappid(1606140)
addappid(1606141, 1, "1fb8486fed1fa0a67ac28ee90d8e6ca2a53a1ce2470a153d38be9da3652bfe72")
