-- Lua provided by SkyAPI 
-- Game: Last Laugh
addappid(3576690)
addappid(3576691, 1, "fe0d1215b14c65318a9805418526057f5ce7c7ac940ed1cf41c1b6dbeebd28a7")
