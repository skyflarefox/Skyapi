-- Lua provided by SkyAPI 
-- Game: AppID 949480
addappid(949480)
addappid(949481, 1, "c39417b905a3de13b679da5a9d9e17c0bc2d9f84be09b97b985642f060312b2f")
addappid(949482, 1, "e0afc3e55d920946a3e03aaec6880686fc856608774b3d761b5a9af8aaee721d")
addappid(2156870, 0, "6ccd08e03b96507a6d90ee0e3aedcbd494f56c46eeb8246dfe759d741c45b356")
