-- Lua provided by SkyAPI 
-- Game: Nubla 2 Soundtrack
addappid(1969770)
addappid(1969771, 1, "484c3a66b8ab309898da06eff63303b055d8e75936df1ed6c05c6cb20b00573f")
