-- Lua provided by SkyAPI 
-- Game: Downward Spiral: Prologue
addappid(574940)
addappid(574941, 1, "1b85a484cf7820f8007e6deec58586c5e91d0388a4101cdf73e3580c85cc0cac")
