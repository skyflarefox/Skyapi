-- Lua provided by SkyAPI 
-- Game: Linia Super
addappid(2411140)
addappid(2411141, 1, "5a3b7843780b64a7a2df3a2e6b6a520061fbd86b7327459eb0561260de07cad4")
