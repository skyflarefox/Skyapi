-- Lua provided by SkyAPI 
-- Game: Regular Human Basketball
addappid(661940)
addappid(661941, 1, "4ada3ae8031250a1c304f51d33cf572087160797195fdabbe0bebea718c95c1c")
addappid(661942, 1, "6b01f49a1b958e3ff13caa9f559cdc8e4f3e307117cb3412d2be700143274bb7")
addappid(661943, 1, "0792e3534981b5cbc7d5e40d4b36a1959353baa19c418635f1b8b3aaed913c64")
