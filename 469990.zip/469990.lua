-- Lua provided by SkyAPI 
-- Game: NEKOPALIVE
addappid(469990)
addappid(469991, 1, "07bc91442bc6e5407ba8bd72e061a8e18c4d7f1c009c9d59cb37f51047aff766")
