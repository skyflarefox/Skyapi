-- Lua provided by SkyAPI 
-- Game: The Edge of Allegoria Soundtrack
addappid(3377190)
addappid(3377191, 1, "cc8277ba09751e388f1e95484500baf980accc4555af04f5a4a5bc72e8ad8080")
