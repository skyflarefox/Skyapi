-- Lua provided by SkyAPI 
-- Game: AppID 1127940
addappid(1127940)
addappid(1127941, 1, "1e6461aee60d2643010bbcf8b2830fe3734f0984ee776f2f49a2772af7895f79")
