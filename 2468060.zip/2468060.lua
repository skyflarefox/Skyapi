-- Lua provided by SkyAPI 
-- Game: Breaking Survivors
addappid(2468060)
addappid(2468061, 1, "e5df1bfa140bf32e2fc97547145ac3341a868d1bb69f13eb0b68806fc25e112d")
