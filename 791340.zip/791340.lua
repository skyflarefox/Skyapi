-- Lua provided by SkyAPI 
-- Game: AppID 791340
addappid(791340)
addappid(791341, 1, "f42cfe468a04fad8592d6f29352a2da9a19db7e90598f837fc746a070cf6c6d4")
