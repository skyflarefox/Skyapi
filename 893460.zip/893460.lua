-- Lua provided by SkyAPI 
-- Game: AppID 893460
addappid(893460)
addappid(893461, 1, "b12cb3c9c70b72334e2005203e00603d588c6f4f204e9c4a8d7f848bb9a062c2")
