-- Lua provided by SkyAPI 
-- Game: Forced Sacrifice: Hejled
addappid(2283360)
addappid(2283361, 1, "4096288a78aac35235d9f9b65dc524248b4d5f0cc2248def8721b790bfbc1f54")
