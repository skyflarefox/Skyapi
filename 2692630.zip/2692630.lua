-- Lua provided by SkyAPI 
-- Game: Lunacid: Original Soundtrack
addappid(2692630)
addappid(2692631, 1, "c55d03c26f2c777e6c444038fa15728a7be37624dd7e116b9f6b40e674968876")
