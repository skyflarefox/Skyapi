-- Lua provided by SkyAPI 
-- Game: AppID 1441240
addappid(1441240)
addappid(1441241, 1, "15b860d9ef7f54520e7294b91a27354376c1d5fe51563fd7a0597b50d0ad3494")
