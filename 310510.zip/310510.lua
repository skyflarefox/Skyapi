-- Lua provided by SkyAPI 
-- Game: AppID 310510
addappid(310510)
addappid(310511, 1, "3588965a77d5a97aec9e785ca8aae9c47d597c072b1c776b759867af2affcbef")
addappid(310512, 1, "049eef765b64011176c2f48407611f6088da4b632ba965135894966ea710f3e4")
