-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(624090)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(624091,0,"0eaedfdfe20625923a7924d9939c58e2ce4d969f2b38838fe0c1693d925357c7")
setManifestid(624091,"6586434344960516620")
addappid(624092,0,"85b09112ae949e6d725632dd45fca3f4077510a037ff2f45dc735abaec7f1b59")
setManifestid(624092,"6020580437664476675")
addappid(624093,0,"088ea190e0f89903e796f98af0f4ce9754fbc69f53a8b3f5d6e8bb3bd27ada9f")
setManifestid(624093,"1188836194022829487")
addappid(624094,0,"da44204814c11446fcbb134e14502c0f70d791499097a615e31e42a4d18e52d1")
setManifestid(624094,"5794423974494677435")
addappid(624095,0,"a8bcf3452521a9c3bd91bc6ab0c58f4ff901c1fd7bfb759a62cf2f0fe66720fb")
setManifestid(624095,"2331486719461962212")
addappid(624096,0,"5ae68d4e6aa1961b5d5aabe060bf12392e43a6c5f1d8a7753c91a2e38b4e35c1")
setManifestid(624096,"2971559482997085453")