-- Lua provided by SkyAPI 
-- Game: Keen: One Girl Army
addappid(566490)
addappid(566491, 1, "caef7ab6a2c82094baf7ee001564353c380ace55dcfe18422d4eefc0deb8f9b0")
addappid(566492, 1, "44c9b0f8a163d08e45fdf59c14908e2275e07dfc15f5027c51aad4c0c73aff47")
addappid(566493, 1, "40f346bfd211e509c21d2c784d0979bc7be8fc953ce42af6d2cadbeb736c629f")
addappid(566494, 1, "5114845eeffc95cb66ec48ab4a49aa7dc31ba113ba557de8eb7e1d921ff2175c")
