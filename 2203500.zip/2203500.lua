-- Lua provided by SkyAPI 
-- Game: Cars vs Train
addappid(2203500)
addappid(2203501, 1, "a4213893611c3ecb0bb6ab832c50dd1286e279e36d297bfb89ccfca09fdd12c8")
