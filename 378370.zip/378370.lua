-- Lua provided by SkyAPI 
-- Game: Nomad
addappid(378370)
addappid(378371, 1, "081e6f5fd10b3c598c5bd8b9ec1e21c9d8863d6749e0247d4953ab962e45e9af")
