-- Lua provided by SkyAPI 
-- Game: Mot De Pass
addappid(1855710)
addappid(1855711, 1, "ce63ad1c740fc04252678392a6d64dfa3d5d8c2f4ffbe6849bc49be110846ac7")
