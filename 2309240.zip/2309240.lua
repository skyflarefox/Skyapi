-- Lua provided by SkyAPI 
-- Game: AppID 2309240
addappid(2309240)
addappid(2309241, 1, "78a1cc7982c1d342b647eeeeb068a1e141121ce986f39ef97100bc7d49b301a2")
