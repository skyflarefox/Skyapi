-- Lua provided by SkyAPI 
-- Game: Half Sword Playtest
addappid(2527870)
addappid(2527871, 1, "3f6418b433c5e9b32d9c205e085ee5ae124bc8c7c0d40d39b9588648008515df")
