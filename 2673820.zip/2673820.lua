-- Lua provided by SkyAPI 
-- Game: silkbulb test Demo
addappid(2673820)
addappid(2673821, 1, "e202b5ad9646d33829d8b69d4c54fa2c3d96783077108fd1609872a5deab92df")
