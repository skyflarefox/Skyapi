-- Lua provided by SkyAPI 
-- Game: AppID 351080
addappid(351080)
addappid(351081, 1, "466c7cf6e69410014f30952d7220930444d134679802302be27356fa20682c0c")
