-- Lua provided by SkyAPI 
-- Game: RageBall
addappid(660390)
addappid(660391, 1, "7a8c18c7692b4863b9962b8e8ba9ec25a56a3d1881688beb60113d35b02640eb")
