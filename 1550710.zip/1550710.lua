-- Lua provided by SkyAPI 
-- Game: Warbox
addappid(1550710)
addappid(1550711, 1, "de980e14a66fd5dc0f045e9c8c0714d30f6cb5d3781a1ce633bdf5454d8be7dc")
