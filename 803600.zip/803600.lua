-- Lua provided by SkyAPI 
-- Game: AppID 803600
addappid(803600)
addappid(803601, 1, "43fe05a18369739b01155c0e077828682e79f87bdc198e9dc869b9383869956b")
