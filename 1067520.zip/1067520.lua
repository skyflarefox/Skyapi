-- Lua provided by SkyAPI 
-- Game: AppID 1067520
addappid(1067520)
addappid(1067521, 1, "54511d6f06218451d1bb59c933e99228d995f73422a9063c1a4077b39c9cdfbe")
