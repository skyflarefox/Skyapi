-- Lua provided by SkyAPI 
-- Game: Sixty Four
addappid(2659900)
addappid(2659901, 1, "948b537e16b1f7f17071329983f2d3d57c5cde71d1a8a34e50dafc71afc03ae7")
