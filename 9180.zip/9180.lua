-- Lua provided by SkyAPI 
-- Game: Commander Keen
addappid(9180)
addappid(9181, 1, "8165b38d55b9476044ed2e1776bbc2c2d7824a3dbea672ce5279da46253b7005")
