-- Lua provided by SkyAPI 
-- Game: Elasto Mania Remastered
addappid(1290220)
addappid(1290221, 1, "0f5f4a6e524c6779ae0f36fc7897138152c55ec12ef4cc1947bf177068b4bd2c")
addappid(1290222, 1, "150de84d86370e58f991de7dc98551101d744e5aec69083b45a639753bbb4685")
