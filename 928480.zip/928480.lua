-- Lua provided by SkyAPI 
-- Game: Darkness and Flame: The Dark Side Collector's Edition
addappid(928480)
addappid(928481, 1, "b7dcf68fc4a1dc87f63046e15436987d7a5f5a56b687a29faf2554f57dba4583")
addappid(928483, 1, "29e72e9cbf1b7fa0ae4b4b3c33881ab9f0a49fd3f0cae4eac8c3899e12a536f4")
addappid(928484, 1, "e6a3a8373eccfd6a3c123a50c8a8e3d2ebcf4b43fbcbee2982f03a1e5f9a4f5e")
