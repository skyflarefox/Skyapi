-- Lua provided by SkyAPI 
-- Game: Dark Days
addappid(2856570)
addappid(2856571, 1, "95e7a3d60cccd9ecb52ac3e2b92961b6f6028ecaccf486349dda7651e2210ab4")
