-- Lua provided by SkyAPI 
-- Game: COTTOn Rock'n'Roll -SUPERLATIVE NIGHT DREAMS-
addappid(1364760)
addappid(1364761, 1, "d6e0a91c184b5daccafdd35a61687c82e6b24242040af1634b39fd3f84b7a89f")
