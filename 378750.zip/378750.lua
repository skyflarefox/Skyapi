-- Lua provided by SkyAPI 
-- Game: Sayonara Umihara Kawase
addappid(378750)
addappid(378751, 1, "cf078aa3934fcf4171d870238ffce504f36c6603d15b7bf8d9ba0fdb9ea4f0a2")
