-- Lua provided by SkyAPI 
-- Game: AppID 886590
addappid(886590)
addappid(886591, 1, "03ecd033b713f8104564356e69ce4d5400f588f7cfff5b4efee4975daf57cf11")
addappid(886592, 1, "00d208b735b84654e43979452bfb057c9d6c2c0b59c992ddcf68d65ad993af4d")
