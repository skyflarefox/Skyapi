-- Lua provided by SkyAPI 
-- Game: AppID 2758270
addappid(2758270)
addappid(2758271, 1, "f7b409722c237404c5491ea2c099a1806cc7f630c4ad1fc1c5e5e4b8120f9ca6")
