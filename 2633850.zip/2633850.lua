-- Lua provided by SkyAPI 
-- Game: AppID 2633850
addappid(2633850)
addappid(2633851, 1, "a27f21c1b5a1acad299fa93df4679d9e09a728d606593e9f1e16c939dc45d186")
