-- Lua provided by SkyAPI 
-- Game: Floating Life Record
addappid(2557870)
addappid(2557871, 1, "3f9d4fad1969550b121ae753b17d325350a51ed20b8f6470947d0d56ffdf3d72")
