-- Lua provided by SkyAPI 
-- Game: Unit Down
addappid(1538350)
addappid(1538351, 1, "49fa358570fb524b37cc0864321a78461363ee365be65d656b5b52723c3ab29c")
