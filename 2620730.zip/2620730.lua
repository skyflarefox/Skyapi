-- Lua provided by SkyAPI 
-- Game: DEVIATOR
addappid(2620730)
addappid(2620731, 1, "d7a48e5026010c357d7b5c8064679e589f8def84dc2689b353b600df90a785d5")
