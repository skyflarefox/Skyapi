-- Lua provided by SkyAPI 
-- Game: Imagine Earth
addappid(280720)
addappid(280721, 1, "4f4bca96a3f8b3b6d54c2f6ecc467d19705fe8f86fb9faf58271c630d67e5a7b")
addappid(280722, 1, "2252baf3e3bfcd59aedb2870276279fcd5d562fc58932386cdce0a08b0309d34")
addappid(280723, 1, "4088f8dab7eb61e91d8c67b0e5d7d58cf2e6248726d8492294bf469b140edd94")
