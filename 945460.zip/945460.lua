-- Lua provided by SkyAPI 
-- Game: Zombie Builder Defense
addappid(945460)
addappid(945461, 1, "523726336668b928387a24a58d7a14e79fe9086cb407f90eb906621190b37fdd")
