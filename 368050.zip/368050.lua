-- Lua provided by SkyAPI 
-- Game: Almightree: The Last Dreamer
addappid(368050)
addappid(368051, 1, "4fd98b1835ecc6490377a3f3f206ab7a6ad1c21bbfed1962e0446b946cf285b1")
addappid(368052, 1, "687372356a841db59740aead5f4b92a9aa91e4cd25413a93ea800b72ed721b32")
addappid(368053, 1, "23d47761f2b10c60cd705849d650785df6eac0dc64008a27fed91281ba0ef134")
