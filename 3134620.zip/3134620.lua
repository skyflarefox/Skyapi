-- Lua provided by SkyAPI 
-- Game: AppID 3134620
addappid(3134620)
addappid(3134621, 1, "5ac6a54e4ded3bd226c74c152d526dc960897e23618689a8cda32acf20cd92ca")
