-- Lua provided by SkyAPI 
-- Game: Sakura Gym Girls
addappid(2017640)
addappid(2017641, 1, "082ede6de577c3d26b17790d30fc75be73d0ffde4a0162ab83d419c926e28c7e")
