-- Lua provided by SkyAPI 
-- Game: DeeperRed2028-WeAreEscape-
addappid(1215120)
addappid(1215121, 1, "cf8b6f9e118d859a53c9dd4b88030e670437c98d73f216fe68cad0fcdf7c6bae")
