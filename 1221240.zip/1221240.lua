-- Lua provided by SkyAPI 
-- Game: AppID 1221240
addappid(1221240)
addappid(1221241, 1, "bf8581ee1559d6154c71e212e759d20c71277f1e720b62a0f0a978fb05ea6df7")
