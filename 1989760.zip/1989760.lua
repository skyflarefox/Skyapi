-- Lua provided by SkyAPI 
-- Game: AppID 1989760
addappid(1989760)
addappid(1989761, 1, "179baa77102a4e8a9ef108fda237b240f492841de6ac4699d94afea26aed6608")
