-- Lua provided by SkyAPI 
-- Game: Lucent Heart
addappid(283060)
addappid(283061, 1, "148544f392048a2f880e3f9dc5080cfd9e5e7da14db5ecae43e1cced5969abb5")
