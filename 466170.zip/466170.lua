-- Lua provided by SkyAPI 
-- Game: Idling to Rule the Gods
addappid(466170)
addappid(466171, 1, "e63d31d28a62d6f2107ff942b4ec70fe3d0188e2c9eaffcc1f8597f95e149820")
addappid(466172, 1, "bca017fa36ad3591c4eb007820165b72aa60882c46fa35d9e48a167a9c5cd985")
addappid(466173, 1, "05e11a1d60b427c678b9165b300d695a9bfaf098765c827a97573d0daabe7b02")
