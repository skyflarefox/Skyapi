-- Lua provided by SkyAPI 
-- Game: Infinite Skyline Superflight
addappid(1111420)
addappid(1111421, 1, "0a7875368690f2158594e429fd44953402da788798bc01bf595d52fa1a4c03ab")
