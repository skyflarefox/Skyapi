-- Lua provided by SkyAPI 
-- Game: AppID 1108320
addappid(1108320)
addappid(1108321, 1, "f7e4a5a5bff6c84a73b75d8664b53a1f74bb77e1ce85eec06c4dfa04ff99a051")
addappid(1108322, 1, "ded489b573cd7d82c3d1e67cabd358b3be9369b0a7d539850589e996a5fc3423")
