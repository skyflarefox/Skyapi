-- Lua provided by SkyAPI 
-- Game: The Horrorscope: Fatal Awakening
addappid(1379020)
addappid(1379021, 1, "0d0bcd038445895db7aeff811f2da1aef71d85793e43114ecac3d5d898fb1ec4")
