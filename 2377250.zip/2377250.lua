-- Lua provided by SkyAPI 
-- Game: Whimel Academy
addappid(2377250)
addappid(2377251, 1, "db59201fba7cfbfc6f6f90f0bac0233b2a414afc92fa181037314aceccee999b")
