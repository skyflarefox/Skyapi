-- Lua provided by SkyAPI 
-- Game: AppID 925460
addappid(925460)
addappid(925461, 1, "0d59ddfb1e323947f0383515b0d9878f6fd8b9980a42a9b0a2aaae00a6c7ecf1")
