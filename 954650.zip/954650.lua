-- Lua provided by SkyAPI 
-- Game: AppID 954650
addappid(954650)
addappid(954651, 1, "0a4594866df407233bbaab2186edad9592e6847c30dbc9fc870fd5b23097cfc2")
