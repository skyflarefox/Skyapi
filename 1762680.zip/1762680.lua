-- Lua provided by SkyAPI 
-- Game: AppID 1762680
addappid(1762680)
addappid(1762681, 1, "5c76bca43379c05edfee79a522dfa0b7a9bf26348b49f122d03bafdb059a4d9f")
