-- Lua provided by SkyAPI 
-- Game: Cozy Keep: Farm, Craft, Manage
addappid(2261350)
addappid(2261351, 1, "d69076bb6ef8e9fe72fc48d7e81f79a512ba83496052e773a1097d65712291f3")
