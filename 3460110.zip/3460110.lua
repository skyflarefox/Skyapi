-- Lua provided by SkyAPI 
-- Game: Breaker of fatalism
addappid(3460110)
addappid(3460111, 1, "d03ec0d3fcbaddda47fe14e2b82f56e030fb49d36adf609f3b33407e95183e75")
