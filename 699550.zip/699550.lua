-- Lua provided by SkyAPI 
-- Game: AppID 699550
addappid(699550)
addappid(699551, 1, "8507e72188a49316a4e622fe08a4d60f8a6d20d13f8b9d58fe955a26b9c1a2dd")
