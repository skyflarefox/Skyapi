-- Lua provided by SkyAPI 
-- Game: AppID 1808260
addappid(1808260)
addappid(1808261, 1, "907ad25b0b9160b0db45e1a4f8d51e273a99bc6b186de0f97405f0b7a491933c")
