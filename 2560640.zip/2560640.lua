-- Lua provided by SkyAPI 
-- Game: Orgasm Simulator 2024 💦
addappid(2560640)
addappid(2560641, 1, "5443567f6eb195a91e6dcbf5734c3becc20bfccea9db8eee23a7da7c4f6f422b")
