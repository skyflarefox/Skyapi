-- Lua provided by SkyAPI 
-- Game: AppID 542720
addappid(542720)
addappid(542721, 1, "a1ebd342c7ae060d9d5914275d1e37f9c10afca49c92de76575b78e7336f806d")
