-- Lua provided by SkyAPI 
-- Game: 天狐札记 Demo
addappid(1917430)
addappid(1917431, 1, "4abaf9142635828d0f3f3172dd43528a76233efa654cfe6f7a8913be0b576a46")
