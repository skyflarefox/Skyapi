-- Lua provided by SkyAPI 
-- Game: AppID 3639500
addappid(3639500)
addappid(3639501, 1, "9e161cae8bc58d83c2b1af05b5d4445751a5c4cb4746eb94ea55f1a138a19cdc")
