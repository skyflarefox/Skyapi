-- Lua provided by SkyAPI 
-- Game: Future & Girls
addappid(2098970)
addappid(2098971, 1, "762c9c0ecd7f62492d262f85125c04deade509b417a9fb0f76d43165ff48f353")
