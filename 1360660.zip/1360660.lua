-- Lua provided by SkyAPI 
-- Game: AppID 1360660
addappid(1360660)
addappid(1360661, 1, "76418a4d771fee6e8b059e0697d1b7f4c24688613944dd991a0d0144ac8e4130")
