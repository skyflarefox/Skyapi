-- Lua provided by SkyAPI 
-- Game: 时之扉
addappid(1081810)
addappid(1081811, 1, "c5374520377569e6740f261f5d4d5a9a77d368b6544ecbb2dfbe9d8024d33012")
