-- Lua provided by SkyAPI 
-- Game: Magic Research Demo
addappid(2342420)
addappid(2342421, 1, "50002b9874528f2dcc695f2d47271ec7cc4b354c61a9a8445265e8f065dcbb22")
