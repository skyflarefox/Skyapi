-- Lua provided by SkyAPI 
-- Game: AppID 2232400
addappid(2232400)
addappid(2232401, 1, "43a9d35ecac40620e90e08cd275d18ef95173857311746d46e1c352582e4960d")
