-- Lua provided by SkyAPI 
-- Game: AppID 265360
addappid(265360)
addappid(265361, 1, "5429a27f66aa3ebc6d7272f2484c6dcb3ffb56e41c0b4ce7f1609356269ce811")
