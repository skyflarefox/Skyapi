-- Lua provided by SkyAPI 
-- Game: AppID 443530
addappid(443530)
addappid(443531, 1, "2a28a20885df9d871a971e1441d3581d9a3cd13d14908c5467e1d2ef0a546ecf")
addappid(443532, 1, "55fcffe80d21c968a3e17aa15896c8c79039b7250d9e8d6e058a591e8a0306b3")
