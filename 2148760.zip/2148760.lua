-- Lua provided by SkyAPI 
-- Game: Extreme Truck Stunts
addappid(2148760)
addappid(2148761, 1, "e848127e6a4e302545bd5ae91bf59263bcaad9292d98a99fc4c9fbf2eb45d902")
