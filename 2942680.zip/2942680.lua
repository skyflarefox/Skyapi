-- Lua provided by SkyAPI 
-- Game: Survivor in the Forest
addappid(2942680)
addappid(2942681, 1, "2640d29d14b6d390d5633236a8e7368286d99cd5b40d5bc3cb0f6f4dd9278070")
