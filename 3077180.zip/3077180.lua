-- Lua provided by SkyAPI 
-- Game: Gamer Stories: Dating Real Japanese Female Gamers
addappid(3077180)
addappid(3077181, 1, "6f6d78eb93c37b77e12489a7eccdf337fc349374ab0d4b7168a8da16a4e57ef6")
