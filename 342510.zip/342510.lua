-- Lua provided by SkyAPI 
-- Game: Bret Airborne
addappid(342510)
addappid(342511, 1, "05219939658058209695042c869e758b0d12120c22a61d69d55bba1694e69f6b")
