-- Lua provided by SkyAPI 
-- Game: Mini Golf Arena
addappid(485670)
addappid(485671, 1, "3b6d25a461efda7e3363c5cb6d0d4097d3d3212301a8b7a5d6ca66dddb5aab74")
addappid(485672, 1, "d3890ee31b8df2e284b06d5e966e7999bc2391e073e67f9ec981df9278bb6c7f")
addappid(485673, 1, "8814d280d4c2b0d2ee2a4b021ce26be4945ac810f259ab1895d064e355ab4a8b")
addappid(485674, 1, "cfb5b61fb9f84b543948ba490d96c189e74c56e5372e1a6cb60ef8a30f565b66")
