-- Lua provided by SkyAPI 
-- Game: LEGO® The Incredibles
addappid(818320)
addappid(818321, 1, "6ce5dfe98f68fe49ee0ca8464231b09d5d34c71227f41b4a98d2e77fea8a87da")
addappid(818330, 0, "d3782143e833f0a2ee1f432490d82e17dedc4b8ec937d351418e7285f5a7fa6e")
