-- Lua provided by SkyAPI 
-- Game: Gummy Nightmares Demo
addappid(3430370)
addappid(3430371, 1, "fa8b4799612372a79aeef60aeadc7581fa20877fcb864af0e7b3ce84972459a8")
