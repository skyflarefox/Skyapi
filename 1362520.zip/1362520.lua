-- Lua provided by SkyAPI 
-- Game: AppID 1362520
addappid(1362520)
addappid(1362521, 1, "ec7625d95e00aeec856a416760d3d37f0ee9bab4afa811b16d3d3da7c8613db5")
