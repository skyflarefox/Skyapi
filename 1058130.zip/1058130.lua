-- Lua provided by SkyAPI 
-- Game: Queen's Wish: The Conqueror
addappid(1058130)
addappid(1058131, 1, "70be393becdf89ab909e2d8b11f722e5327f84f328f3def4aee3628eed0bf3e6")
addappid(1146620, 0, "eceecfb5704fc225bcbf5a9a5f93a6f4744a104883ae5cea3fe30cb9e7597a43")
