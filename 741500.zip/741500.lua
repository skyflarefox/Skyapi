-- Lua provided by SkyAPI 
-- Game: AppID 741500
addappid(741500)
addappid(741501, 1, "498bc9aef49022edf28109062043d6190a2d0530caba6702ce35d2ef914825d1")
