-- Lua provided by SkyAPI 
-- Game: Trash Goblin
addappid(2407830)
addappid(2407831, 1, "ea23b0d0a0032c830f4a7465cffc83e39ed4632bf16182ddb029fadb0868cf80")
