-- Lua provided by SkyAPI 
-- Game: Bank Simulator
addappid(3355800)
addappid(3355801, 1, "fabe54fdaf7a5a04910f223f36584ebb24fee7c50fa79167e55c6c5fcb1ecfa2")
