-- Lua provided by SkyAPI 
-- Game: Mall Mayhem
addappid(629400)
addappid(629401, 1, "d450e0503fff30720578a870a74299337faf21a7d0471541664a0f7c95cf4ba0")
