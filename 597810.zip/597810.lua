-- Lua provided by SkyAPI 
-- Game: Shining Plume 2
addappid(597810)
addappid(597811, 1, "585e513bfa7cac8334bc33eb96d14151198204ffde41be2f290bb2e7a788f5a5")
