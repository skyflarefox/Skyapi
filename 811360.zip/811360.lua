-- Lua provided by SkyAPI 
-- Game: Archibald
addappid(811360)
addappid(811361, 1, "5b4dcd791b4e9c62e1dc719b37647f3f47474017925781d06919d475d0778447")
