-- Lua provided by SkyAPI 
-- Game: MEGA MAN X DiVE Offline
addappid(2183650)
addappid(2183651, 1, "b65ef186c0a946139f12cda82197079ecef408e6b7eecf14b5ebf6f33faf0c81")
