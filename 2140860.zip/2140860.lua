-- Lua provided by SkyAPI 
-- Game: Beacon Pines Original Soundtrack
addappid(2140860)
addappid(2140861, 1, "b60a5ab03aa05aceaf6cb21d918e3fc88259f8ce9e571addd7df4e59141fb1d8")
