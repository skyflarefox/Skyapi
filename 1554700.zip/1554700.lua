-- Lua provided by SkyAPI 
-- Game: Inglorious Waifu VS Nazi Zombies
addappid(1554700)
addappid(1554701, 1, "6444f4304a2edd0d63896731c321b459cb3cde8fc941eeec935bc17ab6f28096")
