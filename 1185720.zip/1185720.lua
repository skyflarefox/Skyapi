-- Lua provided by SkyAPI 
-- Game: AppID 1185720
addappid(1185720)
addappid(1185721, 1, "59f50aad35e932da13e8fde1d117fd9a960be9077b557cf5842c361003ce16e1")
