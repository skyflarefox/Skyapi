-- Lua provided by SkyAPI 
-- Game: The Floor is [Blank]
addappid(1580980)
addappid(1580981, 1, "270cdbaddd82215225740536eca8ddc17f83832b9ce8d655e79ffd6912c5764f")
