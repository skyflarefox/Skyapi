-- Lua provided by SkyAPI 
-- Game: 末代侠客 Demo
addappid(1408940)
addappid(1408941, 1, "f40b30617b924f9c4e77bb1b1f719ac4dabe39b6a381fb4671fee104e755170b")
