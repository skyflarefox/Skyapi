-- Lua provided by SkyAPI 
-- Game: Ninja Senki DX
addappid(405540)
addappid(405541, 1, "0cbe38e540d1992ff5e619da53dc721a4550b8386333724468cdcd59c803ecd7")
addappid(405542, 1, "e7327113ad3d2a127f2e0baa66e9f3b15e107d93ad34b05d94a8c8f50530a5ad")
