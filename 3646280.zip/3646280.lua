-- Lua provided by SkyAPI 
-- Game: World Alone: Dreampools
addappid(3646280)
addappid(3646281, 1, "ba9e30dba90e587331fb2f746b6d827fecef5455a0450c7955b811f9522ec0e5")
