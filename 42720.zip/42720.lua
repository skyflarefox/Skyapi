-- Lua provided by SkyAPI 
-- Game: AppID 42720
addappid(42720)
addappid(42721, 1, "b1eb9b44b5388cd3d71339aecdffcd6884647524d6a886afef5d1a67d1ec2daa")
