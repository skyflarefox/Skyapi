-- Lua provided by SkyAPI 
-- Game: AppID 1259180
addappid(1259180)
addappid(1259181, 1, "c9c4b8d1a09aee89627e18b127c7f452fa7d5ae875fead71e5ae40fbfe849d9b")
