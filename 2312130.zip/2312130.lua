-- Lua provided by SkyAPI 
-- Game: AppID 2312130
addappid(2312130)
addappid(2312131, 1, "4e5fbb99c1fc93f87f7fcd749a5aec64969361774ab2456423ab768e81bed99b")
