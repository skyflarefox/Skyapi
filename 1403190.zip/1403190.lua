-- Lua provided by SkyAPI 
-- Game: AppID 1403190
addappid(1403190)
addappid(1403191, 1, "b77b80cdacd339fb34175a257e0791b4ec7a6ea668d5f256bbf3a69a7c482075")
