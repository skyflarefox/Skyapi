-- Lua provided by SkyAPI 
-- Game: Wonderway
addappid(2372220)
addappid(2372221, 1, "de843425201db49f4291e88d90b05d389683f6920c0febeb19fa90071d7dd93c")
