-- Lua provided by SkyAPI 
-- Game: AppID 597120
addappid(597120)
addappid(597121, 1, "f1d15e6de475d45120a67a90d70eee8d3f8654cbe07e0538d41df581f08f277a")
