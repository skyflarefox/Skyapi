-- Lua provided by SkyAPI 
-- Game: Darfall
addappid(1961600)
addappid(1961601, 1, "648e64e57df4bde6e9a0e771af2cc97e87617a73b96057c3c67a788fab747bdb")
