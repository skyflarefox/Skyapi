-- Lua provided by SkyAPI 
-- Game: Artisan Story
addappid(2505510)
addappid(2505511, 1, "29e3fb708d9308f3eaaf2fe90dbd7d57f95a1c1d551b0cce777e049c6ff2a8bc")
