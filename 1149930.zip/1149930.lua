-- Lua provided by SkyAPI 
-- Game: AppID 1149930
addappid(1149930)
addappid(1149931, 1, "4932c2941d0196a7d1af7ddebf8854abc0cd3b784de64028abc9bff8f35ca04c")
addappid(1149932, 1, "78101eb0cc54672cc5dc373247a9bca35f0189f4c36d1445f0e4cd7959e576a7")
