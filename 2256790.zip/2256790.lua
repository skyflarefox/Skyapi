-- Lua provided by SkyAPI 
-- Game: GameDev Life Simulator 🎮🕹
addappid(2256790)
addappid(2256791, 1, "25df0f950fbc7ca28990ba0405f4bdd9d828dae85f7c777ccf2ccc47362f6311")
