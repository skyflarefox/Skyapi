-- Lua provided by SkyAPI 
-- Game: AppID 1157740
addappid(1157740)
addappid(1157741, 1, "9575b37dcacda67ed9e2966999b1258c3255c65e2404ac12219267257b7baf77")
