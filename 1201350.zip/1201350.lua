-- Lua provided by SkyAPI 
-- Game: AppID 1201350
addappid(1201350)
addappid(1201351, 1, "54b76a57eeba942e53614a5081722fe47ac8f5ae6bbbc0ea317feb523e8d5e83")
