-- Lua provided by SkyAPI 
-- Game: Project SolarBot
addappid(1144690)
addappid(1144691, 1, "c19c9bf59cbaef25dcae70deeea4719d32c9d6876271b4c2c7960e47c6170c10")
