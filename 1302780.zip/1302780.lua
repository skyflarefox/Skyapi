-- Lua provided by SkyAPI 
-- Game: Zombo Buster Advance
addappid(1302780)
addappid(1302781, 1, "34ff45d5a5120171f6fb71d571e52f485b3bf797faf1969ba8f0714cad226a82")
addappid(1302782, 1, "889ca319ae3d39f62e068ad399325b8839bb91484d362b955204d30f90174236")
