-- Lua provided by SkyAPI 
-- Game: AppID 2057310
addappid(2057310)
addappid(2057311, 1, "6cd2b97d428b97400371bca55f1b7005799949abf9a6f9cdd33a9aebdbfb8a73")
