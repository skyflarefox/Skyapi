-- Lua provided by SkyAPI 
-- Game: Coffee Please
addappid(3226140)
addappid(3226141, 1, "63dd1edaebc06b259c5d283bbd4763689f622ab7733bd3173e140e1e35d456e2")
