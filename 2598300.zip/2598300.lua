-- Lua provided by SkyAPI 
-- Game: Cum & Climb
addappid(2598300)
addappid(2598301, 1, "8fa317dbd308c9a82b5bda0837b83d9aa209e1d55ce6eb921629410f233cd05f")
