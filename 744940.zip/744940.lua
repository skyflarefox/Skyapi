-- Lua provided by SkyAPI 
-- Game: AppID 744940
addappid(744940)
addappid(744941, 1, "b5e99001b1d0df7fbee37ad96352626c0d6e794b69a73f0e7be2f8425aa1e4c5")
