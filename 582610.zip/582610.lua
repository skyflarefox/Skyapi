-- Lua provided by SkyAPI 
-- Game: Z-End
addappid(582610)
addappid(582611, 1, "41e4dddbed24ff085e8cf56d5a83d628393e320505cf3d47dc0db5436d39b40d")
