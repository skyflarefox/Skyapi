-- Lua provided by SkyAPI 
-- Game: Prey with Gun 带枪的猎物
addappid(718940)
addappid(718941, 1, "6514e1d75627221828a43e73f7b45b66602d9af5e8caca7f5817fb1f4657747d")
addappid(718942, 1, "68eec1c1f135abdb95ff14d37d954b039b8344123b0dc7aed625edf361364c0a")
addappid(718943, 1, "5a069ed5ad9fdca1a10d843d69bef41eb369c3e3cdccc8b6ca999cda3ff399af")
