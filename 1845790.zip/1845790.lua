-- Lua provided by SkyAPI 
-- Game: Nanook's Revenge
addappid(1845790)
addappid(1845791, 1, "8d132a0167da409cc2292edb1050ce34dd1ac776db75a8fd372a6aab4326b4d9")
