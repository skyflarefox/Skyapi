-- Lua provided by SkyAPI 
-- Game: AppID 1014270
addappid(1014270)
addappid(1014271, 1, "c2f41f2d7134664d998963a56cb2fecd1315dd7a4ca3dfc93c8e4e0ff093faa3")
