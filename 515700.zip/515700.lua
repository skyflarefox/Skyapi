-- Lua provided by SkyAPI 
-- Game: Snowday
addappid(515700)
addappid(515701, 1, "1e16c85e81ce0da866ddacdf40b4cef5afc6955b33f2723575ab5430544985d3")
