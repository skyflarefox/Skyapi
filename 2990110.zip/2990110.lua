-- Lua provided by SkyAPI 
-- Game: AppID 2990110
addappid(2990110)
addappid(2990111, 1, "56770b94ba5b754f12ccc419dd50a43b24af44869bd12ce21f4ec1cf98f1317b")
