-- Lua provided by SkyAPI 
-- Game: Kuroinu Redux
addappid(2348170)
addappid(2348171, 1, "181ba457aea310b0124ce51495c0645435f185a424fbf121e9d0952de490b2a9")
