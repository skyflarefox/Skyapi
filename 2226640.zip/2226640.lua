-- Lua provided by SkyAPI 
-- Game: AppID 2226640
addappid(2226640)
addappid(2226641, 1, "fb85f74908c407499cf9cf194a033964c94212dec4895df3a3fc78940227529d")
