-- Lua provided by SkyAPI 
-- Game: Lamplight City
addappid(761460)
addappid(761461, 1, "296fb49fdc982088f71691f386ee8a071d3f26a9abd8065bd5771914582a8a5f")
