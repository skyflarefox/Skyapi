-- Lua provided by SkyAPI 
-- Game: Finding Annie
addappid(3674140)
addappid(3674141, 1, "c8cd35664a2bd6c568d633f8a8e55bcb9536328c5ebfae91cd02464db424108d")
