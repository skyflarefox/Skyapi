-- Lua provided by SkyAPI 
-- Game: Star Clicker Odyssey
addappid(3709490)
addappid(3709491, 1, "468937f2f6b15ac0e77ae9e2a7e68ade4a46717985e822043c8da3477666e455")
