-- Lua provided by SkyAPI 
-- Game: Robots n Lasers
addappid(1692520)
addappid(1692521, 1, "5f4ccdc5d7f3ae72e314e6966a4cc4f698d8c150c113e9abaed703660b968d73")
