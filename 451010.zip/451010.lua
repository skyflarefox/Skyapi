-- Lua provided by SkyAPI 
-- Game: AppID 451010
addappid(451010)
addappid(451011, 1, "e1992c190fc5933b61de6ecb19a58e4cdb261e935e5acfa5bd05a3919d5dc4ea")
