-- Lua provided by SkyAPI 
-- Game: Lockdown: Stand Alone
addappid(513270)
addappid(513271, 1, "85056c05e0e7a2e7d592028bf78e743cd9765dbd0d38810db22017e0d9773371")
