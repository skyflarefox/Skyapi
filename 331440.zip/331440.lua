-- Lua provided by SkyAPI 
-- Game: AppID 331440
addappid(331440)
addappid(331441, 1, "e709c581130803f4f2450442fe73dcf3ff69d01ecca1d4259c75a4cfa35067df")
addappid(331442, 1, "507b22315f11e66c6712fa8f4eb300a81a027413b1427a54104808f9dbbfd738")
