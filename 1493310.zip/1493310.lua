-- Lua provided by SkyAPI 
-- Game: Brave Hero
addappid(1493310)
addappid(1493311, 1, "14524b2169c8aa5e9cc45b5a28426b350555bd8b96e8b5065fcdb02f0d659209")
