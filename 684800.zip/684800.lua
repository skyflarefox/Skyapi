-- Lua provided by SkyAPI 
-- Game: AppID 684800
addappid(684800)
addappid(684801, 1, "e659f95bfc5e2ca0a5cf3e4b30a7589dd811239f6987a336045cc34a9e520af6")
