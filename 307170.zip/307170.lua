-- Lua provided by SkyAPI 
-- Game: AppID 307170
addappid(307170)
addappid(307171, 1, "547eef52ef7dd49c96f3ee10173633a62225dc57ab75cd7da8a58aa7c96dbd86")
