-- Lua provided by SkyAPI 
-- Game: AppID 3739700
addappid(3739700)
addappid(3739701, 1, "fa8e6859c771f38d9b4bb862172935ae3e8187cb3033ec4219f1d679af5da9e5")
