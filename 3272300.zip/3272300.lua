-- Lua provided by SkyAPI 
-- Game: Yasuke Simulator
addappid(3272300)
addappid(3272301, 1, "a04583eb791521d867756bfcabe7706dd288b23799bd1a5ac112362590ab5208")
addappid(3599190)
addappid(3599230)
addappid(3599240)
