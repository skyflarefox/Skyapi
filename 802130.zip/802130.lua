-- Lua provided by SkyAPI 
-- Game: Break The Targets
addappid(802130)
addappid(802131, 1, "345f5dd9db2be44f6642b528a444f36722af740d3fbe9c7b85d9110097c04ef2")
