-- Lua provided by SkyAPI 
-- Game: CHR$(143)
addappid(1695620)
addappid(1695621, 1, "e20920d081f07cde0a8e949c29f1768b962fa7793679bf1da932814d347b4caf")
