-- Lua provided by SkyAPI 
-- Game: Airstrike One
addappid(713600)
addappid(713601, 1, "2a093b9a72a7ef47d1812b18b4d60e15be4e98157181580522b93b6363ae1466")
