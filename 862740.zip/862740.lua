-- Lua provided by SkyAPI 
-- Game: AppID 862740
addappid(862740)
addappid(862741, 1, "5dc0da74f6abb18a8a03c4b50e1dd037a7ea266ca1176f65a1972a412f6a6afe")
