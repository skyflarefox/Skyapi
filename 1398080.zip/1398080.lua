-- Lua provided by SkyAPI 
-- Game: Seaside Cafe Story
addappid(1398080)
addappid(1398081, 1, "d4a1654a932dd91dfb9a5c2773cbbfa90e4cc4eb9683ec181948d2d4bf2ed04c")
