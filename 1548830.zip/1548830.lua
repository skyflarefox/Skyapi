-- Lua provided by SkyAPI 
-- Game: TAL: Arctic 4
addappid(1548830)
addappid(1548831, 1, "353691839e347245d297566d68526b223116174e815e402bd8ead08a98c2d23f")
