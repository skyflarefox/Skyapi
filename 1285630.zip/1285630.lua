-- Lua provided by SkyAPI 
-- Game: AppID 1285630
addappid(1285630)
addappid(1285631, 1, "e5ee273b5f4831d30de9f6b3e9e22793293a6491cbe0afe92ce568bf6e2f8d34")
