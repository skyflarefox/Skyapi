-- Lua provided by SkyAPI 
-- Game: INVERT
addappid(1774700)
addappid(1774701, 1, "8f72f7ef9fa9229adedd0dafdc221a5472f13637c199cf8b216bbf50df619fe2")
