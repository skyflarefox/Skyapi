-- Main AppID
addappid(3946110)

-- Main Depots
addappid(3946111, 1, "1289c01d4dab9fc716f2590cec8294a1554f51333aadc8aaf9e03287ad0e69f8") -- (windows)
setManifestid(3946111, "5110422667059102450", 251809996)
