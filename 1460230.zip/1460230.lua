-- Lua provided by SkyAPI 
-- Game: Javols VR
addappid(1460230)
addappid(1460231, 1, "44a6e5722601b5ffc870720334d8b5d0dcb0a84861fc16067be2610bf4c3b7b3")
