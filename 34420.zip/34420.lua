-- Lua provided by SkyAPI 
-- Game: AppID 34420
addappid(34420)
addappid(34421, 1, "091c75123ce4eea89be9a09ea0059273267f08272c6e82f30ad394d14494417b")
addappid(34422, 1, "8a6e18db1a13df45fbe260d81539d29badb8f3eda287020447599cafb55fa0ba")
addappid(34423, 1, "85882ffb0414dbbab68d3333f121babfbfb87ab67801035d785a28adb0bf1c4b")
addappid(34424, 1, "ace3745a90f4cd2c67917c12f5fc90502055ec0a12be311bcce1dd8df3ba5459")
