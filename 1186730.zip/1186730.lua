-- Lua provided by SkyAPI 
-- Game: Terro Lunkka Adventures
addappid(1186730)
addappid(1186731, 1, "026af74792200c43656ddb2edd7b33d47b6a3dea61b7f47884cb74ec228e02cf")
