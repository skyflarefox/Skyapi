-- Lua provided by SkyAPI 
-- Game: Erica
addappid(1514930)
addappid(1514931, 1, "30bab68bedaf1f24449cae0033f0040ef176663efdb56c53723ab8fbc749d9ae")
addappid(1514932, 1, "aa001bfec369c6e8e2b545a4d9ba6ca6ac8af48bf25385478f32b40732b83187")
addappid(1514933, 1, "a7a81c45cdc8e59255c7f5636e109f95804ba8e074101edb2b8bdcb846773823")
