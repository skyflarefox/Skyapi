-- Lua provided by SkyAPI 
-- Game: HEARTSHOT
addappid(2702700)
addappid(2702701, 1, "75ce8062241c9d9087218e9c995292ba85eb03c815396a08cd51433da82d6904")
