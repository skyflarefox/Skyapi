-- Lua provided by SkyAPI 
-- Game: Gravity Castle
addappid(2231170)
addappid(2231171, 1, "5f757b2f9cdb3772f6eb71e2a24163347b28719ad28d71f8e6419b0f19439933")
