-- Lua provided by SkyAPI 
-- Game: The Wandering Village
addappid(1121640)
addappid(1121641, 1, "589062032126cb115e44bf22b1f1a7e84ac07202db9d7e297972cc12130c256b")
addappid(2108240, 0, "3bab56d802407d29977f89e57f59dbddd3fbdffb45f22df1832cf0e363bb7a13")
