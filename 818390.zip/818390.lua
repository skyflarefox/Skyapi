-- Lua provided by SkyAPI 
-- Game: The Deer
addappid(818390)
addappid(818391, 1, "f7345196f15993683fadf4655b3673bb0f4a3f8bb37046b75841cc765cbe2f7a")
