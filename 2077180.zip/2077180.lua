-- Lua provided by SkyAPI 
-- Game: SCP: Daybreak
addappid(2077180)
addappid(2077181, 1, "531914749d2450f94e185b87a897133fd6958e93dac77f3cbbd67c5d8f66fd32")
addappid(2207730)
