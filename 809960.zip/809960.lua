-- Lua provided by SkyAPI 
-- Game: Radical Heights
addappid(809960)
addappid(809961, 1, "30e1a6d34e2f287e5a5a7e2f25f36f6bd6bec7a35c9075242d42e1f66af36b9a")
