-- Lua provided by SkyAPI 
-- Game: Bank Robber
addappid(1990270)
addappid(1990271, 1, "c81a7231ff5f01518e9618229833d37674a5f0ba2b4e5f97b165e13fe3b4791b")
