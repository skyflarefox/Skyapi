-- Lua provided by SkyAPI 
-- Game: LAW 56 Demo
addappid(3381040)
addappid(3381041, 1, "10eb3fd2464078969e277d2e938fecbaf6c768d311723d17bc4e3348503b74f0")
