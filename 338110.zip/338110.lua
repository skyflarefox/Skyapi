-- Lua provided by SkyAPI 
-- Game: Khaba
addappid(338110)
addappid(338111, 1, "e57af96023ce9cba2a2ba5a5c08309b8e1e015efa18855e6ec5ecb08727d42eb")
addappid(338112, 1, "d047f6888cde92b4edd841631eb2b734791851a1f917b6fd95cf9646ac16d55e")
