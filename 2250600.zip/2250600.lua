-- Lua provided by SkyAPI 
-- Game: Disgaea 7: Vows of the Virtueless
addappid(2250600)
addappid(2250601, 1, "611aaa6ffc70388e7bb62f4b14a877bd178c3d31c98e1d2bcc3046a0b3f0a574")
addappid(2540740, 0, "cc20d1dae797cacb38173b04e3023e15126b20742bf45d0514294a17112191f3")
addappid(2540760, 0, "1c301261d234ea9bb3ec3ab48d09831c3c16c35865f642511ee8b64ff4a3954d")
