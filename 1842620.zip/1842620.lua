-- Lua provided by SkyAPI 
-- Game: Trepang2 - Soundtrack
addappid(1842620)
addappid(1842621, 1, "e381094a9a17f36b1ce9e1040f5bb5ec19b56dc6a59b75473d932693480fbf31")
