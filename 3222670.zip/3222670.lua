-- Lua provided by SkyAPI 
-- Game: AppID 3222670
addappid(3222670)
addappid(3222671, 1, "c59b8189833d9f35418f5f5adb8c56063ca83c9a37529e093ca4b59e127525bc")
