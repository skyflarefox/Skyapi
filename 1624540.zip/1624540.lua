-- Lua provided by SkyAPI 
-- Game: Storyteller
addappid(1624540)
addappid(1624541, 1, "ff6c2e088a80d4a69004fd8f212214f02a6684da905e43037db5c6c7aea8c30b")
