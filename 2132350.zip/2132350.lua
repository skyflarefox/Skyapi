-- Lua provided by SkyAPI 
-- Game: AppID 2132350
addappid(2132350)
addappid(2132351, 1, "166e6a18853bce8fd23e2edef6d6a086abba3c6203aa03990871f905f90a3f89")
