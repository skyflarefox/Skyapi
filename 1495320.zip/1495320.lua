-- Lua provided by SkyAPI 
-- Game: Carnal Instinct
addappid(1495320)
addappid(1495321, 1, "ca5070e2afd6a9665bbb4aaf33a228a623ac43c0c7b7a001a618a7cfcb2f6b53")
