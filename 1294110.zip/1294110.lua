-- Lua provided by SkyAPI 
-- Game: AppID 1294110
addappid(1294110)
addappid(1294111, 1, "814372dc016cffe2f12779c09c2ee6a754081b5cf22c6c5686e12653cd3ab4a6")
