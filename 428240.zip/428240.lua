-- Lua provided by SkyAPI 
-- Game: Hauntsters
addappid(428240)
addappid(428241, 1, "cfae2e1f75d729a258d1d2a31258430046f41d8b3b1c1038eb0b97cc2ee4104c")
