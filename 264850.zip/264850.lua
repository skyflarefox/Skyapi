-- Lua provided by SkyAPI 
-- Game: TrackMania² Canyon Demo
addappid(264850)
addappid(264851, 1, "c06dc36e08c4def18355d454ef6e0c720157411f1924913a0600bf0fdaa642da")
