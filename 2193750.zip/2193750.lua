-- Lua provided by SkyAPI 
-- Game: Desktop Table Tennis
addappid(2193750)
addappid(2193751, 1, "6bb71d0f16d5707db078ebac070cde6c10e4b163411af95b4419fa8fe3da54d0")
