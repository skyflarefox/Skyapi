-- Lua provided by SkyAPI 
-- Game: BookConverter
addappid(1318140)
addappid(1318141, 1, "f2e9e3129a7c02cdb71d310a16df9602f31f70b51f437d069ac5507c4f04c39a")
