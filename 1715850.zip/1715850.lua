-- Lua provided by SkyAPI 
-- Game: NAIR
addappid(1715850)
addappid(1715851, 1, "1e16e98862035f1552e0f4e6bc59d93c80a0a4f9f42d939ba044b24b0a9297d3")
