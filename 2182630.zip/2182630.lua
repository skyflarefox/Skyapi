-- Lua provided by SkyAPI 
-- Game: Mob Factory
addappid(2182630)
addappid(2182631, 1, "210690a0fe087cd3565f7fc9149f34e711723fee74a43d3c9431ee6dd3b6ca6d")
