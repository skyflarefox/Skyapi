-- Lua provided by SkyAPI 
-- Game: AppID 2856590
addappid(2856590)
addappid(2856591, 1, "70234292dcb4da1e823d52e0ac750e7524a024bda6f6d0979340b7f4b3b4a6cd")
