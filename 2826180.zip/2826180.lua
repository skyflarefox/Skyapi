-- Lua provided by SkyAPI 
-- Game: AppID 2826180
addappid(2826180)
addappid(2826181, 1, "d45258f38e802c459905be85f6a018145885954c6c5084c3e5211cd61848929a")
