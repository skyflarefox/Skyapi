-- Lua provided by SkyAPI 
-- Game: AppID 1165610
addappid(1165610)
addappid(1165611, 1, "1900f932f6f9b0f31a2e0a16293b24b85a989632a52512a635c3f7e63d27e95d")
