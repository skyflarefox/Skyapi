-- Lua provided by SkyAPI 
-- Game: Wisdom of War
addappid(649300)
addappid(649301, 1, "07fff84c2c82dfc772a061c5544867b07545517cd49b2c514b5fdba292d0989a")
