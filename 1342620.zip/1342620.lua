-- Lua provided by SkyAPI 
-- Game: Werewolf: The Apocalypse — Heart of the Forest
addappid(1342620)
addappid(1342621, 1, "025d9458eac4264b488038e98d71d39d86bd99bd53cf2edcff6f8f0c64cd8778")
