-- Lua provided by SkyAPI 
-- Game: H Girl 2
addappid(2350660)
addappid(2350661, 1, "ddac9ab1e2c683b7e77099c44b6783a760902a31b0ec6a7249845d42fc51cf05")
