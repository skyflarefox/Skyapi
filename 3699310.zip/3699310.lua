-- Lua provided by SkyAPI 
-- Game: Isekai Sex Boutique Artbook
addappid(3699310)
addappid(3699311, 1, "e6fc101b1e5399cd878cad8d69a41fb4f1ac44bbc23373f6ee91f1146de0f4a4")
