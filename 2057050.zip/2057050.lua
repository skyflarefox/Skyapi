-- Lua provided by SkyAPI 
-- Game: Astro World Demo
addappid(2057050)
addappid(2057051, 1, "af077a99cdc8f3e1c20be55c83b242b6df681694edbd43b82259bc257370847c")
