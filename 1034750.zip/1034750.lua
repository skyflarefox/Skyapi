-- Lua provided by SkyAPI 
-- Game: The Flower Collectors
addappid(1034750)
addappid(1034751, 1, "9cac0502747a7008ebba353516f6fcb2478d22d1ffc4a31f967e17d53e86fdb6")
