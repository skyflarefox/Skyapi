-- Lua provided by SkyAPI 
-- Game: AppID 279460
addappid(279460)
addappid(279461, 1, "31c235c3ed795670d3345fe21e5b37e3059495287a8bc83ac64b19de172aacec")
