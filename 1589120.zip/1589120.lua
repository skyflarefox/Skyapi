-- Lua provided by SkyAPI 
-- Game: Above Snakes
addappid(1589120)
addappid(1589121, 1, "a6344ed696a5558483823af1a67be2c5298340ad46a0c38fc2c925aa9be7d701")
