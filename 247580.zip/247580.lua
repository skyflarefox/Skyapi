-- Lua provided by SkyAPI 
-- Game: AppID 247580
addappid(247580)
addappid(247581, 1, "d0f7afd40f21ce960b8379b2f70a45ac7198622106551a874e620e641aa98109")
