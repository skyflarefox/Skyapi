-- Lua provided by SkyAPI 
-- Game: AppID 299990
addappid(299990)
addappid(299991, 1, "ba239dbe4a1ec3437fccc321db6881dc9b4ca8b12ecd39342b127927c69700ad")
