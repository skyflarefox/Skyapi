-- Lua provided by SkyAPI 
-- Game: Tentacle Girl
addappid(1205240)
addappid(1205241, 1, "8d6259e5ffa0371049c02c5e0815d4612926835748fd585bd17fcc87d81b4c0b")
addappid(1205290, 0, "1221a61972fba827569b60d3833ef8742ba9401e71c7d87926306d2b381c7ea2")
