-- Lua provided by SkyAPI 
-- Game: AppID 451360
addappid(451360)
addappid(451361, 1, "33ab488618763c135d8192513a5ee5d96aff3d9d8cd8f7600768723b931c4044")
