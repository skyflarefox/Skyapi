-- Lua provided by SkyAPI 
-- Game: Cockwork Industries Complete
addappid(1172940)
addappid(1172941, 1, "25a2dc491586f75f0abc70b9b16c93e9b2d76c7103becef52ba41fcebad1884f")
