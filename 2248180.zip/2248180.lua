-- Lua provided by SkyAPI 
-- Game: Just Xiangqi
addappid(2248180)
addappid(2248181, 1, "46ed3208d8d08bc745c0e27bde2178eff013d2ce3baa736ca4ec03a3dd0c23e8")
