-- Lua provided by SkyAPI 
-- Game: Fear the Spotlight Demo
addappid(1960390)
addappid(1960391, 1, "8f2311556cdd36438885139234875b2cc6846f02a3d740f0d9081d4a79fc9c48")
