-- Lua provided by SkyAPI 
-- Game: Symphony Of Motion
addappid(2010920)
addappid(2010921, 1, "24568a435c47da7f125eaa8096177e693e50faaa6e57ee1618d9483521df9c99")
