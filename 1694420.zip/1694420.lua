-- Lua provided by SkyAPI 
-- Game: Card Survival: Tropical Island
addappid(1694420)
addappid(1694421, 1, "0ee0b42b1a7ee30211e35c2a4dbda4cfce3010d74b6706db2216e681d7ef942b")
