-- Lua provided by SkyAPI 
-- Game: AppID 805090
addappid(805090)
addappid(805091, 1, "66ff0aa61592bfa0bba18f3a54e04d7d23cda452fd02dc18f24f2680b7a27675")
