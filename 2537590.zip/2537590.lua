-- Lua provided by SkyAPI 
-- Game: Microsoft Flight Simulator 2024
addappid(2537590)
addappid(2537591, 1, "a149759cc259406fd0f2255297e089d9deb63fb59c263b7f2d1b7fcd7aded1a4")
addappid(3341960)
