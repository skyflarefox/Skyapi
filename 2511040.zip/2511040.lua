-- Lua provided by SkyAPI 
-- Game: The Third Age
addappid(2511040)
addappid(2511041, 1, "7772be9c1728f212f85487c1566595ce2eef0b04319fe0cdae45865346a2022b")
