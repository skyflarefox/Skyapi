-- Lua provided by SkyAPI 
-- Game: AppID 1754710
addappid(1754710)
addappid(1754711, 1, "6c2dd13118ea31ce701fdafff9b9510b667a4636f96bc4ee2a41d6deda27af52")
