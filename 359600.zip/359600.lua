-- Lua provided by SkyAPI 
-- Game: Assassin’s Creed® Chronicles: Russia
addappid(359600)
addappid(359601, 1, "3830d637e9f61d5da62795c0aa9727dd293716618225c14fd8d8d0dfa516af34")
addappid(376430)
addappid(441740)
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
