-- Lua provided by SkyAPI 
-- Game: sok-worlds
addappid(1263820)
addappid(1263821, 1, "249ebc040fcceeb321d4cad1682fef83d576f528f7f10d1d2fff845bfba19732")
addappid(1263822, 1, "4b6d6344a8df1e15979ea16d46edab39c2a241306f3a4fff7a7f601046205c13")
