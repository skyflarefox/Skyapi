-- Lua provided by SkyAPI 
-- Game: AppID 1665230
addappid(1665230)
addappid(1665231, 1, "042a702f259e9057ed5d4d58f0960230fd00758f04e5d113ef9587df08eccc7c")
