-- Lua provided by SkyAPI 
-- Game: Killing Time (Classic)
addappid(493320)
addappid(493321, 1, "660985f9e1666c98648b5f1da18eb7f40ff1085d63472e7dc05de7eda1f1be6c")
