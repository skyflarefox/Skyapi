-- Lua provided by SkyAPI 
-- Game: An Aspie Life
addappid(786410)
addappid(786411, 1, "f79451f69c6fee4fc801f3627bb7b04f221d08b9187fdcd980886b61965163db")
