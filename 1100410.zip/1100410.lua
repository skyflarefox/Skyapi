-- Lua provided by SkyAPI 
-- Game: AppID 1100410
addappid(1100410)
addappid(1100411, 1, "3223e27c4e72fbc7ae2a9b6a55899d94d4ce5c542282812b6df992fab1c7d0bf")
