-- Lua provided by SkyAPI 
-- Game: AppID 1113680
addappid(1113680)
addappid(1113681, 1, "2d8e465d2ee8ef0237a40a8da9c052e9984ae730aee91e5b56d791705f8eeb94")
