-- Lua provided by SkyAPI 
-- Game: RFVR Demo
addappid(1794080)
addappid(1794081, 1, "32eb4a0d2876a5f0e12d1a8a2ef50775e034eebac17e0d3bf83bbbabdc056f57")
