-- Lua provided by SkyAPI 
-- Game: Mount Wingsuit 2
addappid(1957680)
addappid(1957681, 1, "8097fc52f157a6901aa4ec1956944931994bceb5468c59e3cf86d7ec1b10f7ea")
