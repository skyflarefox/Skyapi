-- Lua provided by SkyAPI 
-- Game: I'm on Observation Duty 3
addappid(1458560)
addappid(1458561, 1, "66ed816de6e8e4e6a935743efc8d034882889e3a3f57503b18a45503817d9a01")
