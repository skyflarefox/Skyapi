-- Lua provided by SkyAPI 
-- Game: Nightmares from the Deep: The Cursed Heart
addappid(259740)
addappid(259741, 1, "2939c2274ef5984994da9cbf0849e600304c989266e14cef3efc33666eb44f0e")
addappid(259742, 1, "2d89d4df935270953cf22a31302c8c401ef97b105b7c1eded841cd97b5bb7522")
addappid(259743, 1, "6d2a64a01a3f97f7244b20513d940715260ce876d2d69d5b361807036decc4fa")
