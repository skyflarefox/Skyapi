-- Lua provided by SkyAPI 
-- Game: AppID 3268250
addappid(3268250)
addappid(3268251, 1, "eae07c74cdd2ec56e9e942ea3f619c0a718a17f3311acd1c249e79aa102302f4")
