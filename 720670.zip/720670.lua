-- Lua provided by SkyAPI 
-- Game: AppID 720670
addappid(720670)
addappid(720671, 1, "3b7e2fa8590f1f4bb3f9601dff003b84b69947a54be92f9d99c0d3dd39fd0342")
