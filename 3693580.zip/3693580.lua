-- Lua provided by SkyAPI 
-- Game: Crystal matrix
addappid(3693580)
addappid(3693581, 1, "e62f059267516bd9800202c35baa97ddb557276d85a981be026fdc6e337187c3")
