-- Lua provided by SkyAPI 
-- Game: Thug Life
addappid(725050)
addappid(725051, 1, "13a0bc49662f9126086a37da4083431deb34693cb26da1d3f3c65798f04a4073")
