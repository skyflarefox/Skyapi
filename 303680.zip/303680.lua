-- Lua provided by SkyAPI 
-- Game: FATE: The Traitor Soul
addappid(303680)
addappid(303681, 1, "48d89b348ddc68659a672b4b94c17549b34a78a1f2513b44a632e039c1525be1")
