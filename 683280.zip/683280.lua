-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(683280)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(683281,0,"a8b93525937571bdd6f336114a4b38e481489a1163ee886d0de2c5418d8efeec")
setManifestid(683281,"5018665393910210779")