-- Lua provided by SkyAPI 
-- Game: Silent Still 2
addappid(3869680)
addappid(3869681, 1, "9ddce3458ea9f0dab580448841013dfb9d668d0424934a492bed2f8abbbafd86")
