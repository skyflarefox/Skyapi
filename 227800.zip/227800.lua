-- Lua provided by SkyAPI 
-- Game: Retrovirus
addappid(227800)
addappid(227801, 1, "337961325c79b03506fc76a02d0a8d782f3257f1a702b056cc171577f4c4acb6")
