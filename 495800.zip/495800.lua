-- Lua provided by SkyAPI 
-- Game: AppID 495800
addappid(495800)
addappid(495801, 1, "448f9b136e21d84e116f0836346fccef91ff6c1a7ab3f64d2ee883c7fe22291c")
