-- Lua provided by SkyAPI 
-- Game: Ghost For Hire
addappid(2910850)
addappid(2910851, 1, "49d613e1d3f33a3ef4202b071d2c329a99d6fce9ecc6c02d4b499cf012db35f4")
