-- Lua provided by SkyAPI 
-- Game: AppID 1951960
addappid(1951960)
addappid(1951961, 1, "7ef0f4b4aefc72ea6baa78c36d373c49d32b90c666c55380d5563d6a785bfd8a")
