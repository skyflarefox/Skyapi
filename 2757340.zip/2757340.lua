-- Lua provided by SkyAPI 
-- Game: AppID 2757340
addappid(2757340)
addappid(2757341, 1, "a1b7ff3b607b1a46ced4333d88a31500cef3c6ff65b6f292105318254b46ba0c")
