-- Lua provided by SkyAPI 
-- Game: AppID 960170
addappid(960170)
addappid(960171, 1, "3c5ce74d30cabd2719f1c02a20785834585116b6af6b6c8ca442bcbf2188c3dc")
