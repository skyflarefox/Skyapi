-- Lua provided by SkyAPI 
-- Game: TRIBES 3: Rivals
addappid(2687970)
addappid(2687971, 1, "b503b889ffffd0a9c7b359b754db8098c7f13b10548472db0311f575168ad58e")
