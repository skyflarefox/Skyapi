-- Lua provided by SkyAPI 
-- Game: AppID 1875500
addappid(1875500)
addappid(1875501, 1, "a3553677696a6893d3a61639a91d5dc3d9da198842f24bfcfd0375749f41540f")
