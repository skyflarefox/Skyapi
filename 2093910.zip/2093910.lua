-- Lua provided by SkyAPI 
-- Game: Time Walker: Dark World
addappid(2093910)
addappid(2093911, 1, "0c72776df76be3aec05cbc342bbf2e6ebd3ea7ea837d43639e426747323a9cf6")
addappid(2672120, 0, "6dd96f5cc49d312d53ec826d534a9e7d189915d520ea66bb9d54fae06bedbbd4")
