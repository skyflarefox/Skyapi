-- Lua provided by SkyAPI 
-- Game: AppID 2972190
addappid(2972190)
addappid(2972191, 1, "eadc346eff7c86eb91ce2701b4c72802132b0056281654fbb6f68ee458a0701a")
