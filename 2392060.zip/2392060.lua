-- Lua provided by SkyAPI 
-- Game: Idle ShowOff
addappid(2392060)
addappid(2392061, 1, "d2870d41e70189f1df80f6ab9c7abfaabee6d0fbf36582d11794a6888eba2ed1")
