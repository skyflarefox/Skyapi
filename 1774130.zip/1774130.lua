-- Lua provided by SkyAPI 
-- Game: QontoWars
addappid(1774130)
addappid(1774131, 1, "a7ca78901858c9cd3f811b07b1f17af63afa795c8ab80ef9713dc240ab3325bc")
