-- Lua provided by SkyAPI 
-- Game: Four Kings: Video Poker
addappid(1526160)
addappid(1526161, 1, "43087700dac9a035470f1b3722427275f9f8bbb4468669e6eda0a9ba0aa98cc2")
