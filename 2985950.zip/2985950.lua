-- Lua provided by SkyAPI 
-- Game: Save Daddy Trump 4: Maga 2024
addappid(2985950)
addappid(2985951, 1, "618c4cbabb2d10b59ac1647fef07fe0085fa5b78f16394fee0f7a548a308d04d")
