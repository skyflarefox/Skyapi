-- Lua provided by SkyAPI 
-- Game: AppID 2432660
addappid(2432660)
addappid(2432661, 1, "c117259af446b3f6cfe8f38007b8bf612bcf832b737c95f393ef4895c14378c3")
