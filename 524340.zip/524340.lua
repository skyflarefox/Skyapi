-- Lua provided by SkyAPI 
-- Game: AppID 524340
addappid(524340)
addappid(524341, 1, "edd581099bfb5943b367add5bcfef001e9037f9e3ef19ff36f7651ba31fe9e8b")
