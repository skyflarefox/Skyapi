-- Lua provided by SkyAPI 
-- Game: PogoStickMiooooooon
addappid(1942860)
addappid(1942861, 1, "275934b651dd91e58e59e7abf7b6b098041f6986879e4ddc5805f2e3887d1914")
