-- Lua provided by SkyAPI 
-- Game: March of Empires
addappid(702320)
addappid(702321, 1, "39bb9e80daa8e2e44630d2623627b9c46e3b854ef6e5893423ecd5c5ce64300b")
