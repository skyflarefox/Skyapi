-- Lua provided by SkyAPI 
-- Game: SPIRITUS
addappid(2011650)
addappid(2011651, 1, "6d32704174d88e8dceb000d027d12b6dad7da1c804bc56fb9c7d2473cd04cec9")
