-- Lua provided by SkyAPI 
-- Game: Walking Heavy
addappid(711050)
addappid(711051, 1, "44ea2d054072eca7d93d9cededb12f63984966324d66d322120cee876ec64f36")
