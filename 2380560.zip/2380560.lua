-- Lua provided by SkyAPI 
-- Game: Deserted Island
addappid(2380560)
addappid(2380561, 1, "0c03a07ab40132bab00d7dc9e3394a1c59b6d9586e7e61f6a7b16f05679c5d66")
