-- Lua provided by SkyAPI 
-- Game: AppID 837440
addappid(837440)
addappid(837441, 1, "7de7d2e7bff27af3820c7f62f2d072076fa30b6ab36df404e456266a84b06312")
