-- Lua provided by SkyAPI 
-- Game: Shunga Frame
addappid(1765180)
addappid(1765181, 1, "a70eb67a1c6594359d794fce1de7eebc9357fca1e49fa3f020925683bc5d4320")
