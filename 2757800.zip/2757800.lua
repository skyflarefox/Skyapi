-- Lua provided by SkyAPI 
-- Game: AppID 2757800
addappid(2757800)
addappid(2757801, 1, "0ee6aa66e49a6209d417581c3135b030fc762d37f3bb39b43e64be152a6b4d8e")
