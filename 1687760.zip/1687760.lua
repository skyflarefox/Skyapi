-- Lua provided by SkyAPI 
-- Game: Exos Heroes
addappid(1687760)
addappid(1687761, 1, "845814fb11d98995d63e505a918776c40257b212ae030a91548777c5ae396e43")
