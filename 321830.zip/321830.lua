-- Lua provided by SkyAPI 
-- Game: AppID 321830
addappid(321830)
addappid(321831, 1, "5d7a32a29955cd0922e77de2921d614d35335235dec947c41def449d2826b8ca")
