-- Lua provided by SkyAPI 
-- Game: AppID 928940
addappid(928940)
addappid(928941, 1, "edaa9099cdd21a75a5c6f09965b7ca065515da6fecf15fe4979898d121955095")
