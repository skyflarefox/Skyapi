-- Lua provided by SkyAPI 
-- Game: AppID 2190200
addappid(2190200)
addappid(2190201, 1, "ae9237599afcbfdcd3f8e8880dae0179e48d6c0851d71c6afcbcffffa0bfbc3f")
