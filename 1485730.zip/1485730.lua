-- Lua provided by SkyAPI 
-- Game: Dash Hale
addappid(1485730)
addappid(1485731, 1, "a132c4342e1b7d662963e20160d0b61217c4748c06859dd1fd814eaaa4abc0d1")
