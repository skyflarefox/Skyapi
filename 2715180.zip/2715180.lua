-- Lua provided by SkyAPI 
-- Game: Summon My Girl
addappid(2715180)
addappid(2715181, 1, "0c964bbf8ed2187e8d4cec5481ced7121e57869bad07d2eb2e5107d8581a58ac")
