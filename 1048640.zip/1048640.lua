-- Lua provided by SkyAPI 
-- Game: At Home
addappid(1048640)
addappid(1048641, 1, "42859f0c79db8a3b03c55864c6e0894923f3d4b9cce8158f959c0af9c859389e")
