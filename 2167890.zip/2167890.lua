-- Lua provided by SkyAPI 
-- Game: Lost Hammer
addappid(2167890)
addappid(2167891, 1, "4690c94bf32af44f85e73f3796ff3954a542e37580bd1f44a6b3353001f9d7a2")
