-- Lua provided by SkyAPI 
-- Game: AppID 321890
addappid(321890)
addappid(321891, 1, "34669fdf849a50f7598c1c57e3d402af7593efa51f2180876656f61af94e73bc")
