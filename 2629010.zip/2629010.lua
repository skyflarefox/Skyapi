-- Lua provided by SkyAPI 
-- Game: 疫地求生
addappid(2629010)
addappid(2629011, 1, "465c5c2a6229eb0c23a1c193a42e0e86edb377bd82a701861f135d0c82a9fda4")
