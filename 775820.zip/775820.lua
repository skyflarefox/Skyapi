-- Lua provided by SkyAPI 
-- Game: Controllers Battery Indicator
addappid(775820)
addappid(775821, 1, "6ff0ca16f7a3135634ccc81c00c706b8a3153d834e20e3267ef03affc9a3b292")
