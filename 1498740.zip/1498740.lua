-- Lua provided by SkyAPI 
-- Game: Troublemaker
addappid(1498740)
addappid(1498741, 1, "1b731d335112e8f7b31426874e3e46006774f269f46557d79346e7230babfadc")
