-- Lua provided by SkyAPI 
-- Game: Stellar Blade™ Demo
addappid(3564860)
addappid(3564861, 1, "262176baa1fa0d44b7b0cad48968679d5c5a731eaceb4a7cd0eda5e2dae9818d")
