-- Lua provided by SkyAPI 
-- Game: Garden Paws
addappid(840010)
addappid(840011, 1, "17fe7bf82e7f48fd7e3807af79da04d11ad944b522fa8f2d7f2757fea8a19627")
addappid(840013, 1, "196fe326d0c2a645e4649a7953a0f5c2ebdbd98cc9d5e0d313c09757abbc9f40")
