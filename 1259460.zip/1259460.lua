-- Lua provided by SkyAPI 
-- Game: AppID 1259460
addappid(1259460)
addappid(1259461, 1, "b09573a738317ff0241ece0d420906dc45e4e1bc5da064a9161e42064321425a")
