-- Lua provided by SkyAPI 
-- Game: Visitors: Marine Invasion
addappid(661240)
addappid(661241, 1, "a08624e7eb5ba3e27706e581a250512aa461a69f8a17b4542a85b45fcfb52b1e")
