-- Lua provided by SkyAPI 
-- Game: Anime Sunset Ride
addappid(1639120)
addappid(1639121, 1, "9a20283da5683d5361a92aaf1ac3ff255b1fb6e62fb0ced7b29dbeb236045c9c")
addappid(1650100, 0, "2483a2122f072d670a5e17689a37e5f5c108294fb71738d4768713f1aa3d1206")
