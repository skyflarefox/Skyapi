-- Lua provided by SkyAPI 
-- Game: TRADESMAN: Deal to Dealer Demo
addappid(2932010)
addappid(2932011, 1, "6b4b5c32232f0fd2ac591cf43daa3ac5133dc35c5e34cfc35668f307f286b0e6")
