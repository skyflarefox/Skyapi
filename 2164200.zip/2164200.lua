-- Lua provided by SkyAPI 
-- Game: Acretia - Guardians of Lian
addappid(2164200)
addappid(2164201, 1, "ed173d1e90c40dc1eb05f0ec64b7cc08be9f18c4dd04674f89bdc7c4456491a9")
