-- Lua provided by SkyAPI 
-- Game: AppID 2148690
addappid(2148690)
addappid(2148691, 1, "40d778ac1e1e28cd375b8c74762c5bb267f9afc7623d04cab9f5f09802e7882f")
