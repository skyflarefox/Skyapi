-- Lua provided by SkyAPI 
-- Game: Real Anime Situation! 2
addappid(2361760)
addappid(2361761, 1, "74c7c2c18d0950a6d68646b4de6d293f8a7e42a2cc387942107576b81de06d0c")
