-- Lua provided by SkyAPI 
-- Game: AppID 1827870
addappid(1827870)
addappid(1827871, 1, "edc9930fbf545322356e9d9ce8ee1d83743750dd7df3624db76d1922a82f298a")
