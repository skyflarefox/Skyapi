-- Lua provided by SkyAPI 
-- Game: AppID 3470970
addappid(3470970)
addappid(3470971, 1, "3fc7eed46f893690a8f9e5839b169114190714791a84817a8f05da596d30393d")
