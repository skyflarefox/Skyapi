-- Lua provided by SkyAPI 
-- Game: Viking Frontiers
addappid(1304430)
addappid(1304431, 1, "0b2ba9c1892b5c799c2eaa1559623f7ab20790096a0228b7767b05109ce9f88e")
