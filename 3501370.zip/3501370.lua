-- Lua provided by SkyAPI 
-- Game: BANNED TAPES
addappid(3501370)
addappid(3501371, 1, "d96e1ae7fc69fd872be44fde05a37bd811d8879c69c6dbdba41c66618d6ac631")
