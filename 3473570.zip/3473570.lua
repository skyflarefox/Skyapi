-- Lua provided by SkyAPI 
-- Game: Detective - The Test
addappid(3473570)
addappid(3473571, 1, "8b0bdea1176b461f71653e71b1d9061a0bd957ed2023af5db3f99eef5dbb0b10")
