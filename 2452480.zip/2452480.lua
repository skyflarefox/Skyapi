-- Lua provided by SkyAPI 
-- Game: Neon Fantasy: Girls
addappid(2452480)
addappid(2452481, 1, "4a0013a3d6dd84dc49349764495c13540dd2dc9916b0cc51de7394d91cf4addf")
