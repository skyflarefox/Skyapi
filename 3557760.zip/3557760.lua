-- Lua provided by SkyAPI 
-- Game: AppID 3557760
addappid(3557760)
addappid(3557761, 1, "8073d9b25785203feb08e8dc97357dd4850ff1b629f9d664d2c8296d653178ae")
