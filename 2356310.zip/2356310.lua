-- Lua provided by SkyAPI 
-- Game: Continent of the Ninth Golden
addappid(2356310)
addappid(2356311, 1, "9dba45ff6f93936fd58b5ed7c881cd5e1d85a4bedbf3f104648222c27b039add")
