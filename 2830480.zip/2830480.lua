-- Lua provided by SkyAPI 
-- Game: Gentoo Rescue
addappid(2830480)
addappid(2830481, 1, "1d801f64ac7a36e4c48d28a3f2f2535b4638b9e454da650b81aa6c14ae7648a3")
