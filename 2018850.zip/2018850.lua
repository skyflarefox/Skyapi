-- Lua provided by SkyAPI 
-- Game: Fire Truck Simulator
addappid(2018850)
addappid(2018851, 1, "522d8fae9a17dd2775ceeda289a604138ce9606438735a812a61b9585b612e54")
