-- Lua provided by SkyAPI 
-- Game: Near-Mage
addappid(1685870)
addappid(1685871, 1, "e91e3b8a0c5c10a0ab7bd2336c0a1233e77f5459be4bd135cbd335d0e00f0ead")
addappid(3748670, 0, "705cb0f857d2e3bffaf498937c51bcdf8dec49a4c469fa19d6317c527b117b72")
