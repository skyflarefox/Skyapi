-- Lua provided by SkyAPI 
-- Game: Ocelot Sunrise
addappid(2194190)
addappid(2194191, 1, "aec78768293c99b31fb2533893737d432b3a6d541c1957b3952c59347ea82167")
