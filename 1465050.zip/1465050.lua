-- Lua provided by SkyAPI 
-- Game: AppID 1465050
addappid(1465050)
addappid(1465051, 1, "97e09622ba0cf6f5431dd2be2bfffc25b970920d8c7e89c646776e7cc7d01699")
