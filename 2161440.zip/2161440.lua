-- Lua provided by SkyAPI 
-- Game: Sailing Era
addappid(2161440)
addappid(2161441, 1, "058d2d96ec93cd84305ae7b4f77ef2a8211aaae87cb74503b16c15b25dfb45d1")
