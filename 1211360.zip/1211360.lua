-- Lua provided by SkyAPI 
-- Game: NEOMORPH
addappid(1211360)
addappid(1211361, 1, "e651b29d7cdafc882eb591f99186d5314a289ae033671eecb3c85477e5a064ba")
addappid(1219330, 0, "68cc4ea4ee7b4e31636625ca54c983c456f703e37764c3955a58f8e999d0eae4")
