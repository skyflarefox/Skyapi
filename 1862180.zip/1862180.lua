-- Lua provided by SkyAPI 
-- Game: Lunar Odyssey
addappid(1862180)
addappid(1862181, 1, "455eff6f4cc9da5204caeb804fd56349f37a4faf4d299d9b06294e0428ae77e1")
