-- Lua provided by SkyAPI 
-- Game: Masquerade: The Baubles of Doom
addappid(299380)
addappid(299381, 1, "3349409a2b99eb9f37942191bb63db9c4d1e5b4dda50edebe8e2ea69819b69dd")
