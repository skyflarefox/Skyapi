-- Lua provided by SkyAPI 
-- Game: Leafing Home
addappid(3349610)
addappid(3349611, 1, "db654b036dc63d299e466cefe9d33d8574469190fd6c5b932490139ee50bc7c4")
