-- Lua provided by SkyAPI 
-- Game: Pinball FX Classic
addappid(442120)
addappid(442121, 1, "08f0e8392d005c3071af9f81d139539c81112a47be754f2b16cf2fa317887b31")
