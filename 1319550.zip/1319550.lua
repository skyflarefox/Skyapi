-- Lua provided by SkyAPI 
-- Game: Power of Ten
addappid(1319550)
addappid(1319551, 1, "3dc5201c062b371196a7c77b73fbdee94f22802e4691420461398d7c5132f862")
addappid(1319552, 1, "b97c562f1be19999c34e8f28f451c7eca8c561ca62cd29058c4a2ae8c21085eb")
