-- Lua provided by SkyAPI 
-- Game: AppID 2609490
addappid(2609490)
addappid(2609491, 1, "faaeeae7ebc51446d2fa3ecbbd62ddb299e21eef8eed49b6bce5efb19522e1ed")
