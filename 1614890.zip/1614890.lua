-- Lua provided by SkyAPI 
-- Game: Baldo: The Guardian Owls
addappid(1614890)
addappid(1614891, 1, "e66b4c8125567f712682f0e053b3320f272c9849a472ddfb9ff8c79e40f3c143")
