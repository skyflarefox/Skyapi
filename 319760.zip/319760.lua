-- Lua provided by SkyAPI 
-- Game: Oh My Gore!
addappid(319760)
addappid(319761, 1, "9c4d880969b25d527ff254a10891b25c590bc7f9c897105ed41249341a0bee7b")
