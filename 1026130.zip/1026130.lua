-- Lua provided by SkyAPI 
-- Game: AppID 1026130
addappid(1026130)
addappid(1026131, 1, "e8f200456c7f36ee2e76ab9933d4424185e6fec5b1e117ecc2696475670b6886")
