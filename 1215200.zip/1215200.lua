-- Lua provided by SkyAPI 
-- Game: Shining Song Starnova: Idol Empire
addappid(1215200)
addappid(1215201, 1, "2065a39c0cc6bed79177390a16aad5ae328db35f990380799a9bd4c211ac2194")
addappid(1227030)
