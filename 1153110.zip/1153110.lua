-- Lua provided by SkyAPI 
-- Game: AppID 1153110
addappid(1153110)
addappid(1153111, 1, "b547ffd6c404941024a5ee764667dd4d241a0a9415e6fdab86381b237b551973")
