-- Lua provided by SkyAPI 
-- Game: Jam Above Jam Below
addappid(2136810)
addappid(2136811, 1, "d5f2a0eeb440a071e78579217401433a841e41d3c53e324a43ae298a9280296a")
