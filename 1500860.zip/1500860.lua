-- Lua provided by SkyAPI 
-- Game: SAW HELL
addappid(1500860)
addappid(1500861, 1, "a7949bf92da52783378a2d8a3de141802a2f5c8eec0f9e9246c4e0b58f3ff464")
