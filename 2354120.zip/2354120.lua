-- Lua provided by SkyAPI 
-- Game: Mortanis Prisoners
addappid(2354120)
addappid(2354121, 1, "e6d96ec67033a7f3de30fd38fc453281b78808cc6d73c5199cf14b6b2c2b8697")
