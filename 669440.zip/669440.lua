-- Lua provided by SkyAPI 
-- Game: IKAROS
addappid(669440)
addappid(669441, 1, "4bcca51e3b291e930302a320d16849294ac7c58230f9473c2e18f84180ab2780")
