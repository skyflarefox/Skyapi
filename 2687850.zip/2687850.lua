-- Lua provided by SkyAPI 
-- Game: AWA 2024
addappid(2687850)
addappid(2687851, 1, "f6e7e207b53ed1f0ac9681b63671c75d18af1c4187622a3b112e9e845bac3ce4")
