-- Lua provided by SkyAPI 
-- Game: Alchemy Garden
addappid(935400)
addappid(935401, 1, "40b04e348ab9cbb7994bdb8d9163f52c86d23ee7b0e0280bd2ece32bd53bb34b")
