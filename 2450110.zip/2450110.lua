-- Lua provided by SkyAPI 
-- Game: Sex Campus Story 🔞
addappid(2450110)
addappid(2450111, 1, "a68da7eb5eeb9b13ee210e97d78ba2442f3e9b6d468d908871c005e08370adba")
