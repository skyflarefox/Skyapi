-- Lua provided by SkyAPI 
-- Game: Harvest Days: My Dream Farm
addappid(1515320)
addappid(1515321, 1, "df1d0bee216cd3b2cb6ea457e111562b9c086111356a308fbbc3e7805940c0eb")
addappid(1989660, 0, "52c1c39eb97aa7b640db97d58206d51e9ff8f6eaf7d8ad5578b4834b8b42e8de")
