-- Lua provided by SkyAPI 
-- Game: Astroloot
addappid(3498390)
addappid(3498391, 1, "2d60bf1cd65f860165590f233447aa54e1bb63ccb89b664ece9afb87bf4ba5b4")
