-- Lua provided by SkyAPI 
-- Game: AppID 267180
addappid(267180)
addappid(267181, 1, "758ae5523af42909443d617611c2dcc0af923057c54b5d267ab90586ec39490f")
