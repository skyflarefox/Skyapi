-- Lua provided by SkyAPI 
-- Game: Nut City Blues
addappid(2670920)
addappid(2670921, 1, "2d6f6a224b511e13b50620f56952408828b3145bfd1715f01a2a23e85a90ebc1")
