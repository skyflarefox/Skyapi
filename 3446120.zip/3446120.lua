-- Lua provided by SkyAPI 
-- Game: Kira☆Kano
addappid(3446120)
addappid(3446121, 1, "aadb32c08fa1e2753ecc0a2f349070af853935b7687a435b3cede167d84ee267")
