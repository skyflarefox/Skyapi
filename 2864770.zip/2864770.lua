-- Lua provided by SkyAPI 
-- Game: BrokenLore: FOLLOW Demo
addappid(2864770)
addappid(2864771, 1, "0d45e19d798d64ea35f1de178ab59745831ad0e796a41bf0fa4ee7607b3387cf")
