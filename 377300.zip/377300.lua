-- Lua provided by SkyAPI 
-- Game: Thunder Tier One
addappid(377300)
addappid(377301, 1, "f208ada3346b8af8cc1c44bb1b0dd34a526f58f1f1005d402adaa2fed5b2161f")
