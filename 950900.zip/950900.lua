-- Lua provided by SkyAPI 
-- Game: Operation: Harsh Doorstop Dedicated Server
addappid(950900)
addappid(950901, 1, "cf03a739480f50ec8fc4dae4e973e6e0aa5eab8ac849f485ca5538f87d801f94")
addappid(950902, 1, "f747189c382f92583fbcc0152f25f813b8f51e18a23d3a1d08bf59d09f307f8c")
