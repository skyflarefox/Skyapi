-- Lua provided by SkyAPI 
-- Game: Turbo Chicken Simulator
addappid(2569610)
addappid(2569611, 1, "a13eb449349c99d211d6d0daf87a1b3d7943e3bd33fb483cc7f3dfe2c007df2b")
