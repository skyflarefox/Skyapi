-- Lua provided by SkyAPI 
-- Game: Krum - Battle Arena
addappid(1324560)
addappid(1324561, 1, "972e1029921de74796fb044325dbee8f23d39138ddb82d4135d77a035f73d3d2")
