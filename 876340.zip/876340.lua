-- Lua provided by SkyAPI 
-- Game: AppID 876340
addappid(876340)
addappid(876341, 1, "0cdc5275ed314fa22254bd22d3b98a1e4b98629735ec0f1f7f593ea362146fc9")
