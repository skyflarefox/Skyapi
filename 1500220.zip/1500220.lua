-- Lua provided by SkyAPI 
-- Game: AppID 1500220
addappid(1500220)
addappid(1500221, 1, "edecc76182c86a694dea20676ca35b46a32122fbe1ae06c7388ebbc025fe8f1f")
