-- Lua provided by SkyAPI 
-- Game: AppID 815370
addappid(815370)
addappid(815371, 1, "2d729703a7a551530f0fadf02b8c1da3cb944c4a898295bef1c19722f9f9f3cd")
