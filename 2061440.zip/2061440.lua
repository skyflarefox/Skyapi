-- Lua provided by SkyAPI 
-- Game: Oxygen: First Breath
addappid(2061440)
addappid(2061441, 1, "d52db3db4b99ba447b1a2844b15020902a08800cfc492ad2c1973a81d4d1f89a")
