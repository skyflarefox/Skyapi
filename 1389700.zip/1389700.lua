-- Lua provided by SkyAPI 
-- Game: Sweet and Hot
addappid(1389700)
addappid(1389701, 1, "87e6ec0ff48cb77106205595d5b72a55e6ab0b3e2118713fe4b58765eecca4bf")
