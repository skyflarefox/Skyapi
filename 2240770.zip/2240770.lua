-- Lua provided by SkyAPI 
-- Game: AppID 2240770
addappid(2240770)
addappid(2240771, 1, "d2225d3b38bb0b7bd493b3879ee57bfc1b238788327e7fd86e9bdb1b06f7802d")
