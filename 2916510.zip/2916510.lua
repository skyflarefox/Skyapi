-- Lua provided by SkyAPI 
-- Game: AppID 2916510
addappid(2916510)
addappid(2916511, 1, "0370df23f1006759856821e9f782761ce4e2b0a67fecb3685bb6aad9a7046598")
