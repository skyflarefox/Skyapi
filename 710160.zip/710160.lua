-- Lua provided by SkyAPI 
-- Game: Mula: The Cycle of Shadow
addappid(710160)
addappid(710161, 1, "f204787ec193c242d7d936b67c7c1338da1e32894b3a4947483de770f11f0cfb")
