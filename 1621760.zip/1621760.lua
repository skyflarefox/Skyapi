-- Lua provided by SkyAPI 
-- Game: AppID 1621760
addappid(1621760)
addappid(1621761, 1, "92cd4bdecb9ccff631034592da24e750456ab846ba04cb648c263dbed076af69")
addappid(2079040, 0, "4db3216ac1548acc15e72f19243824525091198aa2fde37c4b0c688050f11669")
