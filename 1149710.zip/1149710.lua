-- Lua provided by SkyAPI 
-- Game: AppID 1149710
addappid(1149710)
addappid(1149711, 1, "794855333ba41d1668da57050f62e5346547eedca0f9e07fb33b9103a4de951a")
