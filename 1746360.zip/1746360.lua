-- Lua provided by SkyAPI 
-- Game: AppID 1746360
addappid(1746360)
addappid(1746361, 1, "658da0af773fcbb2bd24d1e3116966ede7c1343fc4695cc112e543cfa981a54b")
