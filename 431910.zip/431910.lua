-- Lua provided by SkyAPI 
-- Game: AppID 431910
addappid(431910)
addappid(431911, 1, "c6e549c89d8e3f94d6cdeb7f131e1e630448f3c4a9c9ef6ee8d279ad0ce602f8")
