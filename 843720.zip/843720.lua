-- Lua provided by SkyAPI 
-- Game: Dissimilated Land
addappid(843720)
addappid(843721, 1, "809c20ca8299a841d6ff347100b9eda4666e0aef91e7c9a1cdd8d77928640f5c")
