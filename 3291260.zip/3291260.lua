-- Lua provided by SkyAPI 
-- Game: Craft & Conquer
addappid(3291260)
addappid(3291261, 1, "5d928425239c9c43f0a2d65aeb48116cc2e3cfa280c698e537dc2eea68524c85")
