-- Lua provided by SkyAPI 
-- Game: Star Sign
addappid(1860540)
addappid(1860541, 1, "37fbedced883029d6a2f685a01cd13d7b7717303a0e8bb24bb9716d7d00a5dc2")
