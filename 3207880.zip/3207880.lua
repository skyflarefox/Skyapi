-- Lua provided by SkyAPI 
-- Game: Universe Horizon
addappid(3207880)
addappid(3207881, 1, "3d4bf445cc303aca2dce3f23328852d8b2a846bc8877066895e8b5baa9c07ac6")
