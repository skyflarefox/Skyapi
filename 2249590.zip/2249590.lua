-- Lua provided by SkyAPI 
-- Game: All You Need is Help
addappid(2249590)
addappid(2249591, 1, "51190b8464ef8dc57418d4e5ea37e0a1a660d3431f93a4e9bc3bbf85ffb6e5b9")
addappid(3109770)
