-- Lua provided by SkyAPI 
-- Game: To Pixelia
addappid(1954160)
addappid(1954161, 1, "332f2483767301ab094b5f487bec95a0d0595d293c04cc1a244f9af56736db56")
