-- Lua provided by SkyAPI 
-- Game: Room 301 NO.6
addappid(1949010)
addappid(1949011, 1, "34beb74af3b770950da2a5a92db4da41c3bbf180171ae46179ea435916393db7")
