-- Lua provided by SkyAPI 
-- Game: Thief Simulator 2 Playtest
addappid(1838590)
addappid(1838591, 1, "d2f9745bb73243fae29eafabc56bd89597a17e929ac5b1b65ab126277ee3cfa9")
