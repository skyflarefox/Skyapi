-- Lua provided by SkyAPI 
-- Game: Hell Architect: Prologue
addappid(1382910)
addappid(1382911, 1, "212512f068c0b37178ebad84e72fa52d39f27b9470d3a96185f033a7b8f3cfb7")
