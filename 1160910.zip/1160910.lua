-- Lua provided by SkyAPI 
-- Game: AppID 1160910
addappid(1160910)
addappid(1160911, 1, "41ef205d39f92ad1e90abfba5e238276c6aaf648e6919e97ac43936f1ef1ca5c")
