-- Lua provided by SkyAPI 
-- Game: Eternium
addappid(981600)
addappid(981601, 1, "40c94380d0799588ee391ece523dc9d596e043b428a73e7f106c586f70b83489")
