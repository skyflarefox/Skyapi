-- Lua provided by SkyAPI 
-- Game: keyg: the last prison
addappid(922550)
addappid(922551, 1, "4ff6c7f19c10994f3b97f24c19223bf2ff7e293861f74e4ae536aa251c00c291")
