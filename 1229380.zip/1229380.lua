-- Lua provided by SkyAPI 
-- Game: AppID 1229380
addappid(1229380)
addappid(1229381, 1, "7cc7ff5e5b664787ad0b9a68935c1f4cfcff978908599c8b64d9ed0a1b643c56")
