-- Lua provided by SkyAPI 
-- Game: Shoottera
addappid(804970)
addappid(804971, 1, "a987f8467de100ee5d2a9efe69b46a56acd43d7fca4ede61e55980d97e3666cc")
