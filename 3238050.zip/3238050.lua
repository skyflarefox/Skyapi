-- Lua provided by SkyAPI 
-- Game: Zero-Sum Heart Artbook
addappid(3238050)
addappid(3238051, 1, "5a0c128732fcd909a3adb4a035b048bc9f2d206ba61b6ba6827e20b321d7bf91")
