-- Lua provided by SkyAPI 
-- Game: Slash Abyss
addappid(2816400)
addappid(2816401, 1, "ed1edc0898294ffd411a556723c9492312bb5e6802a5f03378157c9c62222733")
