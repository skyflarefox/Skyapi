-- Lua provided by SkyAPI 
-- Game: More Dark
addappid(1167770)
addappid(1167771, 1, "012d434aabf05e15a3d81bd6db1ab53f9f66536d8762e46fe77a2274b6589e9a")
