-- Lua provided by SkyAPI 
-- Game: It Stares Back
addappid(1094250)
addappid(1094251, 1, "3d2581e86a85f1e572a7d3def071dfa101331829f4097fe3b18772794e25127b")
