-- Lua provided by SkyAPI 
-- Game: Nightmare Shift Playtest
addappid(3232110)
addappid(3232111, 1, "d7857f6e460fd185966d49331dca4cc7a2d484cd09d73e4ff42e34ef04a27844")
