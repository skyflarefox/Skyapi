-- Lua provided by SkyAPI 
-- Game: off
addappid(2061680)
addappid(2061681, 1, "8ecaefc7c632739d13b45354442a7a3cf30e80be380f42d5f7d2e12134fc0b8f")
