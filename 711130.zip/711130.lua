-- Lua provided by SkyAPI 
-- Game: AppID 711130
addappid(711130)
addappid(711131, 1, "e68f6b4b6dfde1e683ca9238b574cec4b29eacc02a4101585e5a49954dd85211")
addappid(748080, 0, "a635f8042c88379866b7e878efd197a1bdbe64d566943cf018fbdd614420237e")
