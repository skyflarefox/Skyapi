-- Lua provided by SkyAPI 
-- Game: Hatoful Boyfriend: Holiday Star
addappid(377080)
addappid(377081, 1, "e109f4995c5934ccda7378afb801b31c70064284526b7f1d271a0bca8a7c957b")
addappid(377084, 1, "3404bf7f462e8c074624470a43f9881c12d5e99c1ad59788f8d2726eb69e3d63")
addappid(463090, 0, "3443a63aff40da023b8ca9468fed3029583bd08ced5499b2e08a79dcff87d964")
