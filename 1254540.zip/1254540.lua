-- Lua provided by SkyAPI 
-- Game: Booty Calls: Men At Work
addappid(1254540)
addappid(1254541, 1, "5238bdc414a48c595bdf98d7b280fdaceddf77ea88a409a1c98f6c954605d083")
addappid(1254542, 1, "26f03a3c10d3851b7d5edbab76cadb76b7a3c6d6175aa9003a6590196dcb80e0")
