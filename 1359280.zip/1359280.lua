-- Lua provided by SkyAPI 
-- Game: AppID 1359280
addappid(1359280)
addappid(1359281, 1, "0ea0372f2d7a17b6f3d1e202e5e0f787ee7317ee6d56cc2cf5064755934f4df8")
