-- Lua provided by SkyAPI 
-- Game: Max Payne
addappid(12140)
addappid(12141, 1, "852706f81744732c81de6bb29ee0c7bde48941cbdde1b270c0def608d8414827")
