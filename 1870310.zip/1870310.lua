-- Lua provided by SkyAPI 
-- Game: Doomsday Robot Girl
addappid(1870310)
addappid(1870311, 1, "a3d341658a9283c196433c193eaf54cb9f02505dd8c33bd4f6a966ae86d34cd2")
