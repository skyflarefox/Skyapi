-- Lua provided by SkyAPI 
-- Game: Sex Lens: A Porn Story 🍓🎥
addappid(2624740)
addappid(2624741, 1, "1b73eff41eba5922089424f4622480b698cb4cbafd9aa87eae5308e4820d0744")
