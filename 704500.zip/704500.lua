-- Lua provided by SkyAPI 
-- Game: AppID 704500
addappid(704500)
addappid(704501, 1, "c835cf31e04552cd4feb57825c998cb64aa70f7d005d4a1dc46d7b2f39a16fc7")
