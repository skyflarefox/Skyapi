-- Lua provided by SkyAPI 
-- Game: 420BLAZEIT 2: GAME OF THE YEAR -=Dank Dreams and Goated Memes=- [#wow/11 Like and Subscribe] Poggerz Edition
addappid(2624280)
addappid(2624281, 1, "14e69537f39dc7ed1d11d71d8a4c1e4abd47974f686cbb00f2ca617e8d0654bd")
