-- Lua provided by SkyAPI 
-- Game: She and Rope
addappid(2300850)
addappid(2300851, 1, "3115f2411333d1f0b3ed209b939c41096bc5549fdf155c6f2e15129674188c66")
