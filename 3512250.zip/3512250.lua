-- Lua provided by SkyAPI 
-- Game: Paranormal Torment
addappid(3512250)
addappid(3512251, 1, "e3ab3f291a46078e0daa4ca3b8cbb5f12e4c404740fd4220d0099e29f0cb54d7")
