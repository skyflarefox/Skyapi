-- Lua provided by SkyAPI 
-- Game: AppID 1162960
addappid(1162960)
addappid(1162961, 1, "e02e17d203e295c046e8560525c5ecc69f63921b34b7ab7362691b4fe6b15925")
addappid(1162964, 1, "3f908e5a9d3bc58a41022afd2ccd7932d7c61a218febdf6f29c0993e9d0aa858")
