-- Lua provided by SkyAPI 
-- Game: Voidwrought Demo
addappid(2865740)
addappid(2865741, 1, "ba4260538a2508316e209c20437b28c9fa9fade6b0aa9c6a07744619e3f0f54e")
