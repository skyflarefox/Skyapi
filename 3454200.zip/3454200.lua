-- Lua provided by SkyAPI 
-- Game: 101 Cats in Milan
addappid(3454200)
addappid(3454201, 1, "d3585408ffa0e1b8e25ac678737212547b2bac729e03dfb8f10f4c842cfb345f")
