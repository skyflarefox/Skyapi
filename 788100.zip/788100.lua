-- Lua provided by SkyAPI 
-- Game: Neon Abyss
addappid(788100)
addappid(788101, 1, "1524d54ee8d4105840022012751ba42ac9d631c069c91f661f0869a5801a146e")
