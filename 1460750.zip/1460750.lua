-- Lua provided by SkyAPI 
-- Game: SUPER DRINK BROS.
addappid(1460750)
addappid(1460751, 1, "07c03435a7b27d01de59ee3926060079d878a9cb501a6e9e239d5a431702327f")
