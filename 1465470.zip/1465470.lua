-- Lua provided by SkyAPI 
-- Game: AppID 1465470
addappid(1465470)
addappid(1465471, 1, "93f4a37540967cc2e6b661061973e3281089b15e33a95fd24afdb5e6045aeebd")
