-- Lua provided by SkyAPI 
-- Game: Harder
addappid(3133740)
addappid(3133741, 1, "3918e32c15496d0f78c6489136eb83cf3645e4e0840bfc1d593184970c662e14")
