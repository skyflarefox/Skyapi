-- Lua provided by SkyAPI 
-- Game: Corridors of Their Memories
addappid(1371040)
addappid(1371041, 1, "b8e3f43856e91d6b8123e16bb06c5c8b9a3412b6079b6f7694b4c595c8c9a328")
