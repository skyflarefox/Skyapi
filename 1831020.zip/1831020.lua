-- Lua provided by SkyAPI 
-- Game: NeuroWorm
addappid(1831020)
addappid(1831021, 1, "64a3ca89ebe7980d021b9642a673a6110f2f05ac30480c7ea5cb2535e2db249c")
