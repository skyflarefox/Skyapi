-- Lua provided by SkyAPI 
-- Game: AppID 1956770
addappid(1956770)
addappid(1956771, 1, "b006456130ecd9204f6ac2683f82defa9effa298cfbad50ef7b6dec424d74446")
