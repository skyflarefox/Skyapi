-- Lua provided by SkyAPI 
-- Game: Any Fish
addappid(1720200)
addappid(1720201, 1, "ed0cebfc57d222fa2007b899c4abd90b95951b290e662be4ea598f03989546f7")
