-- Lua provided by SkyAPI 
-- Game: AppID 1004770
addappid(1004770)
addappid(1004771, 1, "8c50bf0d876825852ca0c0d07a09ce2cece4bad9828494aaaa8d72b817d9df14")
addappid(1205731, 0, "bf9174e7e0775f4bcdf491373b7c6dd382cc57a69dde6bf9b49c0c14c55a34bf")
