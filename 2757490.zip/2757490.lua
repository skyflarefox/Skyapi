-- Lua provided by SkyAPI 
-- Game: Petit Game Collection vol.1
addappid(2757490)
addappid(2757491, 1, "9023d8bd5d1b6f1ff09161484f606daf62aa3acfa2505e2671f7c9cb1ed8e186")
