-- Lua provided by SkyAPI 
-- Game: AppID 3111910
addappid(3111910)
addappid(3111911, 1, "564a3a5fad4f9b4d75316efecf77ca68323fd29e6744443153b6dcecaf3b93af")
