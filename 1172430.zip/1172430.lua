-- Lua provided by SkyAPI 
-- Game: AppID 1172430
addappid(1172430)
addappid(1172431, 1, "99917ef83ed2c4c7f3db6ad99697132c47beada0f36c24cfdbbfc00786af6975")
