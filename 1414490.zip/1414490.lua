-- Lua provided by SkyAPI 
-- Game: AppID 1414490
addappid(1414490)
addappid(1414491, 1, "b0ad165bcdd24a07bef7284a07582e63a7bd8e01c9c3b5b9ba7c42d96b31d22b")
