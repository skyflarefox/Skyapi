-- Lua provided by SkyAPI 
-- Game: AppID 1283190
addappid(1283190)
addappid(1283191, 1, "c482a5a6304d7f7d3df9a771f629969364f0c0019ce2c646d92ababfbf04b889")
