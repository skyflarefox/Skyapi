-- Lua provided by SkyAPI 
-- Game: PlanetSide Arena
addappid(987350)
addappid(987351, 1, "fddd9bb5b74296ac2356dd6be3857d9bb7f101c2c86841f74811b00a1520f561")
