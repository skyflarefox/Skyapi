-- Lua provided by SkyAPI 
-- Game: Goat Survivor
addappid(3470660)
addappid(3470661, 1, "6952827fafb308ba2c84b059bbbece733de5be5a03b08a851825a9484d1195a0")
