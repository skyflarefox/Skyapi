-- Lua provided by SkyAPI 
-- Game: Castle Crumble
addappid(3562340)
addappid(3562341, 1, "034daa3c1ffb1007c688900dd216736bcdc27ef896380ebb6adbb5a18c2231eb")
