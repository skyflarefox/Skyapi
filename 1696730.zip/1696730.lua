-- Lua provided by SkyAPI 
-- Game: B.I.O.T.A. Demo
addappid(1696730)
addappid(1696731, 1, "13b489f768fe4b33d18b4e2cb9b7113a276d1565cdef4026d6d16f6000eabb38")
