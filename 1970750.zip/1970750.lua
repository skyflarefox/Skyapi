-- Lua provided by SkyAPI 
-- Game: SpearFrog
addappid(1970750)
addappid(1970751, 1, "752e23a6fbcb441a65c85a5363c9c80de1646d348dd05227e8d6b9f179af75a8")
