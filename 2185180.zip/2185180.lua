-- Lua provided by SkyAPI 
-- Game: Fantasy Madness: Bloodbath
addappid(2185180)
addappid(2185181, 1, "b24c6ccc39288fb39de8ff22274de37d24f2d5ffe4e5f8b0668be1b438e3966c")
