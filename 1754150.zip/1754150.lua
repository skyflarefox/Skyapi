-- Lua provided by SkyAPI 
-- Game: Car Tuning Simulator
addappid(1754150)
addappid(1754151, 1, "98b28c381410b9a0c575dfe45f293f4c26298a596d52311c3f5f4a4e5cdea4c0")
