-- Lua provided by SkyAPI 
-- Game: AppID 2868040
addappid(2868040)
addappid(2868041, 1, "8a825f639961d16ae016c1694976eba6745c3b1266e047a47e5fe2c2c06e4860")
