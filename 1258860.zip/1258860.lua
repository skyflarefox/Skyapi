-- Lua provided by SkyAPI 
-- Game: AppID 1258860
addappid(1258860)
addappid(1258861, 1, "bc9ba0c38cc2c00518aa1a1951fb29f23336d786dfc76a7a9774da38636b9a6e")
