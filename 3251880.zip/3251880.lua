-- Lua provided by SkyAPI 
-- Game: AppID 3251880
addappid(3251880)
addappid(3251881, 1, "400bf7bd2f7324f3887a8bc0e1610ed75b24583cdbc8315382b9e26635d39bb6")
