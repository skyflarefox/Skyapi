-- Lua provided by SkyAPI 
-- Game: SNKRX
addappid(915310)
addappid(915311, 1, "a402f6b0f6f23994e293e2d8d0dc951268cfd288d3642ed643280231a0636fc3")
