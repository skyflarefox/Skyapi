-- Lua provided by SkyAPI 
-- Game: Quest room
addappid(1965060)
addappid(1965061, 1, "50f0804a5b916ed944bf1729b0c011c04c196075de793c9871b9269d74910632")
