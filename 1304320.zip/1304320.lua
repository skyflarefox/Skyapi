-- Lua provided by SkyAPI 
-- Game: 重装无限·Metal Infinite
addappid(1304320)
addappid(1304321, 1, "cebb86b85f3f22b4aebefa3894d617fe0c75272d755bdd8c863cbf0583b11040")
