-- Lua provided by SkyAPI 
-- Game: MadGuns
addappid(1342340)
addappid(1342341, 1, "06270375aa9c7fd7f1dd526f675c0a8fe67c049560fac25a5d71e05f4ef7a058")
