-- Lua provided by SkyAPI 
-- Game: AppID 3154590
addappid(3154590)
addappid(3154591, 1, "e31ea95cf43af05a3c41504f3108888ad41d0e20dee2f68aed4ee2526a33babd")
