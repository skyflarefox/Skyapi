-- Lua provided by SkyAPI 
-- Game: West Hunt
addappid(1570330)
addappid(1570331, 1, "5ac859676f89d9398ad7cdf2bc000881eb620df56012ebc9ace954e66a34dbc2")
