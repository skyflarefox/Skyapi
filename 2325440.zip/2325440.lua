-- Lua provided by SkyAPI 
-- Game: Bitter-Sweet Cohabitation
addappid(2325440)
addappid(2325441, 1, "e3c7a533a5ef849020c659accb8fd574aaca0d4888156426f6b4e57cd8b365b6")
