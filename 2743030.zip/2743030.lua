-- Lua provided by SkyAPI 
-- Game: LISA: The First
addappid(2743030)
addappid(2743031, 1, "fc3aefb6a509fb25ff67390f561acdb9c5f7dc60c8e16155a93512f84a689f55")
