-- Lua provided by SkyAPI 
-- Game: Sky in your eyes
addappid(1980890)
addappid(1980891, 1, "5dbc653f850686c70d4700bda98d9a21181e5d6f95803842485f438aacffd2b5")
