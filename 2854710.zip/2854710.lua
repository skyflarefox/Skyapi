-- Lua provided by SkyAPI 
-- Game: Chocolate Factory
addappid(2854710)
addappid(2854711, 1, "84fce5e9642a918516c4ae043ab19514277dd62fb1caf9b41b24470fb54ec88f")
