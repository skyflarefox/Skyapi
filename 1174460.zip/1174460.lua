-- Lua provided by SkyAPI 
-- Game: Poker Club
addappid(1174460)
addappid(1174461, 1, "ed8b75ad32145573a7ecb76a9daf57d2a2032907ec25909c72464bdf012c6e79")
