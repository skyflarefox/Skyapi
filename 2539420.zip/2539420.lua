-- Lua provided by SkyAPI 
-- Game: Midnight Witch Starlight
addappid(2539420)
addappid(2539421, 1, "10694fc99b31a1d38fcf581a8e5dbee387f2754b133857f5d6bc3699cfd6ef56")
