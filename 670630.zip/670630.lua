-- Lua provided by SkyAPI 
-- Game: Slingshot Puzzle
addappid(670630)
addappid(670631, 1, "345584df00f19089ecebd7768cd47939fccc7efdc4b38dccae2d96596c2beb05")
addappid(670632, 1, "b74734d5ee330974e66801cdf1d6fbab72edb042493752f7d14e660ae3e8aa6b")
