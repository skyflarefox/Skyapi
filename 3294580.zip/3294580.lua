-- Lua provided by SkyAPI 
-- Game: 506战纪
addappid(3294580)
addappid(3294581, 1, "1a107bd9ff0a5b244358b8e40564846862f58c36a25122a66d0d9d425c063dea")
