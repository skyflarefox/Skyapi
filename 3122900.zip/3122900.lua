-- Lua provided by SkyAPI 
-- Game: MASSAGE MY EX-BULLY
addappid(3122900)
addappid(3122901, 1, "9dc10c99649df343d7e3a218ccfe2522e3c01c59de485cb279dff490b5f5e34b")
