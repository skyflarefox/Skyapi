-- Lua provided by SkyAPI 
-- Game: Fatal Velocity: Physics Combat
addappid(722620)
addappid(722621, 1, "e7780f05499413a8d522617e1a5a98f7e7a3279c3a2573944e406f6a7c6ba607")
