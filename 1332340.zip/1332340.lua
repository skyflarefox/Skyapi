-- Lua provided by SkyAPI 
-- Game: DISORDER
addappid(1332340)
addappid(1332341, 1, "4299a87965c6fa8f20880c1225607076c95cae50666d2ee56b9a19d5cc3e7da2")
