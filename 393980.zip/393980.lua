-- Lua provided by SkyAPI 
-- Game: AppID 393980
addappid(393980)
addappid(393981, 1, "d98c713232e11e5f8ca76916ca82f4b803c687f44fc6d23d121608ba51ca7565")
addappid(393982, 1, "c95e1febef325bbf8a3df273315a68068e9dd7d0764af81b83e6d11ff3fdc285")
