-- Lua provided by SkyAPI 
-- Game: DUNGEON ENCOUNTERS
addappid(1451080)
addappid(1451081, 1, "1e9210b049d3d5ab438ca571f7708025b302639f1beee2d284025fffb51911ee")
