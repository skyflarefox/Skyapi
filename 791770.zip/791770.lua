-- Lua provided by SkyAPI 
-- Game: AppID 791770
addappid(791770)
addappid(791771, 1, "6501d1bf5430dedfe48fe97f17ffa6c04c56b7453053ee6f776165b4ed72697c")
