-- Lua provided by SkyAPI 
-- Game: To Pixelia Demo
addappid(2474530)
addappid(2474531, 1, "bdc3c429b8031655a8ae7d9448b6acab85eea88899966598948d2fc122c12821")
