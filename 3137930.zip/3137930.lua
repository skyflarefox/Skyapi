-- Lua provided by SkyAPI 
-- Game: IMPETUM
addappid(3137930)
addappid(3137931, 1, "eb873bd724040bd481267f32ebe26f5b1d03e6bc811dba91898fdf01c48da20d")
