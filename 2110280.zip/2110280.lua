-- Lua provided by SkyAPI 
-- Game: Dungeons of Aether Demo
addappid(2110280)
addappid(2110281, 1, "27d56df667c2d25157bc109bc3a887af284a5553cc2382e232f4c9d9920da4fd")
