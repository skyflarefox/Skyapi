-- Lua provided by SkyAPI 
-- Game: YOU DON'T KNOW JACK TELEVISION
addappid(260040)
addappid(260041, 1, "c33c9f0a651b505b89ebbe7d316118a257e3678e8894d40cbb50528fa3efca89")
