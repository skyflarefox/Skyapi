-- Lua provided by SkyAPI 
-- Game: AppID 857080
addappid(857080)
addappid(857081, 1, "7fc670410e5981c330fb7e4b80661704b7fd8c0a7d1897f7c818f497692085c1")
