-- Lua provided by SkyAPI 
-- Game: Zen Trails
addappid(1418570)
addappid(1418571, 1, "47fdc0b128a9c691665f0da4533f25dbeac3328025e1f64f81ec3290e457d2c6")
