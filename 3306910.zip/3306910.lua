-- Lua provided by SkyAPI 
-- Game: Hentai Elizabeth
addappid(3306910)
addappid(3306911, 1, "d189724b5ce9e1b7304158d9c619f0703774321fcd185988e2992a94982ada42")
