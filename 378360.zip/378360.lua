-- Lua provided by SkyAPI 
-- Game: Ymir
addappid(378360)
addappid(378361, 1, "713385bd229af8b8996b9c2dafada1225a6c67c2ee9b0aa5ca6fcaa19ba8bf36")
