-- Lua provided by SkyAPI 
-- Game: LUNARK
addappid(1050370)
addappid(1050371, 1, "aa0b3db007fc776c20f9bb92ba7e40e1dc1f83487daafcf94f0573f655bd6711")
