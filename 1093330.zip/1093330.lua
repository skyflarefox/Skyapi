-- Lua provided by SkyAPI 
-- Game: AppID 1093330
addappid(1093330)
addappid(1093331, 1, "b557d2cebbb434ffdf02c47865bb4bf1762f23a056d9756a8f2da3e42c0de1e4")
addappid(1109850)
