-- Lua provided by SkyAPI 
-- Game: AppID 1162070
addappid(1162070)
addappid(1162071, 1, "e7f32bf7cfa527733b7e1f9e704417e0c73c9e87b5944720c77455a35d417727")
