-- Lua provided by SkyAPI 
-- Game: Sexy Girls Puzzle
addappid(932930)
addappid(932931, 1, "434c88a74b272534670036e425bf97593fbdc73b534c95ec573e80d73391d3f0")
