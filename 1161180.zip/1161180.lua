-- Lua provided by SkyAPI 
-- Game: Funbag Fantasy: Sideboob Story 2
addappid(1161180)
addappid(1161181, 1, "e1c94b2eaaec5ac08608c5e29ef4642fedf4483c967652e9013ee302df7fcd70")
