-- Lua provided by SkyAPI 
-- Game: Hannah’s Day Demo
addappid(2946000)
addappid(2946001, 1, "4dc91183dc074e79694c2b4d4f82ac275f484263102eaf91c78d216ca0d4826a")
