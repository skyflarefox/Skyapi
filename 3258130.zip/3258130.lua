-- Lua provided by SkyAPI 
-- Game: AppID 3258130
addappid(3258130)
addappid(3258131, 1, "4d4ee278da0758837759e43ae523d4fc2b81fc961e1ad09dbdf3a5980db7d86b")
