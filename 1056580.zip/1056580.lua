-- Lua provided by SkyAPI 
-- Game: AppID 1056580
addappid(1056580)
addappid(1056581, 1, "3e49bad221b31e858e8a3e158ac29e4b3dd5e8d47d85eaa66daea7249aa02055")
