-- Lua provided by SkyAPI 
-- Game: VRacer Hoverbike
addappid(668430)
addappid(668431, 1, "a700820d5fd00fad0c0a86d33150808c20584f592402cd3f8c7395667940ad47")
