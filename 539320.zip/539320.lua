-- Lua provided by SkyAPI 
-- Game: Picontier / ピコンティア
addappid(539320)
addappid(539321, 1, "ecc5397f5e53eaded90797ff0adde748047916f24d8a2ea6ebcd171099e81eee")
addappid(539322, 1, "61317e13df6936c146a4efcf5719378c53f192bb412f45b86d5c4e1134ec8e3a")
