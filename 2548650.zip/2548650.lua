-- Lua provided by SkyAPI 
-- Game: Run or Die
addappid(2548650)
addappid(2548651, 1, "3f030b52ae91f1974ed6d22e7f29ba5cd075928c52451e2951815a08125364f7")
