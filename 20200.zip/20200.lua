-- Lua provided by SkyAPI 
-- Game: Galactic Bowling
addappid(20200)
addappid(20201, 1, "48dc4ac1a2ed15c9d4e91a90e1673addd27cb62e90b2361370a1d9cfc0de234f")
