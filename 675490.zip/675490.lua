-- Lua provided by SkyAPI 
-- Game: AppID 675490
addappid(675490)
addappid(675491, 1, "ca87810e836b4061e8483e4fa1c27ab1f7c67a425dcb9b3497e50a36b4c416a1")
