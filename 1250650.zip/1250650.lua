-- Lua provided by SkyAPI 
-- Game: AppID 1250650
addappid(1250650)
addappid(1250651, 1, "afa5356481ba8c88343716391d1692b39ad47fc1976c224763ac75179601f367")
