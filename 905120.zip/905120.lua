-- Lua provided by SkyAPI 
-- Game: Son.Light.Sleepwalker
addappid(905120)
addappid(905121, 1, "882032b4bdf1f187f00f6e25a85b986768a066ec67d3c85a2159e09c47f4db1b")
