-- Lua provided by SkyAPI 
-- Game: Hentai Tales: The Entrance To Isekai
addappid(2911540)
addappid(2911541, 1, "d2445540694c7eaa84570a5586f93fd614111a45e325341b161101266561f4c3")
