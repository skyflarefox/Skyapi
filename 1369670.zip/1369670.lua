-- Lua provided by SkyAPI 
-- Game: Motor Town: Behind The Wheel
addappid(1369670)
addappid(1369671, 1, "2997d5be0b53d13cde83335f41136a55c7198a843f319a2e9e3667ef228a1aed")
