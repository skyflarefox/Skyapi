-- Lua provided by SkyAPI 
-- Game: 梦里彩笺来
addappid(2817070)
addappid(2817071, 1, "00bc1164bbdaa489f83002c776a0f1d5c6affce87bb456246c25ae4e4d3e2ab0")
