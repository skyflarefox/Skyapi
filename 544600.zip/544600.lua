-- Lua provided by SkyAPI 
-- Game: Delicious - Emily's Christmas Carol
addappid(544600)
addappid(544601, 1, "44b053b7fef1061bafcd9a1afdb163bd2d01be097fce98e7d7c9957f9672aa09")
addappid(554360, 0, "ef25f1258fe1551240a5ec1b46f363fd56f745c7e6c63cc6dd906cc4ad9bece9")
