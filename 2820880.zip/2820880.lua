-- Lua provided by SkyAPI 
-- Game: Commute
addappid(2820880)
addappid(2820881, 1, "d1b2aba9a5d89b530f533ea0ad2c26ff45311516206efdcb758bb03977976d8f")
