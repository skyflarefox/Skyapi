-- Lua provided by SkyAPI 
-- Game: Bakumatsu Renka SHINSENGUMI
addappid(1451160)
addappid(1451161, 1, "0109edbe233c943f992c04e9e7bb0f1a8778cd1ce90a477137cf677e8480ca26")
