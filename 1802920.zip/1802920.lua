-- Lua provided by SkyAPI 
-- Game: Tear of Time: Lost memory
addappid(1802920)
addappid(1802921, 1, "a3e9357188007c97d6b50e79168f22d14a66a1c3ba73669bd8b6e1b6c9d51607")
