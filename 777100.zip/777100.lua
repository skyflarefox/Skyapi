-- Lua provided by SkyAPI 
-- Game: AppID 777100
addappid(777100)
addappid(777101, 1, "0f3b26ca3dd0a93651f361b88fcf723117692a3700ca78d0421b4900eb073487")
