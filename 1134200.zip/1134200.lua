-- Lua provided by SkyAPI 
-- Game: AppID 1134200
addappid(1134200)
addappid(1134201, 1, "70ba7ca3cc09a0dd54fe27e26bfd12e2501cd9c455fb858394e25b77359644db")
