-- Lua provided by SkyAPI 
-- Game: Dodge
addappid(1667800)
addappid(1667801, 1, "fefca74ad59c65379c734d45eb90c9586361a85cdda3a7a78528845882517854")
