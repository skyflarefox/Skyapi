-- Lua provided by SkyAPI 
-- Game: CornField
addappid(3127480)
addappid(3127481, 1, "fe5b41723d774146cb24cc327b990c032ccd57e429cdcf1d067a31bb4f2a9441")
