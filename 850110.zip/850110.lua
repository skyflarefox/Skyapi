-- Lua provided by SkyAPI 
-- Game: AppID 850110
addappid(850110)
addappid(850111, 1, "67ccbe0f20daa4ae1f972e2ba69d79045454569f1068ddc04507145f637f5718")
