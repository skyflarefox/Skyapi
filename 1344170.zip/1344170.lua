-- Lua provided by SkyAPI 
-- Game: Sudden Way
addappid(1344170)
addappid(1344171, 1, "52a1e480f7ed300f8bf9ebc6737546e1a5652025f3c1d2add86301318ae501da")
