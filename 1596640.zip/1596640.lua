-- Lua provided by SkyAPI 
-- Game: Dark Chronicles: The Soul Reaver
addappid(1596640)
addappid(1596641, 1, "975bfdc0d8466120d1c0cee1213bfbf18cefe38d1980fb65803bcaca39cc5285")
