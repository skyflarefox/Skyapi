-- Lua provided by SkyAPI 
-- Game: FINAL FANTASY IV
addappid(1173800)
addappid(1173801, 1, "81eeba512901afad70a794fda96e542241c5baf0127035bbe2b0cd961cc3effe")
addappid(1638380, 0, "fda1ebeaed0a78c3763208ab93f284009638971d4b66c335df4896b6a91a26e2")
