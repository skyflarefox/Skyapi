-- Lua provided by SkyAPI 
-- Game: ROOM FOOTBALL - Petrol Station
addappid(3571660)
addappid(3571661, 1, "75e45c327f8181060a68bcd2feb6aece70638808562247349a9810ac886e104a")
