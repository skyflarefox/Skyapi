-- Lua provided by SkyAPI 
-- Game: Trap Shrine
addappid(951000)
addappid(951001, 1, "766c753ef96ccf3d373159335fefdeef08b1cc9c7e92610a1e4ca62d7c30b47c")
