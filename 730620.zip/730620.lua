-- Lua provided by SkyAPI 
-- Game: Hammer 2
addappid(730620)
addappid(730621, 1, "f8eea09b10bc83c5691a4ad8078dddc10a3c5f8bbf09cc0ecb2e20b4e0fcd242")
