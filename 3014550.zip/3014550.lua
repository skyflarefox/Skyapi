-- Lua provided by SkyAPI 
-- Game: AppID 3014550
addappid(3014550)
addappid(3014551, 1, "b1f185bb56847d7cbff819eb539d34d36282e2cedd4c7a509487430b14b415ec")
