-- Lua provided by SkyAPI 
-- Game: Crosshair X
addappid(1366800)
addappid(1366801, 1, "c5417c02a22d0961ede2808e93da40d019b1d1f88131568488d7659bdc01ddcf")
