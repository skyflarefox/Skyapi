-- Lua provided by SkyAPI 
-- Game: The Witch in the Forest
addappid(1419740)
addappid(1419741, 1, "ccee4b00992c7c5a21941a37a0b58fc256a172e3f5e09d912e236aa360298311")
addappid(1427370)
