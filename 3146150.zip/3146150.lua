-- Lua provided by SkyAPI 
-- Game: AppID 3146150
addappid(3146150)
addappid(3146151, 1, "f32470ffd239e7d7cdf399921907be74c0ee213021dbc580a83644ca916ad85c")
