-- Lua provided by SkyAPI 
-- Game: Idle interstellar Factory 2
addappid(2218570)
addappid(2218571, 1, "20b7f1203e46e583492acbbf6f4e46be8414cd625898c4d35421e5099179c946")
