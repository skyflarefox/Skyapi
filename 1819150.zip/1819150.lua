-- Lua provided by SkyAPI 
-- Game: After the Fall® Soundtrack
addappid(1819150)
addappid(1819151, 1, "402c35d58507b337d45aee20c6ee1eb8ef37ee3d37ae463f002334d5b9242ff8")
