-- Lua provided by SkyAPI 
-- Game: Death in the Family
addappid(1762830)
addappid(1762831, 1, "408d524f10a05cef62ce817bb4d8b764bd31da0cd6b9f0efe9c25542eb5bfa59")
