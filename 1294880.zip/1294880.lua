-- Lua provided by SkyAPI 
-- Game: AppID 1294880
addappid(1294880)
addappid(1294881, 1, "7b1cb6e90988e8e0b5fe697d913bb1fd8029d6d98d6d59f4efad31ef2d8afe6d")
