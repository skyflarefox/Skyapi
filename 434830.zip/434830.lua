-- Lua provided by SkyAPI 
-- Game: DragonStone
addappid(434830)
addappid(434831, 1, "9508bdb633abf6bc98e9f600509381216740dc55f30096beb7454819d996971b")
