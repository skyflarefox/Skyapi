-- Lua provided by SkyAPI 
-- Game: IOX
addappid(1190690)
addappid(1190691, 1, "c8dcebe760dc43763b0377671b6d98572d9ef564f23f08c06bbe5c89329cfdd5")
