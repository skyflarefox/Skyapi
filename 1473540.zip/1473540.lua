-- Lua provided by SkyAPI 
-- Game: Gondola's Adventure
addappid(1473540)
addappid(1473541, 1, "d89dc0ac6b49ae3cf38c5c2d8ab0763227829c3df119a0483a3e4305f7f1e153")
addappid(2436320)
