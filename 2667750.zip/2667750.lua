-- Lua provided by SkyAPI 
-- Game: Hungry Cats 饥饿的猫
addappid(2667750)
addappid(2667751, 1, "5c3b37a3331cdadad4f4394b34404c1d94b0f330be976594b6844a6ce070fb9f")
