-- Lua provided by SkyAPI 
-- Game: Journey to Alien Worlds
addappid(628960)
addappid(628961, 1, "bc1fc8e10bdeff7190f6b49ae5fc233432c34b4ff94af0a4c7c5169f10ee5688")
