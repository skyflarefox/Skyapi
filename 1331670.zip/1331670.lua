-- Lua provided by SkyAPI 
-- Game: International Space Banana
addappid(1331670)
addappid(1331671, 1, "d4316b5950a62e3cfac06620af8c43f6ae0ac0f0e71d7ef619c334de68fdc20d")
