-- Lua provided by SkyAPI 
-- Game: AppID 3158050
addappid(3158050)
addappid(3158051, 1, "ba8580e076dc36245c203df6bfc3651e4951e215a20d55c7ea7d938d028cbd79")
