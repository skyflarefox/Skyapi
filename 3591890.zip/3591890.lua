-- Lua provided by SkyAPI 
-- Game: CombatBox
addappid(3591890)
addappid(3591891, 1, "88cc928083025985aff3225bf3db57ae28c7369b7cd712f30801c78c1d944acf")
