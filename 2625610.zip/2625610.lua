-- Lua provided by SkyAPI 
-- Game: AppID 2625610
addappid(2625610)
addappid(2625611, 1, "8b9391e7b9f14f3fdd1bb56b4928d8e4ac5d8f963d69df528dbfc958cd197484")
