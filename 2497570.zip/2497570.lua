-- Lua provided by SkyAPI 
-- Game: AppID 2497570
addappid(2497570)
addappid(2497571, 1, "5754df0048d7ab02d2a712e5e380f7bf503a350ab673cfe80b713a1b863cd69c")
