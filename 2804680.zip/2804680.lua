-- Lua provided by SkyAPI 
-- Game: Only Way is Down
addappid(2804680)
addappid(2804681, 1, "7b698f6d57277b3ead21e6caa0ccf9a58062cdf8ee2d9de08bd185a2da32474c")
addappid(3800810)
