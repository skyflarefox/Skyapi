-- Lua provided by SkyAPI 
-- Game: AppID 567660
addappid(567660)
addappid(567661, 1, "458957a89c8c7cd64821a5f6308b9dd3ea86553d0c90eb398fb4a18bb6274ee2")
