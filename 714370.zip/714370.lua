-- Lua provided by SkyAPI 
-- Game: AppID 714370
addappid(714370)
addappid(714371, 1, "636b89371d3506d1a8edec63d4fd097a5a8e48e38818ea3d2829f2b0fadc2874")
