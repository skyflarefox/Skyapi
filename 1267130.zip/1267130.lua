-- Lua provided by SkyAPI 
-- Game: Axe Girl
addappid(1267130)
addappid(1267131, 1, "ab8c6baba6a3e25d1853436c2d0231012099b489638cbae4971e8007d99cca90")
