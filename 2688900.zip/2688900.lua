-- Lua provided by SkyAPI 
-- Game: Super Algebrawl
addappid(2688900)
addappid(2688901, 1, "af3bdc55ceadb64dab94346bdf46c89df1fef2af3ba5813a262b4299d418c6de")
