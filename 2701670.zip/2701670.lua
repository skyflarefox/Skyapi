-- Lua provided by SkyAPI 
-- Game: Mystery Stories: Mountains of Madness
addappid(2701670)
addappid(2701671, 1, "33096bb74eb517be882eb7de2b995a0d7e531d0519cbfbb1b76090d4af36530d")
