-- Lua provided by SkyAPI 
-- Game: VR探索梅西爾
addappid(1486330)
addappid(1486331, 1, "d4602a5a45058cb233b2b0ac2be9cdc2f0fdcc16036b4276b0bd45e3911204c0")
