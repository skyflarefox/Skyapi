-- Lua provided by SkyAPI 
-- Game: AppID 291390
addappid(291390)
addappid(291391, 1, "608e5dc21a53591bb8f42e64e780118884b63e2fd5bf2540df2f042f83f57306")
addappid(291392, 1, "a64cee753d8dffe807f3df924347119dc74ebe6f014ef0a9874565d6cd974c29")
