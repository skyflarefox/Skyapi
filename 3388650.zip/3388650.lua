-- Lua provided by SkyAPI 
-- Game: AppID 3388650
addappid(3388650)
addappid(3388651, 1, "eb7a30cc4b60ed277c689d8992cdb410069623388b24b92b2102c0cfdeaf9115")
