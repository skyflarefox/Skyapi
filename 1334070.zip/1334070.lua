-- Lua provided by SkyAPI 
-- Game: Sleep
addappid(1334070)
addappid(1334071, 1, "f1a8e56c41c049ee28f487543a1c22b75ea43191bf38d82665d0b5f9d65c3b7f")
