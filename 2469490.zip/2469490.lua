-- Lua provided by SkyAPI 
-- Game: Elemental World
addappid(2469490)
addappid(2469491, 1, "7a6070a9ae1f03bdb57a1d1943ea8434da720c2b7b6d8deff5f3a1668d2f669b")
