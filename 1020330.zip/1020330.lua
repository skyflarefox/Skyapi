-- Lua provided by SkyAPI 
-- Game: AppID 1020330
addappid(1020330)
addappid(1020331, 1, "37eed2e70f7e24eb0c3e683fdc88793297bc64d47ec08405a7c2c9ba0551a83f")
