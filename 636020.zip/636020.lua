-- Lua provided by SkyAPI 
-- Game: India Garden
addappid(636020)
addappid(636021, 1, "5bf65f762d56748b8b7923cfa8c3c95556cf18b21f63ac5be1960d65a9fcb1d1")
addappid(636022, 1, "dc7cb76efd1d5113b6f3d72c4c5ad0636a3cd6e887c914dd99b95e22260d9e61")
addappid(636023, 1, "ba5c98bd3f5418dae8da8cf162b41b0df5377fff0b63b1923975454ce7125f2e")
