-- Lua provided by SkyAPI 
-- Game: Feather Party
addappid(2300230)
addappid(2300231, 1, "381a09ded1a5dd416d4c4b38d744d6220d455426876d2f90471363bddf70a27d")
