-- Lua provided by SkyAPI 
-- Game: NightSky
addappid(99700)
addappid(99701, 1, "6197ff92f2570c21c6d847702ae0077834c847e959f847a0ff60f53f96d414ca")
addappid(99702, 1, "52254fb1d14dd1592ffbaee1c6c9cc151913a519d45e9048f2e90b7eaa1bc75b")
addappid(99703, 1, "babd07f6c18baaee43f22d256d1791489aff59b0f92f54fc66a8cdcf1c51247c")
