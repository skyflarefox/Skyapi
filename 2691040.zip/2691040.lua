-- Lua provided by SkyAPI 
-- Game: Warcrow Adventures
addappid(2691040)
addappid(2691041, 1, "41bc6d3b5f45814550e2f8b453da70f70c1477b16b6dc1c00f4f890e7f568575")
