-- Lua provided by SkyAPI 
-- Game: Lairchitect
addappid(1362430)
addappid(1362431, 1, "36302e59aa5ac06f0e59961df531bcde10c0a0a34a0469b3e8e336aef0c2387b")
