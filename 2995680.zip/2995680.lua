-- Lua provided by SkyAPI 
-- Game: AppID 2995680
addappid(2995680)
addappid(2995681, 1, "9d1d86494122c5e1b3c71a4793305632f1505615d708b6224f3d7580f43df3b8")
