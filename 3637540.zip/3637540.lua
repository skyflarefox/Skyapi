-- Lua provided by SkyAPI 
-- Game: Cricket Captain 2025
addappid(3637540)
addappid(3637541, 1, "5dcf180ad32c922806d2da5e98a65b17fe859b22761984ca223dc1cf31bec5a9")
