-- Lua provided by SkyAPI 
-- Game: There's a Butcher Around
addappid(1077430)
addappid(1077431, 1, "b481d2f97d2d4e9538f838dd3bb1dc9adb604bc69bad953e382ccc19f69b36c5")
