-- Lua provided by SkyAPI 
-- Game: AppID 1116210
addappid(1116210)
addappid(1116211, 1, "0e6e4af313a3cb98d8b8e629c847a57f0aa2317d9861ae2e5a35f2ace08264bf")
addappid(1223780, 0, "4a52424576bd50199e8c1e79606ffc52662301af0e16dd4950c4bf6b667077a8")
