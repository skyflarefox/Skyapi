-- Lua provided by SkyAPI 
-- Game: Age of Defense
addappid(603320)
addappid(603321, 1, "40bb3f928371a1385f6df88a336d5204241b6b3e2cefbb98fbc03af160107b6b")
