-- Lua provided by SkyAPI 
-- Game: KILLDOZER
addappid(3417500)
addappid(3417501, 1, "71192f9ca8bc9e88243297dbe57792c57421f5b867659d7500f03f2c976b0d11")
