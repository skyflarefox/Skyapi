-- Lua provided by SkyAPI 
-- Game: AppID 2938220
addappid(2938220)
addappid(2938221, 1, "8935b23c1e5d2b00d132953ee5a0bf45e3bbe7daa712d9ea98212c71a2547570")
