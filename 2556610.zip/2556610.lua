-- Lua provided by SkyAPI 
-- Game: AppID 2556610
addappid(2556610)
addappid(2556611, 1, "be80ee9b7b638736ad9ae24c345250664ddb357a409ed501f934d6b5f64e05f8")
