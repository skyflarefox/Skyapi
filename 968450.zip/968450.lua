-- Lua provided by SkyAPI 
-- Game: Hentai Puzzle Classic
addappid(968450)
addappid(968451, 1, "8e3ae06877926735a00a18d59c586532e8daa13697e22eede30bc9dcd2cc1ba7")
