-- Lua provided by SkyAPI 
-- Game: Danger Scavenger
addappid(1169740)
addappid(1169741, 1, "98fe95448382458b341568872cce63d29cac0b501597d7941de7e3b0108581e8")
addappid(1877120, 0, "ea3cb8b14df82204ce0c4b7f2ae4a54de59f9f031eed2cbd4c3413b24d633d83")
