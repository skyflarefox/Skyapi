-- Lua provided by SkyAPI 
-- Game: Fish-Click Squad!
addappid(2982100)
addappid(2982101, 1, "5222c355e517a15ee218f9237c000297d9ceef3e8b7ec14330b17c6222dff7a2")
