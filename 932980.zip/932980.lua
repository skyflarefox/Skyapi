-- Lua provided by SkyAPI 
-- Game: Axis Football 2018
addappid(932980)
addappid(932981, 1, "c7289c43ad65cd9f7278e63b6ed280287c9c4c092b6fec9045f2f4900cb0eca6")
addappid(932983, 1, "44d274a16a83d4a8a9bf4cc46ce204e6ca9267ac0ca4476df04d11e273567e7d")
