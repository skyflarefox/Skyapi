-- Lua provided by SkyAPI 
-- Game: Push The Box 3D
addappid(1549620)
addappid(1549621, 1, "8268efc685fe76acc6fb85fe0693c6e6c9a97b4c7ebaf33c81361f0fdac78d37")
