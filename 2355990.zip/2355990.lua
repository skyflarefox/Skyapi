-- Lua provided by SkyAPI 
-- Game: Dippy & Chippy
addappid(2355990)
addappid(2355991, 1, "77894f98a389476c5d7b3673dea3446be533e5ba223a994fbf43e9e2c1520790")
