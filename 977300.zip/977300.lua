-- Lua provided by SkyAPI 
-- Game: Fenimore Fillmore: 3 Skulls of the Toltecs
addappid(977300)
addappid(977301, 1, "9bc0198d66e5365f2e8e8a12c5eddaa7c92d2a5655c84dbc8c92fe8dcd094c9a")
