-- Lua provided by SkyAPI 
-- Game: VARIOUS DAYLIFE
addappid(1897050)
addappid(1897051, 1, "dc337d52af4c196f05e27b36e354287796f43dde225ae15bdc54ec237df62e52")
addappid(2081320, 0, "d72e14646a42ffdb26d8ab7da4afa1f602f5f59f2468882a1e11cebf32ab4c10")
