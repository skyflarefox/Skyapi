-- Lua provided by SkyAPI 
-- Game: Red end
addappid(2802240)
addappid(2802241, 1, "744de515c95a3c15d69b02b3ae4133e64ae8e6496cd444f435679e9648db099d")
