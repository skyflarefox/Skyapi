-- Lua provided by SkyAPI 
-- Game: Three Kingdoms The Last Warlord-Heroes Assemble
addappid(2718740)
addappid(2718741, 1, "b1a2c27ca53df6f77e224bfdfcf211fd874afea094b01555a6b369ee10c7913d")
