-- Lua provided by SkyAPI 
-- Game: AppID 3519390
addappid(3519390)
addappid(3519391, 1, "20022fdb59f665dbfc5e7de9b00bf36130ea6398a8b3b2d13e6dbf55b3f562cb")
