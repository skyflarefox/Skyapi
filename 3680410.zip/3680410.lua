-- Lua provided by SkyAPI 
-- Game: Tears of Vanfell: New Beginning
addappid(3680410)
addappid(3680411, 1, "ec2f9558cecfdaa198c616df4bbd521969e751012a01589990d06de1d391d001")
