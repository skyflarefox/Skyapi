-- Lua provided by SkyAPI 
-- Game: GeneWars
addappid(2093980)
addappid(2093981, 1, "b1520573567df9016b95576a1af0da36b8f86189b8953927f19b8641498c406c")
