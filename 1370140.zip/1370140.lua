-- Lua provided by SkyAPI 
-- Game: AppID 1370140
addappid(1370140)
addappid(1370141, 1, "3f8629fbb74ca939c630c00762b9622a3a5e17611b0a9e65db4caebdb2dbec12")
