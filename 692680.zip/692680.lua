-- Lua provided by SkyAPI 
-- Game: AppID 692680
addappid(692680)
addappid(692681, 1, "f605549d8e02a52d9d8c6e6ba2a5a32c6bcf26e123a6e0e226ae50e3a70a5fdf")
