-- Lua provided by SkyAPI 
-- Game: AppID 2978590
addappid(2978590)
addappid(2978591, 1, "59e367a3a16cb26b8ad096868397c1e467b339e6a12540664a446a5aec6b2501")
