-- Lua provided by SkyAPI 
-- Game: AppID 3359210
addappid(3359210)
addappid(3359211, 1, "c85fb772ad17414514259d227f051c02070de03a243bdfb9142ab3a8862138b4")
