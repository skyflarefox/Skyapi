-- Lua provided by SkyAPI 
-- Game: AppID 1981030
addappid(1981030)
addappid(1981031, 1, "47ade1eafbc315e5016492b33c3a250e7ab96c7bac20bf3d6e6a91165725a994")
