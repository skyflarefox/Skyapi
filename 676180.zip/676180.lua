-- Lua provided by SkyAPI 
-- Game: Spaceguard 80
addappid(676180)
addappid(676181, 1, "4b6817bbc4516aa8a5a3986772bccfca8c4031adb6802064ba4333111e019daa")
