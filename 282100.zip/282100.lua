-- Lua provided by SkyAPI 
-- Game: Fearless Fantasy
addappid(282100)
addappid(282101, 1, "a746e9f1a6cba890be9ef34088ba6cbd916f62af9e49b6d47339d13474f9c4d5")
