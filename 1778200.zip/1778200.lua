-- Lua provided by SkyAPI 
-- Game: Minigunner®
addappid(1778200)
addappid(1778201, 1, "bba6df15eef10f28f6d5340f9c79b222c7153831ff789a701fe65ba4dfeeb07c")
