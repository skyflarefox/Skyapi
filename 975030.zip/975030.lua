-- Lua provided by SkyAPI 
-- Game: Abandoned
addappid(975030)
addappid(975031, 1, "ff18cbe400dbca87ca5710d0d5ae5aa059f90be641c5a0d2c8e58242f4aaf973")
