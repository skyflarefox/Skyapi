-- Lua provided by SkyAPI 
-- Game: Nemesis: Race Against The Pandemic
addappid(1497180)
addappid(1497181, 1, "ecae189684a9c46c076899afe25e359771db6c1bf57b33a7eeb47bfd9ee5ef78")
