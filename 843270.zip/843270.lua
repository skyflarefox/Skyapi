-- Lua provided by SkyAPI 
-- Game: AppID 843270
addappid(843270)
addappid(843271, 1, "47560b9b6e4b2c165ae38a264498181393b01074ca98f794798193a79b3014a7")
