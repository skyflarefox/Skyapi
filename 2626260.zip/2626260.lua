-- Lua provided by SkyAPI 
-- Game: AppID 2626260
addappid(2626260)
addappid(2626261, 1, "f71902f52515c79380ef4e0d0acd2fec709236a3aedf78a7e39ee21aa54d02b9")
