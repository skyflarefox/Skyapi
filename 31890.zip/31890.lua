-- Lua provided by SkyAPI 
-- Game: AppID 31890
addappid(31890)
addappid(31891, 1, "3eaf00896b429a2b10ce1b95b6109b8033cd69461f8bd4583867b5531b1683f7")
