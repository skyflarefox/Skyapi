-- Lua provided by SkyAPI 
-- Game: AppID 806220
addappid(806220)
addappid(806221, 1, "faa50ea834eeda463e352b2284bae41cc72d820d350c2b62eca4a87985dcadd7")
addappid(810280, 0, "e71d5c06d87112ae2c62507513a475aa23e2bb46ed9f0f0d1529d4c9639e5ad8")
