-- Lua provided by SkyAPI 
-- Game: AppID 307130
addappid(307130)
addappid(307131, 1, "8ba910e412632536660c1480884b835c54e52dfe44888201aecf85ad5bbb2b39")
