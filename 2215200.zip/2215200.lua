-- lego batman (have denuvo active on https://discord.com/channels/1408201417834893385/1473436575403737281)
addappid(2215200) -- Lego batman: Legacy of the Dark Knight
addappid(2215201, 1, "5d2bafc1381c29ebabb37bbab50e496548be24f6bf5d511e8d471b99d60cfbf3") 
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") |
