-- Lua provided by SkyAPI 
-- Game: Kingdom's Deck
addappid(2655590)
addappid(2655591, 1, "938cf7542d29fddb19cc588a978b2bcabbf645729522dfbd8d3c2a87e9341e8c")
