-- Lua provided by SkyAPI 
-- Game: DEFCON VR
addappid(579040)
addappid(579041, 1, "6ac61836679923588aca6ca4fa6bc3fe6b1f42eb3d733f0674fae5df11bf7fe4")
