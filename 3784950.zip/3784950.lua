-- Lua provided by SkyAPI 
-- Game: SUBS
addappid(3784950)
addappid(3784951, 1, "0bc917b7b0276eb47650315e60d3d6996d8d4ad35dd91eaacf0a86323b73f7b6")
