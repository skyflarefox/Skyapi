-- Lua provided by SkyAPI 
-- Game: Sonny Legacy Collection
addappid(2757720)
addappid(2757721, 1, "22e2469b49b989d01b0411c613c26a28b6a6ffccd10101234a795060900fcfed")
