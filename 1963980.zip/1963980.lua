-- Lua provided by SkyAPI 
-- Game: ...
addappid(1963980)
addappid(1963981, 1, "96af90f34b23001a22d176d52079b3ac2e8182c4cfd298d5b2a09f7602c7da10")
