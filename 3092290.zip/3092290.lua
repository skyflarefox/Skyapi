-- Lua provided by SkyAPI 
-- Game: Shin chan: Shiro and the Coal Town "Digital Contents Set"
addappid(3092290)
addappid(3092291, 1, "48598b3e5d4f571f099f1acdf7c94ac98acee865700c45fb1135e185543ffa3a")
