-- Lua provided by SkyAPI 
-- Game: AppID 301840
addappid(301840)
addappid(301841, 1, "3ecf26b81fe3b3a9f3f44bdeb1120aa084969a8560bd6431bd427717c684d647")
addappid(834020, 0, "2b065a9ad96209f05a7c0ab2ae7c0aab1912cfa9c743b1a7de583d05ca6bcb7a")
