-- Lua provided by SkyAPI 
-- Game: Survive Ten Days Demo
addappid(2872200)
addappid(2872201, 1, "9c2bf54687278926d04202e561d3df64f509d9dc7fa7d3602241d68c30ff0753")
