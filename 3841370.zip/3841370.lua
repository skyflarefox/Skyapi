-- Lua provided by SkyAPI 
-- Game: AppID 3841370
addappid(3841370)
addappid(3841371, 1, "1285e22aefa86536ea6a334472ebe0c1b457685eea573ca331891664a9814183")
