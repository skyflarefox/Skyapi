-- Lua provided by SkyAPI 
-- Game: Tank Hunter
addappid(2957440)
addappid(2957441, 1, "2c02c4cca1f6f78079e0f0f27efcca8c14fe89af5a304fec6bfbe6adb5feb971")
