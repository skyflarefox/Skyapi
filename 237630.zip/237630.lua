-- Lua provided by SkyAPI 
-- Game: AppID 237630
addappid(237630)
addappid(237631, 1, "8109a2506a5c0b1d757517edf3b1fb809c43ea094e293acf57dd46c2c6314127")
