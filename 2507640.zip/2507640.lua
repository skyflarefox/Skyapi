-- Lua provided by SkyAPI 
-- Game: Pyroworks
addappid(2507640)
addappid(2507641, 1, "219c1428074f10ed170d15a6f5048fed3adf662c43772af8dc1cfafc721c2c4d")
