-- Lua provided by SkyAPI 
-- Game: AppID 392230
addappid(392230)
addappid(392231, 1, "00f344bfaf8a877b36176cb73bc03d80234d567169496eb75bd3d31d034a0a06")
