-- Lua provided by SkyAPI 
-- Game: Trigger Saint
addappid(354770)
addappid(354771, 1, "6156ba099756a5131acf800f579a72fe512886a3e5ffac8152ba3b5916aa657f")
