-- Lua provided by SkyAPI 
-- Game: The Pyraplex
addappid(2101280)
addappid(2101281, 1, "ef48318093942e2e1179ab0b60d8c9dc1dccd34c2059ecc093bd8c62c6f50272")
