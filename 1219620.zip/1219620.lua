-- Lua provided by SkyAPI 
-- Game: Lovely Overseer - Dating Sim
addappid(1219620)
addappid(1219621, 1, "5ffbcbb9177e586285285128668ad908db484d1d14a1167fdb85dd3c3e15fbcb")
addappid(1321550, 0, "0807ca5c5e2cca5a45144b5a566cebbe4dbe6e95ac172c9f77b6ccbb6bc66dbb")
