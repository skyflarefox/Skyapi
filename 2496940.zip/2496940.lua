-- Lua provided by SkyAPI 
-- Game: Grandpa's House
addappid(2496940)
addappid(2496941, 1, "dfb900c1f20b1e88585dbfe2529b64debb0694b3c8e5816890a7c0518f1fbee5")
