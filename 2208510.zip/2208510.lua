-- Lua provided by SkyAPI 
-- Game: AppID 2208510
addappid(2208510)
addappid(2208511, 1, "3083c2c9797cab5a1df903716395b0314defac69f408c50df50a7924675efea8")
