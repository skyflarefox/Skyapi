-- Lua provided by SkyAPI 
-- Game: Project CARS - Pagani Edition
addappid(429180)
addappid(429181, 1, "f24c485d3231569719d0b662d1ddd9ee0e8f4303f4b6fe1c8648329e6bd992aa")
