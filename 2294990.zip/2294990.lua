-- Lua provided by SkyAPI 
-- Game: The Homecoming Exhibition
addappid(2294990)
addappid(2294991, 1, "3407e81ad609cc48988c7c591feb91a63105f23e3377a9af38311ece860dc0df")
