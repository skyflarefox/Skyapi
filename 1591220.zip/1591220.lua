-- Lua provided by SkyAPI 
-- Game: AppID 1591220
addappid(1591220)
addappid(1591221, 1, "f7b3db1c5636abbf6f48afd04069d285002e64053e56569f2d5245e9a2cbba50")
