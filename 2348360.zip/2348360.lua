-- Lua provided by SkyAPI 
-- Game: AppID 2348360
addappid(2348360)
addappid(2348361, 1, "bf4b12207bc8773c920abe49c2b1d2ac0ee53dcf02e6a72deb7981d80517164d")
