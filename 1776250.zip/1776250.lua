-- Lua provided by SkyAPI 
-- Game: 盖世豪侠
addappid(1776250)
addappid(1776251, 1, "6947c90b8081abeb02f97af9e466afd7f6fb8c0d6b052932f61b0263adf351d1")
