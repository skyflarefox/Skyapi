-- Lua provided by SkyAPI 
-- Game: Under Contract Demo
addappid(2003980)
addappid(2003981, 1, "2a5ba0f751fa053d4950c8af158049236acef1f645960d25558ce1d030931594")
