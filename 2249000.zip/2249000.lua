-- Lua provided by SkyAPI 
-- Game: 候鸟 Demo
addappid(2249000)
addappid(2249001, 1, "c9a98cf29998e12a31c0187b8b946c87e2785b168ca2d537bcab0030715f8b97")
