-- Lua provided by SkyAPI 
-- Game: Maze Art: Red
addappid(1818830)
addappid(1818831, 1, "19af856b95853fe969d223b6187eb673afe69e5bc28d23a09ec6c1510bb5a940")
