-- Lua provided by SkyAPI 
-- Game: Anime Dream Match: Dogs
addappid(3735190)
addappid(3735191, 1, "1c8aad26c75cc075fb17c118b8580b74f8de03a3af5e7c24c98fc8386e2b1422")
