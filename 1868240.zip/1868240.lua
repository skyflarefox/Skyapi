-- Lua provided by SkyAPI 
-- Game: Ink Bunny
addappid(1868240)
addappid(1868241, 1, "770f165f8868a5a93f25687663abb10460ea5b23e996b5b6533cbb0af359d100")
