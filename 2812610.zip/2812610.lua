-- Lua provided by SkyAPI 
-- Game: AppID 2812610
addappid(2812610)
addappid(2812611, 1, "fbddbbd999cc40eb99086bc5c4a6420f03002bfb1bd89b1cac59b7b75c9df933")
