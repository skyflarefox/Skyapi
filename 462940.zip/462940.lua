-- Lua provided by SkyAPI 
-- Game: AppID 462940
addappid(462940)
addappid(462941, 1, "b9f5ed1c991d1165b358f79dbf1e0d57a339ed9a8c5bb997d791d2daa58f52a7")
