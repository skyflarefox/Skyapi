-- Lua provided by SkyAPI 
-- Game: AppID 1041670
addappid(1041670)
addappid(1041671, 1, "f0bd9e827792c195c11b388347e0a5de467709db1adc1164a16addc145eca03a")
