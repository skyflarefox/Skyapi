-- Lua provided by SkyAPI 
-- Game: Deadwater Saloon
addappid(1696080)
addappid(1696081, 1, "7480f6af448e9a51461e9df5ce7c156f803a1c556ec1150ccab4859f3e2ecd9f")
