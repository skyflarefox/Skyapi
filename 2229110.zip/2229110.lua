-- Lua provided by SkyAPI 
-- Game: A Familiar World
addappid(2229110)
addappid(2229111, 1, "545560c855b12640b4fa89e443938b6068089e3e5cec4e38e4b5c6c431218863")
