-- Lua provided by SkyAPI 
-- Game: AppID 1015620
addappid(1015620)
addappid(1015621, 1, "7ac300a5da03012b4fc657ee2015b457debaf5e878e6bd47563d4b0e4b7cf5ec")
addappid(1093230, 0, "714c84f44c0263f6c080a94714c168ff02f04c392ca05281c3daf27423a90fde")
