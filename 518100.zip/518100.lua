-- Lua provided by SkyAPI 
-- Game: AppID 518100
addappid(518100)
addappid(518101, 1, "809d46b8fc9d272b51ab74ec6e6d612e388ea9abb87dd3ce21ca339d0efcf2be")
