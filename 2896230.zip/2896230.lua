-- Lua provided by SkyAPI 
-- Game: Mother's Sword Demo
addappid(2896230)
addappid(2896231, 1, "638d3a1b51387173c88d0723e16be1b81421ad4b6c676139a2d1aee757545612")
