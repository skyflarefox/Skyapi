-- Lua provided by SkyAPI 
-- Game: Screen Cat
addappid(3402530)
addappid(3402531, 1, "cd8a012bb6725a1443e905eb3686ed79accef272dddea835bdf0ca5fd9564d46")
