-- Lua provided by SkyAPI 
-- Game: AppID 2328740
addappid(2328740)
addappid(2328741, 1, "db07a203f86ed9d6e935e803e6bf77cb41a8345be1d21258fda29d375eb85731")
