-- Lua provided by SkyAPI 
-- Game: Happy Treasure King
addappid(3516920)
addappid(3516921, 1, "0b4a8fa2d71ca8691863e4b1917feb07c3e3fa777d8aa75cf123c8a667603f47")
