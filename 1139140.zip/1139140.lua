-- Lua provided by SkyAPI 
-- Game: AppID 1139140
addappid(1139140)
addappid(1139141, 1, "a0ad9b1bb6f534988ef922c51605e327eae42d96fe457faf8f801535f4558814")
