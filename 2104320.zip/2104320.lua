-- Lua provided by SkyAPI 
-- Game: ToS Gamepad Tester
addappid(2104320)
addappid(2104321, 1, "a45daa4a63ecee090be401ebe88907553b5a901debd1706fa433a49568f03daf")
addappid(2104330)
