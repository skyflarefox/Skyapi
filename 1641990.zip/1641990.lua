-- Lua provided by SkyAPI 
-- Game: Warhammer Combat Cards
addappid(1641990)
addappid(1641991, 1, "a70812a5b36360e256f50ba617de81413a42e108705412c4b606658745a5e9db")
