-- Lua provided by SkyAPI 
-- Game: SEX Apocalypse 3D
addappid(2155600)
addappid(2155601, 1, "4674bfcfd0a368868bdfb3a42bf62595c490b4d119df5f8fbb2389a90e59236a")
