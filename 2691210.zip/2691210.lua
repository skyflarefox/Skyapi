-- Lua provided by SkyAPI 
-- Game: Idle Life - An Idle Game
addappid(2691210)
addappid(2691211, 1, "9ca519abd1ac5f04e1e8ea6b0feba65bc90048f098d5bc436fd353d14e278d59")
