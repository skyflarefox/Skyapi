-- Lua provided by SkyAPI 
-- Game: Force of Nature
addappid(568570)
addappid(568571, 1, "bb3c543016ff599b4bbeebaa163d5b41976b898951c3ff5672eecb4705cdf00c")
