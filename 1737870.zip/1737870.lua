-- Lua provided by SkyAPI 
-- Game: REKA
addappid(1737870)
addappid(1737871, 1, "288b0a2a0e74dc9fa05b6bc7ff0cb545073f5cef5c2039549a4373491652e742")
