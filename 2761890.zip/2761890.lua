-- Lua provided by SkyAPI 
-- Game: AppID 2761890
addappid(2761890)
addappid(2761891, 1, "60df43351f67caea4a0c7f6b7d4b2dafa9d9ac81a04e1202364aac69a93aa7f9")
