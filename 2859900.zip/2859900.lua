-- Lua provided by SkyAPI 
-- Game: AppID 2859900
addappid(2859900)
addappid(2859901, 1, "7043ea023cdff81f51f35447a922dd26be322c6be6c2704122815d271284cba5")
