-- Lua provided by SkyAPI 
-- Game: Suna
addappid(803920)
addappid(803921, 1, "32f416f17cfaff7b5452c550e2c49d1955d8e9860a139bff6eae2938c1adf84a")
