-- Lua provided by SkyAPI 
-- Game: Road Food Simulator
addappid(3207670)
addappid(3207671, 1, "2d0e5a8969b201ba636cc318891c091f3590e610318b5df540c2be4d5e4a66ff")
