-- Lua provided by SkyAPI 
-- Game: AppID 505550
addappid(505550)
addappid(505551, 1, "c99c0fd4540271320528de4344cca31ab5ef58c433f8f7481223e0c28eaa9a00")
