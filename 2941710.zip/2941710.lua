-- Lua provided by SkyAPI 
-- Game: Project Silverfish
addappid(2941710)
addappid(2941711, 1, "58f3fb42e32fc7f54e16d87c3952b2a1c537e0be679fd35a1d16acc5e4d870d4")
