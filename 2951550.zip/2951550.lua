-- Lua provided by SkyAPI 
-- Game: AppID 2951550
addappid(2951550)
addappid(2951551, 1, "e9ba357813edd0e8e0fc465162ea4edcc9d9de575c1c109a7173618edfd5c3b4")
