-- Lua provided by SkyAPI 
-- Game: Live Cycling Manager 2023
addappid(2492420)
addappid(2492421, 1, "cd07aec68be4c9197ff4aff84dea75f3fed83da64a20d9025bdcf83534db6124")
