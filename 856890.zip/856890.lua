-- Lua provided by SkyAPI 
-- Game: JUSTICE SUCKS: Tactical Vacuum Action
addappid(856890)
addappid(856891, 1, "255a38e3e742499a0e973be0b6cbde54cf7340ff6669fdc0112d3c0d1ae033e7")
