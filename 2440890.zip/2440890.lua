-- Lua provided by SkyAPI 
-- Game: Nobody Nowhere
addappid(2440890)
addappid(2440891, 1, "57014a8c9e570e3251a1614e3bbd9dc7433a932543998b829f80ea7e64fc46dd")
