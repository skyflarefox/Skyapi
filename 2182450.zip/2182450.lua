-- Lua provided by SkyAPI 
-- Game: Fairy Girl
addappid(2182450)
addappid(2182451, 1, "bf75f839ac5f112e0eb63b6f2187ed86e2e8ddd4a73fb6e4cdbd0d6e49e0e5a7")
addappid(2191940)
