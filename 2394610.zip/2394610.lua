-- Lua provided by SkyAPI 
-- Game: Destroy All Zombies
addappid(2394610)
addappid(2394611, 1, "84215eb3a77c299dc18bd0373d778d7e01cada37c72fd75ee0588edaf61830f4")
