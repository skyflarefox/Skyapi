-- Lua provided by SkyAPI 
-- Game: AppID 1264280
addappid(1264280)
addappid(1264281, 1, "c6f30f391d892cff62283e848ea9368dad8ebb8658ffb599246c61311023df03")
