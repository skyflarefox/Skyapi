-- Lua provided by SkyAPI 
-- Game: Lights Out
addappid(948080)
addappid(948081, 1, "223e6af7a019f91919e97e7da599370c575f7ef6d519ef24e79073f6c43db836")
