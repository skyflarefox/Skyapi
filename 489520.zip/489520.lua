-- Lua provided by SkyAPI 
-- Game: AppID 489520
addappid(489520)
addappid(489521, 1, "45a166379b24baf7777bc77d32ad618dbb49857a55199085a38bd2a0c5beee72")
addappid(489522, 1, "7225f5252b1a5ad86620873e7d4b862fcbafc56bbe826dd52be1b3b34c279f6c")
addappid(489523, 1, "d5321a86e91d11c18618b16ed442a2d53d2baecb3780fc25e2f7aa02da8723a7")
