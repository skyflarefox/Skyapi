-- Lua provided by SkyAPI 
-- Game: Porcelain Panic
addappid(790050)
addappid(790051, 1, "8c0230f6eb3cef30ee0ea15e06df9c07cf3b7494f355175ee5bb2d7a40664f9e")
