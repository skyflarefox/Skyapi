-- Lua provided by SkyAPI 
-- Game: Vestiges: Fallen Tribes
addappid(2511780)
addappid(2511781, 1, "0790dbd3cf777b75548120aa0674f4afe4ac4d79cca556edfa0f332d7b6430ff")
