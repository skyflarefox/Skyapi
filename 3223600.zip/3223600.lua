-- Lua provided by SkyAPI 
-- Game: CROWDED. FOLLOWED. Demo
addappid(3223600)
addappid(3223601, 1, "ca93edff4861a5f241841b4cafb7b063e19af23255730eea3c7ba1b6e6c66aab")
