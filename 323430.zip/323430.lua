-- Lua provided by SkyAPI 
-- Game: AppID 323430
addappid(323430)
addappid(323431, 1, "8eb01bae5391b2ec0d3f7e6d7bdfb3d0c88c682b7170a70d76ccb6376d6619e3")
addappid(323432, 1, "598a6ada4c9c9a15bbb6d1d01f24a774317777cb007fabdedb08cbad994c3554")
