-- Lua provided by SkyAPI 
-- Game: Heart Of Altai
addappid(1723770)
addappid(1723771, 1, "c09f5c66447ae32c7c6f21443b3fae28e6d5dde75cb609616c20421c409accc4")
