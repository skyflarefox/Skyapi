-- Lua provided by SkyAPI 
-- Game: Hell's Gate - Slide Puzzle
addappid(1561880)
addappid(1561881, 1, "ba2c5e7931737cd97cfab31a3dc52830838461a7d3e85b57957128ab25659352")
