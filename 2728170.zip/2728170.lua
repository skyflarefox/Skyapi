-- Lua provided by SkyAPI 
-- Game: AppID 2728170
addappid(2728170)
addappid(2728171, 1, "62bbc10dd83d0a14835d36824e4372655a7f90d2dd60aec409d743dbcf3ce00f")
