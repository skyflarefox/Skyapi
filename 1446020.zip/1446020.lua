-- Lua provided by SkyAPI 
-- Game: MADNESS: Project Nexus Demo
addappid(1446020)
addappid(1446021, 1, "a3537024a8bcc1bf0b7269533df6bc2b2b0a793c405337a2ba0a8e002765f242")
