-- Lua provided by SkyAPI 
-- Game: SugarWinds: Prologue
addappid(1549070)
addappid(1549071, 1, "dbdd85ef72eb7970d127b9aa8bbab90209ac7cbf0419f86e6f3379dbf53bcb56")
