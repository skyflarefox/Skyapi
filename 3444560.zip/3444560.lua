-- Lua provided by SkyAPI 
-- Game: AppID 3444560
addappid(3444560)
addappid(3444561, 1, "fe6cd1c6962e960b52e272c1b490250a1fc2ad9ede6fd6c3e9f7cdce67e4da69")
