-- Lua provided by SkyAPI 
-- Game: AppID 799070
addappid(799070)
addappid(799071, 1, "80277edc6cd9398594f05b5e2a931af10cb032000cf074d71634ee37b10b792f")
