-- Lua provided by SkyAPI 
-- Game: Parallel Experiment
addappid(2012320)
addappid(2012321, 1, "bcdcac45ea040db57ec42574707273f04ec7f21be80e16b4b0ad0e920c34a3b2")
