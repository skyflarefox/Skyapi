-- Lua provided by SkyAPI 
-- Game: Heart-Lung Machine
addappid(3103480)
addappid(3103481, 1, "dd3f6cc9c5288a2b3edcc3628192258ad00f6deb2ea92f5431a294e128eafa96")
