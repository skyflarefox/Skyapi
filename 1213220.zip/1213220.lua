-- Lua provided by SkyAPI 
-- Game: IRON GUARD
addappid(1213220)
addappid(1213221, 1, "2037ca432bcc4413a18cb67c6159de3c9f4512102ca8005a50adb2c74843b365")
