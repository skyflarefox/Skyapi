-- Lua provided by SkyAPI 
-- Game: Raw Metal Demo
addappid(2283830)
addappid(2283831, 1, "9b29d8eae23d8bd3502cda80e6d3770cf12e9c8970596d14c0d29bca64e32c7d")
