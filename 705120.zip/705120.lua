-- Lua provided by SkyAPI 
-- Game: AppID 705120
addappid(705120)
addappid(705121, 1, "f3aa5d5fe76260d17644a872021bcd3fefe371c5799d91bc69a5477f7fff623c")
