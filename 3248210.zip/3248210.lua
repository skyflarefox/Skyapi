-- Lua provided by SkyAPI 
-- Game: Cemetery Warrior 6
addappid(3248210)
addappid(3248211, 1, "b15bec71ba1851badb63dbfb3b30b12d548ed4a0181350cf8d63508f6b77fe9f")
