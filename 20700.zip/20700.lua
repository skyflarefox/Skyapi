-- Lua provided by SkyAPI 
-- Game: Starscape
addappid(20700)
addappid(20701, 1, "4ffa06d0bab24edf9ad01167e3f97c097f41700e3181d2ced4e02e6b55c098a1")
