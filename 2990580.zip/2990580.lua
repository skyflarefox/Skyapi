-- Lua provided by SkyAPI 
-- Game: AppID 2990580
addappid(2990580)
addappid(2990581, 1, "323a28714c6214a4c73b2e6094e18fc0db017239c3f1aad194b81cae55597dca")
