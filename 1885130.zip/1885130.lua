-- Lua provided by SkyAPI 
-- Game: AppID 1885130
addappid(1885130)
addappid(1885131, 1, "60fbe90bda1d3c40aa3f40713650fb06dbca1edfc2d7299cc558b15444194ba7")
