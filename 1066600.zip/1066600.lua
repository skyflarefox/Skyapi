-- Lua provided by SkyAPI 
-- Game: AppID 1066600
addappid(1066600)
addappid(1066601, 1, "4518212a3da5da252568af6833a461f387f7cda5d3188080634139563e49aec2")
