-- Lua provided by SkyAPI 
-- Game: Dragon Blast
addappid(2137770)
addappid(2137771, 1, "3c34cb682940753687163a684327ac096b3896bc81633e04a868692af6dd69b1")
addappid(2141590, 0, "8e21263b89131a2dc32c452ad0c2fb726fd9e18b0476553671f32e7fb0ee0ffd")
