-- Lua provided by SkyAPI 
-- Game: Nimbusfall
addappid(2924040)
addappid(2924041, 1, "7cdada10f1fccf92b420c8a045260c86a385b3a5c802646f72dd1de09df0ad4c")
