-- Lua provided by SkyAPI 
-- Game: Ticker
addappid(3183840)
addappid(3183841, 1, "d7b503985500980b9312a438b204de9574c6ee2d276194a1b15951c99a0ed101")
