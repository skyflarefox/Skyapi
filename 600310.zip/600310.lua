-- Lua provided by SkyAPI 
-- Game: Rogue'n Roll
addappid(600310)
addappid(600311, 1, "1c51b4058f745b35fd353dc558897088604ed19a38f69cf9b4697505eb717460")
