-- Lua provided by SkyAPI 
-- Game: AppID 529100
addappid(529100)
addappid(529101, 1, "dd2254b407b41f9c0a66f3b9932993de53681e12bcb246f0370f7327c597f31f")
