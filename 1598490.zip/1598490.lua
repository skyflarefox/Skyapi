-- Lua provided by SkyAPI 
-- Game: EyeRoll
addappid(1598490)
addappid(1598491, 1, "23a875968611967284116b29fef8442f7006ae52dc2caf3c8cf812a51fd4513f")
