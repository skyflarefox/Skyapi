-- Lua provided by SkyAPI 
-- Game: AppID 1028840
addappid(1028840)
addappid(1028841, 1, "c8e1656f5b5b1d38efb4abcec1caa37331cb00fc78bfac95e726444df7ab2813")
