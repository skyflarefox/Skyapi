-- Lua provided by SkyAPI 
-- Game: Endless Furry Killer Infinity
addappid(1597170)
addappid(1597171, 1, "181f9624a549da480ab4b2c4baa0ddd03a24c7d31ce80e934cd7531a253c1a07")
