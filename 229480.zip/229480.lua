-- Lua provided by SkyAPI 
-- Game: Dungeons & Dragons: Chronicles of Mystara
addappid(229480)
addappid(229481, 1, "70fdd0e29f3065e4da04ee358197903c1dde835c271fb99355d91460122a54e0")
