-- Lua provided by SkyAPI 
-- Game: The Case of the Serialized Killer
addappid(2451730)
addappid(2451731, 1, "685c21ca8dc701d2588811dd5f6b1b9eaffb9715e2d3f58a68357bbb56f84a45")
addappid(2697660)
