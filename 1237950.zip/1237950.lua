-- 1237950's Lua and Manifest Created by Morrenus
-- STAR WARS™ Battlefront™ II
-- Created: September 30, 2025 at 19:34:21 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 16
-- Total DLCs: 2
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1237950) -- STAR WARS™ Battlefront™ II
-- MAIN APP DEPOTS
addappid(1237951, 1, "32aebb4721998dff07fa694f35e621ebcd86e835d845fb86b80bd21850623d89") -- Telstar - SWB2 Content
--setManifestid(1237951, "1092172661111760910", 96931654447)
addappid(1237952, 1, "a429a63ae566d27c07a931f0e77f512a52e2736ab8c5fac0a5373c708cdbe89d") -- STAR WARS Battlefront II - en_US
--setManifestid(1237952, "6816938749349294005", 106998)
addappid(1237953, 1, "e451de4b67b508629d06f1596e18755997bf784772e02aadf1884c8c503bd9c3") -- STAR WARS Battlefront II - fr_FR
--setManifestid(1237953, "8158434786442585297", 119344)
addappid(1237954, 1, "2e5f36106d4b30d7139296d253463571f90732215b24f9c4d84b8ff878f26477") -- STAR WARS Battlefront II - de_DE
--setManifestid(1237954, "3222395978558611342", 108152)
addappid(1237955, 1, "ac6eff781588c21a6c366ffe25b9985e1268dbc3d115afc396db9c05b7542918") -- STAR WARS Battlefront II - es_ES
--setManifestid(1237955, "7175788750451163551", 126259)
addappid(1237956, 1, "e3724edc3633aa6c0b03702ac29831957174b8bf57d8a8efbc9f71f3de107a4d") -- STAR WARS Battlefront II - it_IT
--setManifestid(1237956, "79758105325256702", 113684)
addappid(1237957, 1, "754f92570fab59e2b66df6758518d5365fc55868fe3720b3ec2708f450233264") -- STAR WARS Battlefront II - ru_RU
--setManifestid(1237957, "2834675556270217944", 185077)
addappid(1237958, 1, "ef3e61260f6029625c930f35338e71d16751019193906d35d4cc35617b8768f0") -- STAR WARS Battlefront II - pl_PL
--setManifestid(1237958, "4123698815381533805", 117103)
addappid(1237959, 1, "9cd377f3731ba722053d7a59947a2d753785d9246de419c65534fc43a7435bb3") -- STAR WARS Battlefront II - ja_JP
--setManifestid(1237959, "1918546214929540544", 202592)
addappid(1237961, 1, "4723a18a7aafdeb24b7f8b83f31d66bae5ca0275d7fe0418e80a5c75ade9d3b6") -- STAR WARS Battlefront II - zh_TW
--setManifestid(1237961, "864458850781568145", 165958)
addappid(1237962, 1, "f273b73bdddcca0b5aa6d07fc7118abae337108cfcb9e01d7ae2ef90cef594dd") -- STAR WARS Battlefront II - pt_BR
--setManifestid(1237962, "5825045303255250937", 111553)
addappid(1237963, 1, "393e39fefa56881c5e37ce151550e525ade5f554a454072112b7f3f8d56827e7") -- STAR WARS Battlefront II - es_MX
--setManifestid(1237963, "5111962543797924959", 121748)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
--setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
--setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
--setManifestid(3340991, "4079816251012753833", 235656703)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1237960) -- STAR WARS Battlefront II Celebration Edition Upgrade
addappid(1253170) -- STAR WARS Battlefront II Celebration Edition - Key
addtoken(1253170, "18249887771865952330")