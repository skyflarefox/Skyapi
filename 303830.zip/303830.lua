-- Lua provided by SkyAPI 
-- Game: Motorcycle Club
addappid(303830)
addappid(303831, 1, "3734888bd63064db04b8ff5317741ff38d447eb4e9142418b33235d4caab6134")
