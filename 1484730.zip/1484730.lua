-- Lua provided by SkyAPI 
-- Game: Papa's Quiz
addappid(1484730)
addappid(1484731, 1, "e88f30a8c32e011fb60c80ce0a7aab8ef82b68dc5a1f18b6b64bd278b710ed01")
