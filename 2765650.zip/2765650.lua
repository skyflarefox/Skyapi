-- Lua provided by SkyAPI 
-- Game: Deconstruction Simulator Demo
addappid(2765650)
addappid(2765651, 1, "ec6b2b94f45928dc4c8a74a9407b346c3b15f7751adaed7fc55066d9b5953a43")
