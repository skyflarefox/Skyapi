-- Lua provided by SkyAPI 
-- Game: Chicory: A Colorful Tale
addappid(1123450)
addappid(1123451, 1, "b4cd0ce8c522800cd37e1ce4a2f47d6f570fd1ed3df8dd1bf10cef18724104fa")
addappid(2446380, 0, "b2ec39abef34edb0378b8e336fb50e9b942e92070128b508af9b3e0b017f7759")
