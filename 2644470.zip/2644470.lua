-- Lua provided by SkyAPI 
-- Game: PICO PARK 2
addappid(2644470)
addappid(2644471, 1, "742488856b65c1f5c8c1d8c3d8b64f0f47fe89887d5308427c354d9ef5902e51")
