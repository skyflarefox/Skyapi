-- Lua provided by SkyAPI 
-- Game: AppID 1501570
addappid(1501570)
addappid(1501571, 1, "efb8b16846f5bcdab5938956444be8abb53603de2d622d0263627a5bc3dcbbbe")
