-- Lua provided by SkyAPI 
-- Game: AppID 1187330
addappid(1187330)
addappid(1187331, 1, "50a2ae885bf5123dd08b5929a0e6b59eb51abbd14181ca77183c1621e55e68f5")
