-- Lua provided by SkyAPI 
-- Game: PowerWash Simulator – Single
addappid(2182380)
addappid(2182381, 1, "712e31b12758bdb1248e3b0281f602b46d11fb7c5f8fd91efee87f03efcfad6b")
