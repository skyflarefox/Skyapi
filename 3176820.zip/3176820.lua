-- Lua provided by SkyAPI 
-- Game: Drift On Snow
addappid(3176820)
addappid(3176821, 1, "f4b5ac931c733ead52d24a68b0ca666420a47ee4331daca6a757c76fa6f1cc97")
