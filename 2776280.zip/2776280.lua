-- Lua provided by SkyAPI 
-- Game: Goblin
addappid(2776280)
addappid(2776281, 1, "4431671061681d9723cdba955be5f151397e287cfa374d1e036e2441042c2b52")
