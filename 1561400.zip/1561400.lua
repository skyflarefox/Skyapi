-- Lua provided by SkyAPI 
-- Game: Sylphine
addappid(1561400)
addappid(1561401, 1, "938bc2ffe03782c4ae9250667c138d73313fb71dc3ef50d82be9876dc6b013e6")
