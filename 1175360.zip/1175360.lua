-- Lua provided by SkyAPI 
-- Game: AppID 1175360
addappid(1175360)
addappid(1175361, 1, "474762a0b0e44e77480374cdb172c736b3b987742cdf39a80149dc65ad9b6696")
addappid(2685580)
