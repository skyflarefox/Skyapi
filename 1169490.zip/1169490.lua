-- Lua provided by SkyAPI 
-- Game: Interactive Horror Stories
addappid(1169490)
addappid(1169491, 1, "252d1880f1b424876a597c82a94adaa2176b087188c23e71a4d3e1d4f2f0d0c4")
