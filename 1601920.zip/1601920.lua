-- Lua provided by SkyAPI 
-- Game: Sparkball - Season Zero
addappid(1601920)
addappid(1601921, 1, "1156b5d507e85adacbccca78158e27a3fa32f34ef6a8b11c431dc18b9cf10739")
