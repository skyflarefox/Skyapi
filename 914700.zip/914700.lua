-- Lua provided by SkyAPI 
-- Game: AppID 914700
addappid(914700)
addappid(914701, 1, "382f490b9ef30253b64ce8e32515cd24e1ce5f48c856517ab8911c9533c5e645")
addappid(914702, 1, "d006e5ac2a0503a5dbf697b4646e15214e57df88eeb4ef62aa3fb4abd5d17d6c")
