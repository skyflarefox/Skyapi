-- Lua provided by SkyAPI 
-- Game: AppID 1142510
addappid(1142510)
addappid(1142511, 1, "25b3ab5d431eea92e6d6a0bde96b7f0e2480a825acdd59211ab41cf6718ab6e3")
