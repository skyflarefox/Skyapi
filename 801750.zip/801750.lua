-- Lua provided by SkyAPI 
-- Game: Hot Shot Burn
addappid(801750)
addappid(801751, 1, "f6a537275c0d1cfa06641e729d64aa0c6a0e0b61ddd02c8f9e5571572ad54fe5")
