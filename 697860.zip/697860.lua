-- Lua provided by SkyAPI 
-- Game: Cathodemer
addappid(697860)
addappid(697861, 1, "8d59f362fd940d9a10dedaac97dc60854eb0aeb3480e0b420e8859c215e0817c")
