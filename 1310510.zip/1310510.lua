-- Lua provided by SkyAPI 
-- Game: Handy Harry's Haunted House Services
addappid(1310510)
addappid(1310511, 1, "5581391d9cfffd8fde190d85a1eebdb93889beccd1d97cbc256b37f6e0d85131")
