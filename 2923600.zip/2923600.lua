-- Lua provided by SkyAPI 
-- Game: AppID 2923600
addappid(2923600)
addappid(2923601, 1, "a842e209150f81f3050a29177befb6947d4d80fdc2ec39d631f8ad679ff05f04")
