-- Lua provided by SkyAPI 
-- Game: AppID 977690
addappid(977690)
addappid(977691, 1, "39bfd11f3475c7b57f7f58075ef78a8e2a596054604b24c2b5f369ba309a4f4c")
