-- Lua provided by SkyAPI 
-- Game: AppID 941040
addappid(941040)
addappid(941041, 1, "12b4d01f8f6e0c74c4f40353722ee1c7b69fb34a47b1489451e36117ba90fe00")
