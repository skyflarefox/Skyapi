-- Lua provided by SkyAPI 
-- Game: Backfirewall_
addappid(1920100)
addappid(1920101, 1, "0f725f21cd8403396b1078567c7ab310c00a412c2283475bc4481d6725d6f963")
