-- Lua provided by SkyAPI 
-- Game: Parfait Remake
addappid(2947220)
addappid(2947221, 1, "5376cc46e644da99000eeb3b8daec374deb6a7fac2a9a8d74be14f05bc4a98b9")
