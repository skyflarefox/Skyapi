-- Lua provided by SkyAPI 
-- Game: Art of Stunt
addappid(1913610)
addappid(1913611, 1, "21560a0bb7ad7f0b73089cc6910945160d9fb199ff7a978418213956d53d3ae1")
