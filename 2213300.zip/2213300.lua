-- Lua provided by SkyAPI 
-- Game: Might & Magic: Clash of Heroes - Definitive Edition
addappid(2213300)
addappid(2213301, 1, "8c4e3ece3a273a60d9f657e2426ab58c6fb8ad0fa69949a61608a36cef4f563c")
