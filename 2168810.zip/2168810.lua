-- Lua provided by SkyAPI 
-- Game: Dream Sketcher
addappid(2168810)
addappid(2168811, 1, "fa364ba5010de07fa24ffef1634e6dab22c3b091deafd9c8ba35852800894d80")
