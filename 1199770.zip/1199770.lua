-- Lua provided by SkyAPI 
-- Game: AppID 1199770
addappid(1199770)
addappid(1199771, 1, "d3a5d5f17c5cb651a388c31a4f57df5f1e181ecd276488a083e5ae845c22ccd1")
addappid(1199772, 1, "2111172d058e2b5dae4ee5975d9704a85e16cf153a7608b0ea0aa7888720b71c")
