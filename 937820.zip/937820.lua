-- Lua provided by SkyAPI 
-- Game: Shadow Play
addappid(937820)
addappid(937821, 1, "60dbf24ff93e950ae1f7dcf0b8f596327baf6df5c3f7321cef985d451c598213")
