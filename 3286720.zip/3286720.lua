-- Lua provided by SkyAPI 
-- Game: AppID 3286720
addappid(3286720)
addappid(3286721, 1, "1af3de0d01a0c2b7b0348c44159f4cc742640a989969f3ef0141a9faf533cc9f")
