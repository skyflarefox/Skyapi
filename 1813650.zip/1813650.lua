-- Lua provided by SkyAPI 
-- Game: AppID 1813650
addappid(1813650)
addappid(1813651, 1, "d2c33a5ec3060e3db2a3d66db96574ae147e1173752f5d32efa81d4eadea7e09")
