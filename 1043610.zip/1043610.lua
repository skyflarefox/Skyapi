-- Lua provided by SkyAPI 
-- Game: Cold Cable: Lifeshift
addappid(1043610)
addappid(1043611, 1, "1aecc18563a33ed8395aa0715fc00e7994c7d76b73004c4cf8858bd0c2e3910f")
