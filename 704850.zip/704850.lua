-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(704850)
addappid(704851,0,"c6eb71b65618938bcf35d976cdd952c08d6fc53d1617ec8a408d9e8aedf5fb6f")
setManifestid(704851,"5905302388927689467")
addappid(704852,0,"7fdb57788d74395af527b98fb77483e1f82f93204f6dcd1d4ae5a424c4aa006b")
setManifestid(704852,"6408742455698385061")
addappid(1840650,0,"0c60b1aec120a0a8e452e02c449781b389f1fa7fa872611e338ad9a952c7bf1b")
setManifestid(1840650,"6887987143828794476")
addappid(2518241)