-- Lua provided by SkyAPI 
-- Game: cat and rat
addappid(2214950)
addappid(2214951, 1, "34356574f9517715c0c8848a3b4fd49cb6c8169002554f8fedff1b11761b1460")
