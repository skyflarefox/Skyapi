-- Lua provided by SkyAPI 
-- Game: AppID 2385060
addappid(2385060)
addappid(2385061, 1, "fd870ffc08286a7a6b64b109d48f3769b0e2e86746f899e6a34493e07a552c7c")
