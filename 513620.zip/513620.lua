-- Lua provided by SkyAPI 
-- Game: SkyTime
addappid(513620)
addappid(513621, 1, "b6a5396639cf91e387bf611d73166d4ecfa5d9e1844856e0b75f12a0b99b627f")
addappid(513622, 1, "d0a780cd681bbc0b8c2d72ebd7d657147e48e4ea73f2eb5d1157be7b81c6c636")
addappid(513623, 1, "0b5eb7e7a874732f269f6d4a6616aeab8aa9469b5b696bce950f857120e91347")
