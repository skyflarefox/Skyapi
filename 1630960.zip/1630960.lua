-- Lua provided by SkyAPI 
-- Game: AppID 1630960
addappid(1630960)
addappid(1630961, 1, "a83745bbd4f1c3c90e05b3f5c601fe796ed6c8ea860037da51f84bd11dacd425")
