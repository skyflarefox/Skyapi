-- Lua provided by SkyAPI 
-- Game: MEANDERS
addappid(734920)
addappid(734921, 1, "df3d778a1d86c7d6e58177dab5b66afe3a7b1906707ac5a18b80516b79f482c2")
