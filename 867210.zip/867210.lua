-- Lua provided by SkyAPI 
-- Game: Songs of Conquest
addappid(867210)
addappid(867211, 1, "ea2be0c817a8f6f2e694b3318c5560c41ff4eb9d1a16f9ce3490dc2bf58fe78c")
addappid(867212, 1, "3546a5c46d083b5474f272b188d063e43fcf017ad720f78d3d8d655f4e5190f8")
addappid(2977420, 0, "80e2ebc61dc25516ad93ec795c8526386047c766e10b9f6b5b3a3c96d810173d")
