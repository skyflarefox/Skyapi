-- Lua provided by SkyAPI 
-- Game: AppID 770740
addappid(770740)
addappid(770741, 1, "ae0149fe592ce603353592e2f88b34f1473fcfa97e93f59b1ff6c4013080e326")
