-- Lua provided by SkyAPI 
-- Game: The Cloud Bazaar Demo
addappid(2231470)
addappid(2231471, 1, "5750663528e915c605c846419d0a3a89216be9d2162da3874e9a3fd657aaed22")
