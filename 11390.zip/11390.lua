-- Lua provided by SkyAPI 
-- Game: Crash Time 2
addappid(11390)
addappid(11391, 1, "e4f90b74aff1982203eee7b2bcfb28c2cadb85c96665bf698e8ce355501e0534")
