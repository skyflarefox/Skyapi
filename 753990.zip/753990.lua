-- Lua provided by SkyAPI 
-- Game: Psi Project: Legacy
addappid(753990)
addappid(753991, 1, "96da9d82badee579105681e4f962951009c6889443fdca7148f05c8f62056782")
