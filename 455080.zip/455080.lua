-- Lua provided by SkyAPI 
-- Game: AppID 455080
addappid(455080)
addappid(455081, 1, "1dfa622de9694fb9acbdf96c21d2755be6b2b9533c6f2b64c929aea07c1913da")
