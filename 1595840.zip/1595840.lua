-- Lua provided by SkyAPI 
-- Game: Phoenotopia Awakening Soundtrack
addappid(1595840)
addappid(1595841, 1, "38111977402a6d1d8c77ce8f5ba03b068002158af7dc5854a015933c6d584231")
