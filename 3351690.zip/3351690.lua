-- Lua provided by SkyAPI 
-- Game: Gauntlet
addappid(3351690)
addappid(3351691, 1, "1f9d6ef3a7aeb70f405858b0647198f5cc6da3334e6ab371fed877c604d476a2")
