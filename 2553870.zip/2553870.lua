-- Lua provided by SkyAPI 
-- Game: The Genesis Order
addappid(2553870)
addappid(2553871, 1, "7eb6f1e8beddbfaeb434476e4d1d7c2a53c9c3b799888085d89703ee3e4ec36a")
