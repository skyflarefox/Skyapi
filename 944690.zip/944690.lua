-- Lua provided by SkyAPI 
-- Game: AppID 944690
addappid(944690)
addappid(944691, 1, "faef91ad6ff532b2fbc2dcf787039cbc6249d6cd77789f121637167a2e92f20f")
