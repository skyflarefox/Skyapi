-- Lua provided by SkyAPI 
-- Game: Cardpocalypse
addappid(904400)
addappid(904401, 1, "f094d59256bb78bac5150846d64a173bd5456982f174aef6157f026a18d810f7")
addappid(1388730, 0, "42e54768f323257137371b8e2fa299730fc9eda0912a96c0cada5cc89d35d3b7")
