-- Lua provided by SkyAPI 
-- Game: AppID 516920
addappid(516920)
addappid(516921, 1, "f8829d61512e5f8b5601fe4f043ccfecff1050c5dec1b0c42fb9eef677b0f54f")
