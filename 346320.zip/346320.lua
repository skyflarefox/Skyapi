-- Lua provided by SkyAPI 
-- Game: Streets of Chaos
addappid(346320)
addappid(346321, 1, "15f54514fb2319911268ff16cdff56d932176a79328583257c75d1c09f1f215e")
addappid(358620)
