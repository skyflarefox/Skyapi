-- Lua provided by SkyAPI 
-- Game: Mugen RPG
addappid(2344570)
addappid(2344571, 1, "0c7f5616b26620eb3c7f102b5af03947a450445ae8c1968b683a3597ef5f8ead")
