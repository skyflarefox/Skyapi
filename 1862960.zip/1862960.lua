-- Lua provided by SkyAPI 
-- Game: Vestige
addappid(1862960)
addappid(1862961, 1, "e1e1245aed152a8f55f125823857d4070f991b8a87e886bcedbdb7c8fb87c1f9")
