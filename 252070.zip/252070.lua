-- Lua provided by SkyAPI 
-- Game: Gimbal
addappid(252070)
addappid(252071, 1, "c73ed0d201fe1cb1e46a3ff007cf99b88f907cdaa5dd5ba88227bb64ff9c4015")
