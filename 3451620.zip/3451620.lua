-- Lua provided by SkyAPI 
-- Game: The Jester
addappid(3451620)
addappid(3451621, 1, "eef967517236832ccf389acf25f3ed64e6f5813c82393cb81baa9188a870e476")
