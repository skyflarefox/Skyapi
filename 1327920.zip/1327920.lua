-- Lua provided by SkyAPI 
-- Game: Maestro VR
addappid(1327920)
addappid(1327921, 1, "086b334bba243a70ef3f0b65861ec255c693f3e6be33df47496a90d02c09c843")
addappid(3293890)
