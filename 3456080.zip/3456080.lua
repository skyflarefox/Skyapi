-- Lua provided by SkyAPI 
-- Game: Weirdo Soundtrack
addappid(3456080)
addappid(3456081, 1, "44832af1e87e0fd6227ceace26b5a01a681bb509505acb84e4d4467701a49e94")
