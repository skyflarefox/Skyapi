-- Lua provided by SkyAPI 
-- Game: Cultivation Realm: Card Survival
addappid(2921670)
addappid(2921671, 1, "920df379b5be334e3596ca4c7eef466e5db09832bc19456fea651c7643573b6f")
