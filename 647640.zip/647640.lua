-- Lua provided by SkyAPI 
-- Game: AppID 647640
addappid(647640)
addappid(647641, 1, "fae0ab8fafc1862fc438ea781930f918edc951df3cd9cfaa9c3a9266cdb2949f")
addappid(673490)
