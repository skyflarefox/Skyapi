-- Lua provided by SkyAPI 
-- Game: //signal.
addappid(3632010)
addappid(3632011, 1, "0b3b7fb62d02bbaec8e43cd516c05b77ae7a7e97e6b520bc91dc93ed753456bb")
