-- Lua provided by SkyAPI 
-- Game: AppID 3135560
addappid(3135560)
addappid(3135561, 1, "63e13174184bc9fcdc7b70c5b206b792a180c0426569096716d866fa2f9d3476")
