-- Lua provided by SkyAPI 
-- Game: 芙兰杂感记录 Demo
addappid(3160350)
addappid(3160351, 1, "6bd6233fef82372605bbf1acf1f46d5573a9dc293cb17a463c04459bdf3a9e52")
