-- Lua provided by SkyAPI 
-- Game: Wrestlers Without Boundaries
addappid(860580)
addappid(860581, 1, "5634d2c8f369b83876e593a0ff4266c457e180a0e92135a0feea2286ee184169")
