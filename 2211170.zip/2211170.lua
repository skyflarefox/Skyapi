-- Lua provided by SkyAPI 
-- Game: Unrailed 2: Back on Track
addappid(2211170)
addappid(2211171, 1, "924f04bf42410b224830a5cbe6e5fe8ed52b2cac3a5fc909505918bbbc2670c7")
addappid(3393870, 0, "677987212f50458d0f106db2ca80b57787838ed4128669ed85322d2923aa79b0")
