-- Lua provided by SkyAPI 
-- Game: Banana Yetti
addappid(2260560)
addappid(2260561, 1, "4ebffb0bb947af53f6574ce633a3230e57bf86426a126239f48db6667f56cfef")
