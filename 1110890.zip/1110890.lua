-- Lua provided by SkyAPI 
-- Game: MY WOLF - Desktop Wild Pet
addappid(1110890)
addappid(1110891, 1, "f0ecaeb9aae21d6480063b03ef1dbce39a4a1227670e91eb81174a53846c81b6")
