-- Lua provided by SkyAPI 
-- Game: 101 Cats in Venice
addappid(3735890)
addappid(3735891, 1, "a88e1d45ac98fa05a8b7dc2eda68156fdde1f9dd4d99377b9001306264fdb6f5")
