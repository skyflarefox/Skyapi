-- Lua provided by SkyAPI 
-- Game: RADical ROACH Remastered
addappid(301750)
addappid(301751, 1, "7131b5e740275ec488d9d3e0ad17e0dbd6cef6c7a47944d2cd0fc3a366a22d6a")
addappid(739620)
