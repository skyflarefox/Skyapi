-- Lua provided by SkyAPI 
-- Game: Hyper color ball
addappid(515470)
addappid(515471, 1, "c5f44eceb99e963b0dd918ca1a7eb124f89b0f55bb1984107a90f0a52cd4f52d")
