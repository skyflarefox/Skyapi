-- Lua provided by SkyAPI 
-- Game: Only Trump: Up To Presidents!
addappid(3108000)
addappid(3108001, 1, "e47efff0f15dfb3abd1424ea44b291672bbb059cdc8007e2597f597834f91dbd")
