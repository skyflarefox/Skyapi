-- Lua provided by SkyAPI 
-- Game: AppID 1702550
addappid(1702550)
addappid(1702551, 1, "8574c52b4a99f164e3dc863d8604ced078b27f99e2bb287b772dc7e999967826")
