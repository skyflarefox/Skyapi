-- Lua provided by SkyAPI 
-- Game: AppID 1052540
addappid(1052540)
addappid(1052541, 1, "57c5ebb5c741a74c93248b5779365d66e444086e66a7f7033708b8aac15e7552")
