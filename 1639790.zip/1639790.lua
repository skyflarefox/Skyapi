-- Lua provided by SkyAPI 
-- Game: Northern Journey
addappid(1639790)
addappid(1639791, 1, "97ed18f6885cfdb936911b4c194d6db7cdb2b4c1db61008f4c1f97cfff1798ee")
