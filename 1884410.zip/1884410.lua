-- Lua provided by SkyAPI 
-- Game: 灭顶之灾（crowning calamity)
addappid(1884410)
addappid(1884411, 1, "14ef17bb39d9e21acdfeaf580b96fdde147072f1d51d712f91940c5313281e24")
