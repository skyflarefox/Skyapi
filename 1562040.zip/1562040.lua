-- Lua provided by SkyAPI 
-- Game: LuvSic
addappid(1562040)
addappid(1562041, 1, "20279dfc9d0677c6e56551e89f29fd41544311b4b1c317b134d6477bdfa89304")
addappid(1630480)
