-- Lua provided by SkyAPI 
-- Game: Deathly Dangerous
addappid(2318550)
addappid(2318551, 1, "b557fe7c3d2f305c1ea6513ed1b3b8d833083a64e155e1d2157cd1a0531764cc")
