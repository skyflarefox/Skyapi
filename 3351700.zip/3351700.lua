-- Lua provided by SkyAPI 
-- Game: AppID 3351700
addappid(3351700)
addappid(3351701, 1, "4d103072af215b3899eefc8c55fcce6a0a4903f96a2ebe0ece9e8d09f91c2eb3")
