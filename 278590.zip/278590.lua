-- Lua provided by SkyAPI 
-- Game: AppID 278590
addappid(278590)
addappid(278591, 1, "c20c19a69ec2de82d9d670815ec25699a91aa72b337d187d5641dc56cffde414")
addappid(445710)
addappid(680160)
