-- Lua provided by SkyAPI 
-- Game: AppID 1123340
addappid(1123340)
addappid(1123341, 1, "a67749fdda15a0d4e7bad6d0e3b62edc6037bce3d0e9349a46fd4863b42dad37")
