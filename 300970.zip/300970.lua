-- Lua provided by SkyAPI 
-- Game: Fiesta Online NA
addappid(300970)
addappid(300971, 1, "c74bec115e81735a516fa3d899ce13e84ebddffa773927e41578590dbd35a6aa")
