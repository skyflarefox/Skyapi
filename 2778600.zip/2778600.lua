-- Lua provided by SkyAPI 
-- Game: FLASH OF THE BLADE X
addappid(2778600)
addappid(2778601, 1, "25da56a5384b3d0e9895ab0f437ed0a3fefddde8b4f313c28be76d61bdadbc6b")
