-- Lua provided by SkyAPI 
-- Game: AppID 790250
addappid(790250)
addappid(790251, 1, "f6a3513c763c96602890cbf68ada28b6aa9e670162b5eafd6fd90d7df9e4db52")
