-- Lua provided by SkyAPI 
-- Game: 3030 Deathwar Redux - A Space Odyssey
addappid(464360)
addappid(464361, 1, "4bb71c98725e9b8eb1d741fb9403484724d8ab7d0214c79ff3e551ab93494d44")
