-- Lua provided by SkyAPI 
-- Game: AppID 1012030
addappid(1012030)
addappid(1012031, 1, "a04810d3b8009b364b25ddd2cb421a521f295c4878c24ca2b033216aa1f05d65")
