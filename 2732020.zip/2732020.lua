-- Lua provided by SkyAPI 
-- Game: TV Studio Story
addappid(2732020)
addappid(2732021, 1, "c070f79f4f6dfddf6b771383f60c70e30a6379ac4c1a47819b78627b07fa60a4")
