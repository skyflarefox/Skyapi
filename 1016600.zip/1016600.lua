-- Lua provided by SkyAPI 
-- Game: Devil Slayer - Raksasi
addappid(1016600)
addappid(1016601, 1, "7305a22edb02e01eb406044f97a78b787bd783e099051056349ea84f1b46f673")
