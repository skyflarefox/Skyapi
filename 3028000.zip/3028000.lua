-- Lua provided by SkyAPI 
-- Game: AppID 3028000
addappid(3028000)
addappid(3028001, 1, "8dc528f99ca1efd4bcf0310ab5b0c2bcae151a6da1a076b294303265c3e1c57c")
addappid(3079060, 0, "f95e160396d8df710a56199182a7e56e9459e0b59360fe7c9560c54988ba6368")
