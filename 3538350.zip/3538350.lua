-- Lua provided by SkyAPI 
-- Game: Trump Simulator 2025
addappid(3538350)
addappid(3538351, 1, "d881859e27503374ec8dc1c00fbbb894339d65ce477987dedd4959ad20f7357c")
