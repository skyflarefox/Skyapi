-- Lua provided by SkyAPI 
-- Game: Flynguin Station
addappid(969250)
addappid(969251, 1, "b54ecd34dd57314d9833480d378cd128d51ae0538260d78a67ef0b9aa80516a0")
