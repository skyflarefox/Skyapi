-- Lua provided by SkyAPI 
-- Game: Straimium Immortaly
addappid(515650)
addappid(515651, 1, "3e994f81ed290f30b9731c9a038af3958c847749fd328c90691b6e1a87a644b3")
