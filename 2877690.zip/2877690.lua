-- Lua provided by SkyAPI 
-- Game: Anne Frank House VR
addappid(2877690)
addappid(2877691, 1, "07aa72c035e83b6ee06f7000946eb315b9d11a3ccf3774713b4b9dd2999e97ee")
