-- Lua provided by SkyAPI 
-- Game: AppID 2416480
addappid(2416480)
addappid(2416481, 1, "4c9182e65b0e9cc231a9cf17de5631f8c62f96195334ac398781423c08109a95")
