-- Lua provided by SkyAPI 
-- Game: AppID 1203670
addappid(1203670)
addappid(1203671, 1, "83beb137293027317ec069cf6a7df23cd5c5e6f6ca62948ec31f99e4a9ddbcd4")
