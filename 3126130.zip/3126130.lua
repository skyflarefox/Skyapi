-- Lua provided by SkyAPI 
-- Game: The Prisoner in Letter Demo
addappid(3126130)
addappid(3126131, 1, "c7e77581522e2bbf9e9a1bfe791cabb2c4bd8301c0b4e2e7c8d4d9ddfecb81ea")
