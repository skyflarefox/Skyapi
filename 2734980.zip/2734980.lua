-- Lua provided by SkyAPI 
-- Game: Forward Brave Demo
addappid(2734980)
addappid(2734981, 1, "82a2709393180cfd2c3878b144168dc152529e6acd8efe9f340241804ac41861")
