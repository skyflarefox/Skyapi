-- Lua provided by SkyAPI 
-- Game: AppID 1168460
addappid(1168460)
addappid(1168461, 1, "e1a06e821923c865a60daba0443c374aae9d61820307b44a6f5062ebab279a2d")
