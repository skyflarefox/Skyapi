-- Lua provided by SkyAPI 
-- Game: Safe House
addappid(2707580)
addappid(2707581, 1, "80077ebc4849c66d5a8717e0224ba0ac51b5efe8a1feaed2f636431d2a3b06e5")
