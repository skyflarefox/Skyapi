-- Lua provided by SkyAPI 
-- Game: KinitoPET
addappid(2075070)
addappid(2075071, 1, "add3aec9cb7617a6460aaafda50ed1df8a1529fe3b88cd858796ace96aaefce6")
