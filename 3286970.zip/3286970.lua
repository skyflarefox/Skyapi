-- Lua provided by SkyAPI 
-- Game: Spear Song Artbook
addappid(3286970)
addappid(3286971, 1, "e182612821559ff03401b3f37a56a7b61addef08351de0acd2e0c4a3ffbbaf3c")
