-- Lua provided by SkyAPI 
-- Game: Iratus: Lord of the Dead
addappid(807120)
addappid(807121, 1, "4abef78e7146eb9c67587777f09791efc6f89486b2c3be18305d0c97517e563a")
addappid(1018330, 0, "f7ba2e39c03e365a2901925687991bbd8c3668839d9df5239c5d3dddae5822bc")
addappid(1125270, 0, "1f83eecd6bc6cdef44ea0d4edbcc703ade8549efba78d54ef865edf1362a088a")
