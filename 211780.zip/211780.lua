-- Lua provided by SkyAPI 
-- Game: Conflict Desert Storm™
addappid(211780)
addappid(211781, 1, "a55c0f30889aa5da769fc173e0764eb0d5bc2c955ef2419bc54307f4b72ea7b3")
