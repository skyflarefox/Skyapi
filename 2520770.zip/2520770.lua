-- Lua provided by SkyAPI 
-- Game: 骑士派对
addappid(2520770)
addappid(2520771, 1, "568315870a01bf5e812386dd7c12b2410b847d38b2f60483f27c33d6db85eba0")
