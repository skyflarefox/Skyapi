-- Lua provided by SkyAPI 
-- Game: Destructor Tanks
addappid(1820030)
addappid(1820031, 1, "c3f6e37cb789b386d765038dd8b5271296b3bbc94c98798cd29937707919ccf3")
