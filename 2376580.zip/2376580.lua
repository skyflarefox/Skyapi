-- Lua provided by SkyAPI 
-- Game: TRIBE NINE
addappid(2376580)
addappid(2376581, 1, "9529c75bff5b33fcc97f5e0533787f0933efd77a1a6d01a721b9986aab800dd3")
