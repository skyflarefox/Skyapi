-- Lua provided by SkyAPI 
-- Game: From The Past
addappid(3342650)
addappid(3342651, 1, "2e83d1a4526417dbb18c32a9ebda314ef2e22c55d49b5a71300aa0dd0d7611f8")
