-- Lua provided by SkyAPI 
-- Game: Uninvited Guest
addappid(1659210)
addappid(1659211, 1, "c5ef6f34f3abdc67a21f44b727eaf2372969381c058f595df177a5e1960d1561")
addappid(1814660, 0, "d1e5049e12a889d8f24d2a34ad3cdfb7b511c820e54ceef5a778bb19129c8ff6")
