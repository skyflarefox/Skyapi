-- Lua provided by SkyAPI 
-- Game: The Answer Is 42
addappid(1199660)
addappid(1199661, 1, "26b6d1dcbd7d9e7689f1b2add2182764abdded94df790f202603c4790e95143f")
