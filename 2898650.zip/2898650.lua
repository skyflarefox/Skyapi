-- Lua provided by SkyAPI 
-- Game: AppID 2898650
addappid(2898650)
addappid(2898651, 1, "d8b0c65b6f8f35d890fb7283daca9f3b31f45b0b2c6dc7685d1179937f211869")
