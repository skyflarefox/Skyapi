-- Lua provided by SkyAPI 
-- Game: Friday the 13th: Killer Puzzle
addappid(795100)
addappid(795101, 1, "adee86e7c8b3991dab5bc54f1bf5545a32a0ca89799ab96a12883dfb6755236c")
addappid(795102, 1, "2751bfbfaf93c7a1a1d0fc2b5bcb4cad2e78b9c7207cc7802e500bd98117e558")
addappid(795103, 1, "4ed1a7a806d8a75e12fedac99f6339363d6962f3f74c197f14a311ef7a241098")
