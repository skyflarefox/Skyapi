-- Lua provided by SkyAPI 
-- Game: AppID 2895000
addappid(2895000)
addappid(2895001, 1, "602ffeaad5999b5527490aff6b55ceeadd7985cd1d7eee010bfc2413836183a6")
