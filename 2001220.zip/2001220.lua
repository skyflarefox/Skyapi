-- Lua provided by SkyAPI 
-- Game: AppID 2001220
addappid(2001220)
addappid(2001221, 1, "8edc060329f3c0f84b22f9ef7a0d7d8a8bfde1c5a77a56c836494f4431b774e9")
