-- Lua provided by SkyAPI 
-- Game: AppID 2735060
addappid(2735060)
addappid(2735061, 1, "831dba296794e9d3a8803fd40878e0585633f67e705d94d8f84c7f134f123c86")
