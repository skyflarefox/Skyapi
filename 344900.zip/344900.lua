-- Lua provided by SkyAPI 
-- Game: Undeadz!
addappid(344900)
addappid(344901, 1, "6e60b25f740048c8760b45d587af9a2e56eebd22510ffa9ece11631f7d8776cb")
