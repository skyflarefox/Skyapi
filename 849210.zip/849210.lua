-- Lua provided by SkyAPI 
-- Game: AppID 849210
addappid(849210)
addappid(849211, 1, "c11d517fc644e3e488333a3e48aaad646d44721889b3fdc16c2fff8ec48cd2f3")
