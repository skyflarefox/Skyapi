-- Lua provided by SkyAPI 
-- Game: SULFUR
addappid(2124120)
addappid(2124121, 1, "5a0438ea06459ea27a8da1e417a22ffeee9793b472712d0a2a86179b4554bf36")
