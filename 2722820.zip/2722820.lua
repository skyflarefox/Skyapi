-- Lua provided by SkyAPI 
-- Game: AppID 2722820
addappid(2722820)
addappid(2722821, 1, "a6b3076c05fcc421f3f165a0c3fb77d8c1d806262a86474b269f8f6d07ef6e9a")
