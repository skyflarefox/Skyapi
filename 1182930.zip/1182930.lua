-- Lua provided by SkyAPI 
-- Game: AppID 1182930
addappid(1182930)
addappid(1182931, 1, "dfe44415b9c9a0a0cd4c43d2627265d9376155578223541e39d5fddf123bb372")
