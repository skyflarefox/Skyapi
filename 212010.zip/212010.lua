-- Lua provided by SkyAPI 
-- Game: Galaxy on Fire 2™ Full HD
addappid(212010)
addappid(212011, 1, "dd3488556b41c0ad54abb267eba9145ec5f93d5f199b561716c73865716b111a")
