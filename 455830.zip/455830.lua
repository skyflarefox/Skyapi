-- Lua provided by SkyAPI 
-- Game: AppID 455830
addappid(455830)
addappid(455831, 1, "c2262929a40e7ee1a0332c45a1b9b8ee03896d4b3d75c15075e6328d22cccc5e")
addappid(549650, 0, "67cc7b50f797259b52d5dd3b1ae1983c3f194071e341f991eac8a31b2a393853")
