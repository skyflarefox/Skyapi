-- Lua provided by SkyAPI 
-- Game: Guardians of the Sanctree Demo
addappid(2941270)
addappid(2941271, 1, "729dfb8f366179057be9599cd29262302e1015697d23e7cd0c1026f019871c5a")
