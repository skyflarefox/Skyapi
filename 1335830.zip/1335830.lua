-- Lua provided by SkyAPI 
-- Game: AppID 1335830
addappid(1335830)
addappid(1335831, 1, "f2232a3bfcb5c7612c95312dfd25d89e6f0795121c0554e12b911b6f8d982e65")
