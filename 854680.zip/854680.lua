-- Lua provided by SkyAPI 
-- Game: AppID 854680
addappid(854680)
addappid(854681, 1, "91b1ac691f42a6e601a8273af9a48b912064b001d845ac2469d6ccf8b5b85216")
