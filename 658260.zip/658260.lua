-- Lua provided by SkyAPI 
-- Game: AppID 658260
addappid(658260)
addappid(658261, 1, "bc8db29f4ace088199b4a7707a605213d76c51412d5c2507cd6cf1bb78c153c8")
