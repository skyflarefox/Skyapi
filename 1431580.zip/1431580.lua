-- Lua provided by SkyAPI 
-- Game: AppID 1431580
addappid(1431580)
addappid(1431581, 1, "9f276fe30d9957944ed829f634b57d3025aa43bf57e770df991311aebdc60243")
