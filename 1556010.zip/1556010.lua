-- Lua provided by SkyAPI 
-- Game: AppID 1556010
addappid(1556010)
addappid(1556011, 1, "4af82db67f54939cb5f00bca90a3453429d7c1f506fd03b3417e7c1f4988621b")
