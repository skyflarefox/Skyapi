-- Lua provided by SkyAPI 
-- Game: AppID 2382310
addappid(2382310)
addappid(2382311, 1, "a0dc4057e4bd12a9a7d0cdf9058d74c525d1b1435d58f0e52a9a734146253554")
