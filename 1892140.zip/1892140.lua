-- Lua provided by SkyAPI 
-- Game: Cryptid Farm
addappid(1892140)
addappid(1892141, 1, "9a3e4bcb7ee383a8d1fde22c4f94ccec8f457f8aa6adc8f427699a6cc52cf303")
