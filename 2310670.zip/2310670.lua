-- Lua provided by SkyAPI 
-- Game: Midnight Arrow
addappid(2310670)
addappid(2310671, 1, "08a3b35f4c84ca0f68f60ec51bd8bec0e4e863c3de87b8d7a945ea9260892d1e")
