-- Lua provided by SkyAPI 
-- Game: AppID 777200
addappid(777200)
addappid(777201, 1, "6fc42a1639dda3667db218e2da11c5dd1519c7886730313fb08bad3731ca0631")
addappid(777202, 1, "28684ec1d2c85965f8e7de0bc9cb5112f71e4d6651ef8d1cb8027d7dd858116e")
