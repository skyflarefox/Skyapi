-- Lua provided by SkyAPI 
-- Game: AppID 1125870
addappid(1125870)
addappid(1125871, 1, "6eec00ad6d314553fc0c254b507da923f1d7dc83c1a9cc42d5c169d90ad52089")
