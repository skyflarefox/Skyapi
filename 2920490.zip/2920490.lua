-- Lua provided by SkyAPI 
-- Game: Splash Dino
addappid(2920490)
addappid(2920491, 1, "9513c7fb9238c9bfd1bd9ae6f71ca3160342619f3d2d5841d127be40cc05a78c")
