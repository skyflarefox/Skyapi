-- Lua provided by SkyAPI 
-- Game: Nightmare
addappid(1665250)
addappid(1665251, 1, "e943f80dc063d129f080752e4199d25636cd56019e5a234b47ade707a9bf5209")
addappid(2268680)
