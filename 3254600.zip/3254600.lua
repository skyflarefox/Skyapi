-- Lua provided by SkyAPI 
-- Game: AppID 3254600
addappid(3254600)
addappid(3254601, 1, "08203d01d9d614918e2dd82f0ca33aee5c4ecc75177cf3b710bae566c1b9d568")
