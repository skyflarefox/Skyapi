-- Lua provided by SkyAPI 
-- Game: Tribe: Primitive Builder
addappid(1059900)
addappid(1059901, 1, "1e29a8ec0be8503eb1df392dbedd81117d6763820605a731f15cdf91b45629ef")
