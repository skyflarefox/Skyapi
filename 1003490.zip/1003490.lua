-- Lua provided by SkyAPI 
-- Game: AppID 1003490
addappid(1003490)
addappid(1003491, 1, "ca8db6c0085ccd86506239a187bdce1e782b2f83b03f55a1a06d5d299188e58f")
