-- Lua provided by SkyAPI 
-- Game: AppID 1178790
addappid(1178790)
addappid(1178791, 1, "83a0b55b7617bf9b5b5486d119ad8149889388e6e6623448878596ff4ebbad46")
