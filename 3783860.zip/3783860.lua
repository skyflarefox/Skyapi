-- Lua provided by SkyAPI 
-- Game: Anime Dream Match: Cats
addappid(3783860)
addappid(3783861, 1, "67d8537140f48f506d0788659945d4d66b0cf671a11b6f0beb18642c758b6f8c")
