-- Lua provided by SkyAPI 
-- Game: INMOST Soundtrack
addappid(1399420)
addappid(1399421, 1, "f3f3f9a3ca98eca5a3d9d03aa9fbbb9e5f9bc4995212d0035538bb70740cf73b")
addappid(1399422, 1, "c107ef090334274e00302d2578eca312c0f081a68273a548f702830c25725617")
