-- Lua provided by SkyAPI 
-- Game: AppID 2487560
addappid(2487560)
addappid(2487561, 1, "f70d8bd0f2e29e3116635827ce0cb56e2b791a9f8ab4ac91188a7c9a0187ca26")
