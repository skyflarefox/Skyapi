-- Lua provided by SkyAPI 
-- Game: Lemon vs. Teddy
addappid(1803290)
addappid(1803291, 1, "51038b8ca06b2dfcf02a5ec3bfe00f8b74555173dc2bc4f67c5c9751b10c4aff")
