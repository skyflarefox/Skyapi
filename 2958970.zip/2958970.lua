-- Lua provided by SkyAPI 
-- Game: The Thing: Remastered
addappid(2958970)
addappid(2958971, 1, "6a77249e795dc23efaa8cc24bd18b87cd28f6707dc75eeb0e8f7a3170cd8e420")
