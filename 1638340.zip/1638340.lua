-- Lua provided by SkyAPI 
-- Game: Cat Simulator : Animals on Farm
addappid(1638340)
addappid(1638341, 1, "c88cb203c91a7548335c85fe1bd67e7df913e02e8a04663a760fd265ab003021")
