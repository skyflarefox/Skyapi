-- Lua provided by SkyAPI 
-- Game: Trump Jigsaw
addappid(3616070)
addappid(3616071, 1, "3ee78e46d9e4e22bcf739f0af257b6ca881c38dd984e2814a3031b02089da7e5")
