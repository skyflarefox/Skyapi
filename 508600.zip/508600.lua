-- Lua provided by SkyAPI 
-- Game: AppID 508600
addappid(508600)
addappid(508601, 1, "941301e9c0b113ca2aba0ac61d5bfd01ddc7a2d310f11c8aa3d7e0a1316954ca")
