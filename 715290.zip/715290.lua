-- Lua provided by SkyAPI 
-- Game: SEGFAULT
addappid(715290)
addappid(715291, 1, "958932ae132bdb775b463f6a6a0d01d79fdd88e9425d714363a1a7d85d35574d")
