-- Lua provided by SkyAPI 
-- Game: Atomic Wilds
addappid(1693960)
addappid(1693961, 1, "6c45167f0742932a585ec52c388f056c6f807bdbd05e22e309f55059a1391c49")
