-- Lua provided by SkyAPI 
-- Game: AppID 1192260
addappid(1192260)
addappid(1192261, 1, "7cc112132faa7b1e3c653f883fbb58d52308312b90938ea293a27ac9177b0088")
