-- Lua provided by SkyAPI 
-- Game: One More Line
addappid(356890)
addappid(356891, 1, "152dcd9b540a085bf3e5da6fff472ac0b3cfe2d8114704fda441421947522952")
addappid(356892, 1, "fde2f9981253b6f2279afcacec0f8840ddfba4548edc4f3c05f5eb30a2e8cbcf")
addappid(356893, 1, "2ce3ace305050c3c8e176b4905bf27bd587dc6976f5f9eeccb34c0b8c53f9be8")
addappid(356894, 1, "e9f1211dc37533e8342a44dfc2a0a30725680958a32707a51895633f408abd69")
