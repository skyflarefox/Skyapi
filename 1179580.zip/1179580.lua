-- Lua provided by SkyAPI 
-- Game: AppID 1179580
addappid(1179580)
addappid(1179581, 1, "25bfa1d6d3edb9d1e31516745901555734cec90b16ef7f90644748fc08d3c45d")
addappid(2987590, 0, "2d772ceb4a91f072b19ea1ae0ea489020a0af6e6828cef0e68994db2cb714fb8")
