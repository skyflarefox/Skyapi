-- Lua provided by SkyAPI 
-- Game: A Twisted Path to Renown
addappid(2304660)
addappid(2304661, 1, "ab915c4089c6508ae830d6e4d9fa6410b6879c4484a8edf2714714be3f5df8a2")
