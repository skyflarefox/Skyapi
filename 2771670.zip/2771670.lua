-- Lua provided by SkyAPI 
-- Game: Psychopomp
addappid(2771670)
addappid(2771671, 1, "61086f362fcf8684640b4381c747a1f177b9bced5af6b11194f671c283da15f0")
