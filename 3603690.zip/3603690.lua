-- Lua provided by SkyAPI 
-- Game: Pool Protocol: Loop
addappid(3603690)
addappid(3603691, 1, "639a0ba280106165ab391f60a8e447e674e4bf8d26cb6f9617eb8c15f93c6e89")
