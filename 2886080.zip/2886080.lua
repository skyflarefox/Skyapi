-- Lua provided by SkyAPI 
-- Game: Color Splash: Dinosaurs
addappid(2886080)
addappid(2886081, 1, "cc3b81f53e4a644b7bd764e4c581fc12020640da442373feba472a243e0ea37c")
