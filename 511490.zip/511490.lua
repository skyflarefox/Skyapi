-- Lua provided by SkyAPI 
-- Game: Malavision: The Beginning
addappid(511490)
addappid(511491, 1, "d79c86d3cb5b1333b35133be10b6cafabcc9dfea3c22718b582f0dfca2e01378")
addappid(559890, 0, "41f87babf0d65c14147244af465993a5d598f11b065fd44297c78faa849a328e")
