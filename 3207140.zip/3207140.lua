-- Lua provided by SkyAPI 
-- Game: AppID 3207140
addappid(3207140)
addappid(3207141, 1, "4edb10a3cb704b0d49187cccf317739dc19bfbfca981f179d67ba45c985b4bee")
