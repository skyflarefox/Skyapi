-- Lua provided by SkyAPI 
-- Game: Weakless
addappid(1072620)
addappid(1072621, 1, "37c4492a626bfb774a91f4e3a6b3adb19fcb8661e673c88943bd6a2be0ca4c33")
