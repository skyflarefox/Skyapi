-- Lua provided by SkyAPI 
-- Game: Beyond Reality
addappid(428100)
addappid(428101, 1, "a2b59f490b0e58441f060035af3b94317db6b663bcd835815326571f796ca3c9")
