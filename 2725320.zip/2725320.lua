-- Lua provided by SkyAPI 
-- Game: Dice of God
addappid(2725320)
addappid(2725321, 1, "a924fe74ddc486634b8400dbeb90745a0bb6af2848f0315f203a6cbe5d8cc062")
