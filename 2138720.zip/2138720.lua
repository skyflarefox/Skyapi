-- Lua provided by SkyAPI 
-- Game: REMATCH
addappid(2138720)
addappid(2138721, 1, "c1a2b9eea7346395b175b2d8458f566dcabe83b99822111d3446a5ce377bdc52")
addappid(3469160)
addappid(3469170)
addappid(3469180)
addappid(3525370)
addappid(3743380)
addappid(3743390)
addappid(4002110)
addappid(4002120)
addappid(4031620)
