-- Lua provided by SkyAPI 
-- Game: Spin Quest: A Slot Adventure
addappid(2161900)
addappid(2161901, 1, "74cec4f05ff79d5a3a7a0bdbaf3a985439813bd57c6b8722cb833c0345e48c63")
