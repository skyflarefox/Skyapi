-- Lua provided by SkyAPI 
-- Game: AppID 638830
addappid(638830)
addappid(638831, 1, "727c9ede38c323a64068665843f3cde91013827fae51a337a0786d1468a2f338")
