-- Lua provided by SkyAPI 
-- Game: AppID 1028130
addappid(1028130)
addappid(1028131, 1, "7743d352c4f59004fc3cf72f3572e9140ff3fad11c7adf0e4868ab91eb6abefd")
addappid(1028134, 1, "6deb9dffe57de06b02c4137ecbfda70955c49163a4883e609ef92fb762c1d6f8")
