-- Lua provided by SkyAPI 
-- Game: AppID 2882440
addappid(2882440)
addappid(2882441, 1, "7ffaeab1059850f6d2bc4a2e1fdd40e249380ed027dd1d4df60c117ca796e391")
