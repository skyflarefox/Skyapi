-- Lua provided by SkyAPI 
-- Game: Felix Jumpman
addappid(575920)
addappid(575921, 1, "2d7b5746c8933e6955b4473a8e022683f03e9797cf22f6eac09f580592a819a4")
