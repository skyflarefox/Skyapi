-- Lua provided by SkyAPI 
-- Game: Sweet Home: Look and Find Collector's Edition
addappid(2701630)
addappid(2701631, 1, "d629d56a26fe6cf4e27f101b307ade60b34bac8af282d63aad387b5912a2038c")
