-- Lua provided by SkyAPI 
-- Game: AppID 1240730
addappid(1240730)
addappid(1240731, 1, "ec2738e2f4c1cc0715f828dbffc48f8731c8128816529b89771a1b290e22400d")
