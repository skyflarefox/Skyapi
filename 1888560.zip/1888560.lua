-- Lua provided by SkyAPI 
-- Game: Sky Resort - Delphi & Jessy
addappid(1888560)
addappid(1888561, 1, "0e87a4ae6591ebaa1f931c5a5875e47966bc7b4d214158cdfccfa2e7ab2ede91")
addappid(2280480, 0, "5f3f87a413b8f815c1e04a0525a8f17adb94db7bcc0793fac3b06faae6644189")
