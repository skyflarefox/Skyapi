-- Lua provided by SkyAPI 
-- Game: Marble It Up! Ultra
addappid(864060)
addappid(864061, 1, "7e5b3a61958199f381f8dd0323098a9360d2622fc002baeafe238d5d205262d8")
