-- Lua provided by SkyAPI 
-- Game: Farlanders: Prologue
addappid(1460540)
addappid(1460541, 1, "4f5bb9e15a161cdee037af6d7538ee506987deb86f67c70686751b30c5feadbd")
addappid(1460542, 1, "981c67123a87c940a65f6c0ab32ba391476c4204ce220e3b2c66dd7a7489d573")
addappid(1460543, 1, "10abdc7b7948d471037a02dcd2cea151919c779239e041b800e3306bcd42e8ef")
