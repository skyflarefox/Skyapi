-- Lua provided by SkyAPI 
-- Game: Arctic Wolves
addappid(3326280)
addappid(3326281, 1, "3a07b80bdb2d0b4a09f05302e1423791c992738bb47172ab1bb458da68306e89")
