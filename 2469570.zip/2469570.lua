-- Lua provided by SkyAPI 
-- Game: Oberty
addappid(2469570)
addappid(2469571, 1, "d8ae2a1c3ce15e679b1bb45afc0afdf4e9f986dc9b06ee0e03d9d46e16d2008b")
