-- Lua provided by SkyAPI 
-- Game: Exquisite Fishing
addappid(2146300)
addappid(2146301, 1, "3da8a461a36b4c9b746d8de35ab37140b6b288209a07d08cf319b419b7412493")
