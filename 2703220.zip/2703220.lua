-- Lua provided by SkyAPI 
-- Game: 3D PUZZLE - World War II
addappid(2703220)
addappid(2703221, 1, "5a9ff2f9d45c57e8ad86a433d69b2ae0371d4efbc27274e3b826420aaa9ca578")
