-- Lua provided by SkyAPI 
-- Game: Seditionis Crutarch Royale
addappid(1765040)
addappid(1765041, 1, "8ab30150f263c8798dcdfd33be37f0de6ead4051f58f5f94dd3154e3e77cfa22")
