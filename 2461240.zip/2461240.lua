-- Lua provided by SkyAPI 
-- Game: Black & White Lite
addappid(2461240)
addappid(2461241, 1, "c35abec566eec86f3fbcaa2aea98c56090f8c0b8534ddd5023611150bd7a0c77")
