-- Lua provided by SkyAPI 
-- Game: Dawn of Defiance
addappid(2059530)
addappid(2059531, 1, "0e4801f0b0692f017a25532160e3efd4f0607c8ed1d179218d615d77de1fc9c0")
addappid(3133780)
