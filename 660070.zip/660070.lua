-- Lua provided by SkyAPI 
-- Game: Chromatic
addappid(660070)
addappid(660071, 1, "427459e0a21c0c1bf79ea58e9530a9c7d914cc6f44eb8e6fcbd5afc6f73b1d34")
