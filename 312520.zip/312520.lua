-- Lua provided by SkyAPI 
-- Game: AppID 312520
addappid(312520)
addappid(312521, 1, "f36b23dfaca5b387508e33fe17732bcd48a16ab0fef3b1eb819494ad76d5ce2a")
addappid(1933390, 0, "cf34e0fb21789d7fd65c827a966d574e2fbd1e6b0cb47f81322256690ad70532")
addappid(2857120, 0, "f998f9f9862dc3cc8026d11be949bc4d7c17882f1240b6982766721fceaae0ad")
