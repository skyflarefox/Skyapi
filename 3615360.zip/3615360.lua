-- Lua provided by SkyAPI 
-- Game: Your StepSister
addappid(3615360)
addappid(3615361, 1, "d90d490cb9ee756daa844c05fd5e799653136fa7b20fa7428da7e3472af26989")
