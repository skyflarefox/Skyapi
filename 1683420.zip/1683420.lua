-- Lua provided by SkyAPI 
-- Game: Strategic Mind: Spirit of Liberty - Prologue 1939
addappid(1683420)
addappid(1683421, 1, "8261c66abc0a3d02a4da88c4e1870b38214f557d7453deea3a5262283f59f7a3")
