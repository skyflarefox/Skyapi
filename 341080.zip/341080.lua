-- Lua provided by SkyAPI 
-- Game: NeXus: One Core
addappid(341080)
addappid(341081, 1, "40f4c960176e2450b7b7fac99ffa72981911b8d1366983096df488a4ad25df24")
