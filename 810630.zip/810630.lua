-- Lua provided by SkyAPI 
-- Game: AppID 810630
addappid(810630)
addappid(810631, 1, "54e5361e4ea4ac1ce398616dd5eb3b5a1dd724bdb06b4d4ca150efb7bc6f78af")
