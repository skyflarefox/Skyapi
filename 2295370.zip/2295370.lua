-- Lua provided by SkyAPI 
-- Game: AppID 2295370
addappid(2295370)
addappid(2295371, 1, "2bed6614bcc89a7a3131410ec933948c146262d473b9d2b0f7d8a3b9f109369b")
