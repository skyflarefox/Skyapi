-- Lua provided by SkyAPI 
-- Game: Knights of the Temple: Infernal Crusade
addappid(1194610)
addappid(1194611, 1, "02723370984598477fbe6cf750e2b1e5577f31fffdeda9592344fedb8e9c167e")
