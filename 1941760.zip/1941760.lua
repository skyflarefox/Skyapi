-- Lua provided by SkyAPI 
-- Game: Irritability & Mood Swings
addappid(1941760)
addappid(1941761, 1, "fc610e4bef14d9216549f8e217b17d2afee63472d00ec0e5b7f1c6df60621c70")
