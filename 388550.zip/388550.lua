-- Lua provided by SkyAPI 
-- Game: Galactic Missile Defense
addappid(388550)
addappid(388551, 1, "4c5665a741607d33c38fd23c796d5feb089d63700efbf7606b3adc22ad9bea11")
