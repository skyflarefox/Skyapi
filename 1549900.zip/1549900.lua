-- Lua provided by SkyAPI 
-- Game: 18+ for Clip maker
addappid(1549900)
addappid(1549901, 1, "012c3b6407fb1d6cc2d21513c17957d3e3c2f79091d026b6fbfc090c82fe7b27")
