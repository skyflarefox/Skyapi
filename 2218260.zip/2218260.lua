-- Lua provided by SkyAPI 
-- Game: Nuclear Option Playtest
addappid(2218260)
addappid(2218261, 1, "e07af924a2876271bc5acd63a662ed957f9bdbddd0e085a191c11ef54a405093")
