-- Lua provided by SkyAPI 
-- Game: AppID 1674060
addappid(1674060)
addappid(1674061, 1, "a9d6f241a5a82690ba1604dd5c52a6acf9df253b0198de4f13647e853ce93ca6")
