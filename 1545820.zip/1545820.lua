-- Lua provided by SkyAPI 
-- Game: Pixel Art Coloring Book
addappid(1545820)
addappid(1545821, 1, "5e1a0edb2b17bba7266c3a5e6c17082c443309c1f94861e43b46af3779444126")
addappid(1545822, 1, "255881563684bcd153814a35f9221004f9d220145e1eb44384416d97987298e5")
addappid(1576340)
