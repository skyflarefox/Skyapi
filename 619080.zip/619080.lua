-- Lua provided by SkyAPI 
-- Game: SOS
addappid(619080)
addappid(619081, 1, "5c017cd997dc54ab85fa3e0425c9fed11f08ded293f1ad43f8f932b68fb0a0e5")
