-- Lua provided by SkyAPI 
-- Game: Aristocunts
addappid(1314630)
addappid(1314631, 1, "8c8c2e12120abe19735c96c3b03e5bb8e8a10c8413ecc75317f32011878e698e")
