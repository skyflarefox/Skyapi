-- Lua provided by SkyAPI 
-- Game: Teenage Blob
addappid(1096060)
addappid(1096061, 1, "e245eaf076b5490a3b313ecd60f6c35353babc1b2b54cdb591d1f4e813b6f2d6")
addappid(1096063, 1, "6b7ffa24dd413929ba4a848179ece6be78c653464e8e20ec5b2d0c8591e054f7")
addappid(1394980, 0, "b4c71109edb75200284a8c7674979ac361f7d077bf2f68f00dd590005e92cceb")
