-- Lua provided by SkyAPI 
-- Game: Laundry Store Simulator Demo
addappid(3239280)
addappid(3239281, 1, "b404539705f93e69524f48efa81358b62032147d34bd602f4ff5dff8643fdfba")
