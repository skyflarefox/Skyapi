-- Lua provided by SkyAPI 
-- Game: City Rush
addappid(609400)
addappid(609401, 1, "1e5090fefcb78af28d66e0092d3df875a917f99ea97ec6eb0d99e9f833d8e44e")
