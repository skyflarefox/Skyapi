-- Lua provided by SkyAPI 
-- Game: Hard Chip
addappid(2844290)
addappid(2844291, 1, "1379b9884d664079f91bd8978edb0237b091e9a721bb8c2d727857d20c6c318e")
