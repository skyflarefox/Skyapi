-- Lua provided by SkyAPI 
-- Game: Headbangers: Rhythm Royale
addappid(1761620)
addappid(1761621, 1, "335db1725a0fb8006f1f1a4550f16ff869353a58818e2a2805a3530063f7f90a")
