-- Lua provided by SkyAPI 
-- Game: Outbound
addappid(2681030, 1, "212c0a7b5c03882e040badb68ae28f5fed348c96e52b78942ab003e09f13700f")
addappid(2681031, 1, "feac3f781af42ac4e65cdb05e24f482c33e5660d23b377e86d744be6cc53a4bd")
addappid(4148860) -- Outbound  School Bus Adventures