-- Lua provided by SkyAPI 
-- Game: Dead Ground Arcade
addappid(1200350)
addappid(1200351, 1, "3648cd02f5c9a2d1bced806cf0ef4f8780be52ffeadf1ac6d2d5619498f85d82")
