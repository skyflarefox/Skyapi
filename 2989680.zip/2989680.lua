-- Lua provided by SkyAPI 
-- Game: Twizzle Puzzle: Dinosaurs
addappid(2989680)
addappid(2989681, 1, "a2f9bd7d3cdac720156493b8624111e08c023d4f8c8554e150a0ddd80bfc532f")
