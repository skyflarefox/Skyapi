-- Lua provided by SkyAPI 
-- Game: Grandpa's Table
addappid(471570)
addappid(471571, 1, "8b31a2910b6a2b9bb17788b29905c498c8d1501cc0af8a56bed05789da8d90aa")
addappid(471572, 1, "8a0680d13f952376c62dd6c4f56935598bac6720d1b8b24a09a06a98f724cb9e")
addappid(471573, 1, "dd284d64a2405ab5ac566fa8696cc7022a76128d7631ff29f7d7da55f96616f7")
addappid(471574, 1, "880dbb385a9bb871ec90f0fe009c1eb5f9e3eacd3f1b44c4e84a83cb94ab8b71")
