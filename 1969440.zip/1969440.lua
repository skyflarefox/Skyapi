-- Lua provided by SkyAPI 
-- Game: Sunday Gold
addappid(1969440)
addappid(1969441, 1, "3d3854ad783ef775f94954558445d885fe14a80465c151ddf38dcda92276fda9")
