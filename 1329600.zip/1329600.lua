-- Lua provided by SkyAPI 
-- Game: Karting
addappid(1329600)
addappid(1329601, 1, "cb95132f4e610353d7100a9dbad2807cc2418a27ba36ddc05186cfbe31b8894a")
