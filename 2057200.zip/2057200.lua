-- Lua provided by SkyAPI 
-- Game: Cricket Captain 2022 Demo
addappid(2057200)
addappid(2057201, 1, "e5458a549ab188c2b2f8b67019976639c600fb6019b8002756793ffbdc2757ea")
