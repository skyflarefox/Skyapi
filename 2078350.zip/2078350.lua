-- Lua provided by SkyAPI 
-- Game: Bluey: The Videogame
addappid(2078350)
addappid(2078351, 1, "250878d5f554855c09d59af0963ea4e9968fedf5f29415da830146c5de2d40fb")
