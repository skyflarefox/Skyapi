-- Lua provided by SkyAPI 
-- Game: Aozora Meikyuu
addappid(427980)
addappid(427981, 1, "86153a66aed5507180b77cb451705fc4ee178aea2532a2198e4556ee59f15ca8")
