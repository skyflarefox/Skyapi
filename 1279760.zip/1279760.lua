-- Lua provided by SkyAPI 
-- Game: AppID 1279760
addappid(1279760)
addappid(1279761, 1, "5481f1b814b19313ebeda6158f53ac8a6cbea85bff3e5366a96a3c69e7e85a92")
addappid(1279762, 1, "99e6227b52ee04543ebfd538010cdf5630bc82bd74212e509a6e6c80820dd930")
