-- Lua provided by SkyAPI 
-- Game: Drill Deal: Borehole (Alpha)
addappid(1376890)
addappid(1376891, 1, "b5150a121a7a606642d20d7f93c7ddcedb5f15022fff2576f9ae368751616b6b")
