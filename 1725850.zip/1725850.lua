-- Lua provided by SkyAPI 
-- Game: Horny Crush
addappid(1725850)
addappid(1725851, 1, "56e6e1075f1181b3f9ddf1b8fa05bfb9a684fa8bee68efc793f7cfeefa618422")
