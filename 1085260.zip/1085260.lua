-- Lua provided by SkyAPI 
-- Game: Ports of Call Classic
addappid(1085260)
addappid(1085261, 1, "c567a3ede23acd61cff78c1cc697ac9d126927f14749488e4e63906f3a6d127a")
