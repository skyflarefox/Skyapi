-- Lua provided by SkyAPI 
-- Game: Jitsumi's Game Booster
addappid(1014130)
addappid(1014131, 1, "a8bc59f8aad47615b5f22c652132c13f4395fa09158bbbcb41a027722330a137")
