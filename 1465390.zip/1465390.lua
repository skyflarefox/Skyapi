-- Lua provided by SkyAPI 
-- Game: Hentai ASMR
addappid(1465390)
addappid(1465391, 1, "c3047dfbf1c28ad980f3e19e567f6286813526a395f17c30224af554e848703d")
