-- Lua provided by SkyAPI 
-- Game: Lucky Fish Bread
addappid(1695400)
addappid(1695401, 1, "4cad561b0bf42dded15892a0d724fcf7b15493a8867cf278257c7325d2524d95")
