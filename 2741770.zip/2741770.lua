-- Lua provided by SkyAPI 
-- Game: AppID 2741770
addappid(2741770)
addappid(2741771, 1, "496c5401d85657315462972bcba68381368e4d87f04488748b90dbb3d68dc16d")
