-- Lua provided by SkyAPI 
-- Game: Dollar
addappid(3069470)
addappid(3069471, 1, "e23b873a4dbb3bd4618c5984f6f51ec2cdda00e10d60c8971ba0429a97527f16")
