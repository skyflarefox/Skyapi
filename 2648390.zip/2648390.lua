-- Lua provided by SkyAPI 
-- Game: Billionaire Simulator
addappid(2648390)
addappid(2648391, 1, "f52979507a59ab31d5312e9365b58a2e9c64a9f8245a8fe4a7286acc24e10946")
