-- Lua provided by SkyAPI 
-- Game: Greetings
addappid(920190)
addappid(920191, 1, "80788992f21b35b5ab356cd3f41ef56c593338eb9fb9e728e0290416c6304fa6")
