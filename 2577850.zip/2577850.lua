-- Lua provided by SkyAPI 
-- Game: Seekers of Eclipse
addappid(2577850)
addappid(2577851, 1, "5f0a47d460b62926365d3c4e1085bc9f420c712fbf96bc19a729d4c8c8ccf0c3")
