-- Lua provided by SkyAPI 
-- Game: Kaigrad
addappid(1530760)
addappid(1530761, 1, "90a3a486cf9f42e8748c8a845f75308f48750ef288f224bf1a1c71bc72128663")
