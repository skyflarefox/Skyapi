-- Lua provided by SkyAPI 
-- Game: AppID 1098490
addappid(1098490)
addappid(1098491, 1, "c24f8d019278fd9897427e4f95d6c70c42a9de8a38a1c4fb0b9bd8e70b3a27bd")
addappid(1098520, 0, "4120b3a5e39ae70865a258d4ac002b18fe1e4e010fc92924d1257d515c4c5a22")
