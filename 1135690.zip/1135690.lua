-- Lua provided by SkyAPI 
-- Game: AppID 1135690
addappid(1135690)
addappid(1135691, 1, "32dcfa1767b00d316eaa45a92c3f4a387f711be0c45ff63508a6b39e233a5f7f")
