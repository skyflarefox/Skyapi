-- Lua provided by SkyAPI 
-- Game: EARTH DEFENSE FORCE: WORLD BROTHERS 2
addappid(2370170)
addappid(2370171, 1, "d3b5139d0a0c53b1fd1deb6e4ddf1f94e6e320c7796340757a02ebac7cb52399")
