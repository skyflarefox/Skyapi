-- Lua provided by SkyAPI 
-- Game: AppID 3126270
addappid(3126270)
addappid(3126271, 1, "025a1e84627b2375e81206d2483ba868a38264f407af7b32e0c43699afc05ad4")
