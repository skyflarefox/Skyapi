-- Lua provided by SkyAPI 
-- Game: Mad Streets
addappid(1282760)
addappid(1282761, 1, "5321960cdea41e3e93e37be21b0ff8446ca360073ac57e667330ceaecb4dd5a4")
