-- Lua provided by SkyAPI 
-- Game: Nope Nope Nurses
addappid(1846330)
addappid(1846331, 1, "c469d24d80b5f030ec12ae02b3267645a7d2d2643ce9c7e253f985d91ffbbd4d")
