-- Lua provided by SkyAPI 
-- Game: CORVUS
addappid(1219520)
addappid(1219521, 1, "a51c6403789c862c1379036c579c3814ee0e46c3122a7f2fa5150799614188a9")
