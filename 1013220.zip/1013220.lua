-- Lua provided by SkyAPI 
-- Game: River City Saga: Three Kingdoms
addappid(1013220)
addappid(1013221, 1, "245761dac7fd224f5bbc07b1b2c9bbb420edcf65007bd5d118d88100808e861c")
