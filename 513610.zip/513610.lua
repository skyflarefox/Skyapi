-- Lua provided by SkyAPI 
-- Game: Madrobot X
addappid(513610)
addappid(513611, 1, "7762fd1677a00ffde2301af23f0157e91f2249a8ceda9711f9c73a8477d3fe4f")
addappid(513612, 1, "2dd97c930cf8e217fb42bc80e2143340bf7498f075efd95f26d4781688cafa56")
addappid(513613, 1, "3ecb95f8f32b63a0fb14053b52655f9fd18c4d91d484ed94d4c9aca1d0f0f5e7")
