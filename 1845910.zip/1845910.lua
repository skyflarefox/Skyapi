-- Lua provided by SkyAPI 
-- Game: Dragon Age™: The Veilguard
addappid(1845910)
addappid(1845911, 1, "55cde6d605fb6c04a505e84c44ff05f79e75dad69c4b0f6326c4ba4478e7cc1d")
