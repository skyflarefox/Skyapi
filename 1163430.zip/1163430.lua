-- Lua provided by SkyAPI 
-- Game: AppID 1163430
addappid(1163430)
addappid(1163431, 1, "8c45163dab62960a5e4f5e1a3444f1fe0e125a4f7b0ba3e598473add2aafdd48")
