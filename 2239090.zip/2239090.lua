-- Lua provided by SkyAPI 
-- Game: AppID 2239090
addappid(2239090)
addappid(2239091, 1, "5f36c55d496c3da411e0cfdcba46c3fcf8f1e9feac3a85a77e55f8012182c29e")
