-- Lua provided by SkyAPI 
-- Game: Digital Zoo Gallery
addappid(1511330)
addappid(1511331, 1, "a42966be9fe0a54eb1d3de6f387e72a184e93a021a58a18915d1552e170db2a1")
