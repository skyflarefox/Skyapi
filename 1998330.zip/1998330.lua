-- Lua provided by SkyAPI 
-- Game: Yomawari: Lost in the Dark
addappid(1998330)
addappid(1998331, 1, "6480c2d900946b05852a49688cfd14d0b44b50b8d2fd7aa6c1d1f091dd5ede6e")
