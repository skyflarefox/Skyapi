-- Lua provided by SkyAPI 
-- Game: 小艺的异世界冒险-Xiao Yi's strange world adventure
addappid(1883110)
addappid(1883111, 1, "ac3540634fea51bb1eca48b0d4961858eb00b4154d43e9d058e1e01ba6629b96")
