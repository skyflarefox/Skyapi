-- Lua provided by SkyAPI 
-- Game: AppID 2061480
addappid(2061480)
addappid(2061481, 1, "e8899c28f8e7febe7be23aae437ae61d6393171a7e32ccdfe76c9414d7a3fbe9")
