-- Lua provided by SkyAPI 
-- Game: AppID 251370
addappid(251370)
addappid(251371, 1, "f8998a8338fca9eb39d852065f06bcfdd1a54db703df0c105e58d0e3b0a140cd")
addappid(251372, 1, "974bf59c8ce6f0073979b38eaadcda013b65fefd2a82a9212cf1e34012605ef2")
addappid(251373, 1, "c1df1acfba0890fb181eb9341bdfa6386f87b9738420b14132de138977d52a4e")
