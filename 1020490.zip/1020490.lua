-- Lua provided by SkyAPI 
-- Game: AppID 1020490
addappid(1020490)
addappid(1020491, 1, "97c422c304da4664d53964b17b551905a7c4a33bfc966f5ea8e370a624bd0e72")
