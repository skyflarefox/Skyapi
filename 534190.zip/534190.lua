-- Lua provided by SkyAPI 
-- Game: Blink the Bulb
addappid(534190)
addappid(534191, 1, "3cf1ee3fbbe3d9b0d1f6ddb84223dc22ffcc85d5391a4a463f8499084eda6075")
