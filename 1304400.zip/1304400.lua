-- Lua provided by SkyAPI 
-- Game: AppID 1304400
addappid(1304400)
addappid(1304401, 1, "998c0599aacaed594dfb486f151467e0e57165053fc5d8d01f86da3d295b1585")
