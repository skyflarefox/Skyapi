-- Lua provided by SkyAPI 
-- Game: ENCODYA
addappid(1137450)
addappid(1137451, 1, "501e2311428175637a7d16acfdb67b0b7aeb6345e8307796b646822a89825c04")
