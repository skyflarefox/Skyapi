-- Lua provided by SkyAPI 
-- Game: SYMMETRIC;VISION Demo
addappid(2866200)
addappid(2866201, 1, "4bb5fa46fd4f48044c80910c10da60daf4accc49934b28d63d1fa7da30d25906")
