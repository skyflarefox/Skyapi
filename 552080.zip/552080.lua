-- Lua provided by SkyAPI 
-- Game: AppID 552080
addappid(552080)
addappid(552081, 1, "31f840aed6524a32bc4a071f538c4e6a51217a011a9fc0e148163728d7436fa2")
