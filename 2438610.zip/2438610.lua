-- Lua provided by SkyAPI 
-- Game: BE 忍者
addappid(2438610)
addappid(2438611, 1, "3971878a02d8b8529efffd3446032379d05c3a0a6a0c45692f7eec10f75f5c3a")
