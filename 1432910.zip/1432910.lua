-- Lua provided by SkyAPI 
-- Game: Godlike Burger
addappid(1432910)
addappid(1432911, 1, "5297145e4fda3277ada496c6af9f83f7bab55c27b2e55c69105b6546557d7166")
addappid(1670580, 0, "9b59574bdf6f03c848d2d2b71e01fdf2f091899cdb36c484e44d71051e91cc1b")
