-- Lua provided by SkyAPI 
-- Game: Ashen Empires
addappid(937380)
addappid(937381, 1, "a4b8c5c66811e6c4f59ee9b67b38e19fdf0980be30765f254e869b1a631c0509")
