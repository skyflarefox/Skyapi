-- Lua provided by SkyAPI 
-- Game: Vampire: The Masquerade - Reckoning of New York
addappid(2658720)
addappid(2658721, 1, "908bfe0ee03084b92b50fe278e3ab5318feb326f2629641078f42448c58636eb")
