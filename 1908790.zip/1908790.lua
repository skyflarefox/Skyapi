-- Lua provided by SkyAPI 
-- Game: Penny for Your Thoughts
addappid(1908790)
addappid(1908791, 1, "f924a70f4db741ad3153e80e679ef86b657886f85b7c17cb2730be5b0b95e784")
