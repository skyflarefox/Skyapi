-- Lua provided by SkyAPI 
-- Game: Faeland
addappid(1280080)
addappid(1280081, 1, "c48d5e95814120b9866a177114cc9db0a2eeff8afc69ca347f5fdfe23f488a37")
