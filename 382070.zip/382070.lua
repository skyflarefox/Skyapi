-- Lua provided by SkyAPI 
-- Game: Neoncube
addappid(382070)
addappid(382071, 1, "4b2b4ad6c54ffece4f3e607e72ac26d024090f442f3da52eddbf6d7d192f3aa5")
