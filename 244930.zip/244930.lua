-- Lua provided by SkyAPI 
-- Game: SNOW - The Ultimate Edition
addappid(244930)
addappid(244931, 1, "68a04c41820256641aab2e2ece89e9fe85ed5f29e8b74bbc8f08184c129d98d8")
addappid(244932, 1, "c2b7ba04b844b1b17e43e54b12e41fe26dbb58e5395efa4c00f331c19d6ee960")
addappid(244934, 1, "9119fb228785f766c6b25164f6be06426452e82b8f4ce42f8f3d9efa32728747")
addappid(244935, 1, "07c1aee91ec03ceb4db622bcd90243ae899b141a3075296a40a82f1bb497d3a7")
