-- Lua provided by SkyAPI 
-- Game: Strike Force 3
addappid(1525910)
addappid(1525911, 1, "ada8a67c6e409c156b0db4b4b1676f514208b9cbdccc24403240e63fd3e870aa")
