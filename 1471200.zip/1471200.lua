-- Lua provided by SkyAPI 
-- Game: AppID 1471200
addappid(1471200)
addappid(1471201, 1, "59f322c7fda27cb0d7e52930de89529211ca5ef7861c6d53fdc6dd9b38df042d")
addappid(1504540, 0, "c3264112153f04bce40d6f022fb32b4567b48ee2b046e38cb8c8e047a60828a6")
