-- Lua provided by SkyAPI 
-- Game: Comanche 4
addappid(32750)
addappid(32751, 1, "c1caa70d3925608e56cb72e954da6f3905cbe4e5f1235e7912bbaf5297ec3ecc")
