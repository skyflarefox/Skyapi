-- Lua provided by SkyAPI 
-- Game: NOYO-!
addappid(1093300)
addappid(1093301, 1, "5690a3c5135610c821816cc1e3c45058b5caf5c297cd6cde39c1693b4fba60f3")
