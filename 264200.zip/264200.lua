-- Lua provided by SkyAPI 
-- Game: One Finger Death Punch
addappid(264200)
addappid(264201, 1, "bbe95959e387f13bcbd0ee425ca2648f06dfcae360db177cf908bd52b131606c")
