-- Lua provided by SkyAPI 
-- Game: Gravity Wars
addappid(877150)
addappid(877151, 1, "af604224e880ee52d3bb9c32ffb26d972fad8f99a81974aefc296478146d4393")
addappid(1013230)
