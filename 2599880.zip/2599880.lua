-- Lua provided by SkyAPI 
-- Game: Happiness! Sakura Celebration!
addappid(2599880)
addappid(2599881, 1, "f6ab47742cfaf002c00e585b23c69769e6250c672135cc5d5d5b93afd68f18e5")
