-- Lua provided by SkyAPI 
-- Game: Bombshell
addappid(353190)
addappid(353191, 1, "10d76da71b40a188f4cc3db1487e1af2e67a4cbb1267984e26383bbcd869b24b")
addappid(437410, 1, "a12a4634815cd94463e46a91fd0e7b955975ab987471ad4ade0e65116ebefeda")
addappid(437580, 0, "768a98383186276c4bdbd016ae5adbafaac3504f670dc642adc8f844df2b1fe0")
