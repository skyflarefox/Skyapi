-- Lua provided by SkyAPI 
-- Game: Four Last Things
addappid(503400)
addappid(503401, 1, "cf7df1122ce42820efd08ac9a54c459a097f1a3b5de847969e283723ce185f49")
addappid(4562470)
