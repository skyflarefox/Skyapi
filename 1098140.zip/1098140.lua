-- Lua provided by SkyAPI 
-- Game: AppID 1098140
addappid(1098140)
addappid(1098141, 1, "e4da72c00daa4a88d246e14b0d59774460c4c6cb768b680ce0053a0a9eca1b61")
