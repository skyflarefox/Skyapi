-- Lua provided by SkyAPI 
-- Game: Monstrous Love
addappid(2011410)
addappid(2011411, 1, "2878adc34d0ca705f90d97d75f1af3aab3cd4214ea25f0edce223a5773632335")
addappid(2643760, 0, "bf5f2c751568bd5c169ebc2cc02464d1f428bcec8737868bc5676df2147c2fca")
