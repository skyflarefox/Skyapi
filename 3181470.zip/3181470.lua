-- Lua provided by SkyAPI 
-- Game: AppID 3181470
addappid(3181470)
addappid(3181471, 1, "5066773f16781ea886f5c11a6b839fd41ed71983bb0a7efb147712f5a44e847b")
