-- Lua provided by SkyAPI 
-- Game: Vendir: Plague of Lies
addappid(1478850)
addappid(1478851, 1, "996ea734501c30742789b0168b312fd19fda1cb77b41291f27ad49a5f0274ac5")
