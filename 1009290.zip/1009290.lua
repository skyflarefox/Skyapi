-- Lua provided by SkyAPI 
-- Game: SWORD ART ONLINE Alicization Lycoris
addappid(1009290)
addappid(1009291, 1, "d056e798388b47bfa05dc596efe9ae0b226e75296d2c87f950fb8aee7dbc2913")
