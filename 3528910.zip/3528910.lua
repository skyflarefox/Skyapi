-- Lua provided by SkyAPI 
-- Game: Assenizator
addappid(3528910)
addappid(3528911, 1, "55b3a1a1e39bdd2cc5f4bf2e2d76950708701e673499fef94cd76bbbb8b6ea95")
