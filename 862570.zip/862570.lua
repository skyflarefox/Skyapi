-- Lua provided by SkyAPI 
-- Game: Ding Dong XL
addappid(862570)
addappid(862571, 1, "7320a82dedc21bd57af1a37d48827e7af0fd64c3c0911a4c6b84c332fd2457ef")
