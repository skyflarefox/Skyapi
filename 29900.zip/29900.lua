-- Lua provided by SkyAPI 
-- Game: Dark Sector
addappid(29900)
addappid(29901, 1, "43ce2f5c2d91c970c793c79b3be452d3cb8eacaf7688d61aa75880dbda179912")
addappid(29902, 1, "dbc52e69070af3bc404201c9a6a4764206e6d673e0478aead1f8d0f5d2fe2d7c")
