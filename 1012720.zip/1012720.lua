-- Lua provided by SkyAPI 
-- Game: AppID 1012720
addappid(1012720)
addappid(1012721, 1, "8749dd1fafd7a70cfd39b54f79d571cae3e94cd023b27c8a07e846ed83596fef")
