-- Lua provided by SkyAPI 
-- Game: AppID 1398740
addappid(1398740)
addappid(1398741, 1, "7701810995c6f8d0188c52018b598e8bde6570d4fb193d202f778650fa6f15b4")
