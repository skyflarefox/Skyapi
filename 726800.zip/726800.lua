-- Lua provided by SkyAPI 
-- Game: AppID 726800
addappid(726800)
addappid(726801, 1, "3c1a63fa65f6e23c6eb50674d77fa7e9b23ffa62061c7b7c518ad21c8038ded7")
