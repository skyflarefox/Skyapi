-- Lua provided by SkyAPI 
-- Game: Takedown: Red Sabre
addappid(236510)
addappid(236511, 1, "8d8de4ac836313f7b2a5c1c2af773bd438c25e09fb851cb4960f0091016283d2")
addappid(236512, 1, "6c69370ed74678fd9096e565c4d359307731704a8c8bff9f31e72ee78eb5928f")
