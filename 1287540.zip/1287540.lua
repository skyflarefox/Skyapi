-- Lua provided by SkyAPI 
-- Game: AppID 1287540
addappid(1287540)
addappid(1287541, 1, "349f215bcc42a21c113013d88ecf4d4dcd11e194bd5a802e157231a96c4356f3")
