-- Lua provided by SkyAPI 
-- Game: The Pentest
addappid(1638670)
addappid(1638671, 1, "c1d245e465ee4527833f41ccca4432d1ed4af418ff4bf0c2bffc3fbb9386e982")
