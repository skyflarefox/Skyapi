-- Lua provided by SkyAPI 
-- Game: BioGun
addappid(1219240)
addappid(1219241, 1, "cd957a2de203b097e500729e4ed2071cf469711a22461c9aeeaba36858061e4e")
