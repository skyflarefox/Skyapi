-- Lua provided by SkyAPI 
-- Game: Applewood
addappid(1107470)
addappid(1107471, 1, "d7163567cc68ab1e35e89fb8fa7fc1edb2c09ed73c714d4c1b5351143837b87b")
