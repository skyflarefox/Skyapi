-- Lua provided by SkyAPI 
-- Game: 三国仁义传 The Righteousness: SanGuo
addappid(1927100)
addappid(1927101, 1, "5f1b50a5ed79920bac34674621d1a36e66f39c8e5e7db1a825f4dfc4ea4e75d6")
