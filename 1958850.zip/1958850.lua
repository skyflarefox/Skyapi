-- Lua provided by SkyAPI 
-- Game: REDACTED
addappid(1958850)
addappid(1958851, 1, "e4b6de86dd823405511aa49cd318ff6d2c22931b1640427b3602043827723a39")
