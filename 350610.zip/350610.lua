-- Lua provided by SkyAPI 
-- Game: Combat Cats
addappid(350610)
addappid(350611, 1, "4c783851bd5e3061f1724163c1b8875f3c134de35aa814c94ae8e262a8cb5e05")
