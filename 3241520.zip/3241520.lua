-- Lua provided by SkyAPI 
-- Game: SCP: Retrieval
addappid(3241520)
addappid(3241521, 1, "74e73a6a4585c329d96056085cc6467d38821b98ad5df42136d16f485a065d9c")
