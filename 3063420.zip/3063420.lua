-- Lua provided by SkyAPI 
-- Game: Coffee Quest VR
addappid(3063420)
addappid(3063421, 1, "862d57772c8647b13737d28481bab2e24261ddc3ff4473fce7111471be2b5eb7")
