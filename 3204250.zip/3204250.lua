-- Lua provided by SkyAPI 
-- Game: Lost But Found
addappid(3204250)
addappid(3204251, 1, "02f7ccd2d70fc07720713ec9b6050c50ab6cdc94da70f9d3bc957b7c1b8a3415")
