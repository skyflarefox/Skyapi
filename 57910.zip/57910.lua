-- Lua provided by SkyAPI 
-- Game: AppID 57910
addappid(57910)
addappid(57911, 1, "34b1c2cea46875a43c4701badd06cd3c72ae2b203914fee5ef77ee8d36873ec8")
