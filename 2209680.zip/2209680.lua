-- Lua provided by SkyAPI 
-- Game: Beach Invasion 1944
addappid(2209680)
addappid(2209681, 1, "8c3817a1fc90744498d552b6abfe7879c98fe0c824a7087f57fd9c8aef9386d5")
addappid(2255060, 0, "e7ac77d0e9491bcd58e2e150d07226da949dee1eabe5f0cf4343e8d1f078650a")
