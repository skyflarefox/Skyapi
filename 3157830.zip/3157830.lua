-- Lua provided by SkyAPI 
-- Game: AppID 3157830
addappid(3157830)
addappid(3157831, 1, "dabb58a44e22f5a1405da4dc59179c331fe5f0c8efd037a97dc2c58b2d85a683")
