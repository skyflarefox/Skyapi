-- Lua provided by SkyAPI 
-- Game: Fear Surrounds
addappid(1526490)
addappid(1526491, 1, "860a8f75aa96058cd70aac2c16b89aa9916dc1770ba8049c8c70614386e5d95d")
