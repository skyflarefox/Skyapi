-- Lua provided by SkyAPI 
-- Game: Dead End Junction
addappid(518280)
addappid(518281, 1, "9121e87c57baa1cde758533d6ed1fdc0cb0f1efff807f61c4b081302efb2d937")
