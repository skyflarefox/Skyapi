-- Lua provided by SkyAPI 
-- Game: AppID 2719160
addappid(2719160)
addappid(2719161, 1, "09414e3bc70d3b13b3e1145978229a49a56414f7aec9ed4eedc8598d31d720b6")
