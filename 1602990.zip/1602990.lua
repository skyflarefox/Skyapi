-- Lua provided by SkyAPI 
-- Game: POG
addappid(1602990)
addappid(1602991, 1, "46303c955e5f64c07e432bcf0e8d55ffa9989523e4e479266bc1dcf3e0f7359b")
