-- Lua provided by SkyAPI 
-- Game: TOP TRUCK DRIVER
addappid(1547820)
addappid(1547821, 1, "95d71f663c0471c53fc4ba5aa53e7acbbb57447651f91d79dd02b3445609968b")
