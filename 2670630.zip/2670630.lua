-- Lua provided by SkyAPI 
-- Game: Supermarket Simulator
addappid(2670630)
addappid(2670631, 1, "72fc26c211612ffaa7b30cdfea152be9628668260d7f8c375980e0f96e445701")
