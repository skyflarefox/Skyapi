-- Lua provided by SkyAPI 
-- Game: AppID 1253280
addappid(1253280)
addappid(1253281, 1, "a700003f2a4eebd877e5e6e1bd42965fa80dc8aaa5a01592eae4f48a6079a9c9")
