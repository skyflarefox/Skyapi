-- Lua provided by SkyAPI 
-- Game: Forspoken
addappid(1680880)
addappid(1680881, 1, "3a714f498834b6b17b15fd1864da4a1158074207edbc8e94912f7412adac8f70")
