-- Lua provided by SkyAPI 
-- Game: Wrestling Revolution 2D
addappid(673910)
addappid(673911, 1, "6c096f24ce655017e7a37dca029101d121f1fbeb6f14aa7e5413304affdaf70e")
