-- Lua provided by SkyAPI 
-- Game: Fallen Cube
addappid(670370)
addappid(670371, 1, "4024f9dfb0dc43d89587eb94e99ce3aaeb331228f6e89624f1b48c1c340123d0")
