-- Lua provided by SkyAPI 
-- Game: AppID 2904710
addappid(2904710)
addappid(2904711, 1, "96d067029756a9710fc9f5776e3a53e2a47ae06c2e7feab7e31f8e6b17925a5a")
