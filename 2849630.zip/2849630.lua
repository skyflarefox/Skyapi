-- Lua provided by SkyAPI 
-- Game: AppID 2849630
addappid(2849630)
addappid(2849631, 1, "70bc536364da4718c2e568912403fa2545531ae0857f872a358febbaf82fcd28")
