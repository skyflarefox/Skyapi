-- Lua provided by SkyAPI 
-- Game: Mushroom Cats 2
addappid(1258310)
addappid(1258311, 1, "0738a8f96f3926d9ae1254ac79b857539a15be21e7c291f8a4073e8eb89db450")
