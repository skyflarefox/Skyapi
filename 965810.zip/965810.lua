-- Lua provided by SkyAPI 
-- Game: Kara no Shojo
addappid(965810)
addappid(965811, 1, "6e208d5e4e670f7eab56635f18203f18665e4cc48e69e3191576f3677d8b415f")
