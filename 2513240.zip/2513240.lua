-- Lua provided by SkyAPI 
-- Game: Hero Tale
addappid(2513240)
addappid(2513241, 1, "091a6d1ae3e9592f7fa3e8bae5fc376cc9f055c19124d8a56dec7716403056c4")
