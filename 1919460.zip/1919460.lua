-- Lua provided by SkyAPI 
-- Game: Seraph's Last Stand
addappid(1919460)
addappid(1919461, 1, "66b0ae1a35080206bf919e3ab825d999428e66f6accf03b5ab7f3a96e2779914")
