-- Lua provided by SkyAPI 
-- Game: My New Memories: The Beginning
addappid(2952570)
addappid(2952571, 1, "ccae472c9c7c2aa719bdb01885fbef02c1142428be75e073d411484bd0ee2e2e")
