-- Lua provided by SkyAPI 
-- Game: Jennifer's Fragments
addappid(2608570)
addappid(2608571, 1, "1b5a632b595d8de062ef21cb28969315468d14277d86f87f37a8669c73bf8e2f")
