-- Lua provided by SkyAPI 
-- Game: Coffee flavor of love 咖啡甜恋
addappid(1508920)
addappid(1508921, 1, "b510d46d2ec7f7e8882bec9da83bcf48bc3b938066d92f885f24dba3dc39a0ca")
addappid(1508922, 1, "e5a00f3ad16ab7a386d450757835afc24308fe151fa5906dbf09b9b77c9b3edf")
