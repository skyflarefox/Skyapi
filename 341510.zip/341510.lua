-- Lua provided by SkyAPI 
-- Game: Crayon Chronicles
addappid(341510)
addappid(341511, 1, "2b3f12188044c3523432d11f9cdcd748c5d7dffa4c32ef86c9e2d5de389ef992")
