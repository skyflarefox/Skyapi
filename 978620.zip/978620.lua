-- Lua provided by SkyAPI 
-- Game: AppID 978620
addappid(978620)
addappid(978621, 1, "78d3a7982d8983d97fd39587a0f4a6faa2b24761fff6b121da821baed6c66821")
