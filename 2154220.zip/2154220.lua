-- Lua provided by SkyAPI 
-- Game: Decarnation Demo
addappid(2154220)
addappid(2154221, 1, "504ff0e640c9aa5bf80183e1fc592ff0a9d804478e2165697d115300e60696fe")
