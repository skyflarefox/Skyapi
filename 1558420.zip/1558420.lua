-- Lua provided by SkyAPI 
-- Game: Galaxy Arena
addappid(1558420)
addappid(1558421, 1, "295361a0a6a75668e7b1fe06763866ef0b8c72ee4027d944c321a8c2401e6879")
