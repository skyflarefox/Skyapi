-- Lua provided by SkyAPI 
-- Game: Blocks by Google
addappid(533970)
addappid(533971, 1, "b4958e80522de8fd5fa425e1473ab228cbd1e4495b1442a48cbcca3af07141b2")
