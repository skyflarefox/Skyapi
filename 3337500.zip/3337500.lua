-- Lua provided by SkyAPI 
-- Game: AppID 3337500
addappid(3337500)
addappid(3337501, 1, "b8f73aaec1cb7e1f494ce82b09e3ba21babbd58a0b1e123dbb7e451b528dc2c9")
