-- Lua provided by SkyAPI 
-- Game: School Bus Driver Simulator
addappid(1977280)
addappid(1977281, 1, "037f26a0b58fd933f56b55364c0effea90c49bc3c2f7c6f7b88a9a7c131c694a")
