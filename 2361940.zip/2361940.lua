-- Lua provided by SkyAPI 
-- Game: Ninja Golf 2
addappid(2361940)
addappid(2361941, 1, "7e9d6d6511f0d8e7256b1ce60f3e26e028215aac88981d3e6640e8bd8b9bc205")
