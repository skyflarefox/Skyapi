-- Lua provided by SkyAPI 
-- Game: No1Left
addappid(409580)
addappid(409581, 1, "6186568b1b17a79b65b1120274347d3f16c4118c98916af2c85eec69570896e0")
