-- Lua provided by SkyAPI 
-- Game: Good Guy Card
addappid(839640)
addappid(839641, 1, "6db6520eff37d57af4f9bb1c4143e5795e652e48dd8eb9090c2b368cb70164b5")
