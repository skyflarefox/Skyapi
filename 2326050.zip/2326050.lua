-- Lua provided by SkyAPI 
-- Game: Dethroned
addappid(2326050)
addappid(2326051, 1, "ed31c37a4714322cef099d0e37d2241543c1f3fe79601ee0341e85a5104c1a93")
