-- Lua provided by SkyAPI 
-- Game: Intravenous 2
addappid(2608270)
addappid(2608271, 1, "65303bb0b084fda7e68b6e2dc146d2d0e42df675c4fd522649ad8dc41cea69e5")
addappid(3116710, 0, "e4dc2f66d1a61c0ff2f0249ab17212c51cba476048e43aaf576ee8afbcd80706")
addappid(3391540, 0, "0dea1e881b2c4b6b457f09a52489a01823c4a3982790d26a13c6856e38b19003")
