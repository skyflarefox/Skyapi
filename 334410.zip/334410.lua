-- Lua provided by SkyAPI 
-- Game: JUMP
addappid(334410)
addappid(334411, 1, "8379d03d09d41333dda41597654f16437a0a4ebad7660a69946cce89fa36915b")
