-- Lua provided by SkyAPI 
-- Game: Futa Spell
addappid(1879670)
addappid(1879671, 1, "be7b019a73558db5336ba23fae7825ffc980c10f7a7a9733f932f7733095d7bb")
