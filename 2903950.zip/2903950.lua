-- Lua provided by SkyAPI 
-- Game: Master Detective Archives: RAIN CODE Plus
addappid(2903950)
addappid(2903951, 1, "a12bd5bdeb914bcfc0be723089d2e8765ae48f4c1ebf378f37da0ba758b6c6c3")
