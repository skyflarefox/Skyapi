-- Lua provided by SkyAPI 
-- Game: No.L85
addappid(1515830)
addappid(1515831, 1, "b000addff00565af167b3c5555445a65653b8aa5e7b8f28e77eae0b8a1c437cb")
