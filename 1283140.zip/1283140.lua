-- Lua provided by SkyAPI 
-- Game: Burn Me Twice
addappid(1283140)
addappid(1283141, 1, "ec593357c8622edd3bba4fbb2c08a09228d592d198be21972b55c48685fa074a")
