-- Lua provided by SkyAPI 
-- Game: Card-en-Ciel Soundtrack
addappid(3306340)
addappid(3306341, 1, "02b3cbb419684e4c81a880ac7a8f54c6a8b4d89928133d1c8b7a15b1d44a3928")
