-- Lua provided by SkyAPI 
-- Game: Meowhiss the snake
addappid(2733670)
addappid(2733671, 1, "f9ff0b7cb1f67f6a1584c8f74171990954eb39f139da69c236391554d720a766")
