-- Lua provided by SkyAPI 
-- Game: ROGUE LIGHT DECK BUILDER
addappid(3149370)
addappid(3149371, 1, "09424bc1480e0fa4dc505c5f1007b724b4b6287f7a88f2fe9dcb911144d392b1")
