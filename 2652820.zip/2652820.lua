-- Lua provided by SkyAPI 
-- Game: Mechanical Trap
addappid(2652820)
addappid(2652821, 1, "545951eb7e95c3f85293d04d82c8278653db1719d04df3bae4069f7d7bcd4c47")
