-- Lua provided by SkyAPI 
-- Game: Ancient Rush 2
addappid(835560)
addappid(835561, 1, "9924be2513da1afa1063e7cc2ee8d499f7ea280c7ceeaf4109b23583c342f3f5")
