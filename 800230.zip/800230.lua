-- Lua provided by SkyAPI 
-- Game: AppID 800230
addappid(800230)
addappid(800231, 1, "f93da7ab9c3bc40a2821ae5419ee69eb9ded202a7dcbc866ac718e171c1e5d46")
addappid(800232, 1, "ec379250cfa824795bde51d2ab12d672199db3be432ff3a1e277b3792bff2d93")
addappid(800233, 1, "179b26fc0ea74c4e62d4da0b770bed5d6e24d645baac973b4d7d0dd4c0cd5464")
