-- Lua provided by SkyAPI 
-- Game: Rum & Gun
addappid(1210800)
addappid(1210801, 1, "cb27fb9f49dcb73a382aa83a2e4ff08379720daafa530a9283a00acb71732c2c")
