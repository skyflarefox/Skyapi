-- Lua provided by SkyAPI 
-- Game: Black Skylands: Origins
addappid(1286530)
addappid(1286531, 1, "07655f562e468f6fc8daaed3afd34c2a7850657a372c35cb9f7c46ab22ebd27c")
