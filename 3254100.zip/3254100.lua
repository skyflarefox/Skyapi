-- Lua provided by SkyAPI 
-- Game: AppID 3254100
addappid(3254100)
addappid(3254101, 1, "7bccf428831a0c6ac954c039fbe9276721f013cab39ceb5e25ee4c3b2a8c78fc")
