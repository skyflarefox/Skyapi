-- Lua provided by SkyAPI 
-- Game: Kitchen Simulator 2
addappid(688020)
addappid(688021, 1, "669434479b9b8d57f6ebafcec293681e21aa223ea64856a7a7d9510ba7f9370b")
