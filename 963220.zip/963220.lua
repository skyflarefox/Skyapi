-- Lua provided by SkyAPI 
-- Game: The Bluecoats: North & South
addappid(963220)
addappid(963221, 1, "b2cc42d06603760d200006d293aba4a73353c949bbed7735186913bcf33263c3")
