-- Lua provided by SkyAPI 
-- Game: Little Kitty, Big City - Customizer Demo
addappid(2411900)
addappid(2411901, 1, "f76f375085695245c834d4e5df67e3fbb899d099bb629f8607ed05e8c69e116d")
