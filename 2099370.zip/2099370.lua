-- Lua provided by SkyAPI 
-- Game: PIP
addappid(2099370)
addappid(2099371, 1, "b60fbc3aef2b8fc76f3578a6c31acd9a90cd128d377ee46e23658520f9467444")
