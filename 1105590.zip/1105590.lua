-- Lua provided by SkyAPI 
-- Game: Dream Cycle
addappid(1105590)
addappid(1105591, 1, "d4a52ea4696ad4df5cf285f873b576fd94ee58da68021d08a8f1882c017298ea")
