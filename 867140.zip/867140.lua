-- Lua provided by SkyAPI 
-- Game: AppID 867140
addappid(867140)
addappid(867141, 1, "4e1e684e1b1279b2e20c223e0d4560311fd04b279060e1155a5b56b99a004b57")
