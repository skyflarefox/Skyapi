-- Lua provided by SkyAPI 
-- Game: AppID 3781380
addappid(3781380)
addappid(3781381, 1, "b7f22888ff5b4e754e97db6019eb903a05f7384500ee35d4c5855eb6e9dc1105")
