-- Lua provided by SkyAPI 
-- Game: AppID 2565890
addappid(2565890)
addappid(2565891, 1, "41a2b6f07360de3dc5771827b0c2e258a7a724ebb88188d1fb71ce970c943198")
