-- Lua provided by SkyAPI 
-- Game: 风流公子romantic young man
addappid(2829600)
addappid(2829601, 1, "fbb8036b1c4203d81c4daf47a7a87baa3c68150a3ab491f63a2f17457d95444b")
addappid(2857950, 0, "beeb055ff2710be8476cd907d1544ba338d759a722722ac3cab0cf2f61aaa95d")
