-- Lua provided by SkyAPI 
-- Game: Concord™
addappid(2443720)
addappid(2443721, 1, "f0892830a844873bbfba514f05ad5a9c1da6fc15e033663ca1bc65ba2b821c6d")
