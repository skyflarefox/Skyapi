-- Lua provided by SkyAPI 
-- Game: Retirement Simulator
addappid(1220840)
addappid(1220841, 1, "ef66866d11e6b3186a9e0ce7ababa181e97149742fc73c7b5c132d8207e34f89")
