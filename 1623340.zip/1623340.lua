-- Lua provided by SkyAPI 
-- Game: 3D Hentai Puzzle 2
addappid(1623340)
addappid(1623341, 1, "e05f74cef3390e258ab0bb21b587b9d4c4897c8b80ad27bb43036f63f6a5bde2")
