-- Lua provided by SkyAPI 
-- Game: Casting Couch Simulator
addappid(1355960)
addappid(1355961, 1, "a222e5e307aa4bf32d7fbb426d9156b9772351d0aea32dbf10de1ee443c15e14")
