-- Lua provided by SkyAPI 
-- Game: AHEGAL SEASONS
addappid(1106860)
addappid(1106861, 1, "e6d0bb39fc6c297eaf42f40caa2374bd2f16604a4161acc97cc27fda96bcb88a")
