-- Lua provided by SkyAPI 
-- Game: Naughty Queens
addappid(2642090)
addappid(2642091, 1, "394c7f08d80469bc17ebd3ce8ac76d32dec8b5ea1b5915c169bbc0f250484684")
