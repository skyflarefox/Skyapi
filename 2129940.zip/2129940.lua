-- Lua provided by SkyAPI 
-- Game: ZombieSquad Playtest
addappid(2129940)
addappid(2129941, 1, "4b6fbf39f7b167385e386df60dfccb1b51e3a4f0c74d9ba1c0d8ee20ed4b8c4d")
