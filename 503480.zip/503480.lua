-- Lua provided by SkyAPI 
-- Game: AppID 503480
addappid(503480)
addappid(503481, 1, "0a7a1999cb8d6d31f073841edd6c3c7e8c427aa85954cb26b59f3e468b635df7")
