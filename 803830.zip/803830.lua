-- Lua provided by SkyAPI 
-- Game: AppID 803830
addappid(803830)
addappid(803831, 1, "6edf3570ac0ff1370f3e15d7d04e7db4632a996d0c3e7547397a60b67eaa45bb")
