-- Lua provided by SkyAPI 
-- Game: Cloudpunk
addappid(746850)
addappid(746851, 1, "ed83d35dc6be8e31e1ecfc8c93f64adb695d5079b751e42eb509e0d07542b1cb")
