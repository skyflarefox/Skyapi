-- Lua provided by SkyAPI 
-- Game: AppID 3199200
addappid(3199200)
addappid(3199201, 1, "acb6f59b540941d329241a3aa3a34ac2aaed0228d8da377385bd3f25c769f98e")
