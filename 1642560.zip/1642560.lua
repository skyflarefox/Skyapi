-- Lua provided by SkyAPI 
-- Game: Stardom MiniGames
addappid(1642560)
addappid(1642561, 1, "4c8cd7aedc7641ee55d58564a6ec0d31aaaa40c510256b05d6e32f34e818bb76")
