-- Lua provided by SkyAPI 
-- Game: rush
addappid(2653500)
addappid(2653501, 1, "4496fb442a17c981bbb765cba57f59410f4596b7ec3402ca9c504b215390f7f2")
