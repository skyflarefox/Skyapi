-- Lua provided by SkyAPI 
-- Game: rFactor 2
addappid(365960)
addappid(365961, 1, "e1341e8323a5e1b100e4ab63a6b513d40d8e1bb511bae72cf3297dcf63fed844")
