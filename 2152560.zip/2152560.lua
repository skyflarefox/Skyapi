-- Lua provided by SkyAPI 
-- Game: Airline Flight Attendant Simulator VR
addappid(2152560)
addappid(2152561, 1, "304aab420bf4687d90a03e2614f77b7b1b0bc3b0f7876d31ec2bdb4919e1205c")
