-- Lua provided by SkyAPI 
-- Game: AppID 1271070
addappid(1271070)
addappid(1271071, 1, "67c7e4993de80a2c8d0e5af2f35c3381efc8e30694963bfb81f715d4f286ae97")
