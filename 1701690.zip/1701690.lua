-- Lua provided by SkyAPI 
-- Game: Erotic Jigsaw Puzzle 5
addappid(1701690)
addappid(1701691, 1, "eac8be9a9e29be991bfdc82333ba0f15afa76a8e2edf3d0758199cc5e87d984c")
addappid(1704100, 0, "c34d70e5abc330a5e621a97f0332879e75685a56f7bb8938d43ebbcafbaf8c82")
