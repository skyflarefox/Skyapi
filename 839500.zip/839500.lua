-- Lua provided by SkyAPI 
-- Game: AppID 839500
addappid(839500)
addappid(839501, 1, "5801e055f5d842f4570c7e197f909da1a6d3fe76be101918c2f2e43b240d5f0c")
