-- Lua provided by SkyAPI 
-- Game: Damned Hand
addappid(1367860)
addappid(1367861, 1, "708ed2760937c4b301baa376ce415f7aad9c4e0da01d8e64868f81a333d1333e")
addappid(1472720)
