-- Lua provided by SkyAPI 
-- Game: Card Storm Idle
addappid(1734280)
addappid(1734281, 1, "0742054cf519fd30f7864302643537af4533fc756b7681babca2d29a4a2fbdde")
