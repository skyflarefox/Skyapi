-- Lua provided by SkyAPI 
-- Game: Mandragora: Whispers of the Witch Tree
addappid(1721060)
addappid(1721061, 1, "306438da4a61fac40cb7311f983967fcfca6258b8bd766b48605199f1c19c37c")
addappid(3352660, 0, "45bdc1425936ffac9f364dbfe269a725fe18985b08b48927638227e157786a39")
