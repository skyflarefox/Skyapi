-- Lua provided by SkyAPI 
-- Game: Laser Lasso BALL
addappid(502700)
addappid(502701, 1, "179c54c61e2ab941a5158842ce7733dcbc593476ac84db9d66c2215a2b1b5e5f")
