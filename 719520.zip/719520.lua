-- Lua provided by SkyAPI 
-- Game: Spectro
addappid(719520)
addappid(719521, 1, "99c9202ba6e706f804fb7ce7a5d5ed22b9591236b67f138457cb3bd6e504c6db")
