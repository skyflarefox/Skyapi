-- Lua provided by SkyAPI 
-- Game: SEIKEN-MANIFESTIA
addappid(1482490)
addappid(1482491, 1, "36bdb0bef3b75b3730c22bfec20f1c74725402f176c882c23be8b9a94a6d2eff")
addappid(1482492, 1, "bc536f9656c80bfa3bcca722b86108b55f1dafa5cf3ca108aa26fb1b27b38186")
