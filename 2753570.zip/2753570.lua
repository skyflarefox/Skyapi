-- Lua provided by SkyAPI 
-- Game: Foot Serve
addappid(2753570)
addappid(2753571, 1, "a0eecf1035f91f778d931a7b03d84b9228e91b5e6b4748cf0fdfcca97f7ee0f8")
