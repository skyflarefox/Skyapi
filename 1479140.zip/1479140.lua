-- Lua provided by SkyAPI 
-- Game: AppID 1479140
addappid(1479140)
addappid(1479141, 1, "a9fb539d8f51721164cf77f8eae5920f78569a47156b69a61f7aa1435f1f2343")
