-- Lua provided by SkyAPI 
-- Game: Sailwind
addappid(1764530)
addappid(1764531, 1, "907ea10d78e84b92043fd808e954ab7d4fa8de5d3eeab0227d2488d7b899cb30")
