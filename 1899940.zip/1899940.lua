-- Lua provided by SkyAPI 
-- Game: AppID 1899940
addappid(1899940)
addappid(1899941, 1, "d119066657f81c74637a9339b4c92ffab19c43ec0d61db5880e091e11699dc2e")
