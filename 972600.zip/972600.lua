-- Lua provided by SkyAPI 
-- Game: AppID 972600
addappid(972600)
addappid(972601, 1, "0a6e8f8870cd0f82c51efb68bb94cae44b560ea92e04866408657c5307dba0f9")
