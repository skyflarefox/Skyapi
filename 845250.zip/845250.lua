-- Lua provided by SkyAPI 
-- Game: Fish Tycoon 2: Virtual Aquarium
addappid(845250)
addappid(845251, 1, "54d77b9f169767841285ff00bde2811043ad46a083e8cc2685bf397df5c9d0d8")
addappid(845252, 1, "1973f721405961b6bb1386875d86ddf91e4780031d932506235984818aaed5da")
