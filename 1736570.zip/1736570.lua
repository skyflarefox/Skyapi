-- Lua provided by SkyAPI 
-- Game: Deflector: Specimen Zero
addappid(1736570)
addappid(1736571, 1, "ea171882537ebdbcc855ad589bef8c5fbdfa1a7bc40943216d554e4838e1eef0")
