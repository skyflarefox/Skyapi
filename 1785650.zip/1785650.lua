-- Lua provided by SkyAPI 
-- Game: TopSpin 2K25
addappid(1785650)
addappid(1785651, 1, "378291ca5d9f448851858d96883fd163188369d47a68b51012798acd9dc5e5b1")
