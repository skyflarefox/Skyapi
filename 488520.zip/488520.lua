-- Lua provided by SkyAPI 
-- Game: AppID 488520
addappid(488520)
addappid(488521, 1, "ae3f8910792863533d6964db3498482c59bbb47414ddc6b823e960858eadb7ee")
