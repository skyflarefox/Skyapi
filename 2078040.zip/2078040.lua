-- Lua provided by SkyAPI 
-- Game: White Day 2: The Flower That Tells Lies - Complete Edition
addappid(2078040)
addappid(2078041, 1, "5472ba4226b347600963043344b79eeb090dd333fe9a97cdf09c3f310b4e15af")
addappid(2079900)
addappid(2277190)
addappid(2277191)
addappid(2277480)
addappid(2277481)
addappid(2279900)
addappid(2279901)
addappid(2279902)
addappid(2279903)
