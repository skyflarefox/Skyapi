-- Lua provided by SkyAPI 
-- Game: Pinstripe Original Soundtrack
addappid(332740)
addappid(332741, 1, "0495111bdf6b7aeffef03572fe169a6e54056d93342ba861dc2795608bd3df93")
