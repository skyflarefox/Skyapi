-- Lua provided by SkyAPI 
-- Game: 幻想三国志2
addappid(1457630)
addappid(1457631, 1, "dca69517e36ff71a3c96e112ff619452fef2d1a494b1f6c602671ded590ea29f")
addappid(1457632, 1, "9e3a397ed158baa9900a7c39f192b0223c356fe9c033124178e3bc4f0f8ca6a6")
