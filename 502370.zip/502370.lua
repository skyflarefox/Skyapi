-- Lua provided by SkyAPI 
-- Game: Warhammer 40,000: Sanctus Reach (Classic)
addappid(502370)
addappid(502371, 1, "19996d49b389b4203817159379b7a56684311727a0525fdd45a7d1e8ee924c3d")
