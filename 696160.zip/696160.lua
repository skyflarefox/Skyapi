-- Lua provided by SkyAPI 
-- Game: Necromancer Accountant
addappid(696160)
addappid(696161, 1, "54e90d352745ea40111f68ede0d9ec4466091a860baefc1090e233ce7e32b6b2")
