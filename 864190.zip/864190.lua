-- Lua provided by SkyAPI 
-- Game: 3, 2, 1, SURVIVE !
addappid(864190)
addappid(864191, 1, "9cead3b0e49dfa6e46a3ac35f3f2fb052f736c3cdeb9ae98db38df6dbb8a232b")
