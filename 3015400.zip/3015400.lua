-- Lua provided by SkyAPI 
-- Game: AppID 3015400
addappid(3015400)
addappid(3015401, 1, "5b007486db2b5095ee614d20851c1b9e113a28e5037f1fa003e7554a82a21a64")
