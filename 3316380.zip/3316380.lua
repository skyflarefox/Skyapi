-- Lua provided by SkyAPI 
-- Game: Lilac 0
addappid(3316380)
addappid(3316381, 1, "72fc01c656a5b306d4de660ede42c65cad8b48c76aaad2b2c07e921ecd6d832f")
