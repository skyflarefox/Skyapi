-- Lua provided by SkyAPI 
-- Game: AppID 1063040
addappid(1063040)
addappid(1063041, 1, "e688df5521598d13739bd33e4f9940dfd14b4d36f8a79a360e5a1030c4f38281")
