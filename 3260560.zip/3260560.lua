-- Lua provided by SkyAPI 
-- Game: AppID 3260560
addappid(3260560)
addappid(3260561, 1, "49b254c2170fbcd6311f07732c0345f3ac1f17a026b6ab800af1646fa231f965")
