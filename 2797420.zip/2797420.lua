-- Lua provided by SkyAPI 
-- Game: Yuri Sword Saga
addappid(2797420)
addappid(2797421, 1, "8bc09468ea576e96b9344fa8dc3910a19ca2e80fb9550d12c2b9b2ba77234d26")
addappid(3236820, 0, "0f0d79dd93699bb50eb4f9b19d73a7ff8cc790961ea45984b81a6ac853e462d9")
