-- Lua provided by SkyAPI 
-- Game: AppID 1078760
addappid(1078760)
addappid(1078761, 1, "19540c6e349a1a7ada84247e525c19397874db503244bf7956e4167e1e9c0b74")
