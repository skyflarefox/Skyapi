-- Lua provided by SkyAPI 
-- Game: No Ghost in Stay Home
addappid(1645640)
addappid(1645641, 1, "31259b86369d37a1faa37ae25da58f4ce9ae61f1affdd59d71d822c6f5fec10c")
