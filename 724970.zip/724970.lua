-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(724970)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(724974,0,"d0d23caad120c2378acf7a42c89ab1c58b41442bba25c86f73efb0d255bcf147")
setManifestid(724974,"1833098542592905705")
addappid(724972,0,"cf46c30f82f465317a0f0a2968a2e488c659f0362e9d4f75754a62d899ca510a")
setManifestid(724972,"8091259143722160155")
addappid(724973,0,"890cac5eb2d41a03d5d1c0125cdab7e094617598fb061cf051b28842f77e4eae")
setManifestid(724973,"6294021704624651499")