-- Lua provided by SkyAPI 
-- Game: Blade & Soul NEO
addappid(3669060)
addappid(3669061, 1, "954cf335a2da6fa57e524ef0408fb1ee568a8dfcbed10abfb8afe4a81d0dca0c")
