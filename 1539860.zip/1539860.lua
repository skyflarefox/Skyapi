-- Lua provided by SkyAPI 
-- Game: AppID 1539860
addappid(1539860)
addappid(1539861, 1, "2ad591da0335bdc33f8701ed5b7f073ae47fcb91d4edd0ba5f3f45b2a6d4f785")
