-- Lua provided by SkyAPI 
-- Game: AppID 637960
addappid(637960)
addappid(637961, 1, "c9fc22d203ef3372040f0128f6fae60c6144562e5dd03465b0427afb5efc89c9")
