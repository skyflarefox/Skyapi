-- Lua provided by SkyAPI 
-- Game: Aqua Moto Racing Utopia
addappid(468100)
addappid(468101, 1, "bdeb5d33cd5df11889d1459da0d7ce609025680160e12ae8c7ffbefef8954acb")
addappid(468102, 1, "a3f0773a23e82a3ab33047441ceceef46afae2bdb3773f9e63ae2f1b1c718194")
