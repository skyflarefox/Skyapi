-- Lua provided by SkyAPI 
-- Game: The Final Take
addappid(400510)
addappid(400511, 1, "69296ae450c080f99f6aa733de48aa7139a030d1490f0ce8f765c28bd68dfdb1")
addappid(400512, 1, "777f9170436109853997de7cb25eff75faaf762533b9b5e5d900213f9de3f325")
addappid(400513, 1, "85d13ead783c76a560cfabf7daae9783c416daef55a173e8c8578ad900b70178")
