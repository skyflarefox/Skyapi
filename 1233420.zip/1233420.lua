-- Lua provided by SkyAPI 
-- Game: AppID 1233420
addappid(1233420)
addappid(1233421, 1, "73be1385efaea6676c75268901ce1462b915b9ad4c44f33fb824de14bbdcc27e")
