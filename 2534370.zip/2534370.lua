-- Lua provided by SkyAPI 
-- Game: Yars Rising
addappid(2534370)
addappid(2534371, 1, "afe81b306f8b11d39a36bef2e54ffdca862afd8648b3adb02c60c4c1f661fc01")
