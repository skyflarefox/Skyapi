-- Lua provided by SkyAPI 
-- Game: Cypherpunk Essentials
addappid(1700250)
addappid(1700251, 1, "b223abfca270e05a33413b52e23b1b0a9a3badfe588e242857d720941f7d61fa")
