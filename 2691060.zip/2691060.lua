-- Lua provided by SkyAPI 
-- Game: AppID 2691060
addappid(2691060)
addappid(2691061, 1, "7dce7e15aed1f824bd471747bbc0d733c55b4a50907415d00f1065b9103ab208")
