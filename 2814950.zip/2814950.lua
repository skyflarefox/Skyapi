-- Lua provided by SkyAPI 
-- Game: AppID 2814950
addappid(2814950)
addappid(2814951, 1, "7f0d3e883fab68900fb205c94befff009590f26762a107207e166f7e59d7a068")
