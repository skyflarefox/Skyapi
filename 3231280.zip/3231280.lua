-- Lua provided by SkyAPI 
-- Game: DreamWorld Playtest
addappid(3231280)
addappid(3231281, 1, "5dd2b0230616c985f91f46d6b63137ce8ea2f15d1e5447892068e3f6aab4fcb5")
