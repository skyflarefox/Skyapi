-- Lua provided by SkyAPI 
-- Game: Mega Veg Man
addappid(1426330)
addappid(1426331, 1, "2850ea1362d4da07851096a6524e6f726412cf2dd9e438f517c7af6c075c497b")
