-- Lua provided by SkyAPI 
-- Game: AppID 1558740
addappid(1558740)
addappid(1558741, 1, "2a69d9f5e532a4f054a9d90164e105c7773f0492c872dbd4b9573c22835399a2")
