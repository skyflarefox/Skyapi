-- Lua provided by SkyAPI 
-- Game: Happy's Humble Burger Farm: Landing Gear (OST)
addappid(1832430)
addappid(1832431, 1, "a8e5b2f872fb3b090e11f5ed4a61b56ce2672955945d2a508706949d575986e8")
