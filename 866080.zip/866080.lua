-- Lua provided by SkyAPI 
-- Game: AppID 866080
addappid(866080)
addappid(866081, 1, "59c782fb24b7048e48aefb7a79e192c85757d2d4e350ccfb12019cf659473cae")
