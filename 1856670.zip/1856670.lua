-- Lua provided by SkyAPI 
-- Game: AppID 1856670
addappid(1856670)
addappid(1856671, 1, "81c3e2d8b4be0737e09f9d6a0d264b2ca65c3c0c7ffdde7af5fe89122ce85592")
