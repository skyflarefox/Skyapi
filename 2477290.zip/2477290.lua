-- Lua provided by SkyAPI 
-- Game: Half-Life 2 RTX
addappid(2477290)
addappid(2477291, 1, "c2ed46a3853ae84c30e191f69f3d3b0b0760008364bfdb03b38ed00cbfb0d22a")
