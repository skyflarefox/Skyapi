-- Lua provided by SkyAPI 
-- Game: Dwerve
addappid(1132760)
addappid(1132761, 1, "24be484eec15129b698c5ead024658c0bdced8d88f97319e6aebc0afa8b7ae9c")
