-- Lua provided by SkyAPI 
-- Game: The Cleaning Game
addappid(3281900)
addappid(3281901, 1, "78e032de5169424fa10309c6b0d28cc52211ed410ee3b4c876dc6368e8c745c9")
