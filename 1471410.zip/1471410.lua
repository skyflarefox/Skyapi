-- Lua provided by SkyAPI 
-- Game: AppID 1471410
addappid(1471410)
addappid(1471411, 1, "7736e6becbf754713c9a4974b4accd1e7eea9cc5f22721a9899ccb43010a8398")
