-- Lua provided by SkyAPI 
-- Game: This Company Of Mine
addappid(3263730)
addappid(3263731, 1, "bda1a4bf093d073ac35fb84166b895a29dbb9c8dd6e3b906aa06ab1c6f73f871")
