-- Lua provided by SkyAPI 
-- Game: Infinite sky
addappid(1714640)
addappid(1714641, 1, "25b8d85ca5b5acee0fa1749635de6ac70d06c1a9116a75a5b11136ec2e80996f")
