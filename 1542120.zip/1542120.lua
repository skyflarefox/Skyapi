-- Lua provided by SkyAPI 
-- Game: AppID 1542120
addappid(1542120)
addappid(1542121, 1, "61cff5e76f30e85e129afd6e7d119134e7ee1cbec244ac593f2c7217612529e4")
