-- Lua provided by SkyAPI 
-- Game: AppID 1233200
addappid(1233200)
addappid(1233201, 1, "a52e98e8a98ac324f73b30a1789c95a9d819bd8e3c3283d3d09695eed89ea440")
