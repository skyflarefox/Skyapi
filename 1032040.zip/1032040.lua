-- Lua provided by SkyAPI 
-- Game: 龍炎高校伝説２ The Legend of the Dragonflame High School 2
addappid(1032040)
addappid(1032041, 1, "5b06342f80ad8e3caada83cc76e25cd63166d71af1168976c84c9a199d2190d9")
