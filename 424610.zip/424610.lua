-- Lua provided by SkyAPI 
-- Game: Peasant Knight
addappid(424610)
addappid(424611, 1, "8f83ec733afc9e69b9568a18cfcf856bf35ff8967e543931fe2a78fe5ccc30b8")
