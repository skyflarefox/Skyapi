-- Lua provided by SkyAPI 
-- Game: Luxury Supermarket Simulator
addappid(3403920)
addappid(3403921, 1, "96843d1216958ee47c8cccbd853d8d6815626853b15bcad33276b983996f3b41")
