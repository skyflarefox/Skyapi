-- Lua provided by SkyAPI 
-- Game: Zahalia: The Knights of Galiveth
addappid(562290)
addappid(562291, 1, "6dc9769f379f3a1a1759922a6b0cb88d38dd836cd9f1e53330013d47081b2115")
