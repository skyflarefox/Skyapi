-- Lua provided by SkyAPI 
-- Game: Lisa and the Grimoire
addappid(1342050)
addappid(1342051, 1, "2c34c8005f0c85d6b85b3332b3638e188adbbe7544481440efc785d69ca1788b")
addappid(1342052, 1, "0a22b4ff1c148d3a19ec0d144007839b21a29c67f21852b732b513743c927de8")
