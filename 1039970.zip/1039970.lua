-- Lua provided by SkyAPI 
-- Game: Grisaia Phantom Trigger Vol.6
addappid(1039970)
addappid(1039971, 1, "9a7cd8e8c907cd4b92b5df06bc602b3deacb64b2ff60452f10501bfaab5b0801")
addappid(1039972, 1, "9f7b1c168f19435f94a564bb0d982b3324881c008d8b050bdf4aafd1202127d7")
