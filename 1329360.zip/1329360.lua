-- Lua provided by SkyAPI 
-- Game: Lords of Exile
addappid(1329360)
addappid(1329361, 1, "9330fada8f9ad8d72f54371889c4ce20f0525d3401688ee652681fba5abd4e6e")
