-- Lua provided by SkyAPI 
-- Game: AppID 2626230
addappid(2626230)
addappid(2626231, 1, "3bf3efd3d220db3f203e5e31f3050f18cf4025fd51fe00df249166de8c68e309")
