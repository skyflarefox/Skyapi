-- Lua provided by SkyAPI 
-- Game: Axiom of Maria: Prologue
addappid(1885250)
addappid(1885251, 1, "e38f7b9fe7af4bc66b1be5237ada446735f1e5b13ed72b014ca124bcbcba1758")
