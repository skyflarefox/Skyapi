-- Lua provided by SkyAPI 
-- Game: Malice & Greed
addappid(1566090)
addappid(1566091, 1, "0fe3693ff1f5c6c91a4633b6e27de8b9daf1a08c17d5998ded16e6949e75b239")
