-- Lua provided by SkyAPI 
-- Game: Lost For Swords Demo
addappid(2661450)
addappid(2661451, 1, "d7157595ba36a57f276fa80cbfa0eba41aaaa35424e90752f5b8e85c6322e2e2")
