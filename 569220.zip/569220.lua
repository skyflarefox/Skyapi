-- Lua provided by SkyAPI 
-- Game: Spycraft: The Great Game
addappid(569220)
addappid(569221, 1, "ff4038fece9d30213377b08970a87d355254dc9f26cd912a549fa5f3c3d99c8d")
