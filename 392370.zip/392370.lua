-- Lua provided by SkyAPI 
-- Game: Wish -tale of the sixteenth night of lunar month-
addappid(392370)
addappid(392371, 1, "56a233552dafc6fde9a81508063fd6289a355d0be5960ce64bee26b8ab283f60")
addappid(392372, 1, "e75685b577ff413ec0aa9d28b239a0305f9476fae3a099cfa085cf7696f9bb5f")
addappid(392373, 1, "ba295c0b8b879ecaa09009cf73b347e715fa9e6fe0b1343db63d572c7bc2b2b7")
