-- Lua provided by SkyAPI 
-- Game: AppID 1036340
addappid(1036340)
addappid(1036341, 1, "e4e98d103c4d3cee164ef60a85a91998368c20b7301e2f6abc500b389339e194")
