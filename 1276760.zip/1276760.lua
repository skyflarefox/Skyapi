-- Lua provided by SkyAPI 
-- Game: DRAGON BALL: THE BREAKERS
addappid(1276760)
addappid(1276761, 1, "b55d19c1067bef37b1163e7ee075621199e867ed2ecdad10961d829fe48ffe08")
