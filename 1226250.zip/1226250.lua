-- Lua provided by SkyAPI 
-- Game: Synthesis: Mind, Body, and Soul
addappid(1226250)
addappid(1226251, 1, "b724e11b55cea607a53eea31cf8a3255259147c1b0e3cc9709d4b2d470d0bca3")
