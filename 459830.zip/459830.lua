-- Lua provided by SkyAPI 
-- Game: AppID 459830
addappid(459830)
addappid(459831, 1, "7ed13ab22d574191bf8fd2f560cf9bc3ac12ef70f7d26821be4349bff82dd2cf")
