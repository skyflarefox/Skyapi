-- Lua provided by SkyAPI 
-- Game: Tank Battle: East Front
addappid(613120)
addappid(613121, 1, "4a3dd89d7c1cf1101394b50d5efc96d23793d7859a5168e957c4d96127bbcf78")
addappid(613122, 1, "fd5934455a5c10c1266264b807782b5e63721c004d0df7e232dde63786460a2a")
