-- Lua provided by SkyAPI 
-- Game: TheoTown
addappid(1084020)
addappid(1084021, 1, "53cf5369fb7f8fcacfe7efc6a6a640c7eeaddaa4cbcc283666eab8fbb1e0bd95")
