-- Lua provided by SkyAPI 
-- Game: AppID 2438100
addappid(2438100)
addappid(2438101, 1, "05cfbb6c2f464e8d53abb294ea83cf9e8e5c6c9c91c943f3bd317c49d3a92600")
