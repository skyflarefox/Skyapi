-- Lua provided by SkyAPI 
-- Game: AppID 1084840
addappid(1084840)
addappid(1084841, 1, "294f80739ddd7605e4a994fe331dc553653355fb4054468fa883bf41da2c33bd")
