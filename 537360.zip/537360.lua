-- Lua provided by SkyAPI 
-- Game: AppID 537360
addappid(537360)
addappid(537361, 1, "657bf4bf696d7a199fc4042a4f3151af46cd74969d2af264f32845232d4632cd")
addappid(537362, 1, "779b2b402ecdbf5fe5de4aa8d17b7f53c8cd8ba2eeb2da1e67280c0444716555")
addappid(537363, 1, "038331ad33f7b0b30bde05904f1c2621848c9ccee28da6b5ea1476daf22c33b9")
addappid(584820)
