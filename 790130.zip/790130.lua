-- Lua provided by SkyAPI 
-- Game: AppID 790130
addappid(790130)
addappid(790131, 1, "6e4022a739d81af894bac88ce994be84018a882c27e3826fde0516ecc1b79d65")
