-- Lua provided by SkyAPI 
-- Game: Food Delivery Simulator 2026 - Demo
addappid(3208430)
addappid(3208431, 1, "75e9a63b7193f87727444964150b3817bbc53dbb13b3908cb8c55d129680ec45")
