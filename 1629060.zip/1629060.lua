-- Lua provided by SkyAPI 
-- Game: Colibri XR Immersive Art Gallery
addappid(1629060)
addappid(1629061, 1, "c2a192f58102d36c69c9b11147aaffb9b63565270c98f9be9eea0f7e2d6a56c6")
