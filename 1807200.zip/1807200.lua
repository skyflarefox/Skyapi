-- Lua provided by SkyAPI 
-- Game: Mirror Forge
addappid(1807200)
addappid(1807201, 1, "5307695ff33eac0ee958de2b57f897d2257a10f62a788bf00f5fb1a59ed7b400")
