-- Lua provided by SkyAPI 
-- Game: AppID 3402730
addappid(3402730)
addappid(3402731, 1, "7c846b8b08c16c324781e8206229f9e53e9a6671962b6a4b1dc2dfc25051eae4")
