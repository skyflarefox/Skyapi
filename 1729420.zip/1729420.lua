-- Lua provided by SkyAPI 
-- Game: PaintballX
addappid(1729420)
addappid(1729421, 1, "400412143d47312130d04c0b9fe3b07dd62faec6c6f1c9445a592d3368acc17b")
