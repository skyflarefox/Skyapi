-- Lua provided by SkyAPI 
-- Game: Perseverance: Part 1
addappid(854870)
addappid(854871, 1, "87c4efaab441f77efd63ae4581543a31fe5f3b7c97881f7f189add50d95d7705")
addappid(854872, 1, "bea7a08030b651c3cb99094014e09f0357a20631f62a9b6c8e7c69ae23871b94")
