-- Lua provided by SkyAPI 
-- Game: 女神保卫战
addappid(2933180)
addappid(2933181, 1, "dc5ab04ed02af7bab45310b1019844ee301b4e116413798d4d82822f873490f4")
