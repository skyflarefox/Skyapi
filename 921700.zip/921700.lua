-- Lua provided by SkyAPI 
-- Game: AppID 921700
addappid(921700)
addappid(921701, 1, "7e78faf6e94ef61e0d3c6a71376431ced0564911a7dac08139770c88dff7ee2e")
