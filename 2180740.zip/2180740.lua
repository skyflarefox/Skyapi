-- Lua provided by SkyAPI 
-- Game: Sex Toys
addappid(2180740)
addappid(2180741, 1, "93145937b519216d8a482a18b49049ac1ba0ecd4706c0d7fefb87777ebeffc27")
