-- Lua provided by SkyAPI 
-- Game: SUR5
addappid(2159120)
addappid(2159121, 1, "93f714ad53740b18cadf0ac6e75cd1ab7c10e595ebede0f7937869d3ee4ba28f")
addappid(3475740)
