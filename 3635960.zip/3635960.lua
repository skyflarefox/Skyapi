-- Lua provided by SkyAPI 
-- Game: Kumakichi&Nyanzou Birth ☆ Destruction God DX
addappid(3635960)
addappid(3635961, 1, "a950ab4db0d4af3ee4fbe41e201b652dac4fcbbb5ccad4de64b3ef494e8a7c3b")
