-- Lua provided by SkyAPI 
-- Game: Tiles II - Multiplayer
addappid(2100730)
addappid(2100731, 1, "a670489bd9c8043dbbfda07c45b2cc932792df778a4d730308a5bd7139f75ae6")
