-- Lua provided by SkyAPI 
-- Game: Infinite Tanks
addappid(543180)
addappid(543181, 1, "e1e3d1ed5d8f434fee5c9a2f9ca5dbf6a0fbdf837e5997d5d46a62c7ba3ef231")
