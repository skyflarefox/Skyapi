-- Lua provided by SkyAPI 
-- Game: Prescience Demo
addappid(2067870)
addappid(2067871, 1, "2def372454dd6ca550e07d2f8133b74da1851d1295051020e4d49cf7c18ece29")
