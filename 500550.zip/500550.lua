-- Lua provided by SkyAPI 
-- Game: Save the Universe, Please!
addappid(500550)
addappid(500551, 1, "32e0ca330c16d1a4268fb114b19d678b595ae96e88edc6910b9fb4091493063d")
