-- Lua provided by SkyAPI 
-- Game: peakvox Route Candle for Steam
addappid(552210)
addappid(552211, 1, "1aad1a4e3230c3f56727a9d7451d5afd00b5ad76425d9252ec92d39175d7a6fb")
