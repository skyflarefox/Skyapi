-- Lua provided by SkyAPI 
-- Game: AppID 2936910
addappid(2936910)
addappid(2936911, 1, "f1c1e05c14a2c56fa3d315b48dc7cff3f56e360bbd33506e059e93af94d78990")
