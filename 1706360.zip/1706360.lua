-- Lua provided by SkyAPI 
-- Game: Annihilate The Spance
addappid(1706360)
addappid(1706361, 1, "743fc770248686bf7b0f26a791326fc1bc77c9a86c074e83a4dc0c615526f681")
