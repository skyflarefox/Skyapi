-- Lua provided by SkyAPI 
-- Game: Rick Henderson
addappid(1023790)
addappid(1023791, 1, "a3dcc6b5c5cdee0cc40b4fa5b30c55b0ab855453716e768636d08bc19a7937e9")
