-- Lua provided by SkyAPI 
-- Game: AppID 688650
addappid(688650)
addappid(688651, 1, "a9cf61c8423bcc347e46070c8891bfaf089e13f9ddb55cbb5289bf404f59662c")
addappid(688652, 1, "cc38d0379bbe68baa79483a5b7478b1735e747b0f199019583d9bbac8a4d6d2b")
addappid(688653, 1, "d933c4da8ab46ea0041a8d0ac46613e543c6fddf1aa273c0f7079ff2d0d8ecda")
