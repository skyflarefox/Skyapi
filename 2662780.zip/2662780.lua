-- Lua provided by SkyAPI 
-- Game: Heat Death: Survival Train
addappid(2662780)
addappid(2662781, 1, "ed24354acad5e4184839fc73f8566220cb531f97a71d4bfae7ba7251b890a8f4")
