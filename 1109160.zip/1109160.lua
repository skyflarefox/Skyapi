-- Lua provided by SkyAPI 
-- Game: AppID 1109160
addappid(1109160)
addappid(1109161, 1, "e933a01eaf66796937c77dfed2819af6597f1e33fc2fb1aef345aca63968aba7")
