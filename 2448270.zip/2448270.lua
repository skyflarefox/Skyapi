-- Lua provided by SkyAPI 
-- Game: Mars Survivors
addappid(2448270)
addappid(2448271, 1, "954fe1699718b3ab7e75c0779872ef5591e452e8f6a3e2af0c2f3e1517160a30")
