-- Lua provided by SkyAPI 
-- Game: Slappy Board
addappid(1714910)
addappid(1714911, 1, "125a4954bb095a1040b7b72c6cc81447bf40728116a5934dd020528c0e1cde3e")
