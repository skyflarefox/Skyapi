-- Lua provided by SkyAPI 
-- Game: Hardware Store Simulator Demo
addappid(3369880)
addappid(3369881, 1, "92971a1510efbf54c973a8f133c4ae3cc36dcaf2be883c96039478701595446f")
