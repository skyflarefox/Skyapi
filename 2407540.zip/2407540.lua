-- Lua provided by SkyAPI 
-- Game: AETHERIS Demo
addappid(2407540)
addappid(2407541, 1, "4793f826892aa017762c8bbb967c3fa217f9ba2631d240cb0cae4d176199b067")
