-- Lua provided by SkyAPI 
-- Game: ZERO Sievert
addappid(1782120)
addappid(1782121, 1, "0bc5588f4c3b046a032c9a572cad93842f26607606bbfa76dbf4468046feabec")
