-- Lua provided by SkyAPI 
-- Game: Tribes of Midgard
addappid(858820)
addappid(858821, 1, "396cc73b4dbae399058e283549bd4e3a305081d85808c286ab9989f1c9d0bade")
