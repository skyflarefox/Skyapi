-- Lua provided by SkyAPI 
-- Game: Seven Hearts
addappid(3748090)
addappid(3748091, 1, "748a884b2f571138a0268e6565d758bfa95fbb9e7a7b5d5c007f1e718b96755d")
