-- Lua provided by SkyAPI 
-- Game: Mangui
addappid(3220010)
addappid(3220011, 1, "54bfe07fe3455190a0a9f0489ba360d40469e9f5a7ac7a727bba84e71be38c77")
