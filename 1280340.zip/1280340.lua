-- Lua provided by SkyAPI 
-- Game: AppID 1280340
addappid(1280340)
addappid(1280341, 1, "d798b099af2cf515f21d39d161c33f15fa3c32992fec2bd20cd0b27210b0cce4")
addappid(1280343, 1, "194f54698be0212846b126dc8a4b0905351cd70d5f38d40b753503b46becc85a")
