-- Lua provided by SkyAPI 
-- Game: Hentai Boy
addappid(1620890)
addappid(1620891, 1, "96660b8e186fb32d93f816ec155fe928a51dd2cf0a80fff274fce21a9658e814")
addappid(1629640, 0, "938744a979fa70c3210dced2af5ed3fd81d5e7b9621949de404441fcdf4c3a82")
