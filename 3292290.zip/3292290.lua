-- Lua provided by SkyAPI 
-- Game: FatSheep Crisis II
addappid(3292290)
addappid(3292291, 1, "c6faa233bc5227b212cbff36941e01a03b758da4a2ca8802b7881b1337704b77")
