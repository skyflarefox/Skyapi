-- Lua provided by SkyAPI 
-- Game: Off-Peak
addappid(467360)
addappid(467361, 1, "a7372af12689e63e0bc39f9f44a979d056538a6e149561160587dbbf61bb1762")
addappid(467362, 1, "5949238554823cdd796fca1bf87d6f2c93a6b4499d32e4f2679ad4668d08dbff")
addappid(467363, 1, "dd7f774f9ad4e01ca381374ae77c704b777bbf0d31d6c6d8dc3eac78c1a15eb6")
