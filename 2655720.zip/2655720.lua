-- Lua provided by SkyAPI 
-- Game: Hidden World 5 Top-Down 3D
addappid(2655720)
addappid(2655721, 1, "be86eba966cff3ef525932bfa61200a7045dcb4e1591c0790b0303bd5e7b801d")
