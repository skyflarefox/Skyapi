-- Lua provided by SkyAPI 
-- Game: GLAIS GAWIZT
addappid(2455420)
addappid(2455421, 1, "0639e1571317467076d4e3e0b05e0732b28ff85dd3360bea55f79f597c2c0239")
