-- Lua provided by SkyAPI 
-- Game: Gravity Game
addappid(1858980)
addappid(1858981, 1, "acaf834d3d59a9d964bb9436e7cedcae52bf56f2f425f6fc8eca164744b5ea52")
