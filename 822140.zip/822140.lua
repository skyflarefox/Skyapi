-- Lua provided by SkyAPI 
-- Game: AppID 822140
addappid(822140)
addappid(822141, 1, "439bd746fc8694d2cc482d73a45ed7e6e0cc3e6f7f84bc16e19d1766f851bc74")
