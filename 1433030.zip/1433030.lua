-- Lua provided by SkyAPI 
-- Game: MOAI 7: Mystery Coast
addappid(1433030)
addappid(1433031, 1, "802f1ceaef7a9ae51667ce3d7d97749e32e05742bf07958ee2383fa296c3736f")
addappid(1433032, 1, "03ddc7b1b9efbdf00a9bd17c19d2ff37e49ec5f5673a5dab35d1bdcd052196e6")
