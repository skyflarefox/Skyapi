-- Lua provided by SkyAPI 
-- Game: AppID 603560
addappid(603560)
addappid(603561, 1, "870a25e186666ba437aef4ba83f99f9c12e6d44fd870eee6922fecceddeb9425")
