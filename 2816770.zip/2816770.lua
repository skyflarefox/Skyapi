-- Lua provided by SkyAPI 
-- Game: At Tony's Demo
addappid(2816770)
addappid(2816771, 1, "5f40fde09340f55ed64e010d9ce6b8b10e4a1612abac58bc94cb7ec0767ee825")
