-- Lua provided by SkyAPI 
-- Game: D-100
addappid(2373160)
addappid(2373161, 1, "8cd5ed277cd1305c4565081206ab91ce68eb1610473059534f1ee4635c61757b")
