-- Lua provided by SkyAPI 
-- Game: Furry Cosplay
addappid(3103390)
addappid(3103391, 1, "cb5834bf7a27b043d00a507437602433a66a1a3616c6000c153c371f3050bf7f")
