-- Lua provided by SkyAPI 
-- Game: Orc Slayer
addappid(374990)
addappid(374991, 1, "556241a355f8edc5f4a9b4a2871f9717007612ee8b26ded3040731e3d79a95bd")
