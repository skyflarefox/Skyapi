-- Lua provided by SkyAPI 
-- Game: Time to Strike
addappid(2603410)
addappid(2603411, 1, "8528391081dfe241e80b9b183dcfc2c79da6fdd298ba3b2d2bd22f8e4b22b4bd")
