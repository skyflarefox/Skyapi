-- Lua provided by SkyAPI 
-- Game: AppID 2375760
addappid(2375760)
addappid(2375761, 1, "4479492095a638cd435d31ee0569c71d6a201a11408ade892bddef8e4f31f3b9")
