-- Lua provided by SkyAPI 
-- Game: Mortal Rite
addappid(1655990)
addappid(1655991, 1, "dbea863090b8e8ddf511ba39ff065af6c90ab4dae136f0d334d4350e4d5a3aa2")
