-- Lua provided by SkyAPI 
-- Game: AppID 464100
addappid(464100)
addappid(464101, 1, "93a3dcfcf71787c55268548697288726b3ae6a95c8a1ffcb4f80f1d6e2633e4b")
addappid(464102, 1, "96da5878e1238ab4ae2a281fa1f72ed1d35ac5b4a5ea1fc84ecb797954e8c7d1")
addappid(464103, 1, "ebc176255cf016bb006a973226953fbc811bff352f5c604d14fd5ad037b718d8")
