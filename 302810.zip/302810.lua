-- Lua provided by SkyAPI 
-- Game: AppID 302810
addappid(302810)
addappid(302811, 1, "d3ed900f9cd3bb294ea87bf4e53492eb0d52c69c59a4d7cd9d51519426fd0516")
