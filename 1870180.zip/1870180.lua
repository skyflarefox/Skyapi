-- Lua provided by SkyAPI 
-- Game: Frozen Friday Night: The Eve
addappid(1870180)
addappid(1870181, 1, "0e707466f9455060d911c2d3bdf6d387beb0990c6e8012c9f98f328e289af6d3")
