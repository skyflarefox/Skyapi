-- Lua provided by SkyAPI 
-- Game: AppID 1167680
addappid(1167680)
addappid(1167681, 1, "dc0b3e9ed4721c6021fde75fed36862324e101a7d0c33900818a4af8b58c6753")
