-- Lua provided by SkyAPI 
-- Game: AppID 1225600
addappid(1225600)
addappid(1225601, 1, "863889a126fc34f0a0b3b0784dc1cb4a5dd6eb32be43ce2a0aa9b88bb2acc275")
