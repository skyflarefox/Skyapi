-- Lua provided by SkyAPI 
-- Game: AppID 1977110
addappid(1977110)
addappid(1977111, 1, "69b2499813a69f70514df4458a33aaf939f6569950436a4a24698734dabb1cf5")
