-- Lua provided by SkyAPI 
-- Game: AppID 1279740
addappid(1279740)
addappid(1279741, 1, "ad0343802246cd41a95710a7e9a115f5c89f49992506f3e9daa789ea0cd3b96e")
