-- Lua provided by SkyAPI 
-- Game: Sleep Tight
addappid(1563320)
addappid(1563321, 1, "588dbd16842b1a89c3953b0a99b0e2b80a3ebace92bd86c3fb8da26932d41775")
