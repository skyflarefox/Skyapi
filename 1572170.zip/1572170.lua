-- Lua provided by SkyAPI 
-- Game: Pandemic Pandemonium
addappid(1572170)
addappid(1572171, 1, "292c0b0e809daef40de80d10d2160feb26508600d1edf07cf579591d84a781a0")
