-- Lua provided by SkyAPI 
-- Game: Life is Strange: Double Exposure
addappid(1874000)
addappid(1874001, 1, "34de6dc6df22af7fc7df7fda8a5799f8793ae860ac574864e18896fecf02aeb2")
addappid(3012890, 0, "8538cdc8423137fdd53890d96f7395b141dd635ad6ccc37092464d57e5f35ce1")
addappid(3012900, 0, "c50fa338cf0d3a6411b58603d71ffd4209f1e48f95bd13e0a97954dd5a44b12a")
