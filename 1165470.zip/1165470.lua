-- Lua provided by SkyAPI 
-- Game: TombStar
addappid(1165470)
addappid(1165471, 1, "729df57e724c5f92cda2f8c01ca7012f00e3e18db5841504188a6d521dcc7f8c")
