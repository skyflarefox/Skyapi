-- Lua provided by SkyAPI 
-- Game: I was born poor
addappid(2334710)
addappid(2334711, 1, "2797fb881dfff81d0149597966942dba10e851f43598dcd7d74ac25643b90300")
