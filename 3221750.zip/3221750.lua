-- Lua provided by SkyAPI 
-- Game: The RPG Demo
addappid(3221750)
addappid(3221751, 1, "0b6910f420a6cd6287a244295fd0f0229f1c69fc5befaeb02564438af67b4abb")
