-- Lua provided by SkyAPI 
-- Game: AppID 394740
addappid(394740)
addappid(394741, 1, "add429c1e6d13b138b789b6f29379a6907248dfac7b0287486f7d451fe13e04f")
