-- Lua provided by SkyAPI 
-- Game: Colossal Kaiju Combat™: Kaijuland Battles
addappid(290810)
addappid(290811, 1, "14815ddc03305aa4a470fc103f6f3f9120736196043b7f6c367e8d87c316aca3")
