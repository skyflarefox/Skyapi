-- Lua provided by SkyAPI 
-- Game: Supermarket Together
addappid(2709570)
addappid(2709571, 1, "7fa16318d187d201cd5762fec6ac1022fb99b54b7ecb11f228286d5ee2a9790e")
addappid(3146530)
