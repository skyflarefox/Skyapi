-- Lua provided by SkyAPI 
-- Game: Galactic Civilizations IV
addappid(1357210)
addappid(1357211, 1, "e1b28e464e8a1b73bce264c89ada3f3c39d55f32e584807487f8696e927901ff")
addappid(1357212, 1, "c867831f9324890e385929266c8b0ebba69267e6432a5d1ebfb372c32a8ab652")
