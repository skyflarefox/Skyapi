-- Lua provided by SkyAPI 
-- Game: Melatonin
addappid(1585220)
addappid(1585221, 1, "5ba9eb8215a9db5783ac81a4fc0d411d12c6b762266cb31023d3366dc14b92e3")
