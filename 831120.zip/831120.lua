-- Lua provided by SkyAPI 
-- Game: AppID 831120
addappid(831120)
addappid(831121, 1, "f0e98028e1fd48dc1242ed7d12c922147ec8af1c4f8ce01956a74ab0752fe790")
