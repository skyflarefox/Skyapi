-- Lua provided by SkyAPI 
-- Game: Grindstone Demo
addappid(2005840)
addappid(2005841, 1, "e5d1aa2601915627ebe20fb32be309d781aeba0324d65e70058c459c8147099a")
