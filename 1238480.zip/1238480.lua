-- Lua provided by SkyAPI 
-- Game: McSpace Colosseum
addappid(1238480)
addappid(1238481, 1, "aa4fca689c50abfcd0391f9d7b9e1071424f477d7020ce111f832b17429ab6c3")
