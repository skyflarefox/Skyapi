-- Lua provided by SkyAPI 
-- Game: AppID 3148910
addappid(3148910)
addappid(3148911, 1, "63cf0669f6ccab373de74cd99cc69dae59aa64f7531d3e496afae30cf5edddb5")
