-- Lua provided by SkyAPI 
-- Game: Tiny Fight Demo
addappid(2637140)
addappid(2637141, 1, "e8f2c23958d7c257e064787088e395c03532fc0fbeeb34c7ea9e88c41088a346")
