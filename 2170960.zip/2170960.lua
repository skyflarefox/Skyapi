-- Lua provided by SkyAPI 
-- Game: Boot Camp Endless Runner
addappid(2170960)
addappid(2170961, 1, "7077b4ec99527c263b0e9b57ed507781c5c29d5e0b07f4bb3078d881fc62b911")
