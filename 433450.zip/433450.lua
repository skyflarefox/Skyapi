-- Lua provided by SkyAPI 
-- Game: INFERNO CLIMBER
addappid(433450)
addappid(433451, 1, "cb749d173efaa03d3582807e2f93d0c26ed5659bdae6d3cdd0d49caace11dbef")
