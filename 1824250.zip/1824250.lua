-- Lua provided by SkyAPI 
-- Game: AppID 1824250
addappid(1824250)
addappid(1824251, 1, "84444f478ca89bbb88a159f73c71c862f9359047d88c559563934d63b73053e4")
