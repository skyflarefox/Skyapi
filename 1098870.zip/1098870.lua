-- Lua provided by SkyAPI 
-- Game: AppID 1098870
addappid(1098870)
addappid(1098871, 1, "eef8c2706a79e6aa353e67c5b16ff348da52d5f517a56dcb1ee62b8ccd9f7acb")
