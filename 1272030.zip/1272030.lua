-- Lua provided by SkyAPI 
-- Game: Premier Manager 05/06
addappid(1272030)
addappid(1272031, 1, "3311a37d0770beb6d0e5f2697f969c74551052af12ffc0c0fe95a08686dcbcbe")
