-- Lua provided by SkyAPI 
-- Game: Mountain
addappid(313340)
addappid(313341, 1, "1335d7bdd136f5ac6f84e6e8131253ccf3e2afe71e88023510dc7edb6c6ef47a")
addappid(313342, 1, "6c17aa0113f506791102930d5e4c4e0cb1feba745b5d9367dcaf5333996e489b")
addappid(313343, 1, "59bdcaa3ea6c3219db3646002c54b301510ca1f7bca3b5334fe6790c791dbdc6")
