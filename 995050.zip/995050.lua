-- Lua provided by SkyAPI 
-- Game: AppID 995050
addappid(995050)
addappid(995051, 1, "e27093a614db5d9075ba8e80660566664642fc600f034d03df4f8a758e96dd1d")
