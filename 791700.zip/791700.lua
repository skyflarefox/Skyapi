-- Lua provided by SkyAPI 
-- Game: Bird Game
addappid(791700)
addappid(791701, 1, "32ee2e0062ec47f90ac59aac2e6588d28a7cbfc675a708fbf1ca54ff10a596e3")
addappid(826360, 0, "5a024a3036964bd2927ba59e7b0d510ab6f5a3264163a6c89e4cbc1f49a44c67")
