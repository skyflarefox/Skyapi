-- Lua provided by SkyAPI 
-- Game: AppID 1260340
addappid(1260340)
addappid(1260341, 1, "5178035330a225ef8f1c3f629a3964cf3dc71ee105472d9b7b2ad797b31030a3")
