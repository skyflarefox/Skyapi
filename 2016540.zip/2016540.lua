-- Lua provided by SkyAPI 
-- Game: Chess Pills
addappid(2016540)
addappid(2016541, 1, "eb6100dd0a7efa133b885d618a6327089dee0bfb049cbe899efba311df3d2e09")
