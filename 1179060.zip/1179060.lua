-- Lua provided by SkyAPI 
-- Game: AppID 1179060
addappid(1179060)
addappid(1179061, 1, "445bf89df162c9dbfed8e205333cf827a054ac6a2b8b9d74188f23024e00d41a")
