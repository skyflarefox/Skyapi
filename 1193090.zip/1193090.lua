-- Lua provided by SkyAPI 
-- Game: AppID 1193090
addappid(1193090)
addappid(1193091, 1, "37d9d2172d72b5a3e47435e38813ad0572e383d0bde101e99c090ddc742c3e0a")
