-- Lua provided by SkyAPI 
-- Game: AppID 1199570
addappid(1199570)
addappid(1199571, 1, "8b9f6d075afc6a44d97fc3b785d129d865993de7b6cab9519cc59b2fb08397d3")
