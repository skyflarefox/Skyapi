-- Lua provided by SkyAPI 
-- Game: Bright Lights of Svetlov
addappid(1630920)
addappid(1630921, 1, "0e90a13fb5032cfbbb3e17fa9711e74550eabf3f8e45acfb1d0c5f58ee731c70")
