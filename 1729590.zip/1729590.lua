-- Lua provided by SkyAPI 
-- Game: Auto Cell: Game of Life
addappid(1729590)
addappid(1729591, 1, "e1dc36759f9d5b228d821b0f2eddde13f16d3f7bba69bab095df127f6e25a186")
