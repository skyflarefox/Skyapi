-- Lua provided by SkyAPI 
-- Game: MOBA Dodge Trainer
addappid(3170880)
addappid(3170881, 1, "d29dac3a10518f7118c6302e23712d9ea0648bddcb696bb966af0a24793b96c3")
