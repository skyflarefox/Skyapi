-- Lua provided by SkyAPI 
-- Game: Defiled Survivors
addappid(1981050)
addappid(1981051, 1, "65f70b8ca37cdcb8a937b752195ddf810cfe252ed7c1bf04ee6d85bece63f3ef")
