-- Lua provided by SkyAPI 
-- Game: My Bird
addappid(3461210)
addappid(3461211, 1, "b6b5f35c54cd952b5a51cb3f3e9b796df2001a38098b0478324acc31ebe2046a")
