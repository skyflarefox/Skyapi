-- Lua provided by SkyAPI 
-- Game: Beyond the Mountains
addappid(2107170)
addappid(2107171, 1, "6f3e72f8440a38934a6ad244792225f61acf72e83e8ae921089cc0d2761dccc1")
