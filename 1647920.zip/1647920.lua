-- Lua provided by SkyAPI 
-- Game: Valfaris: Mecha Therion
addappid(1647920)
addappid(1647921, 1, "6fdbed4fbc2e4e9488599c297fc2958d077591fa6a085f403cd5bfa6a0eb95a3")
