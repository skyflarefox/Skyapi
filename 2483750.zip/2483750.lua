-- Lua provided by SkyAPI 
-- Game: Research Story Soundtrack
addappid(2483750)
addappid(2483751, 1, "e4c05ff6a5c598fd10597c7f7ef972580117cb4af60cc8ac3237a77470001ebc")
