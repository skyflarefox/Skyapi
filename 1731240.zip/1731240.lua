-- Lua provided by SkyAPI 
-- Game: OnlyFuck 2: Scarlett
addappid(1731240)
addappid(1731241, 1, "c0c25efe5dec25d50c5a59a0f0758f9c5e411ec0c37883491eb6025259900c31")
addappid(1782220)
