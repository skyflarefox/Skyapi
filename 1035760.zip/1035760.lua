-- Lua provided by SkyAPI 
-- Game: Glimmer in Mirror
addappid(1035760)
addappid(1035761, 1, "49f13494191a8c25893207584c85bd1cd79ef369d017c7c02591eb4e06cd9081")
