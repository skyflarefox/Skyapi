-- Lua provided by SkyAPI 
-- Game: TeamTower
addappid(1611830)
addappid(1611831, 1, "c23282bfa7e55cc72c37f680513d7e573ba40641697a41dd2153c3b6b280c656")
