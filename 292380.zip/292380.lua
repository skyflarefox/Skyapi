-- Lua provided by SkyAPI 
-- Game: Racer 8
addappid(292380)
addappid(292381, 1, "f143f781a8adcb4651ee655ba53418cd7222b4edf958867d9b3b65badcfaa128")
addappid(292382, 1, "1c737098d7b7a371b3367ba9713c4357b930b418182e6640380818f1817c3ffa")
