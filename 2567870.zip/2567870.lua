-- Lua provided by SkyAPI 
-- Game: Chained Together
addappid(2567870)
addappid(2567871, 1, "84ff26693d69b1f13f653ad7d1a182142a2a5049bf0ce8dc73735d955d3cb186")
