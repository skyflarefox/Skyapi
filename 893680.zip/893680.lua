-- Lua provided by SkyAPI 
-- Game: AppID 893680
addappid(893680)
addappid(893681, 1, "f243fe9206b50dc0cfc4f160cb9775e514938279d5015367c4b37a38fa5cd49e")
addappid(989960, 0, "d987f5343a4e971257d7bf2153706bd449de31abb4a127c4c12f7bfb62cf861c")
