-- Lua provided by SkyAPI 
-- Game: AppID 1182420
addappid(1182420)
addappid(1182421, 1, "1ccd71ca485e1c46672f8315a3035cd347626125fcbcaa7abff2e2ee071ff0d3")
