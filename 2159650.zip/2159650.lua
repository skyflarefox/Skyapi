-- Lua provided by SkyAPI 
-- Game: Drift: Space Survival
addappid(2159650)
addappid(2159651, 1, "2f09a3562b150942d1df770d41324df7ab9fa137e76b9f6a4bcbfbde6aff3e1b")
