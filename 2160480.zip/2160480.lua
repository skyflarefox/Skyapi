-- Lua provided by SkyAPI 
-- Game: Hellboy Web of Wyrd
addappid(2160480)
addappid(2160481, 1, "3fcbcdcb0104e1848803bf02e785e547ef5c2d7040bb4a3c0e240a143c4b2502")
