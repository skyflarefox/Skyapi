-- Lua provided by SkyAPI 
-- Game: AppID 316160
addappid(316160)
addappid(316161, 1, "d0a2769879676c180a12fadf9258e0a43e84ff4610403feb05ecc3f271d571bd")
addappid(565820, 0, "c8637da893f8f73d210bef98e0895f9f5fcf03b32fe70808ddc0bc4324226107")
