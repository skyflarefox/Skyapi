-- Lua provided by SkyAPI 
-- Game: Lust for Darkness VR
addappid(1563160)
addappid(1563161, 1, "6fec67a86dfb44541ce1e6ce954f2f886f7a2ca9b8009817965541555a474262")
