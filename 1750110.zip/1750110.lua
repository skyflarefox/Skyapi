-- Lua provided by SkyAPI 
-- Game: Frenzy VR
addappid(1750110)
addappid(1750111, 1, "706384dd234e875100fcba55272d64d2f0233fbc1ee42e6af1ed8c3b3673d97e")
