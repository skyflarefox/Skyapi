-- Lua provided by SkyAPI 
-- Game: AppID 1677670
addappid(1677670)
addappid(1677671, 1, "5722ba4fa1319f6c0bc3b0c60f67fd7ad5c60b8975604d1e2b52025bdfdc0843")
