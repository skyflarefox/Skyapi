-- Lua provided by SkyAPI 
-- Game: AppID 747590
addappid(747590)
addappid(747591, 1, "a6002cf943fc95d489b8f7634d48545080b0aecccf415f3d49f4d9acdb8df686")
