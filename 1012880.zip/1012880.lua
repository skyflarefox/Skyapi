-- Lua provided by SkyAPI 
-- Game: AppID 1012880
addappid(1012880)
addappid(1012881, 1, "0f953c110914b4b70a6b6846415d46d0386b0cc1ce3874be245f8b14f494ab6f")
