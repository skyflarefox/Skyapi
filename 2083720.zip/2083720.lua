-- Lua provided by SkyAPI 
-- Game: AppID 2083720
addappid(2083720)
addappid(2083721, 1, "2acbd340457ecaeee6c0d9eb5a3b82ceb5572d31d89d72751228d18a4c82a04a")
