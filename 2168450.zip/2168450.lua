-- Lua provided by SkyAPI 
-- Game: DREAMWILD
addappid(2168450)
addappid(2168451, 1, "12b2a701d1da7657ef2067c597eb0438f9b5239980a261cb0ff3cea9f6014872")
