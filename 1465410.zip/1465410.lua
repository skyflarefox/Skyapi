-- Lua provided by SkyAPI 
-- Game: Spinny's Journey
addappid(1465410)
addappid(1465411, 1, "a263e5aaf4da5c5ea39ba88df8698c3326b0d9c321f4888c7aee8c147c132aab")
