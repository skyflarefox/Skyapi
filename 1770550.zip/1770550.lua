-- Lua provided by SkyAPI 
-- Game: Crypto Girls [18+] - SEXCoin
addappid(1770550)
addappid(1770551, 1, "0032d655c2c2b88ace056f4e1000636452fc1824b18cd4342ed4d87a7669ecac")
addappid(1791330, 0, "c26b4f96fe979d6f4005af27db6838cb165c5f5893ab5679de7126a64745025c")
