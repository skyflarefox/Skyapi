-- Lua provided by SkyAPI 
-- Game: Haunted Investigation
addappid(2400880)
addappid(2400881, 1, "70c58a455ea953ef9cc2c21b36724a35f8fdf582bbb3ee339a33f155ea6b4360")
