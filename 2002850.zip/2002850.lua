-- Lua provided by SkyAPI 
-- Game: Raiden IV x MIKADO remix
addappid(2002850)
addappid(2002851, 1, "9beffe53843a9ba784a2d105983e501128a34ceaf3fdc00d70e55b7c88b89d94")
