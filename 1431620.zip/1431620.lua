-- Lua provided by SkyAPI 
-- Game: Cybercube battle
addappid(1431620)
addappid(1431621, 1, "0d6f0aeac9bc362001050bf98b34a9da0b51a2c14882744b0b5e6ce72edf7392")
