-- Lua provided by SkyAPI 
-- Game: Mars Troopers - 生化奇兵2019
addappid(890680)
addappid(890681, 1, "5566aa7425cc2da824ef0701cb2c6267bc5e057b1988488094684167248c7f2a")
