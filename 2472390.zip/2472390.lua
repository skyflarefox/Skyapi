-- Lua provided by SkyAPI 
-- Game: A Technician's Nightmare
addappid(2472390)
addappid(2472391, 1, "d1337770fd7a3b77dd3719b30756fc54ac2a8f553219c02f8580225719b7a750")
