-- Lua provided by SkyAPI 
-- Game: Not Another Dungeon?!
addappid(1739100)
addappid(1739101, 1, "2a54449bd8346ed489159286a73e240569bcf23ec9db4ed72956911e9be42997")
