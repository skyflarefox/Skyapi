-- Lua provided by SkyAPI 
-- Game: AppID 542930
addappid(542930)
addappid(542931, 1, "7d9adab4d4f8a99fb93a064615fd93c53b92eedf76cfa7a803f1570f3de7022f")
