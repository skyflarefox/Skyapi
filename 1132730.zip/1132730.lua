-- Lua provided by SkyAPI 
-- Game: 巅峰骑士团
addappid(1132730)
addappid(1132731, 1, "8cd65d768fae340184d66327a3d5476f631b9ea226298728c73481dd35a163e5")
