-- Lua provided by SkyAPI 
-- Game: AppID 501950
addappid(501950)
addappid(501951, 1, "692120d9cd155d41d31f1c374c2ce3e8e8466411ebe77a08fa7364da671196d4")
