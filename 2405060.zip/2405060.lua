-- Lua provided by SkyAPI 
-- Game: KIBORG
addappid(2405060)
addappid(2405061, 1, "44e2a2a5b27411fbe5560f3688cce5d5fe65bef7ae16ae220bad5805da08d875")
