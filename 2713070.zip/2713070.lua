-- Lua provided by SkyAPI 
-- Game: AppID 2713070
addappid(2713070)
addappid(2713071, 1, "8090d57f399e11d825519cdb7ddc35ae61defdeae6b2516c6b9d04adf62f030e")
