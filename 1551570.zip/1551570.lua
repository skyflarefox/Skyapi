-- Lua provided by SkyAPI 
-- Game: Kung Fu Grand King
addappid(1551570)
addappid(1551571, 1, "e714c2ce2301be7e01cd673a6aa2f7852813a1048c6e1159690958ced3e6b58e")
addappid(1551572, 1, "3155190789b4d0e1dfc6bf51f575d84b26adfbdaf3e078f22ed4feb649e41354")
addappid(1551573, 1, "a209ffaaddb716d3f2537195fa59585e171e962f9a8fa80199032750e7c7bef5")
