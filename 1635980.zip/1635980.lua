-- Lua provided by SkyAPI 
-- Game: Kubinashi Recollection
addappid(1635980)
addappid(1635981, 1, "e2c898b5a962d69fb9657ae5d5a40bd00efe11988f10fcf963f356b2d21690e9")
