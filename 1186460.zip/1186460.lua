-- Lua provided by SkyAPI 
-- Game: Songs of Wuxia
addappid(1186460)
addappid(1186461, 1, "963416416dca99212d0f39a45b58fb82dfa1ff5c48231cbdb63bbbac9d49db9e")
