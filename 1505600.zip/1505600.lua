-- Lua provided by SkyAPI 
-- Game: RETRIS
addappid(1505600)
addappid(1505601, 1, "be8697cc24c7ab120a391e496da77e6f370b433d0a4b6863832938a19bf23dee")
