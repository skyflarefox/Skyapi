-- Lua provided by SkyAPI 
-- Game: AppID 2246470
addappid(2246470)
addappid(2246471, 1, "e33663120dbd54db9c7835c81acc62c106f45d41ea42938e08127ea14dfc25dc")
