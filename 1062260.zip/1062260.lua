-- Lua provided by SkyAPI 
-- Game: AppID 1062260
addappid(1062260)
addappid(1062261, 1, "7175be4c9856f00b9ca215fbb0dfcee000f65d90ba376afc865b78a77dd34496")
