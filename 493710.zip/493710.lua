-- Lua provided by SkyAPI 
-- Game: AppID 493710
addappid(493710)
addappid(493711, 1, "5d59fdf08fcc971d9905123b258903b50e5e1b4986c05fa713b97c6bbbb69ee9")
addappid(493712, 1, "f21492eb0af3fc349502c0f0139ee4ddb08033aba6c702f7e29008f33d2d928d")
addappid(493713, 1, "83c03956c57fe97ce95d217564d197b4d61a2bbe77a6786aae0b3e8d3f567b0a")
addappid(580160)
