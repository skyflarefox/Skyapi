-- Lua provided by SkyAPI 
-- Game: Nemezis: Mysterious Journey III
addappid(986350)
addappid(986351, 1, "dabcebeb4f6456bf9c68a0eb13dd96c6ac62506a0186a8c2b4f1956ce10cad75")
