-- Lua provided by SkyAPI 
-- Game: Vellum
addappid(917950)
addappid(917951, 1, "782dc04cd840b972d5f38b24f8e6190b7935018e7dfee5516cbe431927c12af0")
