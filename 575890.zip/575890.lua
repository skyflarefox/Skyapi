-- Lua provided by SkyAPI 
-- Game: Katy and Bob Way Back Home
addappid(575890)
addappid(575891, 1, "f168a267d3ab3fb0b9cbfe5d1155ad7c0b25012a6abc7d343b33e45c25291687")
addappid(575892, 1, "2cf07995ae39e15ba3f645207cb13b082fd9f35e15ff3b631072289de8a7af1d")
addappid(575893, 1, "9e0e31d9d1ac398309ca55a57bf5f356ccb0863f1b263eb01522258390cb0897")
