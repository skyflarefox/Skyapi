-- Lua provided by SkyAPI 
-- Game: Slime CCG
addappid(863560)
addappid(863561, 1, "b14a931d47e7243adf6c83b505f0b6ba2739971c92e1d3348dc71c54f841c485")
addappid(865620)
