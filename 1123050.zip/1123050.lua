-- Lua provided by SkyAPI 
-- Game: AppID 1123050
addappid(1123050)
addappid(1123051, 1, "230adf4f9c1f00f60fe23bbe3309ce106c450fa5f0c9e7c1cf9023b0ecb176db")
