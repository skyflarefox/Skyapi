-- Lua provided by SkyAPI 
-- Game: MasterpieceVR
addappid(504650)
addappid(504651, 1, "523384fb3085af50eeb807b4269f088b057801103d681086cb90159206a265aa")
