-- Lua provided by SkyAPI 
-- Game: 黄色猫片
addappid(3452790)
addappid(3452791, 1, "03fa1e3485e55385dc93f7b0f509d8938ae2399d0822eb90836271d6813be3a5")
