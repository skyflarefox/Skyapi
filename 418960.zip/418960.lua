-- Lua provided by SkyAPI 
-- Game: AppID 418960
addappid(418960)
addappid(418961, 1, "d921608c2dec55d2a9719dcff35a3b39ba3b83d88f57d6972496587d1c364e85")
