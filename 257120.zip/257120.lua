-- Lua provided by SkyAPI 
-- Game: Not The Robots
addappid(257120)
addappid(257121, 1, "91db9e81ea5fc02a3b652b34e894d4f34c4efa21d875ee84d22b0d7cd2a89f68")
addappid(257122, 1, "aaa66a03a6a354872aae5bc13cac3d2a4372f55805b974a1ee2974ffc3fe12dd")
addappid(257123, 1, "18085f5dd6389e333289ae5f3d1fc9249f178e80c3010286fa3647cb2304b03a")
