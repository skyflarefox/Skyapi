-- Lua provided by SkyAPI 
-- Game: TAPE DENIAL
addappid(3468270)
addappid(3468271, 1, "4c14604b88f42e106ba4ab616f4a7d4942e546492c3a6e177e44c77c05cfe3a8")
