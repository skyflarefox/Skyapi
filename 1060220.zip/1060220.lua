-- Lua provided by SkyAPI 
-- Game: AppID 1060220
addappid(1060220)
addappid(1060221, 1, "b77999544d6ac2ca6c0a643a0edb7b6b6860a569b70c88486826bf9092be691c")
