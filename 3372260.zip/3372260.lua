-- Lua provided by SkyAPI 
-- Game: Heavensward: FINAL FANTASY XIV Original Soundtrack
addappid(3372260)
addappid(3372261, 1, "c955bb15682d3473e4fb5e1f183e666f41524a0c75ee4d7fffa153c3a3dcc5f1")
