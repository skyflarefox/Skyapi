-- Lua provided by SkyAPI 
-- Game: GIRAL
addappid(914090)
addappid(914091, 1, "e0298ca7921c42b887f0e9107d99267a1e09d73501cc1aaa52777fa395c453be")
