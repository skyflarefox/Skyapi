-- Lua provided by SkyAPI 
-- Game: Ink Cipher
addappid(870670)
addappid(870671, 1, "04156748783a2fdd36b6df250769a2a0219f192145db5069916050dd21653060")
