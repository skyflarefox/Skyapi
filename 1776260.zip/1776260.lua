-- Lua provided by SkyAPI 
-- Game: Crazy Truck
addappid(1776260)
addappid(1776261, 1, "72a32fdfd27422d56340a825811dd6ff25336fea2f7deeb69cd1617b84f3ba6e")
