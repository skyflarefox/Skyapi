-- Lua provided by SkyAPI 
-- Game: Xvirus
addappid(4450350)
addappid(4450351, 1, "fa572485596bebf7f3a03e835d4c6f13c4e4b07cb0fe9dc4637ab66ea362f5fa")
