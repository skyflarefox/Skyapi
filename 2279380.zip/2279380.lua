-- Lua provided by SkyAPI 
-- Game: Nixxsz Castle
addappid(2279380)
addappid(2279381, 1, "5186fb50689312bbb589e2c39a9f0c391e1cbef0154debc0c03290c930c10676")
