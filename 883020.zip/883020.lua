-- Lua provided by SkyAPI 
-- Game: Shadowlings
addappid(883020)
addappid(883021, 1, "721d2aa0a544901db6c6be471888354340e6357f23a1c4fc4632d8574adfb0fe")
addappid(898710, 0, "0e3b877e86c7d67188559d52c5096c21ef70ebac5203d133c6e067df9c25277d")
