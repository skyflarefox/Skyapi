-- Lua provided by SkyAPI 
-- Game: NULLPTR - Demo
addappid(2771570)
addappid(2771571, 1, "7e85813ea0ab11c9793df589a1594ed19aa7753ce87b16a36bc766cb4687618a")
