-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(382900)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(382901,0,"1783bda70675c8cdf062d8fa6d9d1697a1367c8c20738f7280ea3f832b886551")
setManifestid(382901,"8835496764024358659")