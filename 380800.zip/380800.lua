-- Lua provided by SkyAPI 
-- Game: AppID 380800
addappid(380800)
addappid(380801, 1, "9c7f65f14ea039a0db777838c928795db51f5041e13c1ac2604127e8f4c15153")
