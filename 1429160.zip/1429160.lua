-- Lua provided by SkyAPI 
-- Game: AppID 1429160
addappid(1429160)
addappid(1429161, 1, "358c0990bc061b22497c39a26cfc21d7fedb3bce6aca6293b4134bbbb788ce08")
