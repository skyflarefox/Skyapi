-- Lua provided by SkyAPI 
-- Game: AppID 624890
addappid(624890)
addappid(624891, 1, "0e944e25345344e614fb07bf37046af92e0503148fb110d46e227da8578cc96d")
