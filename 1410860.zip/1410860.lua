-- Lua provided by SkyAPI 
-- Game: Puzzle Box Palace
addappid(1410860)
addappid(1410861, 1, "549e988bc83db144f9d8da58d81f230a8be1aab159dcfa4349d0cb0f3f0f79c2")
