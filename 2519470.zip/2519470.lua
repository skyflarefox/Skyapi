-- Lua provided by SkyAPI 
-- Game: Project Rogue
addappid(2519470)
addappid(2519471, 1, "51d96b6cacff23290f366d487f5ca030bfa301eb47efb4333e44f504dc4afbed")
