-- Lua provided by SkyAPI 
-- Game: Rapid Soccer Demo
addappid(2810710)
addappid(2810711, 1, "71e07d632501dfd73c5e31f195722945878224be985989e3696becb50bb9372b")
