-- Lua provided by SkyAPI 
-- Game: AppID 1531730
addappid(1531730)
addappid(1531731, 1, "416cde29dc35e346a93b0e4e8231cdc27c6bea1e767874129f1fe8f5c15d991d")
