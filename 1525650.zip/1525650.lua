-- Lua provided by SkyAPI 
-- Game: AppID 1525650
addappid(1525650)
addappid(1525651, 1, "2718b2df8da9d9165a038b9aa91738489f9b62090599e78128ff2e3b0a4e08c5")
