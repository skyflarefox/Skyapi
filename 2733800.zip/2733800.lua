-- Lua provided by SkyAPI 
-- Game: Bloodhounds
addappid(2733800)
addappid(2733801, 1, "68b84c8bd9f62cb06b3cfb80d6af1b2ed4888901c560876dbde83a6b30212332")
