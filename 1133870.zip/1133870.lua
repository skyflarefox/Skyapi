-- Lua provided by SkyAPI 
-- Game: AppID 1133870
addappid(1133870)
addappid(1133871, 1, "0d760afa5af25326869f34c4e246af9e2f3b4cf30464ad8587e36b5c5a6ae44e")
