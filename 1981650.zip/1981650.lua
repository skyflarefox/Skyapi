-- Lua provided by SkyAPI 
-- Game: AppID 1981650
addappid(1981650)
addappid(1981651, 1, "b78f4b84dccd3d2b8a28c8e86c90c42a9b53b950f90852ed886c4d443a46a2a1")
