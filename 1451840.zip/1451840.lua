-- Lua provided by SkyAPI 
-- Game: AppID 1451840
addappid(1451840)
addappid(1451841, 1, "8d8c250a3ee4fa79a1ecf00062ce618bc14110171aac5eef6801c17f359ebf32")
