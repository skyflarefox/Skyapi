-- Lua provided by SkyAPI 
-- Game: Mist of the Dark
addappid(884550)
addappid(884551, 1, "07aeba55461c0cde133040e602182b88b7bb4ead6033e041af93f1dc8abffd9b")
