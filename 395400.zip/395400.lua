-- Lua provided by SkyAPI 
-- Game: Freedom Cry
addappid(395400)
addappid(395401, 1, "188fad12872e10b27a9d31ce55eb732a0d453baccb217bd754e271fabbfb5b80")
