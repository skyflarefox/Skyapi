-- Lua provided by SkyAPI 
-- Game: Fly High
addappid(945240)
addappid(945241, 1, "0d980240156238623b23d04e21a492bb12d11e0158ecc916385a26ae6043d360")
