-- Lua provided by SkyAPI 
-- Game: Citrus Rampage
addappid(1817020)
addappid(1817021, 1, "613d0a9cafe6455eb3efaeb9f09306384e5b151f514b1de564fd40804a9b43d0")
