-- Lua provided by SkyAPI 
-- Game: AppID 281350
addappid(281350)
addappid(281351, 1, "d19fc9f952e3279bf86e4b3132900223bf9077eedb213d13628574fd7283208e")
