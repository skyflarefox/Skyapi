-- Lua provided by SkyAPI 
-- Game: RP7 Soundtrack
addappid(3179090)
addappid(3179091, 1, "1611e86e7ad96ca8d20f980af4d21829b878174a806665ea8d3807117c7ccb34")
