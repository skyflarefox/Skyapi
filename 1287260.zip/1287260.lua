-- Lua provided by SkyAPI 
-- Game: Barn Finders: The Pilot
addappid(1287260)
addappid(1287261, 1, "d6a110d97fd50e8ff80aac1a141eb7b79e42b346febe5d50f499dec940acb1a0")
