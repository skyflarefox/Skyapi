-- Lua provided by SkyAPI 
-- Game: Sakura Gym Girls: Prologue
addappid(2018930)
addappid(2018931, 1, "3032a23c71226838bebab0c8dc32c8f6a0a2a7e388eedb031b8b1d7e9bd6ddb4")
