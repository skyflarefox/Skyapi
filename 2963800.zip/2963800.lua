-- Lua provided by SkyAPI 
-- Game: DrainSim
addappid(2963800)
addappid(2963801, 1, "378db61e0fba6945aa38162f21ab98cd80c6f68a85a64b0bdeffc76895b8fdbb")
