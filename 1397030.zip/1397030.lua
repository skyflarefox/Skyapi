-- Lua provided by SkyAPI 
-- Game: Survive or Thrive
addappid(1397030)
addappid(1397031, 1, "9234823d1fd98e5c7e781063edb59363843d056aae56e38566651eb73a83017c")
