-- Lua provided by SkyAPI 
-- Game: AppID 2957910
addappid(2957910)
addappid(2957911, 1, "676433b845d83c3f092981a894b0dbe9a162f72b2f72328a97b6ae85248e5cdc")
