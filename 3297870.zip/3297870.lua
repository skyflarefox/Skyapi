-- Lua provided by SkyAPI 
-- Game: Feminization Device
addappid(3297870)
addappid(3297871, 1, "0b6a3aea1c5f6d993ef526cb696943cf17954383043b07696dbc7245cd1b0083")
