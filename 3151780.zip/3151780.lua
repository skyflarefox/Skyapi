-- Lua provided by SkyAPI 
-- Game: AppID 3151780
addappid(3151780)
addappid(3151781, 1, "f472a96f40a617fe0d6c837c448cd6c5430c91c967b6a2afeef1da7be1ac970c")
