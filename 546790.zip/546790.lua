-- Lua provided by SkyAPI 
-- Game: AppID 546790
addappid(546790)
addappid(546791, 1, "1f3fed69a5b9d9c4b6392b5fc3cff424e341e72f9b6c8e091823a643466942d6")
