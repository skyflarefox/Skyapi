-- Lua provided by SkyAPI 
-- Game: Freddi Fish 3: The Case of the Stolen Conch Shell
addappid(294540)
addappid(294541, 1, "463eb98123bf336516a90febe447ec0466ddf1773e7edea47810c08e36630fa6")
addappid(294544, 1, "61eae730be928546c610de8b77cd6a6338018e4f4d9e7bda7b32107db69ad2aa")
addappid(294545, 1, "b1e8694b1ccdc621d4c8635b0fd480a3e30bd26827ba0755766e873f6042891a")
addappid(303020, 0, "60f6678000c2f67e214614ca0712477d683a21c76dbdedd03365a9a82b8773eb")
addappid(303021, 0, "885ad2e850afec763d0503addd7aa821a45b02e49d17e477b317f87a179c4d24")
