-- Lua provided by SkyAPI 
-- Game: 雷雨漫漫Endless Thunder
addappid(2309520)
addappid(2309521, 1, "e7c1911b128f8e3832428393cf9dfc43e752f85c1005007e68ee951c22b3c2eb")
