-- Lua provided by SkyAPI 
-- Game: The Walking Dead: Saints & Sinners - Chapter 2: Retribution
addappid(1947500)
addappid(1947501, 1, "3e113ec5caeaabe59a05798925fc253f0d1e16b6bd978ab02787883ed500cb4f")
addappid(2341660)
