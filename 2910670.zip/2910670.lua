-- Lua provided by SkyAPI 
-- Game: AppID 2910670
addappid(2910670)
addappid(2910671, 1, "468de3990e06c48e8d7d71dc4e28c757a8ca653857ffe768333ccfd7b3e59367")
