-- Lua provided by SkyAPI 
-- Game: Fortune's Run
addappid(1692240)
addappid(1692241, 1, "15cb8dbf675643095e670d155c0d1122ec8def48372a921c33ffb6a0a4ab06b0")
