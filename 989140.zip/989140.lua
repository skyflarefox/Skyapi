-- Lua provided by SkyAPI 
-- Game: AppID 989140
addappid(989140)
addappid(989141, 1, "8807eed61167a602968874eb31e8b9cc042aa91d065d4acfafea727ef6913d99")
