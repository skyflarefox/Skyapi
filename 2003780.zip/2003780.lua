-- Lua provided by SkyAPI 
-- Game: Celestial Project Demo
addappid(2003780)
addappid(2003781, 1, "8d8847421f27b8e79adc4e3caf895070c986234ebca59c75842b3014a5da85ee")
