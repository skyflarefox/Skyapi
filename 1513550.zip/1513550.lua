-- Lua provided by SkyAPI 
-- Game: Table Tennis Pro
addappid(1513550)
addappid(1513551, 1, "cd86029f1e6f3ff52447221983cca89331df712fff747b73ae095aff40e43def")
