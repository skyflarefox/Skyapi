-- Lua provided by SkyAPI 
-- Game: AppID 935260
addappid(935260)
addappid(935261, 1, "5a9804e42950c8c0b40ae6a7b9feca59e7354f93ee9246676ca24a3164c2cf44")
