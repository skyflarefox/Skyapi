-- Lua provided by SkyAPI 
-- Game: AppID 1128450
addappid(1128450)
addappid(1128451, 1, "8e1839dc20fcc5f2460a3221460976ed528d8d71617f45b9ae55a29d52f697a5")
