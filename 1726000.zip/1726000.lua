-- Lua provided by SkyAPI 
-- Game: AppID 1726000
addappid(1726000)
addappid(1726001, 1, "c8ca05a8a7b89cdf80a2a50d2988eb1c7c4ef15c2d5ac69707ab00ec683b0d8d")
