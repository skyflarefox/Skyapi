-- Lua provided by SkyAPI 
-- Game: AppID 954280
addappid(954280)
addappid(954281, 1, "6bcb29172768389988c56a61fd7dba8f2e172b8f12ab6c3bd0351321838932f0")
addappid(2463890, 0, "c942ac5dd8ed29ec42861a0ca91b89e2da9b0e1fcb933b7f4e7ab1c01c3b56f9")
