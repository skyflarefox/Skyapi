-- Lua provided by SkyAPI 
-- Game: #CuteSnake
addappid(782100)
addappid(782101, 1, "f4cf5a523787d6664b813b3261003d00e092183bb954c0e058793ee08c16a2df")
