-- Lua provided by SkyAPI 
-- Game: Prey
addappid(3970)
addappid(3971, 1, "7fa9111cae91ee264476f092ae37d2e563cd3cc008c6bab51a73a63a5c2492da")
addappid(3972, 1, "5022827cf1117c40b4a4164b3e15f435f0a6bc6aafb14f38b78bccc59a93df37")
