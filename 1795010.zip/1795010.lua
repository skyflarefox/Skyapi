-- Lua provided by SkyAPI 
-- Game: Funtasia
addappid(1795010)
addappid(1795011, 1, "3dd65d42059e947e8f8c8098fe01fe28aa6760c9ea31670a1c10f276cd7466f5")
