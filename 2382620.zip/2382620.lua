-- Lua provided by SkyAPI 
-- Game: The Stoevi Curse
addappid(2382620)
addappid(2382621, 1, "c114cef56d487920c858122fc08c1dece94c0cf842030d37dbd653e69e6ad963")
