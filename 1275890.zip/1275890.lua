-- Lua provided by SkyAPI 
-- Game: Baldi's Basics Plus
addappid(1275890)
addappid(1275891, 1, "311496f62a59013629f9698b66e74dc8432a2fd9d30b1182891b7a37a9f2113f")
