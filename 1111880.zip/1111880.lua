-- Lua provided by SkyAPI 
-- Game: AppID 1111880
addappid(1111880)
addappid(1111881, 1, "daf9996dee634a52fdeebeecc27ef739eb2c5f7736bff87653df0183312a2ee1")
