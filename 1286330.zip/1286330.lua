-- Lua provided by SkyAPI 
-- Game: WhiteLily 2：梦醒少女
addappid(1286330)
addappid(1286331, 1, "98313ae9c3fc7fdaae1b1cdf15c5b575f1fcc3452b201b9c74011eaa182bff38")
addappid(1588360, 0, "dc027d5ec08f71626e9765aed4b6db7a89d897aad44f3158a7067772f78b0151")
addappid(1588370, 0, "8955a6b1d11fae5eed356d6a0eb160028704f3d6722e1b72329596ff592940a3")
