-- Lua provided by SkyAPI 
-- Game: Beach Ball Valley
addappid(454830)
addappid(454831, 1, "aa3cdcf359e7f91cc846cdc96f33e8d77cbc6fa0777d359f82c2888d38893f51")
