-- Lua provided by SkyAPI 
-- Game: AppID 420520
addappid(420520)
addappid(420521, 1, "435e942e0b8c6d16485fb4123116f4bd59094d0648208b0cb16e1c47efde3d76")
addappid(420522, 1, "f394ec201e57ae06bc3b184091b1b6a2a07bf602add30ce7b32d6cbacaf71345")
