-- Lua provided by SkyAPI 
-- Game: NASCAR 25
addappid(3873970)
addappid(3873971, 1, "426d1f99b6979fafd74cccbfcf4d62638edfa295a3deaccffdbf15a58039d77f")
addappid(4132390)
addappid(4132400)
addappid(4132410)
addappid(4132630)
