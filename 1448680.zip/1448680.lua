-- Lua provided by SkyAPI 
-- Game: Vigil: The Longest Night Artbook and Map
addappid(1448680)
addappid(1448681, 1, "5e5a84abfafbbd02b4f29c5fbadea27044d7b8980db17e860255aef53c7c9079")
