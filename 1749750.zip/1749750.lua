-- Lua provided by SkyAPI 
-- Game: AppID 1749750
addappid(1749750)
addappid(1749751, 1, "df1a43a719b08e88f04345fffa4c8675b5fd85304af261ada11233f805811173")
addappid(2051970, 0, "21e0f12d187860fe3b67d369bd2180cad8669d2726c4b1eee68d2e3d0eb3b74d")
