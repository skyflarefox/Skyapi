-- Lua provided by SkyAPI 
-- Game: My Stepsis is a Futanari
addappid(1757760)
addappid(1757761, 1, "348c6380529f98559ad226f214886274884bb148159f202470ec5b2c3fd67ae5")
