-- Lua provided by SkyAPI 
-- Game: PHOGS! Demo
addappid(1280140)
addappid(1280141, 1, "76c031a60ba44e06583fe054967a0a3c5f155a490688d0908a5359db738b2e67")
