-- Lua provided by SkyAPI 
-- Game: Monster Girl Saga: Fallen Heroes
addappid(3459850)
addappid(3459851, 1, "b40cca8a471e5fc042be13e34a521d5e89b6c931ae17c412ff564056787bf95e")
