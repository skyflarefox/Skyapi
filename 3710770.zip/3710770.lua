-- Lua provided by SkyAPI 
-- Game: GlobalQuarantine
addappid(3710770)
addappid(3710771, 1, "d672d9031d880f45c64b1d77f6a6122a0bf9ad2bd5385f808f47aae6d062f980")
