-- Lua provided by SkyAPI 
-- Game: AppID 485560
addappid(485560)
addappid(485561, 1, "4449cbb4369e3ece1cd13543ddbd19b3751e28eca0c5a16d982b9d6e383d256f")
addappid(485562, 1, "6175e27c5f8c175ca4c40fdc31219933964e5bf0c1fe1d9501511e63068e6b98")
