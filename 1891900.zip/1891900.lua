-- Lua provided by SkyAPI 
-- Game: Comixxx Flirtatious
addappid(1891900)
addappid(1891901, 1, "bfa2baccd6d3717c06783f3bddcbb96e4797a1b119faf35d6da3b0f82026f7ba")
