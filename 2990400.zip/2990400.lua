-- Lua provided by SkyAPI 
-- Game: Aberrant Nights
addappid(2990400)
addappid(2990401, 1, "329923102a8b34db2443cee3621f50b4f8d51d07aca4def58e960004e26ac743")
