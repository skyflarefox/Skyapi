-- Lua provided by SkyAPI 
-- Game: Temtem
addappid(745920)
addappid(745921, 1, "0b59c50f2cfd62e43a3afffc1ad18f2fd3719fda048cca059b6b56d966c797f5")
addappid(787671, 0, "3340b5917f8c2671fdbe44fb8aa33f675e1830986524329215dc202caf5c6087")
