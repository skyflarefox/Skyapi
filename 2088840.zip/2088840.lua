-- Lua provided by SkyAPI 
-- Game: Picayune Dreams
addappid(2088840)
addappid(2088841, 1, "d94248295f21c98beccd3492513b916ce1614a571d684ac7f904bfbd84d7900c")
