-- Lua provided by SkyAPI 
-- Game: DIG VR
addappid(2891460)
addappid(2891461, 1, "63ca96859e38130e01e89522c3a63f2b1da0336d6758a9348bbfda868f987393")
