-- Lua provided by SkyAPI 
-- Game: Condo
addappid(3739210)
addappid(3739211, 1, "85e0151786f3177bb6c810fdcca1ee74879912916fb8070e0b919a48bd32eb45")
