-- Lua provided by SkyAPI 
-- Game: Heavy Memories
addappid(980690)
addappid(980691, 1, "2e0b55c88c809aea634b78121b4a6790966f7c214c7bb9afd1a5eb0131aac6b8")
addappid(1000290)
