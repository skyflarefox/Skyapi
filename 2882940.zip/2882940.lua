-- Lua provided by SkyAPI 
-- Game: Origami Treasure Demo
addappid(2882940)
addappid(2882941, 1, "3572e1a842852765bb93bb07b0824177f13175347e50431a9f9877044652fc1a")
