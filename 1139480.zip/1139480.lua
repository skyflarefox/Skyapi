-- Lua provided by SkyAPI 
-- Game: Mask of Sanity
addappid(1139480)
addappid(1139481, 1, "66a9abaaf75112ea5f936334116882a0ade45d383b7c9adbd4da22f1607903cc")
addappid(1139482, 1, "e128635e4e47ff7139d837c8a131cc44dee484ce1f79b3bc35a194f931aeaee2")
addappid(1139483, 1, "e5f99dcda95b2b01793d9bb13cdde864d8740a2f337d348358f4c7da32a7e0fe")
