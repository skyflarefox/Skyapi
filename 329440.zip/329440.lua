-- Lua provided by SkyAPI 
-- Game: Sonic Lost World
addappid(329440)
addappid(329441, 1, "f04a41b8c03dadf5c23fe09d6eb014cb62f632aadd68c1a7a3b3b2afb34c3d9c")
addappid(377210, 0, "74a425b244d1f5f37e0ed874d89d2e5d708a588709c2c3d5036cd46ad77ad109")
