-- Lua provided by SkyAPI 
-- Game: SQUASER 5
addappid(3540670)
addappid(3540671, 1, "5e2a98ad35149991ca7cfe93fb505463d599b8703518050754ff8534ea9f1bb9")
