-- Lua provided by SkyAPI 
-- Game: 规则怪谈：梦核密室逃脱
addappid(3436840)
addappid(3436841, 1, "9d9bd492c88b1a88592981143337bee94cc5afaafd090d2d0fa127128d0cf497")
