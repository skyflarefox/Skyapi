-- Lua provided by SkyAPI 
-- Game: YKMET: Strade
addappid(3515380)
addappid(3515381, 1, "5a00b6037e7f15ea1e33d00a6664eb95c58272ccf1693160d58366101aef389d")
