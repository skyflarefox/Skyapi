-- Lua provided by SkyAPI 
-- Game: AppID 895150
addappid(895150)
addappid(895151, 1, "7c0ed2d105dfbd0ec35baf491f6e176a2c7987bdb3fa3fb419bf5194cc8c8fd5")
