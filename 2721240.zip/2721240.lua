-- Lua provided by SkyAPI 
-- Game: Brothel Secrets 🔞
addappid(2721240)
addappid(2721241, 1, "c10a81267d98a6a76323ac707aaa92e8c8d4d4bdf52dcf94c9a0b5b6f840fa7f")
