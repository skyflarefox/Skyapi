-- Lua provided by SkyAPI 
-- Game: Disaster Band
addappid(2216360)
addappid(2216361, 1, "23a25c3c3df61a098c9013088bcb3a550395f1359b791465ea09669054dc7c18")
