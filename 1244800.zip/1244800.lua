-- Lua provided by SkyAPI 
-- Game: Terraformers
addappid(1244800)
addappid(1244801, 1, "8497f1f2c3d208f4150b210cfc9f1b5281d74a3b2e5e209a235baa4ad9553ad4")
addappid(1783650, 0, "0474504e1c09e61912b386782d3e567401170d2a93feb96f49fadd18746ec18f")
addappid(2646850)
