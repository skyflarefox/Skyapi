-- Lua provided by SkyAPI 
-- Game: Crescent County Demo
addappid(3373650)
addappid(3373651, 1, "2ac1515c5aa0ae4a8f245c15c568ca58ced8632420a071cbe8d40c10e4aea0cb")
