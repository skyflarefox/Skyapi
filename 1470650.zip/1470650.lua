-- Lua provided by SkyAPI 
-- Game: bullets
addappid(1470650)
addappid(1470651, 1, "dacc29369bbc6ed5877b4a371b1c043d90d0dea8f7e6a152f348a93a70d0f04d")
