-- Lua provided by SkyAPI 
-- Game: Godslayer Arena
addappid(2870430)
addappid(2870431, 1, "fee213fd375ad3a530c3de459562eacf8fca03e04cc93bd25d2d417b06ff5c68")
