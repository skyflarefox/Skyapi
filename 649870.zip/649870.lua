-- Lua provided by SkyAPI 
-- Game: AppID 649870
addappid(649870)
addappid(649871, 1, "0df1df0b2b378462d3749b87de975ffff3e6cd2322ef13210e296979fea702e6")
