-- Lua provided by SkyAPI 
-- Game: Paradox Wrench
addappid(779250)
addappid(779251, 1, "532831d27fb7fd0f0a72c9dbaa300d0cd9017ffee6ebe173975a3f30d44e6588")
