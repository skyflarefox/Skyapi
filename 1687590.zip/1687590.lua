-- Lua provided by SkyAPI 
-- Game: Mars Base
addappid(1687590)
addappid(1687591, 1, "563ccc9eb5b6ae90dc1353a757afe2e74b0e62e10545053121c36e0be48dac8d")
