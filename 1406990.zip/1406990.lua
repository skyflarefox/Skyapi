-- Lua provided by SkyAPI 
-- Game: NEKOPARA Vol. 4
addappid(1406990)
addappid(1406991, 1, "3a788925e3104dac2a37bd06c1889d4de6ed05d62e672b9f9283f07fd45e3f4c")
