-- Lua provided by SkyAPI 
-- Game: Odinfall
addappid(2154240)
addappid(2154241, 1, "2bdb2330782582bb0c9d3445a7c5d55115b4368433cdbeb303c095d56bfabb67")
