-- Lua provided by SkyAPI 
-- Game: AppID 723820
addappid(723820)
addappid(723821, 1, "58ab0533dc63597f5b7a637618469fbb6d057784acc31b4122de436b658ba935")
