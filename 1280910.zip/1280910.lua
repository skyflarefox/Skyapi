-- Lua provided by SkyAPI 
-- Game: AppID 1280910
addappid(1280910)
addappid(1280911, 1, "556eaf6b3523e989242c9fd2bf97bcac7a5955ea1c5251c19d341bc8d49a677a")
