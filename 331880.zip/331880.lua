-- Lua provided by SkyAPI 
-- Game: AppID 331880
addappid(331880)
addappid(331881, 1, "64c6c2c457589ba191a1deeb2c85bae5a7442d49a9e4b494e3a8289f9a6fa18b")
addappid(331882, 1, "5cc7dcd0c9e8a1be282c138f38b6938abd39c87b14e58323e02ec1ed635a0c21")
