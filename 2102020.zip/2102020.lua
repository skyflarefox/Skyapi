-- Lua provided by SkyAPI 
-- Game: Different Strokes
addappid(2102020)
addappid(2102021, 1, "8ee2e4963f095c9efafbbbf312f0894026dd686205e261fdc8317858350218f7")
addappid(2182660, 0, "48a3cb3242a629b4587baa6bac5b863b93952d8ee1d42328ba44682cf84aec1a")
