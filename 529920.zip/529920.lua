-- Lua provided by SkyAPI 
-- Game: Resurgence
addappid(529920)
addappid(529921, 1, "cf4c630390f79c55bb81e6ab569dc835398023e160acafa20a5a4f3c03ca8fa1")
