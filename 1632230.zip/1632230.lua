-- Lua provided by SkyAPI 
-- Game: Newtonian Inversion
addappid(1632230)
addappid(1632231, 1, "71ac7c8990036cd3d8c79038d1546b1de39877ba5389634a119f4dc879263027")
