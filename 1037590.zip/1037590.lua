-- Lua provided by SkyAPI 
-- Game: Neptunia Shooter
addappid(1037590)
addappid(1037591, 1, "f9e9a18077b2e3ef615b6bf5a59d0a61c9cc29f9c836a1178c4319d5ff4f364e")
