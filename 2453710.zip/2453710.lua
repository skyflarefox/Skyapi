-- Lua provided by SkyAPI 
-- Game: Lethal Operation Episode 3 Lethal Arms of Justice
addappid(2453710)
addappid(2453711, 1, "2D754D5C89199AD2EB90CC028A8E8E7D3A9106AB65C8535FBB37F41805721C0B")
