-- Lua provided by SkyAPI 
-- Game: AppID 1294780
addappid(1294780)
addappid(1294781, 1, "09139acdedea2ad4ea7f20e5b48a5007eacc4c52f486c67cbd9b2b0cb1d9219c")
addappid(1294782, 1, "e8f0f0c5108dd14b37564f37f698ef72c6aaa48a9a971b637159e272e88e97ba")
