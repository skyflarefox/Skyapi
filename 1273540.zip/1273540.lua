-- Lua provided by SkyAPI 
-- Game: AppID 1273540
addappid(1273540)
addappid(1273541, 1, "4512476479ff9928f18955fcf32ca1d6e269de5cc6aafcf53882601f0afe4147")
addappid(1773880, 0, "d9b3b1ed60d9c111fea84d9c87a19abccff6bfc1ec63bb27829e10b8a9f4696d")
addappid(1823720, 0, "dc723a70d7baca338ba087bfa5b0088ff18958a83707812eb14478c070d7e4d0")
