-- Lua provided by SkyAPI 
-- Game: AppID 2825940
addappid(2825940)
addappid(2825941, 1, "420a9cfd94102e261dfd11c3c23044387174c105453401a0a2d544c43fce7c6e")
