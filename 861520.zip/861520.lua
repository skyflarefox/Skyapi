-- Lua provided by SkyAPI 
-- Game: #AkiRobots
addappid(861520)
addappid(861521, 1, "bdef153ce751c59a86fbbf80e74f8aa4ade477f6d786502f0c91464547959c09")
