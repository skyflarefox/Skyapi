-- Lua provided by SkyAPI 
-- Game: Dirty Fantasy
addappid(3217910)
addappid(3217911, 1, "6c90f54398b959656334b80ab8cc5b7cf05e8b336373d2ec1d222a1b482d435f")
