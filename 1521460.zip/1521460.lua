-- Lua provided by SkyAPI 
-- Game: Flowers Blooming at the End of Summer Digital Wallpaper
addappid(1521460)
addappid(1521461, 1, "5dbdf608ecc9358c41d3f7b5c2597d9154ef9f319378cbb3d7429d64a369b33a")
