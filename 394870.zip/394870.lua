-- Lua provided by SkyAPI 
-- Game: Office Battle
addappid(394870)
addappid(394871, 1, "220a39b86b61af4248eb8084304d12bbc7861a5d44b344407e26334123347751")
addappid(420310, 0, "9a36ecb72e5a5e0e0e23cc637b5fe4f180c4ac8e057439423d37a434bf4a2af6")
