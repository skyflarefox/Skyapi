-- Lua provided by SkyAPI 
-- Game: Tenebris: Terra Incognita
addappid(2280060)
addappid(2280061, 1, "a8928c3e35f1b486b7e6601779a46aba034470b87b29c84e6035c53ef8da4597")
