-- Lua provided by SkyAPI 
-- Game: CLeM
addappid(1861440)
addappid(1861441, 1, "251e6fe7522b25bb152fea1c17c4657596a926d3703fb4f4dcf6d1d31b554711")
