-- Lua provided by SkyAPI 
-- Game: STORMBLOOD: FINAL FANTASY XIV Original Soundtrack
addappid(3372280)
addappid(3372281, 1, "238914f54210c1e50aa7a04bc4cda8df17cda8a00a464d52dffa505e0d8a7846")
