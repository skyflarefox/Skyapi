-- Lua provided by SkyAPI 
-- Game: AppID 1250820
addappid(1250820)
addappid(1250821, 1, "a3f11557111cc4dfa0ceb0cacec037c307e1a7f1778a200ec7cc8c5ad170d2c9")
