-- Lua provided by SkyAPI 
-- Game: Ys X: Nordics
addappid(2570810)
addappid(2570811, 1, "632b952fc96fea8272f531a7a8b186927c081ce1228916809d6b7e6ace47379d")
