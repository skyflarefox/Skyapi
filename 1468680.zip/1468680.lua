-- Lua provided by SkyAPI 
-- Game: LiftAir Ski Jump
addappid(1468680)
addappid(1468681, 1, "2d512e8cd982acfa10ef5c7b2486d4f5a911fd9b9c0c8ef15e4f9d6c3c120162")
