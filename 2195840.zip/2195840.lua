-- Lua provided by SkyAPI 
-- Game: Furcifer's Fungeon Demo
addappid(2195840)
addappid(2195841, 1, "7c6b49375b7d1df8983edadb544a3f3977a3659be4e7e940c2a61fb9cd9b315a")
