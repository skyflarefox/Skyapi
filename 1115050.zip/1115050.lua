-- Lua provided by SkyAPI 
-- Game: AppID 1115050
addappid(1115050)
addappid(1115051, 1, "346aaa98fc5e8195ca6603a8308ae9e5b5738cae6eb8cb6e468d945108f08899")
