-- Lua provided by SkyAPI 
-- Game: MIDIToKey
addappid(2091610)
addappid(2091611, 1, "bb47a7ea2b46d60b214661a7876896222c9cb8f70f11143183e90db9a11afc7c")
