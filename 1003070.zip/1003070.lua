-- Lua provided by SkyAPI 
-- Game: AppID 1003070
addappid(1003070)
addappid(1003071, 1, "3164326b1aba3be5402482f71244032d51fcd978e34fa07a52da93b16ad6bc1e")
addappid(1003072, 1, "5110c859a121b6c97d284c28d6ecacf029a5b17974aa718dbce8360331ce908a")
