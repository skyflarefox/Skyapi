-- Lua provided by SkyAPI 
-- Game: DAEMON MASQUERADE Demo
addappid(2277120)
addappid(2277121, 1, "ed21a1ed425ac7517a18c55fd7ccb7af2bd70daf53c02177c62636ea4d670d6d")
