-- Lua provided by SkyAPI 
-- Game: AppID 1561340
addappid(1561340)
addappid(1561341, 1, "6e8b0af93aa27fac68cdccd8ca01f89226895a50b73687de76e5e7d47b98252a")
