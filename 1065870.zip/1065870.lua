-- Lua provided by SkyAPI 
-- Game: BRG's Alice in Wonderland Visual Novel
addappid(1065870)
addappid(1065871, 1, "9680723213b325a19eee30e11962fdf5dc2a2dfd00a66497165ebd22428033cd")
