-- Lua provided by SkyAPI 
-- Game: AppID 395760
addappid(395760)
addappid(395761, 1, "baae0772854201dc2cdfee355414f1805353ff8889e8273943fae3f7124821ae")
