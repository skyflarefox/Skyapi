-- Lua provided by SkyAPI 
-- Game: Circle Empires Rivals Soundtrack
addappid(1293580)
addappid(1293581, 1, "125475080728b347ea989e6645154ddcde39626ab96faf93a624dd692a4ef20c")
addappid(1293582, 1, "10081e0fb6de691a0119734b53d1a730766ba1bc3955240995476b2435b79cdd")
