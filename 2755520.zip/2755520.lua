-- Lua provided by SkyAPI 
-- Game: Dark Sword: The Light of Ainn
addappid(2755520)
addappid(2755521, 1, "b6d329c19b20ad2685e60388bf556a8a610286d5e804e1fee75306d139845134")
