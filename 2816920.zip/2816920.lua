-- Lua provided by SkyAPI 
-- Game: AppID 2816920
addappid(2816920)
addappid(2816921, 1, "b3397eafff0a6f24bda014531ed2f2dfe7c3e56c4e97a7ada0594612cfc669b9")
