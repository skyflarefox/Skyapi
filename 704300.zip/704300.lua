-- Lua provided by SkyAPI 
-- Game: Bartender VR Simulator
addappid(704300)
addappid(704301, 1, "8e4f3e847ee835c3831df9ac62e59a9ff98d42b31200aaf722701f335fff8553")
