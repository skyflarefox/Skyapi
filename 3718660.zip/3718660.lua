-- Lua provided by SkyAPI 
-- Game: Coin Hunter
addappid(3718660)
addappid(3718661, 1, "b7c44d51610401882bfbd12f1c951c79d9124c1de3ad6fd8d3a33c3fee2773d3")
