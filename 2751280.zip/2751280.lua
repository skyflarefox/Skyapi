-- Lua provided by SkyAPI 
-- Game: AppID 2751280
addappid(2751280)
addappid(2751281, 1, "82c63aa494580728f1130efd7be5982e192682dc5ec34415eb5c24e0770f8178")
