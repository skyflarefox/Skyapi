-- Lua provided by SkyAPI 
-- Game: AppID 408330
addappid(408330)
addappid(408331, 1, "1b425d37d49b006c2c12d5646da36be6c0f9cb096bb9bf3d2207aca04e5ac5e9")
