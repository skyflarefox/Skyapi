-- Lua provided by SkyAPI 
-- Game: AppID 864700
addappid(864700)
addappid(864701, 1, "faedd46777d12749271e88108954cd2db14f7920472fe445a1b62c5867cff3fc")
