-- Lua provided by SkyAPI 
-- Game: AppID 224980
addappid(224980)
addappid(224981, 1, "3e1a7b127da35a84e3a9eec8906b99258420401b0fe13c8fd2e1fe73d1f0beb5")
