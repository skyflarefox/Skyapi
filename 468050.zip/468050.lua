-- Lua provided by SkyAPI 
-- Game: The Last Time
addappid(468050)
addappid(468051, 1, "94af3080e7c8465eba51440473582d0f093dccc194827d2bbb3d60230dbd319e")
addappid(468052, 1, "f3fe4eb7e29b65958fd055ce85e7fb62ac0c1bf0abd6f6abe738d07719a5b638")
addappid(468053, 1, "bedf2d687ca5b3b02dd586ea5e0bdbb854e3eeedf83b20e9afd7bbfd841f399f")
addappid(527170)
