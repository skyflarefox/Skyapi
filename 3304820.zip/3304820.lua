-- Lua provided by SkyAPI 
-- Game: Vespia: Shield of Aberration
addappid(3304820)
addappid(3304821, 1, "60cf4d86193563f85b5907163688ead4cd40b5ab5bb28e0f296bce92b896e85a")
