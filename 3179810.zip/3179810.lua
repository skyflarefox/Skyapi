-- Lua provided by SkyAPI 
-- Game: Tiny Dangerous Dungeons Remake
addappid(3179810)
addappid(3179811, 1, "5cd551a2cf589edb61616942a5ef65e8da886f9a7c0d131da7922c3fbf47e1ac")
