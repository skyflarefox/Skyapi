-- Lua provided by SkyAPI 
-- Game: Captain Velvet Meteor: The Jump+ Dimensions Soundtrack
addappid(2497770)
addappid(2497771, 1, "7fc2c086f42c9a38123bbdacb7c1e4f0cc7afa9a6629028491526c1ff3bd240f")
