-- Lua provided by SkyAPI 
-- Game: AppID 3265180
addappid(3265180)
addappid(3265181, 1, "bfe6aa02ac3e7be428ff8b7bfd2193bb02276d81adfa19c4931ec8aac5e4716a")
