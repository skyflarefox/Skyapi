-- Lua provided by SkyAPI 
-- Game: Starship Annihilator
addappid(525300)
addappid(525301, 1, "d7ceb321651a3130895a9c68dd66372dc47171dc1b753a3b9c2d3c985cd49845")
addappid(529400, 0, "ac9c779804f6db779ae386ea9fa1adcbc21a77c753ded50d5a791f1d1a31d135")
