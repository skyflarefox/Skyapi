-- Lua provided by SkyAPI 
-- Game: Mage and Monsters
addappid(1950440)
addappid(1950441, 1, "5982f67cf4b3aa50b3a175c6bc94649265fc947a585b40d4f8513058199fd6c9")
