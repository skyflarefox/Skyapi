-- Lua provided by SkyAPI 
-- Game: Once upon a Dungeon II
addappid(2204730)
addappid(2204731, 1, "3b285592f402731907ee92b2f9c01f5b53ee2fc0dc247fda8cbe6c7f30601300")
