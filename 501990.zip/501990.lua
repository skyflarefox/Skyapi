-- Lua provided by SkyAPI 
-- Game: AppID 501990
addappid(501990)
addappid(501991, 1, "4beeec07590c8c2893254fa0eb58a8df4db6847e40c9eec93c440eab033986b5")
