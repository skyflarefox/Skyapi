-- Lua provided by SkyAPI 
-- Game: Gravel Gang
addappid(1518860)
addappid(1518861, 1, "b4c356710c9c22638ae202b0aa840e9f702e03dfb6fdc3bb7a2673ed1d2054e7")
