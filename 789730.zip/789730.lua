-- Lua provided by SkyAPI 
-- Game: Not Without My Poop
addappid(789730)
addappid(789731, 1, "3e4609f9dc66c5d50f7ceaed29171fedeaad8d4ab9b79ae55d9dc7f066f762e2")
