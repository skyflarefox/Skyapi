-- Lua provided by SkyAPI 
-- Game: Toy Shire
addappid(2361460)
addappid(2361461, 1, "6c8e6c05dd18bd60d8e9b322876fe53dc50e732db4866fa8e68a214889ec8c0c")
