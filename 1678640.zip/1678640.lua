-- Lua provided by SkyAPI 
-- Game: Unsouled - Digital Artbook
addappid(1678640)
addappid(1678641, 1, "c14a3f2e3ec3b530e398b4a89bce64ec0547fa53095a37105f2ede1caa4ca7f8")
