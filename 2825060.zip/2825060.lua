-- Lua provided by SkyAPI 
-- Game: AppID 2825060
addappid(2825060)
addappid(2825061, 1, "aee394420c6fd20281d9297fab078702a28ad80ea1bef57c55a82760d15ea346")
