-- Lua provided by SkyAPI 
-- Game: Criminal Attraction
addappid(2775050)
addappid(2775051, 1, "c4c5b96488a4515d97f83a64009b4a5d4e305d56308e79466030df0fb595a3c9")
