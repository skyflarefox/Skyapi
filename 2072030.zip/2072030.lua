-- Lua provided by SkyAPI 
-- Game: Echo Wisp
addappid(2072030)
addappid(2072031, 1, "deb7813f0b4820991a23e83e704433a6c5e1215e9fd1a062adc727559ab08499")
