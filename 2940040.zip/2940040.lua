-- Lua provided by SkyAPI 
-- Game: Trolls vs Vikings: Reborn
addappid(2940040)
addappid(2940041, 1, "5da71a4c5ce92ae5f59611776ec9b9c2ee051cc574af66a29a71e2fbcf80d11a")
