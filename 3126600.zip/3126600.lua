-- Lua provided by SkyAPI 
-- Game: The Depths of Despair Demo
addappid(3126600)
addappid(3126601, 1, "601b9f2ca8c05c44c754f07769573c6ca6ed68177f43f0e68a24841ce711a5c9")
