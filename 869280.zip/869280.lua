-- Lua provided by SkyAPI 
-- Game: RapStar Tycoon
addappid(869280)
addappid(869281, 1, "63f7f5a9649ed6dcbb8cd0cba2c194bfa96a6c4e2eeec252f2cb506842879d79")
