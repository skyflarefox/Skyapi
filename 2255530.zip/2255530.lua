-- Lua provided by SkyAPI 
-- Game: Regenesis
addappid(2255530)
addappid(2255531, 1, "0a872690f8b0f5ab3a0fe6707e9931dd8075e2e41f129f1be2ea787e908a676d")
