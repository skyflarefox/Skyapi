-- Lua provided by SkyAPI 
-- Game: La Quimera
addappid(2282350)
addappid(2282351, 1, "6d30b906df3f94271959b620e26ffa9c21aced6a540a1fd659b8af7adae0ede2")
