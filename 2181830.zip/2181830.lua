-- Lua provided by SkyAPI 
-- Game: Follow The Crown
addappid(2181830)
addappid(2181831, 1, "345a0e1a1268028bdf8fdf462155ae54d08d19133e48a431c325e123f8544730")
