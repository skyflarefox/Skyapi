-- Lua provided by SkyAPI 
-- Game: AppID 283820
addappid(283820)
addappid(283821, 1, "2877ca34af758d05144114e1bbfe562f6f0eb11db777c4dbc0f5473990934a9f")
addappid(283822, 1, "ade8a089f7c3debc3dd88a27aa5320579b5a1db7a2004e0b8362610e956a59b2")
