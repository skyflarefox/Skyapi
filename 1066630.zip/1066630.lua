-- Lua provided by SkyAPI 
-- Game: Master Magistrate
addappid(1066630)
addappid(1066631, 1, "4833965e25fac60c05374b668fbbbad07d4a6166cbe4e9d81c48282b45cb8d8d")
