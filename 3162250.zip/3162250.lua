-- Lua provided by SkyAPI 
-- Game: AppID 3162250
addappid(3162250)
addappid(3162251, 1, "4a85fa5aa24d22ebcc8ed026fb4a3274511f29485167e5454aa0da8a1788626b")
