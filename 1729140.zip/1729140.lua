-- Lua provided by SkyAPI 
-- Game: Hired 2 Die
addappid(1729140)
addappid(1729141, 1, "da5a3e6bbc24688b7eae2f57170eab07c66edcdf9ebf81b9bada505b0d0a2462")
