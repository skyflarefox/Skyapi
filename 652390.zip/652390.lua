-- Lua provided by SkyAPI 
-- Game: AppID 652390
addappid(652390)
addappid(652391, 1, "9b51f9f00c6cc937bcd70d0e4d24eb91842dace6cd274c1b7800afa9c340e1d8")
addappid(652393, 1, "f1edbc72a49392c90af315fbf248667f1670125734b520a62fe523ad1b198ac4")
