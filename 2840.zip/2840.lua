-- Lua provided by SkyAPI 
-- Game: X: Beyond the Frontier
addappid(2840)
addappid(2841, 1, "3b8895419b4af53de7b5f08c4d1385cf109ee5be6bba234328199ed202ba0039")
addappid(2842, 1, "cd4a391bd2c9640f1b6038caf566ebd6a4d340ace33d8b43b288419294edba99")
addappid(2843, 1, "de93d255e1733940f3b8d826cffe5a55ae0e6a59f02a6040d04d3142794ae727")
