-- Lua provided by SkyAPI 
-- Game: AppID 396420
addappid(396420)
addappid(396421, 1, "5495d42b3d70c276c4290b8ffeeddca6609f62c243821518eff54a9aa798a755")
