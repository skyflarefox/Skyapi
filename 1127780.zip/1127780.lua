-- Lua provided by SkyAPI 
-- Game: Daymare: 1998 Demo
addappid(1127780)
addappid(1127781, 1, "61cb1d7887723c2b90b3942a185eedffddb4af4560c49fa17aea8c8af35dbd5e")
