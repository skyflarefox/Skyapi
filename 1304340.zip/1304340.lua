-- Lua provided by SkyAPI 
-- Game: AppID 1304340
addappid(1304340)
addappid(1304341, 1, "3d9a7c2ca1147c026143a07901924be8a2bc38a46a195518c5f48519f13abb25")
