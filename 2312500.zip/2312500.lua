-- Lua provided by SkyAPI 
-- Game: Hidden World 3 Top-Down 3D
addappid(2312500)
addappid(2312501, 1, "6b77e9de390f309ed02accce02af0e766f53a9a6592ed797144a3336553246c2")
