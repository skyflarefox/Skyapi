-- Lua provided by SkyAPI 
-- Game: Holy Heroes
addappid(3107270)
addappid(3107271, 1, "4fe72180ac2a1d6cf422c68b50ecfb805270c79356c4f16dc8ebceab918fdc79")
