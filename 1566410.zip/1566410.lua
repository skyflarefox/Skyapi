-- Lua provided by SkyAPI 
-- Game: Touhou Kouryudou ~ Unconnected Marketeers.
addappid(1566410)
addappid(1566411, 1, "69d6e53ab9f81ffb470430e57f8aa2e3108e3b6695d50d1eff6f3a29cc38364a")
