-- Lua provided by SkyAPI 
-- Game: AppID 1380420
addappid(1380420)
addappid(1380421, 1, "063de495d30f67af07725b9746e40ebfb3bde336231ac892615f66fd1dddf09b")
