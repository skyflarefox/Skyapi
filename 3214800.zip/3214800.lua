-- Lua provided by SkyAPI 
-- Game: AppID 3214800
addappid(3214800)
addappid(3214801, 1, "703ee7a3368fa33ed1245d8dfe5479fb9f31736de181d549c28c8d492ca79a3f")
