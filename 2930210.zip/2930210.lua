-- Lua provided by SkyAPI 
-- Game: MY DOG!
addappid(2930210)
addappid(2930211, 1, "28c81c20318638da7eb9f7f447ec1b8685b342c9db9fb008eaf04f9a0977e721")
