-- Lua provided by SkyAPI 
-- Game: They Are Here Playtest
addappid(2467730)
addappid(2467731, 1, "c97d7278f5db0ecdaa50a80e13d13603aca23ad4f5384ac12ab256770155431d")
