-- Lua provided by SkyAPI 
-- Game: Hauma - A Detective Noir Story
addappid(1443470)
addappid(1443471, 1, "d4cc6d06f78a6bb6b590b2f9e6f1fcb56a39c3d737f61a2a1124c247477c2c92")
