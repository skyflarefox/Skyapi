-- Lua provided by SkyAPI 
-- Game: BATTALION: Legacy
addappid(489940)
addappid(489941, 1, "74435adc1164efd21521555018ef3e81cc7892933c8c9898b4bc4957e7d0997f")
