-- Lua provided by SkyAPI 
-- Game: Death Dojo
addappid(544590)
addappid(544591, 1, "3529e29d3348643367a66f966618f365d152746ef56afcc22c1173c5c54f7f04")
