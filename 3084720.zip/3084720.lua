-- Lua provided by SkyAPI 
-- Game: AppID 3084720
addappid(3084720)
addappid(3084721, 1, "ce3abb97e0e1166937d02a166c54d5f4cc77c4b3ccb78de5d6dd6eb4fe5a6d60")
