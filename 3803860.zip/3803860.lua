-- Lua provided by SkyAPI 
-- Game: Blood Oath
addappid(3803860)
addappid(3803861, 1, "6531150c054a0428a4753cf1903224552c0fa68b1e62171882089c7f6f971b7c")
