-- Lua provided by SkyAPI 
-- Game: Kromaia
addappid(285980)
addappid(285981, 1, "cc42c101917cff5673c6bb1df3c8dbfc1aceafce2cc26b21c20be11b8f69164c")
