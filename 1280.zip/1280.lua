-- Lua provided by SkyAPI 
-- Game: Darkest Hour: Europe '44-'45
addappid(1280)
addappid(1281, 1, "138734b199283e7885c9608a0e3084ee8dfd76197283503c8d34fe3be62b77f4")
addappid(1282, 1, "c26c669966a2d54b5e1715bd14faa2de0607fe762dc07aeebc31a98172cf4710")
