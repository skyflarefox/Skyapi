-- Lua provided by SkyAPI 
-- Game: Marinatide
addappid(566420)
addappid(566421, 1, "ea03601a37c0d9f98468c825869f199e26a1edef8a270583b660ea720002e8c9")
