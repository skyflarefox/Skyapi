-- Lua provided by SkyAPI 
-- Game: Sacred Cubes
addappid(1570740)
addappid(1570741, 1, "beb8770164ff57545d38f4c9b74b26bb00128c3a189e50117b3dd3b1c1e076e3")
