-- Lua provided by SkyAPI 
-- Game: Spray Paint Simulator Demo
addappid(3301340)
addappid(3301341, 1, "18a76f9dfda9ec22c8a4c235a91252228be4131e8f7c51d1808302c4421cadfe")
