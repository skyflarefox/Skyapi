-- Lua provided by SkyAPI 
-- Game: AppID 3208490
addappid(3208490)
addappid(3208491, 1, "77f7083c3c04e3dd54f684eb11ad89107503838b66151096daad7103077b22c2")
