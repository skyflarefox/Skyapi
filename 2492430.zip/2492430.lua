-- Lua provided by SkyAPI 
-- Game: 火焰征程
addappid(2492430)
addappid(2492431, 1, "061f786b6b33be80b6c223185e391a38c83e3a2baab438e64d90901a495f84b7")
