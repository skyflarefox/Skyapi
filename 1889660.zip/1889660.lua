-- Lua provided by SkyAPI 
-- Game: Project XMAS
addappid(1889660)
addappid(1889661, 1, "469c4533d9fd229e91d0ca51378aafd64f5efa2e0a43d8cc0cf269163d1cdad5")
