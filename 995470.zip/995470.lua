-- Lua provided by SkyAPI 
-- Game: Threshold
addappid(995470)
addappid(995471, 1, "ac3d95a3226a2f7e7a037adba12d6cc8f60e011c7e62bf38cf5e840c0bf24af3")
