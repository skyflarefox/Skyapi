-- Lua provided by SkyAPI 
-- Game: Reign of Guilds
addappid(716350)
addappid(716351, 1, "900749c5f46586cd9c823732b9e377672e55bc0f53bf3f49e37d31f0d19bb713")
