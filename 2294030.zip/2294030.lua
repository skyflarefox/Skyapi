-- Lua provided by SkyAPI 
-- Game: Samurai Sword Stage
addappid(2294030)
addappid(2294031, 1, "8d7f26a798fbde151da0a80c6765b6af6408ab1f86eab90a7ff76c4cc871fcda")
