-- Lua provided by SkyAPI 
-- Game: Raspberry Cube
addappid(2001970)
addappid(2001971, 1, "948260248614c9f8395c0f2df09ca4d5bd4720efde305fe2c3639214254d0efd")
