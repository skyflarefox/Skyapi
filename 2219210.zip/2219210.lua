-- Lua provided by SkyAPI 
-- Game: 贪婪大地 Playtest
addappid(2219210)
addappid(2219211, 1, "015c681ee982bd2eab3d5e3d61a2e98ae73c7fa584583a5e19724d4fb5e77c12")
