-- Lua provided by SkyAPI 
-- Game: Exorcist Charlotte
addappid(1892700)
addappid(1892701, 1, "33bb4beca813f83671ebc79b55abfeac8c8f24e428b77325f303cb4c1e64bf5d")
addappid(2296670)
