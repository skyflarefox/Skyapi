-- Lua provided by SkyAPI 
-- Game: The Complex: Expedition
addappid(2172260)
addappid(2172261, 1, "83d83ec58cff9c5a8d4a6c3d49ff5bf3bbd73d72cf9f5fd84508d69d716c5748")
