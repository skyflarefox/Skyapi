-- Lua provided by SkyAPI 
-- Game: AppID 992310
addappid(992310)
addappid(992311, 1, "84e74097c4bbbdc76ee5fbb692d2e5ed1e7597884f7f299c52e89c5e4d6e6c96")
