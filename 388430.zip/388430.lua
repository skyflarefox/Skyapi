-- Lua provided by SkyAPI 
-- Game: AppID 388430
addappid(388430)
addappid(388431, 1, "96b29df0d88fdc091c6d3d6cbfa397925aa64965ace9bd38aaac7eb9e47d18fa")
