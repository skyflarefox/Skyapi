-- Lua provided by SkyAPI 
-- Game: Demon Turf: Neon Splash
addappid(1747890)
addappid(1747891, 1, "a4fc3ee6ae402cadfe40c62942a5cca01b81aaf33ca92da936ea098dd7b8a226")
