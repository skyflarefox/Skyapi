-- Lua provided by SkyAPI 
-- Game: AppID 994700
addappid(994700)
addappid(994701, 1, "0ed341821a32cef64177bef1eac2b0c7820547e0ac0b9889a3b4bba5d1eba6de")
