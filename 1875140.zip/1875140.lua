-- Lua provided by SkyAPI 
-- Game: 黎明为歌 - Melody before the Dawn
addappid(1875140)
addappid(1875141, 1, "ef7512c445e8793ff32f216254249aad6bfd53d625000d676aad97d80a20bf7c")
addappid(1936060)
