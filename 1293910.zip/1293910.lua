-- Lua provided by SkyAPI 
-- Game: Read Only Memories: NEURODIVER
addappid(1293910)
addappid(1293911, 1, "b775f6009847f433753373771d64326ddf38a8662becbbf336fbf3101a3df58e")
addappid(2946780, 0, "2a566733261bca426337e1498852675bd3f57b030c91b74fe6e6f134070bac8e")
addappid(2974180, 0, "68dc30afc0c54f07c967fdf3e675f908cffa1c2a4346ba58caabe50bedd3b622")
