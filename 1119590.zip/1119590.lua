-- Lua provided by SkyAPI 
-- Game: Δ Time
addappid(1119590)
addappid(1119591, 1, "5b7fdaf5efece2bbc760b20bce90492c1a356891316dcc4cbfaa6f3c5fb03f4d")
