-- Lua provided by SkyAPI 
-- Game: Purrrifiers - Friend's Pass
addappid(2235870)
addappid(2235871, 1, "fa5a0853b6e4b260aafa19955a5a027aaa711ccc37bdad10bf325e17613035b4")
