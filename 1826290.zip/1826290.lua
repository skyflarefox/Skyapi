-- Lua provided by SkyAPI 
-- Game: AppID 1826290
addappid(1826290)
addappid(1826291, 1, "c9b635043b3b1f5963c998347afe5743e7b6e4661fcfdf6c83b3e980623661c5")
