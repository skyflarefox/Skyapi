-- Lua provided by SkyAPI 
-- Game: BowMage
addappid(496000)
addappid(496001, 1, "a79d66a5545c3a993d72cfc204c0f17effcb717e389a12b4911a5af5ec746e8f")
