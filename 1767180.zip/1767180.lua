-- Lua provided by SkyAPI 
-- Game: GoldfishFlap
addappid(1767180)
addappid(1767181, 1, "45208af91587fb9572d07c92942ce3a2418eb5ea3a7b54640b484f12fb938442")
