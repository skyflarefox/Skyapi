-- Lua provided by SkyAPI 
-- Game: AppID 1515040
addappid(1515040)
addappid(1515041, 1, "7cc8295987cdd1aa4be9619636e010285809d23c9d8c237c8489b3f901d0cc02")
