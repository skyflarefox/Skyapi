-- Lua provided by SkyAPI 
-- Game: Beer Factory
addappid(1782570)
addappid(1782571, 1, "928a51fe69d7cbcda7c24322219e8a0b7bd9174e28b20acb40eeb0815a3f63d7")
