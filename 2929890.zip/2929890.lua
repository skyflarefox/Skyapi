-- Lua provided by SkyAPI 
-- Game: Cyborg City
addappid(2929890)
addappid(2929891, 1, "c896156881b05e5cb516a2f5fc5e8053836d1c396599f08a4ac6270085e6d076")
