-- Lua provided by SkyAPI 
-- Game: Space Warfare
addappid(1021940)
addappid(1021941, 1, "699d367027ec17723168d17fccddaf1be7422fe537a4bedb1403aac2dd6b0210")
addappid(1021942, 1, "340f6eee9d1a0c3a4c1b0e76356ee345403ca1347548bf8aa40378c8f4a7155a")
addappid(1021943, 1, "b810760fc59988df7de1a240460c95dab46b5b9d35c66eda7033b1294167f836")
