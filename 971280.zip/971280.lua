-- Lua provided by SkyAPI 
-- Game: Bomber Arena
addappid(971280)
addappid(971281, 1, "311f4d7a65738ead053c1eda5b07563c6f6099d0cee25f7997bcbd398a2618c7")
