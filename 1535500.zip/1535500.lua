-- Lua provided by SkyAPI 
-- Game: Mini Car Racing - Tiny Split Screen Tournament
addappid(1535500)
addappid(1535501, 1, "aab145438000bd5a0dae407dfa45c28176c3dfeabb20eab1a49b77a20a25fd92")
