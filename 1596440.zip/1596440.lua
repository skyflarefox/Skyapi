-- Lua provided by SkyAPI 
-- Game: ARKOS
addappid(1596440)
addappid(1596441, 1, "8a9a7b83d3a20e5beb46874514c6e8b93fb06f8e16abb760c7fb805b7a2b3aeb")
