-- Lua provided by SkyAPI 
-- Game: Cosmic Royale
addappid(3315830)
addappid(3315831, 1, "723aedcb0a4a5034e0eeea20027ffc3a139c653c7aa400944145786a9d1351eb")
