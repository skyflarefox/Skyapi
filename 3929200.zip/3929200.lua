-- Lua provided by SkyAPI 
-- Game: BULT: Hunting simulator
addappid(3929200)
addappid(3929201, 1, "01f24d375d502d408f3522e6b492417d29dd2d89be3dbd927711c8e3f2c84ccb")
