-- Lua provided by SkyAPI 
-- Game: Rico-Jump
addappid(1328490)
addappid(1328491, 1, "efd665b88031e3515bb7599d2935cf22bcf8e0f09cef5ca7e3c16127a093ae93")
addappid(1519960)
addappid(1522240)
