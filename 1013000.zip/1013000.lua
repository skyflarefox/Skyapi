-- Lua provided by SkyAPI 
-- Game: AppID 1013000
addappid(1013000)
addappid(1013001, 1, "e253e7784a0e895e91eb9402cb85abc4a2c0558182d82ff08f20c0d1dcba14aa")
