-- Lua provided by SkyAPI 
-- Game: Kenny 7
addappid(2435800)
addappid(2435801, 1, "b42efaea8e4359aeb0aa78c933b8ab08c5c955f420857d1b4250798f4982da27")
