-- Lua provided by SkyAPI 
-- Game: Ballionaire
addappid(2667120)
addappid(2667121, 1, "ed94256223a144a0297adfcfdafe9d6c1c50ba8fa61f41c978b601c82fe0da81")
