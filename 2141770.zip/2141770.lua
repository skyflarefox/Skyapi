-- Lua provided by SkyAPI 
-- Game: URBO
addappid(2141770)
addappid(2141771, 1, "574b482675170472b5e385324d98c698a5a19b464553d3f01300a7d3a7b11cd1")
