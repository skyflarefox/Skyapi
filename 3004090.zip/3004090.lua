-- Lua provided by SkyAPI 
-- Game: AppID 3004090
addappid(3004090)
addappid(3004091, 1, "e1832c2173d7e78e6d0fd851a84a29ec7b20b78b226f4c6502f9c26c33dddc24")
