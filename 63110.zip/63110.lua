-- Lua provided by SkyAPI 
-- Game: Alter Ego
addappid(63110)
addappid(63111, 1, "8ef53bc03e04a2e3e0d4569386670ac01fda12f4050fd78922d1de5f8c487c6d")
