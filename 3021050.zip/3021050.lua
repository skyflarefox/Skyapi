-- Lua provided by SkyAPI 
-- Game: AppID 3021050
addappid(3021050)
addappid(3021051, 1, "ce7311885cab50ab0b05b39312bbf4162f2d62d8a796078820049231b44bd62f")
