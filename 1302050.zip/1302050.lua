-- Lua provided by SkyAPI 
-- Game: Milky Way Prince – The Vampire Star
addappid(1302050)
addappid(1302051, 1, "c05b77b423494085c71edd7945a6684ad5c0da5c17303ab11367fd2ef7341cde")
