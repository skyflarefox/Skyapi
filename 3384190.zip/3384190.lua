-- Lua provided by SkyAPI 
-- Game: TrickShot Simulator
addappid(3384190)
addappid(3384191, 1, "97901f88cd379424859440c2461e5c102d52c718ec07bf823788ac9a39f9087d")
