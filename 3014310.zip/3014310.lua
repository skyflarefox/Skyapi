-- Lua provided by SkyAPI 
-- Game: Virtual★Happy Land | バーチャル★ハッピーランド
addappid(3014310)
addappid(3014311, 1, "7919278ff96fe5ad57455ed711614f32d6193d8590c458737fb21ef1ae9cb7fa")
