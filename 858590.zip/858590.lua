-- Lua provided by SkyAPI 
-- Game: Last Tide
addappid(858590)
addappid(858591, 1, "c98a878e9f37c290d1f91f530098964a93101026473fec98c4e31387b9bb3042")
