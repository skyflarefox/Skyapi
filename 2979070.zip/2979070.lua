-- Lua provided by SkyAPI 
-- Game: AppID 2979070
addappid(2979070)
addappid(2979071, 1, "50872579ca1f2b1b83de3d54155c69eb3c62bf105efe9139cf3236059d37c67a")
