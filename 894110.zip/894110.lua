-- Lua provided by SkyAPI 
-- Game: AppID 894110
addappid(894110)
addappid(894111, 1, "626ebc7064fdb8a6f435599aa3fe8c1950c0df989ed114ff5c509631b5e38acb")
