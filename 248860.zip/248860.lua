-- Lua provided by SkyAPI 
-- Game: NEO Scavenger
addappid(248860)
addappid(248861, 1, "5d41feeab8d9e10c2db8c483f3226af69c14a36270db64428ea8bf8f0edda1ee")
