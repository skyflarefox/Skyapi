-- Lua provided by SkyAPI 
-- Game: AppID 1960690
addappid(1960690)
addappid(1960691, 1, "05d21e3102993a1a9c81a5e71b5bc7d462f11993b42b52016d836c0e10f5b1e5")
