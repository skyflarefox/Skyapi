-- Lua provided by SkyAPI 
-- Game: HGFaceDD
addappid(1218010)
addappid(1218011, 1, "e883900aee7965cf7593a5d02a1281cb6ddd1df49552fed3c47dfa6a45572fb4")
