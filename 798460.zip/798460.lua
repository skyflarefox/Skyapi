-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(798460)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(798461,0,"939a224755dc4c5c3580d0d9f2a8849d836222a4ab25e078137d82cb619b4c70")
setManifestid(798461,"924468745900544797")
addappid(798462,0,"d858c296b49663598e7424076ee6b7079a789856f1f3e944e9997a52c965b307")
setManifestid(798462,"3645056621812612")
addappid(1154000,0,"8ce42d40489dd4eb6b3e1fc33a88f87687751d03d5f4a56e6d79ac2d852f919b")
setManifestid(1154000,"4317760661502125282")