-- Lua provided by SkyAPI 
-- Game: 东方裁判梦 Demo
addappid(2737840)
addappid(2737841, 1, "1bc3e147453c3aa6e53abfa66e3409f643b60b74ea15237fc0cf8f3cf6dd4359")
