-- Lua provided by SkyAPI 
-- Game: Bit-Cremental: Fishistry
addappid(3287300)
addappid(3287301, 1, "4ddc4b0b99e6c8d2e807b03f096d91626f2bdb69d1260851744654a905094f91")
addappid(3421390)
