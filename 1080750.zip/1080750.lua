-- Lua provided by SkyAPI 
-- Game: Mutazione
addappid(1080750)
addappid(1080751, 1, "ef98eef7b7724c17b83585096697ea6b90ec0943205455a0f2d3d8c6037000d0")
