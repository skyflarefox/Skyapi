-- Lua provided by SkyAPI 
-- Game: Nomad Survival
addappid(1929870)
addappid(1929871, 1, "3ee504c44adec68c919e3017edfb69d28bc66a3223f42c91d6189e614d9eb828")
