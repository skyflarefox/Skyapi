-- Lua provided by SkyAPI 
-- Game: Wargroove 2
addappid(1346020)
addappid(1346021, 1, "5f6ec8a48cf98fc4daec0cde1de1bebb1a50d9e7e95df64e4b9f2c097f92dd91")
