-- Lua provided by SkyAPI 
-- Game: xVASynth
addappid(1765720)
addappid(1765721, 1, "fe7b2dd8833f55083fbff4a24f37d56ecfff0f53863c0817c83a0f58a40eb497")
