-- Lua provided by SkyAPI 
-- Game: BLIK
addappid(727190)
addappid(727191, 1, "9f7293de1d458628315a4b654d8d1a8de191e0ad98a80420f1b9a7468d0e3900")
