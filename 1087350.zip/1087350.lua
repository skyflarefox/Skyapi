-- Lua provided by SkyAPI 
-- Game: AppID 1087350
addappid(1087350)
addappid(1087351, 1, "4d4c3bdb64f8dc30fa787e4451205bc2874f14fe6d0868a949385a440ac6c548")
