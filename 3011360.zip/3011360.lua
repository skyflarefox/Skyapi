-- Lua provided by SkyAPI 
-- Game: Primordialis
addappid(3011360)
addappid(3011361, 1, "cc38851f59c1e27c4374122e71df3502f280875cc1c89272e9c846373c8265fb")
