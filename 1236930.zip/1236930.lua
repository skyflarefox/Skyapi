-- Lua provided by SkyAPI 
-- Game: AppID 1236930
addappid(1236930)
addappid(1236931, 1, "377f569da323c2461966bbb9390babdd6eaea3bc4fd7fcd9387014e6fa72a95b")
