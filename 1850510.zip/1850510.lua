-- Lua provided by SkyAPI 
-- Game: AppID 1850510
addappid(1850510)
addappid(1850511, 1, "99eed402af9553dee98bf009dc96fb86d2f69b18d0d475147f36e1b6f8cc00ba")
addappid(1931660, 0, "bea5c4f508d15aba1f4095d42eb4aa470a112263e7aeb70917ea7550a785b4b0")
