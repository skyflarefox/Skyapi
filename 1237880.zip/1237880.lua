-- Lua provided by SkyAPI 
-- Game: Red Town
addappid(1237880)
addappid(1237881, 1, "461bb819993839ca422599516d5d50ca79e38e001b9a2089978007d906a050a9")
