-- Lua provided by SkyAPI 
-- Game: Far Eastern Federal University Virtual Expo
addappid(1309550)
addappid(1309551, 1, "f72ba2ede37dfef48fe61eb42bb6f86a9d43ac46b5bec6544cffef62b19a2c94")
