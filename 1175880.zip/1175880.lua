-- Lua provided by SkyAPI 
-- Game: War Room
addappid(1175880)
addappid(1175881, 1, "8467b9955444d205259f4cca9e077c1004ec0e01ff8897f0858454ca64cc294e")
