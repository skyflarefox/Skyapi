-- Lua provided by SkyAPI 
-- Game: Arrow Dungeon
addappid(3761740)
addappid(3761741, 1, "b7c16cc06fe6f6e1b0e9248bf8d048af0a5ee3e8ce9e1b500177d9617b5844c9")
