-- Lua provided by SkyAPI 
-- Game: Demon Crush Demo
addappid(3267630)
addappid(3267631, 1, "1a5126d03a7cc4e6fdb2b5debccc782478c4ff5b0bd9c4062fede2a43c0d2f16")
