-- Lua provided by SkyAPI 
-- Game: Sol: Last Light
addappid(2395410)
addappid(2395411, 1, "6a17b9b861effe002a99d9815f3a8e5300246bc15191b452c91885dc20f09f59")
