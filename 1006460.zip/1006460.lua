-- Lua provided by SkyAPI 
-- Game: Mission Critical
addappid(1006460)
addappid(1006461, 1, "3a7cf0bdb9a78acd8b617a82646001cc82132eaa4c5288c5b60ccb8b3b9833e9")
