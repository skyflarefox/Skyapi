-- Lua provided by SkyAPI 
-- Game: vision\memory\maze
addappid(1912590)
addappid(1912591, 1, "771510fdd4b94b25cec794a120eb8ae2ee0e0bdd75fd8b560c9116f4e9ec919b")
