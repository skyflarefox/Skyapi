-- Lua provided by SkyAPI 
-- Game: Time Gap
addappid(500150)
addappid(500151, 1, "1dae1c08d7f20bd8b9a0a481fa76f7041e4919329537c48aff0a4de607d38bce")
