-- Lua provided by SkyAPI 
-- Game: Zruce Adventures Demo
addappid(1924630)
addappid(1924631, 1, "46d2ba230144c1b1d25ff50d30b73348ad5a75e4bb524dfd2a74b958ce47e421")
