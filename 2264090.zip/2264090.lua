-- Lua provided by SkyAPI 
-- Game: AppID 2264090
addappid(2264090)
addappid(2264091, 1, "09fe8b6d4e4e72ffcc2c1a7c5350e441eb9792badeed8568f1891cd7f5b60f14")
