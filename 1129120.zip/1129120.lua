-- Lua provided by SkyAPI 
-- Game: AppID 1129120
addappid(1129120)
addappid(1129121, 1, "f8537cc9602cdca3a88e87e55d95b97ad6a6d38a03955ca1dfbc2a55d5e4b587")
