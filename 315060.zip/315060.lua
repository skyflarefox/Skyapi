-- Lua provided by SkyAPI 
-- Game: Bloop Reloaded
addappid(315060)
addappid(315061, 1, "07b08bfd58d04caee977e382286e065be2b590ef86d2abf0c04de3cb41ee5e8c")
addappid(315062, 1, "b7a6d9f211ffad2d759c688bb1208d694362850c29065c2b6f06cf91b3048424")
addappid(315063, 1, "9d1f2812e865b975737ae7fe780355975bd4938ae3bf9bec20a9ccc1072102fc")
