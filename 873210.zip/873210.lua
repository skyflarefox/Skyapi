-- Lua provided by SkyAPI 
-- Game: iterform
addappid(873210)
addappid(873211, 1, "1a54f7f9be2923ff644c689a18772ed029cb06ffbb850d01e81a990c0cb61d38")
addappid(873212, 1, "fa9d0bac8a79a3235c973903623ad63d579be7242f54ac3b80672243b88236d8")
