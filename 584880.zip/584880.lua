-- Lua provided by SkyAPI 
-- Game: Pixel Sand
addappid(584880)
addappid(584881, 1, "f37e9c5f7d2ecab4ee6b2fb3e882eabe42b55a21aa6910608af246974a0f8195")
