-- Lua provided by SkyAPI 
-- Game: Nogard
addappid(725140)
addappid(725141, 1, "aaeba794f64e56e0a2c7394d6c97facd80e5cbab0beda33425313aece2117169")
