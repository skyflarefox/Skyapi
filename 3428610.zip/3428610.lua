-- Lua provided by SkyAPI 
-- Game: Beer Runner
addappid(3428610)
addappid(3428611, 1, "a7664efea16b07312225594d69c002f2567948419d81cb64bc214f9df9dc6a0c")
