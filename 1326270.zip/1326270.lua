-- Lua provided by SkyAPI 
-- Game: Festival Tycoon 🎪
addappid(1326270)
addappid(1326271, 1, "fee82da01d0239caa657d3f45fe542332cc9d7d669128f82070524016e104cfc")
