-- Lua provided by SkyAPI 
-- Game: AppID 3096820
addappid(3096820)
addappid(3096821, 1, "ef4e71b8e457afa599110afd13028ea870bdb3bca31c612c669217b243f64476")
