-- Lua provided by SkyAPI 
-- Game: Metal Garden
addappid(3539440)
addappid(3539441, 1, "44318a0fda95b82dadc858f0e0715e846e942852570d017260df14708f0d5104")
