-- Lua provided by SkyAPI 
-- Game: Witchaven
addappid(1655410)
addappid(1655411, 1, "05c071e338dc2cc8529299c5f5ba770c4316b206eba46ce4a4a527817dc166b4")
