-- Lua provided by SkyAPI 
-- Game: Telebbit Soundtrack
addappid(3639180)
addappid(3639181, 1, "1f09aae93fee5e0ad741360b474c25679f1e4dcd683fd29c3e5ce86c1f03eb63")
