-- Lua provided by SkyAPI 
-- Game: Crimson Ranch
addappid(1407060)
addappid(1407061, 1, "856672d8dfff7059019d176ccd818dd734e2d44898a83e5d3c1aacfe4ef031f9")
