-- Lua provided by SkyAPI 
-- Game: AppID 666060
addappid(666060)
addappid(666061, 1, "8a483add7b0a4179bd57a3f4d41b422c2fa54e403336201280c78822d9f0ba09")
