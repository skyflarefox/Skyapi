-- Lua provided by SkyAPI 
-- Game: Journey Up
addappid(3144110)
addappid(3144111, 1, "334d0629087bc27c71ec099548ad8d97a191600e2022a319e8cbcaacc5c75818")
