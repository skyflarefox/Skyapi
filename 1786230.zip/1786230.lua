-- Lua provided by SkyAPI 
-- Game: Breakers Collection
addappid(1786230)
addappid(1786231, 1, "82fa61c2c0428be1d394a8b1f1c6537e39f90bb4c09b536ab43793ef2ed7e5f9")
