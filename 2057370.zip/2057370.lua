-- Lua provided by SkyAPI 
-- Game: AppID 2057370
addappid(2057370)
addappid(2057371, 1, "90063f31eefcf6501bdbf332ff3ef6d927e076998034cd3e9ce095b74c5ac22a")
