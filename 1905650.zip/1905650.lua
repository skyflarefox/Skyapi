-- Lua provided by SkyAPI 
-- Game: AppID 1905650
addappid(1905650)
addappid(1905651, 1, "7623a8561b8bae4b4f2211cb1e23933615b24d3dc7a64c62da1b132664b7a61b")
