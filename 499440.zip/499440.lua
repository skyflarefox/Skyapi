-- Lua provided by SkyAPI 
-- Game: klocki
addappid(499440)
addappid(499441, 1, "94bee2f04563516efc00f251e44ab79132559d74c209c83e53005541e3fd325d")
addappid(499442, 1, "be3e9c1d42ceee88ca73536b132fde58e5b0436fb8316c8db88e9c1e63114acd")
addappid(499443, 1, "3af686300407f99faa1c17c6b5b1aa9924a85979ba544fced9a3b8c7097f45e0")
