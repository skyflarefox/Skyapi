-- Lua provided by SkyAPI 
-- Game: Epic World
addappid(1040910)
addappid(1040911, 1, "6591f341c9c9731d06f1f7824f4e0a814cbfb897c933a050bddf676e067ef558")
