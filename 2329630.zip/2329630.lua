-- Lua provided by SkyAPI 
-- Game: Lovey-Dovey Lockdown
addappid(2329630)
addappid(2329631, 1, "f1ee7c9e5496b13bd6a7f208e9e3253898f1e15d2f9094db6a194416ba53dffd")
addappid(2864490)
