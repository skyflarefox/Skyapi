-- Lua provided by SkyAPI 
-- Game: School Teacher Simulator
addappid(3304570)
addappid(3304571, 1, "4ae2daa176ea5c6c43156e46791044a9a9f92771bf07ed1590d37360becb8257")
