-- Lua provided by SkyAPI 
-- Game: AppID 2754380
addappid(2754380)
addappid(2754381, 1, "a144e003752b9be3b56e1699fd3513b52775d8de366af34cd9464bf289edc3b0")
