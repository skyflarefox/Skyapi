-- Lua provided by SkyAPI 
-- Game: AppID 1075430
addappid(1075430)
addappid(1075431, 1, "267ac0889e6811aa8ab0b1d4623e11d32d27e28aa7174fed5cde318cb1b66cef")
