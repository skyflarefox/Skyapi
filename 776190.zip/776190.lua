-- Lua provided by SkyAPI 
-- Game: Galactic Battles
addappid(776190)
addappid(776191, 1, "5b79fd0dc509bccb9eab3c70364f82e330efa41ceb56c0db5ed9a15880f9843c")
