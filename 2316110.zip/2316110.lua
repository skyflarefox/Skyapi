-- Lua provided by SkyAPI 
-- Game: Saving Mei
addappid(2316110)
addappid(2316111, 1, "a84755f96eee1946b7f55c16c96ac212a8d3f628cfe401a252e2ea229679d69b")
