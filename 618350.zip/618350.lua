-- Lua provided by SkyAPI 
-- Game: AppID 618350
addappid(618350)
addappid(618351, 1, "46262ea34b59120cd3204c5019d2cb817663010a0aedafb1f2b206d00c34081f")
