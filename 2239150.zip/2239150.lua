-- Lua provided by SkyAPI 
-- Game: Thronefall
addappid(2239150)
addappid(2239151, 1, "505a16dd8c80b12c26bfa9c7780547cf33fff50602e31744cd4d7e582df2870c")
