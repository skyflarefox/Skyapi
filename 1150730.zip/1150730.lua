-- Lua provided by SkyAPI 
-- Game: Island SAGA
addappid(1150730)
addappid(1150731, 1, "f0aaca4c138601f6a13c98397915b06e14291d0f1e7c6324c48b6950ad3bcdd3")
addappid(1150732, 1, "22bf82ee693cb31aa46a1a33d2d49ad911c19652ff39782c00b7b95bdab8b3e4")
addappid(1150733, 1, "321c3a33a4f5c221918896cda1c3771346b4a8ccf372ee811bfcf71223adcad5")
addappid(1150735, 1, "1ddcab5c4f1a2129b21d8f33877d80ae7efaa09d38a059230bd0ec6ca51d5e1c")
