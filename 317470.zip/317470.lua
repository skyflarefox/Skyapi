-- Lua provided by SkyAPI 
-- Game: AppID 317470
addappid(317470)
addappid(317471, 1, "23f4d249e22a6f86ea334389d0e6479f4f645e5d77c78e97c5c860cb2a3d16fe")
