-- Lua provided by SkyAPI 
-- Game: Green Fairy VR
addappid(1600970)
addappid(1600971, 1, "06333fba24e25f0599443ca7a63846c8e3f0d232c36ec52bda89536eb6f75eeb")
