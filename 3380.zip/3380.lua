-- Lua provided by SkyAPI 
-- Game: Dynomite Deluxe
addappid(3380)
addappid(3381, 1, "e86046dc6d1e1ed98b33dda786c2861a514c4e9cf0c8328a20938fb0f70a31ea")
