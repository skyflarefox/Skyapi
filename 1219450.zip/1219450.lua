-- Lua provided by SkyAPI 
-- Game: Inglorious Pirate
addappid(1219450)
addappid(1219451, 1, "a30e82fc285ebe788e9023e40d46c2e0162d256db84d02749a97dcb7f8349a0b")
