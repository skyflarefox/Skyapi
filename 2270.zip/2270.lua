-- Lua provided by SkyAPI 
-- Game: Wolfenstein 3D
addappid(2270)
addappid(2271, 1, "7e60644d271cb1e11f0f6436a8cceabfb8ea472ecbd207d5f9d50924ce33ca82")
