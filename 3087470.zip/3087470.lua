-- Lua provided by SkyAPI 
-- Game: EmyLiveShow: Demons & Mistresses Tale
addappid(3087470)
addappid(3087471, 1, "972c2beef08124f36514338a32faf32124cf478ba635c1f44ac851b334ca1156")
