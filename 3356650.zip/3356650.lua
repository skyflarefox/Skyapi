-- Lua provided by SkyAPI 
-- Game: Slip 'n Slime Demo
addappid(3356650)
addappid(3356651, 1, "eb87679aa4acdbc35e6be6e4d1c2ead3342d2a1d5b4f9c83bc18ccc38f390569")
