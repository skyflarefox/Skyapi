-- Lua provided by SkyAPI 
-- Game: Secret Cats - Spooky
addappid(3269300)
addappid(3269301, 1, "8252ea8c1db7380e49f788a1238bd6817bd34b7c4df0d00251fb94fd705bf694")
