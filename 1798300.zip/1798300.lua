-- Lua provided by SkyAPI 
-- Game: 1940
addappid(1798300)
addappid(1798301, 1, "e7006f83249132c30cc308efb374e1dace6c17f0849b816764f0659857940052")
