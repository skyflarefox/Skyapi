-- Lua provided by SkyAPI 
-- Game: Refight:Burning Engine
addappid(773520)
addappid(773521, 1, "8a1a5b80643504f34bebc7c8c55cbff1a4435ea9862def5e1f51b436578841f7")
