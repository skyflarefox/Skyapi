-- Lua provided by SkyAPI 
-- Game: Dear Mirror Flower Soundtrack
addappid(3638600)
addappid(3638601, 1, "44563df113f158dff4789cfb883a1cfd04bfbeaab95e135035b086de05d0ef65")
