-- Lua provided by SkyAPI 
-- Game: AppID 978630
addappid(978630)
addappid(978631, 1, "8283af1306ac1df0cd970f769f15f71ed5ed39b5428c68fd0171db073647eae5")
