-- Lua provided by SkyAPI 
-- Game: AppID 1312760
addappid(1312760)
addappid(1312761, 1, "65a0dc8bde42de8ef6d4f569a27c7c5c2e6aefc355699dbb5880c5ce0d54107c")
