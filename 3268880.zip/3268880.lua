-- Lua provided by SkyAPI 
-- Game: AppID 3268880
addappid(3268880)
addappid(3268881, 1, "84801fc0b9a5ce26c39237dcf7e1b0a40c911eabb44dfbd46bf29394ac3788b2")
