-- Lua provided by SkyAPI 
-- Game: PC Virtual LAB
addappid(1825460)
addappid(1825461, 1, "109673a0ac6dc2e8011c2b429bec70c1893adf948900aeb2c8329faeaa8441f3")
