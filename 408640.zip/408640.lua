-- Lua provided by SkyAPI 
-- Game: AppID 408640
addappid(408640)
addappid(408641, 1, "a74d6f3fb0b6d87d1dff1c3ee045881e345c3a7a68ac2e0bee8d3e987537150f")
