-- Lua provided by SkyAPI 
-- Game: Autonauts vs Piratebots
addappid(1907720)
addappid(1907721, 1, "749069a888ab52d6b4e847a611e2d23f7989912b6c70edf529e897fbf56749f1")
