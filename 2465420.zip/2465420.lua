-- Lua provided by SkyAPI 
-- Game: The Road To Gaokao Demo
addappid(2465420)
addappid(2465421, 1, "ab54a3e324c50c69aaaefde898a64b043358b50c8c66693a0227769fa6ef5976")
