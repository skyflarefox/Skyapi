-- Lua provided by SkyAPI 
-- Game: AppID 1555890
addappid(1555890)
addappid(1555891, 1, "573758810e9cfc428f526236928c5702be9f67dab5a50a14c49a546b5f93df61")
