-- Lua provided by SkyAPI 
-- Game: Rise of the samurai in VR
addappid(1473500)
addappid(1473501, 1, "5267babbb030a8c1dd9f62256ebd1a501e835b1e60bee94afaee93912e628ab7")
