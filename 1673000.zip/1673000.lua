-- Lua provided by SkyAPI 
-- Game: Blood Field | Cỏ Máu
addappid(1673000)
addappid(1673001, 1, "b3384a6a6ed53e4b613cf703386c5a278a2401733e0c4ddf7835b6758348022b")
