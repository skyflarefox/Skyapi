-- Lua provided by SkyAPI 
-- Game: Shirone: the Dragon Girl
addappid(1805200)
addappid(1805201, 1, "66a9b100d06aa393e05f10ab63e069af45e88b666f7c585ffae316368dbe7320")
