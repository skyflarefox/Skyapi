-- Lua provided by SkyAPI 
-- Game: Lost Angel
addappid(1489390)
addappid(1489391, 1, "a120ce065c79ac3187c99aac9db6bdcaafd844a717721fa9f5b0bc2b5121e395")
