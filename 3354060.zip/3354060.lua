-- Lua provided by SkyAPI 
-- Game: ELISSA ：Body in the bedroom Demo
addappid(3354060)
addappid(3354061, 1, "a9c03734077af28d62f47eb0bc4b7df1edc35418564fab5c08ade4f5ba7430d9")
