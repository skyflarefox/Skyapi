-- Lua provided by SkyAPI 
-- Game: AppID 2120940
addappid(2120940)
addappid(2120941, 1, "d64464f8d3915127044b3fe60e7968b41e5dc6f9e142e0909d6867953d1ddcd6")
