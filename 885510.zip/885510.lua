-- Lua provided by SkyAPI 
-- Game: AppID 885510
addappid(885510)
addappid(885511, 1, "4e7da215512ddf537cc43bdc42f5db2ae14cb6b71728d67f90be293395d7e74c")
