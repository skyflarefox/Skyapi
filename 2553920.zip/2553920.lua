-- Lua provided by SkyAPI 
-- Game: King of Avalon
addappid(2553920)
addappid(2553921, 1, "eebe88c666e178d3843fea66f4cbdddb8e87c28af21971b327942bed8b65d65e")
