-- Lua provided by SkyAPI 
-- Game: Carrier Command 2
addappid(1489630)
addappid(1489631, 1, "4aeaff33ce828e179d33a551109dd8861c61ced318318f07de6b519f081231b3")
addappid(1489632, 1, "13d81d19fb6eca8c42546b1d00149b70ce330a3ecbb22f816e3b46c948264c29")
