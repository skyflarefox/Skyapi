-- Lua provided by SkyAPI 
-- Game: Dwarven Realms
addappid(2015240)
addappid(2015241, 1, "af9571cc8c6e975247efca0a6cda92a974e384ce0ad7420bcfd110a941ee981f")
