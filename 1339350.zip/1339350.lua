-- Lua provided by SkyAPI 
-- Game: AppID 1339350
addappid(1339350)
addappid(1339351, 1, "8a3029ed9c957ee94aa8d72fe62ca68265b6860b6833d3f82226a7f704766e41")
