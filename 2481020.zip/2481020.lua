-- Lua provided by SkyAPI 
-- Game: Vampire Therapist
addappid(2481020)
addappid(2481021, 1, "e5ae19d84ad6b1ca2c7c49510a399765c6903bd71041e64d75598304bf702069")
