-- Lua provided by SkyAPI 
-- Game: Air Forte
addappid(55020)
addappid(55021, 1, "e0a7b910fc15d6d0d106f8f3f46c5bff1417d9d9a052e470cdf830bd80257ac4")
addappid(55022, 1, "a572de8cd90391f47269fc3511f7b9e4f995a5cdc8cf24b967b7aa5eb1852c2b")
addappid(229020)
