-- Lua provided by SkyAPI 
-- Game: AppID 2779890
addappid(2779890)
addappid(2779891, 1, "da09acc9a01580964465d6ef76255c1ab19737ac5e22421c29a86be8746e3def")
