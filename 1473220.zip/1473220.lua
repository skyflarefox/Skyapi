-- Lua provided by SkyAPI 
-- Game: Hundred Chances - The Fortress
addappid(1473220)
addappid(1473221, 1, "21cd0d18fed23b72713dd6bca5685fa8767bf1bf119cc86d2ffcaabd3ff3bac8")
