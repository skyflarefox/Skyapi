-- Lua provided by SkyAPI 
-- Game: AppID 1147500
addappid(1147500)
addappid(1147501, 1, "8376b2d64cb098a219bc440634b7dd98ed84e0591876a32aef0185f17821ae50")
