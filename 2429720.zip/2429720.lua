-- Lua provided by SkyAPI 
-- Game: AppID 2429720
addappid(2429720)
addappid(2429721, 1, "2334affd911342d90cad90488101271699b1b6838d419b8ad60a15d5f6f38504")
