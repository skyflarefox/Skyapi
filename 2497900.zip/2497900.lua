-- Lua provided by SkyAPI 
-- Game: DON'T SCREAM
addappid(2497900)
addappid(2497901, 1, "42d0e96d7b5440cf0b812b5ec843e2e437e28ba281e46830a2d2d7ec65c2a030")
