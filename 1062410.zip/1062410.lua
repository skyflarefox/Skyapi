-- Lua provided by SkyAPI 
-- Game: AppID 1062410
addappid(1062410)
addappid(1062411, 1, "8242bbc2b4375eeaeda0e97276f145c6520b750f6523a721b46a4ee8e571e068")
