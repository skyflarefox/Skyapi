-- Lua provided by SkyAPI 
-- Game: El Dorado: The Golden City Builder
addappid(1451470)
addappid(1451471, 1, "290c3aadb074debca467a37342cc0a2cda582f653ad5f3b8932ef442452038eb")
