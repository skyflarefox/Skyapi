-- Lua provided by SkyAPI 
-- Game: AppID 408440
addappid(408440)
addappid(408441, 1, "451ed584e0b1ac3f537fca5fbd8bc9f7d3369d4804e6e33b1123086c80dad972")
