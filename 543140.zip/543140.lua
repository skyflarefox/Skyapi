-- Lua provided by SkyAPI 
-- Game: Legend of Merchant
addappid(543140)
addappid(543141, 1, "eccf0e4da6f944a027e36b4d58082f858ba210a3d331738008b398b0851e3e28")
