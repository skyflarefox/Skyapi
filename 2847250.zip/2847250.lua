-- Lua provided by SkyAPI 
-- Game: River Town Factory: Prologue
addappid(2847250)
addappid(2847251, 1, "c3a01eeb4f3ec03e7c5c9e1163da614b393df968eaeaf659837c3ba75a23fd62")
