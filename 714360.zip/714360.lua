-- Lua provided by SkyAPI 
-- Game: AppID 714360
addappid(714360)
addappid(714361, 1, "9aa83daad296122eb567c1737eec38e84556348aeb7abaa7e83ad2d13649fcd6")
