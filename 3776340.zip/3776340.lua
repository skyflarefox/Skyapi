-- Lua provided by SkyAPI 
-- Game: Hentai World Mystery
addappid(3776340)
addappid(3776341, 1, "1ae43449d83896dd55ab7af02a6fb3556d0918025fb80fa238ab1a998a8a9e85")
