-- Lua provided by SkyAPI 
-- Game: Sojourner
addappid(652800)
addappid(652801, 1, "0c7a89a660c2a5249e3f5db18309033c21d683e9d0ca36c33be290df5306bb3d")
