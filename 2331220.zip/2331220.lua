-- Lua provided by SkyAPI 
-- Game: 1 Million Zombies
addappid(2331220)
addappid(2331221, 1, "b510c8d57338c294e36a8084f275635d5df8d735202ee5a6cb6c9cd47993095e")
