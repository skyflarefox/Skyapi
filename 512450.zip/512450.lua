-- Lua provided by SkyAPI 
-- Game: AppID 512450
addappid(512450)
addappid(512451, 1, "a85dfd81830f79bf040fb87faa415bf81eef59e7c020896fa8ee097b62570b21")
addappid(512452, 1, "cce23b1b96f435be7f35ecbc1cd15138ca06910112b718500f4b1a14ba4a9cc8")
addappid(512453, 1, "cb4ab0396b870fcda3323e02b3b2a22921e7ce94e7ae53bc7983fbd269f3537f")
