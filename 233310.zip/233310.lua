-- Lua provided by SkyAPI 
-- Game: Avadon 2: The Corruption
addappid(233310)
addappid(233311, 1, "4612bbdde15789d4280ec6b0ba8fb8c2186482e6b976c137adb84cd7e54e6e59")
addappid(233312, 1, "f5599f80b297c1104e08343793d9fcb906e832f4cb19baeb7e1789e936760431")
