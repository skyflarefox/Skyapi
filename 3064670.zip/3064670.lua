-- Lua provided by SkyAPI 
-- Game: Mushroom Season
addappid(3064670)
addappid(3064671, 1, "ff10221690e60e5af04dcce6e9ec2f13df7b4df4dfe83c13c09b888cf9f92945")
