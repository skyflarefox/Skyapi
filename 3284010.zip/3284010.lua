-- Lua provided by SkyAPI 
-- Game: AppID 3284010
addappid(3284010)
addappid(3284011, 1, "24bbe3b29fdef1c57e2faa03084c9964888369f32a2b7e024974036117e920f4")
