-- Lua provided by SkyAPI 
-- Game: STAY ALIVE
addappid(3472200)
addappid(3472201, 1, "35959acad558f68ad1fc5b80cbc997e10e6ab8cf94d85e449da7f2391813a28b")
