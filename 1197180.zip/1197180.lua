-- Lua provided by SkyAPI 
-- Game: Spider Queen cave
addappid(1197180)
addappid(1197181, 1, "08713bc991bf21e4ef09cd15c901d23632a4f012ca9d20af3d09b77e1614315c")
