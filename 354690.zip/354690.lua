-- Lua provided by SkyAPI 
-- Game: The Lost City Of Malathedra
addappid(354690)
addappid(354691, 1, "6e115ee6060a8f34cc0b3a8ab386a0cb99d04edb91549e6505dd3aa8feebf70b")
