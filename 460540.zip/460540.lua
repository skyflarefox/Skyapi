-- Lua provided by SkyAPI 
-- Game: AppID 460540
addappid(460540)
addappid(460541, 1, "02dc3eead1ff5ac09132f21c83a92632c127997b35f08cb7bc92e6fe6d096206")
