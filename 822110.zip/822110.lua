-- Lua provided by SkyAPI 
-- Game: Magika Land of Fantasy
addappid(822110)
addappid(822111, 1, "5a477993d0828797bf2456c2628072cf19e927aa0bf49a7f3c7f472d8af7c569")
