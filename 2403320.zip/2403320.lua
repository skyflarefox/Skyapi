-- Lua provided by SkyAPI 
-- Game: AppID 2403320
addappid(2403320)
addappid(2403321, 1, "0347998936037fcc49aeae36dcc9852d1e4fda8a96c134ed7a8586370bc5c9c3")
