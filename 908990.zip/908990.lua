-- Lua provided by SkyAPI 
-- Game: AppID 908990
addappid(908990)
addappid(908991, 1, "bddfe2843c7011c5adb8d81cf40d149779b2eeb5cb33a61c9eb74cc58b14d5fe")
addappid(908993, 1, "6938526814ef2833fcee05dc3f3758f989503c47d857a43745e134fcd64ba77e")
addappid(908995, 1, "c8c35a44a5cb0abb7e77291eecbad8411c98b9b3c5a79df16dd72982af12aa42")
