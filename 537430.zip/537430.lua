-- Lua provided by SkyAPI 
-- Game: Inner Chains
addappid(537430)
addappid(537431, 1, "8c101105c6fbdb0c7213b9419e48123c2213ccff852876a6a656108fb54c9d53")
