-- Lua provided by SkyAPI 
-- Game: Horror In Valkeala
addappid(1886850)
addappid(1886851, 1, "88c0079a9d9990b8b6538b33f70b99c5d77738fd58d49dd2af75463bf55f8415")
