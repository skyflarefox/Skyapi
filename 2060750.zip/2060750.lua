-- Lua provided by SkyAPI 
-- Game: Star Survivor
addappid(2060750)
addappid(2060751, 1, "a793b346e793144755ea8d3c7bcd1cb0c09bcb2fd885d616093aa5f22e9444f4")
