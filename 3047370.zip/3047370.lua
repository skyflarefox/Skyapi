-- Lua provided by SkyAPI 
-- Game: Net.Attack() - Code or Die!
addappid(3047370)
addappid(3047371, 1, "ce6a946ac6fb6632b2489d746a06a79acce0c5819852b033b8f79db93be9f9c3")
