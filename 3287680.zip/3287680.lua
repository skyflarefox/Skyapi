-- Lua provided by SkyAPI 
-- Game: AppID 3287680
addappid(3287680)
addappid(3287681, 1, "8c43d464be5127ab820a52b40ac8775dc8bd73cabf4bf461e61cb8b041fb91ad")
