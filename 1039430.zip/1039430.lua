-- Lua provided by SkyAPI 
-- Game: Hyper Flight
addappid(1039430)
addappid(1039431, 1, "e75f2c0632f4509e4f4c6dc75887c0e0f5904143d05446def9a13d094f27f2b4")
