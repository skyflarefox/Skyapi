-- Lua provided by SkyAPI 
-- Game: AppID 3446850
addappid(3446850)
addappid(3446851, 1, "9971739238be7f6f5a9d2fa1717819e11d4141c0c4053276656a3bf15721867d")
