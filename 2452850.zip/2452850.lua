-- Lua provided by SkyAPI 
-- Game: Land Above Sea Below Prologue
addappid(2452850)
addappid(2452851, 1, "d42d7f7a594cb260635ebac397c1265fa6c3ade53936ca482b2361fff9a44a11")
