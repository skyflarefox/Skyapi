-- Lua provided by SkyAPI 
-- Game: Spandex Force: Champion Rising
addappid(380560)
addappid(380561, 1, "d3275994ddbaa3c7104829de5ea53ae14e5b81e3de3f746ad536de88878266a8")
