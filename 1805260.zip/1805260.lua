-- Lua provided by SkyAPI 
-- Game: AppID 1805260
addappid(1805260)
addappid(1805261, 1, "e25c543945b29b90c452daf42e07082c7062e1b291f79c39d09c08d81ab07087")
