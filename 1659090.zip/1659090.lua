-- Lua provided by SkyAPI 
-- Game: REMEDIUM
addappid(1659090)
addappid(1659091, 1, "214585f811b4457a928b7c8888ad914c00ae2378d2b2ebd66887ecf6654bfcef")
