-- Lua provided by SkyAPI 
-- Game: Draft of Darkness Demo
addappid(1439200)
addappid(1439201, 1, "db75f891a46b857189a5ee3a42451a5f46bdd32c9f9b910cbc4d517befb1305f")
