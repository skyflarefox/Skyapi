-- Lua provided by SkyAPI 
-- Game: Start10
addappid(620050)
addappid(620051, 1, "e236c98fb12f7bbc45aa8ea1de9722e6b76e0c31fa5281182079c8737d42c3f2")
