-- Lua provided by SkyAPI 
-- Game: Life Gallery
addappid(1978330)
addappid(1978331, 1, "ad09d78b310eccc880928a0c763f89d964c67abefe9e71fc4079ed0bd90f364e")
