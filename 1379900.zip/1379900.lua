-- Lua provided by SkyAPI 
-- Game: Shikokushi ~food and sightseeing and beauties~
addappid(1379900)
addappid(1379901, 1, "4414d3a8892bb049cc1f7079a880f2b408b4fde33c9e9935df26acbbd8164fdf")
addappid(1379902, 1, "c31407e96380db672d0392606f144a10635ac0b5481ae610573d0cfbb2b68c01")
addappid(1379904, 1, "8b5301ca2f593f1bbfa23a3fd846c325b8f6f1c03aad5d5350aaeb7a5bb9c7ee")
