-- Lua provided by SkyAPI 
-- Game: Anon's Neko Waifus
addappid(2543050)
addappid(2543051, 1, "45ec1ad520a2a6d00015430d25d97ded4de04c315f9cf6baaf219f879cf82ea6")
addappid(2715490, 0, "ad3158e5307c4963da7f6202e55a6ccf82729e96a0244df388c490e921b5a610")
