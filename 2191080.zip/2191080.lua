-- Lua provided by SkyAPI 
-- Game: Poozle Mania
addappid(2191080)
addappid(2191081, 1, "ed77408141afea2662d2341e87a32f30f84f1cec1dc975bf7a85ea43802317c7")
