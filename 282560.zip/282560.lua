-- Lua provided by SkyAPI 
-- Game: RollerCoaster Tycoon World™
addappid(282560)
addappid(282561, 1, "8b3e227e0384abb4cf2bc11c31e7d50519302ee8f891a45faec39b77fac436c6")
addappid(405580, 0, "36c6fb2a14c938966805ab77d290eb8b169ee9bb50d5da5f401ed87b09ac2e3f")
