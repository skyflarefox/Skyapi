-- Lua provided by SkyAPI 
-- Game: AppID 330590
addappid(330590)
addappid(330591, 1, "62cda8f1107c8de5c736b0460e40e52c725a95b1b7b397d3a5d9646c9b126bec")
