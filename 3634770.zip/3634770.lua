-- Lua provided by SkyAPI 
-- Game: Elf World Adventure 6
addappid(3634770)
addappid(3634771, 1, "82a4d7dc7b2bdc57c653ddf4d61ff1e43cad0f21c8901233c2f143af2ef57599")
