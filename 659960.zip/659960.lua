-- Lua provided by SkyAPI 
-- Game: AppID 659960
addappid(659960)
addappid(659961, 1, "d611bba1e59e9d5da67e5e9addc3edef8ad05f1dbc35220b6891ae890f644e52")
