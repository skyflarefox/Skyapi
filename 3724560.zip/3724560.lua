-- Lua provided by SkyAPI 
-- Game: Ornate Machina: The Thousand Trials
addappid(3724560)
addappid(3724561, 1, "d860c08191b248cbe35feb4b4b5bd343764979e397ac2b99dc652296484d5ef3")
