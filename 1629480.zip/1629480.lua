-- Lua provided by SkyAPI 
-- Game: The Last Dance Saloon
addappid(1629480)
addappid(1629481, 1, "ef3d8cabe1cc647e3bb89c34c503cc9288ae681e810e484391696ad2ca8d119a")
