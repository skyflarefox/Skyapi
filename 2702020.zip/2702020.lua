-- Lua provided by SkyAPI 
-- Game: Phantoms
addappid(2702020)
addappid(2702021, 1, "94aef28efe1741e009303c50350ddc9a26a19d2921435c8212edb30eb098f2a0")
