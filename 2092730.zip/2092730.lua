-- Lua provided by SkyAPI 
-- Game: Archaeogem
addappid(2092730)
addappid(2092731, 1, "face6420864ee38dbbe196c3d677d11144fd32fa0e9807ec6173e55201a7fd0f")
