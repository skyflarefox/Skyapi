-- Lua provided by SkyAPI 
-- Game: Altered Alma Demo
addappid(3119940)
addappid(3119941, 1, "c0bd554600bffc8d3c8e21eb1f0210a5efacec77436e1332c3b9c9d21594288c")
