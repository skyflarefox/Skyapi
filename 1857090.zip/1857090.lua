-- Lua provided by SkyAPI 
-- Game: Norland
addappid(1857090)
addappid(1857091, 1, "370d177702e1721868b4db49904b523b83825e329df24930490ba7b3a7da7131")
