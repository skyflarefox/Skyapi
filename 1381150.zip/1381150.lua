-- Lua provided by SkyAPI 
-- Game: Desirable
addappid(1381150)
addappid(1381151, 1, "5e6f7bf016aeb7fd827b88fd2c17b85b64b4edf8beb5b3d7b835ac71a27cf474")
