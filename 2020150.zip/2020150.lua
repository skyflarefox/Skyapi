-- Lua provided by SkyAPI 
-- Game: Forbidden Ninja Scroll: Kunoichi Training Demo
addappid(2020150)
addappid(2020151, 1, "21069da94bfae998579e72c4f149ac0542d50e50d6ec84c95ff200675b69e641")
