-- Lua provided by SkyAPI 
-- Game: Village Feud
addappid(1068640)
addappid(1068641, 1, "a8c12c79465744413c532a91ea1a3b60e5b5e528a71f5186abde6b9fcff726f4")
