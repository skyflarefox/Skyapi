-- Lua provided by SkyAPI 
-- Game: AppID 1403280
addappid(1403280)
addappid(1403281, 1, "b1392497cf7a3ea9c3c791bd7a25076535b1a8505176632cdf543d76f8054e5a")
