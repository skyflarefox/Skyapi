-- Lua provided by SkyAPI 
-- Game: AppID 523150
addappid(523150)
addappid(523151, 1, "1952693979b8f3b9d8ec848f833d9c05a65fd8d9a71d56674c210bf6c827af9f")
