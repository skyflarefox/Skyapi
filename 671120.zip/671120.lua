-- Lua provided by SkyAPI 
-- Game: AppID 671120
addappid(671120)
addappid(671121, 1, "cc4d5e53f0f4e1f88f4c9390bac9d46a8e2717ae04471ef5179397c84d6294fe")
