-- Lua provided by SkyAPI 
-- Game: AppID 2962810
addappid(2962810)
addappid(2962811, 1, "46d3774904d4c61843adc05c677b658f98bdb6a318956b13afa44920936eb0ab")
