-- Lua provided by SkyAPI 
-- Game: AppID 383020
addappid(383020)
addappid(383021, 1, "e63e92ea7a826eb39c0cad1d2452ec2bfb70457cd9e961aa439ef2702876b7b5")
