-- Lua provided by SkyAPI 
-- Game: Taken Soul | Đoạt Mệnh
addappid(2633540)
addappid(2633541, 1, "904a3d6d11654c1d5932714422150a9a7dc5111faef0b9db352069d1eb9d7d23")
