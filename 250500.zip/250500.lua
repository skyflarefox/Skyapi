-- Lua provided by SkyAPI 
-- Game: Super Amazing Wagon Adventure
addappid(250500)
addappid(250501, 1, "6631ca7b61d4b131c4710ddc225b36f5f5b51b759135c5ab0fdb69386861a7d7")
