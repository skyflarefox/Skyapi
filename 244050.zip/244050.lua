-- Lua provided by SkyAPI 
-- Game: Rise of Flight United
addappid(244050)
addappid(244051, 1, "a4aed5eb13916d7135b54a84c3dc6fdab7592a4d708db12fa25a5cd4ce9b5881")
