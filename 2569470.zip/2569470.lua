-- Lua provided by SkyAPI 
-- Game: Dead Humanity
addappid(2569470)
addappid(2569471, 1, "bd11f08953aff57f389b6f5a68456f8d37fca60ef787e57bd929fcfd062b3af6")
