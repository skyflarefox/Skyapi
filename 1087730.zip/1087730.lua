-- Lua provided by SkyAPI 
-- Game: Iron Blade: Medieval RPG
addappid(1087730)
addappid(1087731, 1, "371a4f23d3a6a5330343403875db83de36cd3db0cd4354a9c32b2d1a19bcb7f9")
