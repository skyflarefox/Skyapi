-- Lua provided by SkyAPI 
-- Game: AppID 1265390
addappid(1265390)
addappid(1265391, 1, "1aca0679094114faa0891d7dfc3d80009e9ae035a1a2628504cb7bb834e8e2b7")
