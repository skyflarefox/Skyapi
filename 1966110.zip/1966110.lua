-- Lua provided by SkyAPI 
-- Game: Greed
addappid(1966110)
addappid(1966111, 1, "6f04c401d5fa5d623b8e97585abfbedd1dff54a1455113341c6786a7bb22b15d")
