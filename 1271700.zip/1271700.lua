-- Lua provided by SkyAPI 
-- Game: HOT WHEELS UNLEASHED™
addappid(1271700)
addappid(1271701, 1, "ff5665727b233ab8a0dca5d6d9eb0fb3be4a737fa3a73656f1290d9a132d6e6a")
