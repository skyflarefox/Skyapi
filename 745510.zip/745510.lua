-- Lua provided by SkyAPI 
-- Game: Fidget Spinner In Space
addappid(745510)
addappid(745511, 1, "0c1387da4ff6c4cb0c83843c693e1c93037ef018f08f365505e4860458b79536")
