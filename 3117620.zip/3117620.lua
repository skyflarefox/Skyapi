-- Lua provided by SkyAPI 
-- Game: Robabekya
addappid(3117620)
addappid(3117621, 1, "849a32f2700eef5b5d1be62bdfa33b716d67fd35fc673b55c1910a25f03eb722")
