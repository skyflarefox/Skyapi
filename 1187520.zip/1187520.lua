-- Lua provided by SkyAPI 
-- Game: AppID 1187520
addappid(1187520)
addappid(1187521, 1, "803867c852ca135bb6efdb9201a0e5f7c2a7a7409e50f632d4fcb08548395460")
