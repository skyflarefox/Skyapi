-- Lua provided by SkyAPI 
-- Game: AppID 2386660
addappid(2386660)
addappid(2386661, 1, "482d6de1454a2e3602fc046e3c93795d62102ca7b9ab2e4559ffc109a1d16cd3")
