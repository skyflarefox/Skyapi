-- Lua provided by SkyAPI 
-- Game: Journey of Realm: Dawn Dew Demo
addappid(2732540)
addappid(2732541, 1, "a5b20b351210e158ed197631912c08526f4ea4452978465191fbf3e16cb108be")
