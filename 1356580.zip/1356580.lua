-- Lua provided by SkyAPI 
-- Game: Guild of Darksteel
addappid(1356580)
addappid(1356581, 1, "d50c64002d854a324b02cd3b371bbc6e99e9ae55e69dde0ff84a6a4f8ac363b8")
