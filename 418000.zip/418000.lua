-- Lua provided by SkyAPI 
-- Game: Demented
addappid(418000)
addappid(418001, 1, "17653f5e1dd683f0851eb06f5a1d5e650060f29ad5495a0d796aadaacd7db54e")
