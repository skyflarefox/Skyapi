-- Lua provided by SkyAPI 
-- Game: Slimes
addappid(1313490)
addappid(1313491, 1, "e34153e22f7e598b96e4a624e01778f0cfe0f1bdaedef8a8d45dc3c7bdd6f62e")
