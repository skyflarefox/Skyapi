-- Lua provided by SkyAPI 
-- Game: Bloody Heaven 2 ：Prologue
addappid(2881360)
addappid(2881361, 1, "67207ee9d724a04ee6b9ce469bdd126d8340986fc9eb51a6bf0bc0dc3a82dbca")
