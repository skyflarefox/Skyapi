-- Lua provided by SkyAPI 
-- Game: Garage Flipper
addappid(1764270)
addappid(1764271, 1, "e398712a39618d8cf06309cd33b487683756c3d0d96160504c7720433a222f94")
