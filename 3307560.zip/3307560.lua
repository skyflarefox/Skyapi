-- Lua provided by SkyAPI 
-- Game: FeedBack
addappid(3307560)
addappid(3307561, 1, "c7dafdc3f57a15505b56a72046589ca1034126856a7e98c0a4dbdcb80d989068")
