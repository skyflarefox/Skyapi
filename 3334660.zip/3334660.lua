-- Lua provided by SkyAPI 
-- Game: Winion Virus
addappid(3334660)
addappid(3334661, 1, "481749caf913f8ab96b6e58f8294d6d3f8dd724d96b3f7a3d508e9956356ff8c")
