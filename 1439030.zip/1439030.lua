-- Lua provided by SkyAPI 
-- Game: Brain off
addappid(1439030)
addappid(1439031, 1, "07ae60cd52c019da87a5732b61d4e455fc9653608a4a7365ba6a4c692fb296da")
