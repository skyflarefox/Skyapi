-- Lua provided by SkyAPI 
-- Game: Karate Survivor Demo
addappid(3027940)
addappid(3027941, 1, "c1abcac80173103bcfb4d6866141e78065f7e8a866efa9a1a1572396eb709aea")
