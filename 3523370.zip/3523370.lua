-- Lua provided by SkyAPI 
-- Game: OVR Input Method Bridge Playtest
addappid(3523370)
addappid(3523371, 1, "895a04efcf4dbd4671516e6aa75c130ed4e8548bc21f8429590655d407ced88d")
