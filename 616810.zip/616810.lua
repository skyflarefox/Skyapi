-- Lua provided by SkyAPI 
-- Game: Maski VR
addappid(616810)
addappid(616811, 1, "86feb243df4a4399a9f63852429872393db0b32f370def4028b7f77619879fb7")
