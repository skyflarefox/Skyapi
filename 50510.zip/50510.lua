-- Lua provided by SkyAPI 
-- Game: AppID 50510
addappid(50510)
addappid(50511, 1, "e86687842caeb226bf439dfd5ff4a9087c27282adfe906bb2b24d25aa8dfbddb")
addappid(50512, 1, "cfd9317d00b067f18bc816f14268545309548a17e937a8288c66e3891fb7d77f")
addappid(50513, 1, "593768fbb999c03977eef7b88c3dea0b21df696b3e8932c4de4ae68efac8d770")
