-- Lua provided by SkyAPI 
-- Game: AppID 769670
addappid(769670)
addappid(769671, 1, "14d0d7709db62e101670dac7efba4a7b9f5a26ad304000b0b45d6005f75f90e1")
