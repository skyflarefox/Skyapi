-- Lua provided by SkyAPI 
-- Game: AppID 1872160
addappid(1872160)
addappid(1872161, 1, "db9232ffcc58a6d8ced85b10f0ce2307bb4a7caf25755a991b31d44e04791d31")
