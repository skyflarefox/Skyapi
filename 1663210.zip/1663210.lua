-- Lua provided by SkyAPI 
-- Game: PixelJunk™ Scrappers Deluxe
addappid(1663210)
addappid(1663211, 1, "38dc0abc98338de86057ef95dc89ceb3edcc24ba77768db24ee0e378d76912b6")
