-- Lua provided by SkyAPI 
-- Game: AppID 944740
addappid(944740)
addappid(944741, 1, "f073bd6b2f8526b548f6e81e7a465f173158316472b3fc46dc1e2199d4b02914")
