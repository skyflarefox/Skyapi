-- Lua provided by SkyAPI 
-- Game: Ant secret
addappid(2736110)
addappid(2736111, 1, "0af9879f6ed25ce84701ca85dd5267a64b8cfdb9b6375a7d229980e2eedddffe")
