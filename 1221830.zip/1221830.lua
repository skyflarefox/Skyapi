-- Lua provided by SkyAPI 
-- Game: Farmer Pug Dash
addappid(1221830)
addappid(1221831, 1, "065884fb3f50ae9996b196a5f9770dfe20fa376a3458ef513e72e84b9ae352b4")
