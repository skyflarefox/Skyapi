-- Lua provided by SkyAPI 
-- Game: Wilmot's Warehouse
addappid(839870)
addappid(839871, 1, "a009282167f5c36851a9c723a45f4094dfe0a9ddf66aac7b826cc2f4f3ff8a00")
