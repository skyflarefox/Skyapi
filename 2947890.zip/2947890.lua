-- Lua provided by SkyAPI 
-- Game: AppID 2947890
addappid(2947890)
addappid(2947891, 1, "e3c5a8eb897859d2ee5a82cd43a3c62fdc27b0b20eb54db694dc939e45ee3063")
