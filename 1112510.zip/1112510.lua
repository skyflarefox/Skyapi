-- Lua provided by SkyAPI 
-- Game: AppID 1112510
addappid(1112510)
addappid(1112511, 1, "ed24dfc64a918873b5cfa850ac032535e643c3833116ef761f4fda4f26e7e1b1")
