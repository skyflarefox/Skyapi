-- Lua provided by SkyAPI 
-- Game: My Free Farm 2
addappid(799240)
addappid(799241, 1, "260dd0d19979e16e03eb8de7eb68562a7b4fd0443d5a810320a0ae4269536b75")
