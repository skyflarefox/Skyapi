-- Lua provided by SkyAPI 
-- Game: Broken Thorns: West Gate
addappid(1508220)
addappid(1508221, 1, "109c471454f4cb6ab38d9bcc07a8dbbaa9a2f33c828149b5ebd8d6a63be8d0fe")
