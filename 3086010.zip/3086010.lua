-- Lua provided by SkyAPI 
-- Game: Splash Dino 2
addappid(3086010)
addappid(3086011, 1, "924f28cb3b20d7cd5ff331455ed6392e343e63e9a9b283331359459bd3a82df9")
