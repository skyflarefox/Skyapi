-- Lua provided by SkyAPI 
-- Game: Countryside Life Simulator
addappid(2828260)
addappid(2828261, 1, "0a90a0752babcd694daba58df78598c0e3651d50c35780de2ba477e2234a1736")
