-- Lua provided by SkyAPI 
-- Game: Dungeon Tavern
addappid(1429150)
addappid(1429151, 1, "3bafd302794f50e2031adb6ea5dad62c3478d1eda232044deaf520f93b4ecd4e")
