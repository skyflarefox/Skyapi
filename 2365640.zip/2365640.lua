-- Lua provided by SkyAPI 
-- Game: Form Fitting
addappid(2365640)
addappid(2365641, 1, "e8e41cf786331e094463435b69064f734f1e3dfcf4c3e98cf847c109f525b8e9")
