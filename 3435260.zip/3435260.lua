-- Lua provided by SkyAPI 
-- Game: Dice With Death
addappid(3435260)
addappid(3435261, 1, "2c8f7b164851eaa13b0fd7ac3b3b73504e7c07e4b4faeddd73715f2cf55d2d61")
