-- Lua provided by SkyAPI 
-- Game: System Crash
addappid(481180)
addappid(481181, 1, "5d1f69639af5817361bd1b2097bacca3e9fbd0683dcf78259625ec4ba1f58638")
addappid(491340, 0, "a161866e468209218a30f4cea311c6da16ef28f69f3f3b72c79df011434ec938")
addappid(962540, 0, "2aff071b35b9faea0649154731beec0e0dfe554763aeaa3e8e73ca97c9cde4f1")
