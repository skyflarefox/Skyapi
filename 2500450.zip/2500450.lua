-- Lua provided by SkyAPI 
-- Game: Anx Defense
addappid(2500450)
addappid(2500451, 1, "419840d2ace4d1213ba68d1cc4cef553503139e46d1408dfe2660882d32f0350")
