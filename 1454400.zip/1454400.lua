-- Lua provided by SkyAPI 
-- Game: Cookie Clicker
addappid(1454400)
addappid(1454401, 1, "dc8be6e8bb8cf9a7d3f548fe759eb532def1c3d380deece391d81dafa6c96e67")
