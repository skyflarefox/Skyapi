-- Lua provided by SkyAPI 
-- Game: Easy Red 2
addappid(1324780)
addappid(1324781, 1, "8a121832d20574941b7d7e7eb4a34323c9ebe72338fc859080aac679b74bd78c")
