-- Lua provided by SkyAPI 
-- Game: 海山 Demo
addappid(2932530)
addappid(2932531, 1, "45a4e84127e8d5b90e133f665a034785bad8caa96027aed12f312137b9d5ee0a")
