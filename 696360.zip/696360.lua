-- Lua provided by SkyAPI 
-- Game: AppID 696360
addappid(696360)
addappid(696361, 1, "a42cd1b7a78090437eac86d15679a54552b1e94ce1d63c37ea8b7cd26abbbb4e")
