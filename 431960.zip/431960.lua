-- Lua provided by SkyAPI (fixed manifest)
--  Game: Wallpaper Engine
addappid(431960, 1, "db983bc58a8cb46d89d1d70cc962cc733956e6124c4025a0c932f82b3c37144a")
addappid(431961, 1, "62ac71786b9fbeecc473fccb8a14da04ea676371addd8820638ee6cddac8c344") -- Wallpaper Engine Content
setManifestid(431961, "3687007859740550172", 826275581)
addappid(431966, 1, "3217352ccc45b8943d6af58c14d359a38f2897bcf4d2f7f7eb117f79f1887fc4") -- Wallpaper Engine Localization SC
setManifestid(431966, "5369633619945201395", 8190813)
addappid(1790230)
addappid(1790230, 1, "28aacfb757c396f07f861f189a2c2ec78653123de2177c05f94a792d1a3c8bfd") -- Wallpaper Engine - Editor Extensions - Depot 1790230
setManifestid(1790230, "4193888996927260780", 5962638543)