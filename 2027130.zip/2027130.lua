-- Lua provided by SkyAPI 
-- Game: Protect My Cheese
addappid(2027130)
addappid(2027131, 1, "8fb7949d5985c208b6e940038f6863faeebc35293fe549c9d6f99456c82aabc9")
