-- Lua provided by SkyAPI 
-- Game: UnHolY DisAsTeR
addappid(889770)
addappid(889771, 1, "2cd79e74d5dd109248132b8227a0d720a299653a84f1413d438ef7da319d71c7")
addappid(892870, 0, "ad4340466edc7d0aa844bdf33ec66c15209d860318c634a18e7e05a7602733b3")
addappid(989220, 0, "17d632f76cbe0c8565864f3a13b3f592f82b4ec3afd5cc0b7d2135a4d7d9cb1f")
