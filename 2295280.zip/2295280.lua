-- Lua provided by SkyAPI 
-- Game: Love Exalt 8372
addappid(2295280)
addappid(2295281, 1, "fdb7e9c5d8ac081c33590562253a020981c4a2791e4d11b0112cd5c8df20e647")
