-- Lua provided by SkyAPI 
-- Game: The Redundant
addappid(2859330)
addappid(2859331, 1, "a7ac32932a377ae156b44145213979536d4c17a749aaa86ab79f8a22fe595cb4")
