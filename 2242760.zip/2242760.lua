-- Lua provided by SkyAPI 
-- Game: The Escape: Together
addappid(2242760)
addappid(2242761, 1, "1c07861f2c511e82b5dd2ff31a6d420b203d7138ff888d84a8fe4f83e96a8386")
