-- Lua provided by SkyAPI 
-- Game: Thou Shalt Not Kill
addappid(3064140)
addappid(3064141, 1, "87d878dd7eb60430db4474fdd18249d2c31f624c8def9b7af28829d95b639c70")
