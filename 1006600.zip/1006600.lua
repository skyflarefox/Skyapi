-- Lua provided by SkyAPI 
-- Game: Hentai Octoq Puzzle
addappid(1006600)
addappid(1006601, 1, "19b66c19227e6aa1c43009dde3bf757b141ea5086fd96ae2734effd9a804a392")
