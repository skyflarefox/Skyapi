-- Lua provided by SkyAPI 
-- Game: AppID 2249720
addappid(2249720)
addappid(2249721, 1, "5e5292fdc514f9ba6f41a1d2f8049acce86828d5da23cad2448de4518788b65c")
