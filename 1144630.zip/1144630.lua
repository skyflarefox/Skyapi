-- Lua provided by SkyAPI 
-- Game: Beardy the Digger
addappid(1144630)
addappid(1144631, 1, "956021e452dfadf0d3b20dc6e3017cdb031dfe41ad5c94f78e4e031a64557156")
