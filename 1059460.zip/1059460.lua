-- Lua provided by SkyAPI 
-- Game: AppID 1059460
addappid(1059460)
addappid(1059461, 1, "f87d8bc2383b9a9cacebe798891f766331380204a50cc42b89c6b8af795b7fbf")
