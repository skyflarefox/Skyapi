-- Lua provided by SkyAPI 
-- Game: Try Me
addappid(2019220)
addappid(2019221, 1, "e55ac4af4df9da99b8d3e43b84f1cfe0841e08edfce2b7a497283f0ed7c40cde")
