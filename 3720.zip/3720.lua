-- Lua provided by SkyAPI 
-- Game: Evil Genius
addappid(3720)
addappid(3721, 1, "aff71f7f506ee2628f3345671fa9fbf5f5810ef1c93bd73edcf9f6390f6dae7e")
addappid(3722, 1, "bb58332e0f4bfb20fec49d371621684dc49f9b5773b26d8876839bb62defd388")
addappid(3723, 1, "0d8abb254b348f07caed39cf7f0239f8036e9b5ffefb9ca827af0a843f92f765")
addappid(3724, 1, "aa3a581633590cdb6c99c610ce1d1c99b09e3fe263be1ea4a97df95ee31982e4")
addappid(3725, 1, "ea3a58aa0d4a5fcdbb0d3e5da73439546b4e3f9b009bd0003aee50f72365b072")
