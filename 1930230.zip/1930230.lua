-- Lua provided by SkyAPI 
-- Game: The Hole
addappid(1930230)
addappid(1930231, 1, "1588eec501980e66e0d74d4b2927747a616982cfe6ec68f82277d1e6dc3d0bdb")
