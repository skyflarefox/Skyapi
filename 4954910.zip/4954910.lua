-- Lua provided by Skyapi
-- Game: Scam With Your Friends
addappid(4954910, 1, "8a9051a93f80aeeefb0ac0e26f3b230f513a03af0a2c27eb898fe2f905451443") -- Scam With Your Friends
addappid(4954911, 1, "5ecd6cfa753bc263676f0dd579968e95d209b1e15363154df11fa51d51d4d94d") -- Depot 4954911
setManifestid(4954911, "2317744768457544272", 4672146405)
