-- Lua provided by SkyAPI 
-- Game: Othello 2018
addappid(874140)
addappid(874141, 1, "48a4d7835194a9f22b3355fed660feaeb5a99596e1c72e1acd3dabfd3541d3ca")
