-- Lua provided by SkyAPI 
-- Game: DEBUG DEADLINE
addappid(3344750)
addappid(3344751, 1, "16e2a1265df493a34a0fed585372529b4f5d62e46b82b11bcab5b284a1b3de0e")
