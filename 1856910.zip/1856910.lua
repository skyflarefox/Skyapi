-- Lua provided by SkyAPI 
-- Game: AppID 1856910
addappid(1856910)
addappid(1856911, 1, "a40f9dd3a08dc3c3b6fb75f17b3357137688cfec14706c0958079e57f74f4540")
