-- Lua provided by SkyAPI 
-- Game: AppID 2220520
addappid(2220520)
addappid(2220521, 1, "1532cc193c4f3b73cf9772413dd804fad3c7c5ef3d5d0e0c3a2a61d6921b1068")
