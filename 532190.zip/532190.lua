-- Lua provided by SkyAPI 
-- Game: Super Blood Hockey
addappid(532190)
addappid(532191, 1, "a0689f723c6c3993e48db15ffb4472b57f5bb755291f05eae39f3eab9adf7eac")
addappid(532192, 1, "26e19cb5e89240f6106fe2eb48a22071619b74615df5a57dfbbf0ccdced82962")
addappid(532193, 1, "27177d790b1e0a44cf99a5f9517fdf28523bd034b2815e560e8b317b94922894")
