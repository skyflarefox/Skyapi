-- Lua provided by SkyAPI 
-- Game: AppID 3081040
addappid(3081040)
addappid(3081041, 1, "dfce308128c6d9bb4400f8529ef9a86f2805dc1fb36e3896274603e6ca60c869")
