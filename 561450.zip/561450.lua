-- Lua provided by SkyAPI 
-- Game: AppID 561450
addappid(561450)
addappid(561451, 1, "1d816638bf9554794982e997654e5df4fa355989fdb215e725c5534be8336c58")
