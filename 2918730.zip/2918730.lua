-- Lua provided by SkyAPI 
-- Game: Assassin's Belief
addappid(2918730)
addappid(2918731, 1, "387abfaf116eb15c9ecc2e7bf1e2b53ceeb6551bd1a84ce3eebd2935c78f49ca")
