-- Lua provided by SkyAPI 
-- Game: AppID 993090
addappid(993090)
addappid(993091, 1, "3a02317ffe8c475c236c603a9fcd31c7cd8e4a109240f4c3d9fa28081bdc02bd")
addappid(993092, 1, "7f42c4f024fecc789a821093226e8655818e4f981c698ff5f5bba81abe4edda3")
