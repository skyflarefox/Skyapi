-- Lua provided by SkyAPI 
-- Game: Tanks Racing Sim
addappid(3227380)
addappid(3227381, 1, "e431989890256fd35d9990f5ca32248c14aec83bb8da8900a358f01e39c96cca")
