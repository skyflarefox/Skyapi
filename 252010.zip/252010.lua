-- Lua provided by SkyAPI 
-- Game: Oniken: Unstoppable Edition
addappid(252010)
addappid(252011, 1, "cfe480fbfe1597b466c23bb4e47738f806ea83e340b7f0001aa9a7b09abfb958")
addappid(252012, 1, "15e8c6dd053ee993b5385e7409bc84b518364c234b5198d9c49d2637424afc0f")
addappid(252013, 1, "dcf7421fb880ddd6f3e5badf0492d148cfd89af1bfe2d0256bae3ce0759bb8c5")
