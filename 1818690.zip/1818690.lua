-- Lua provided by SkyAPI 
-- Game: Grindstone
addappid(1818690)
addappid(1818691, 1, "0d6facef61f324f28048b61a828730bab238ea31e330bc37610236b49b05932d")
