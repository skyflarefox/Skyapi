-- Lua provided by SkyAPI 
-- Game: SVFI - Creative Extension Pack Access A
addappid(1991700)
addappid(1991701, 1, "f2b2381c5416086818bdcba3d874725663c8064f01ca8fd4318dbe1d4fe47b3c")
