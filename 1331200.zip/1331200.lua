-- Lua provided by SkyAPI 
-- Game: Backfire
addappid(1331200)
addappid(1331201, 1, "90d1bf123ffa49f305322abf23dc39081400243582fde4c13b0251d290fe65d2")
