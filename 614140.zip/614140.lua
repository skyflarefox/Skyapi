-- Lua provided by SkyAPI 
-- Game: AppID 614140
addappid(614140)
addappid(614141, 1, "0f33f0f097275bd1b220711f956a8810fea06e0b3abe51b43f71570591f1594c")
