-- Lua provided by SkyAPI 
-- Game: Final Dusk
addappid(337420)
addappid(337421, 1, "6292563e8b59777c2c0f0406019d209a585f39249d0bf7793d2b5676d514c0fd")
