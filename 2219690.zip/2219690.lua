-- Lua provided by SkyAPI 
-- Game: Dominator Idle
addappid(2219690)
addappid(2219691, 1, "688ba64d6848d02d2338ee632084d672d985909faf62c2bca95569e76c974c4c")
