-- Lua provided by SkyAPI 
-- Game: Multiverse Loot Hunter
addappid(2776450)
addappid(2776451, 1, "d344b9a8eb3356663a0ad386889d0a675acdf4e1b2e41aa43d220e0ef38e65a8")
