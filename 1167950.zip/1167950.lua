-- Lua provided by SkyAPI 
-- Game: Vampire's Fall: Origins
addappid(1167950)
addappid(1167951, 1, "0eebd2166d87e5bc0616d09e5a811786f4a11cf8e37407a9d59c7ee356ce023a")
