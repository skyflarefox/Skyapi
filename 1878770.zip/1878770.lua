-- Lua provided by SkyAPI 
-- Game: AppID 1878770
addappid(1878770)
addappid(1878771, 1, "bde20f90a9e20deff894ac06245fe8159bd377dc071a069eee7da2f0f21f11c5")
