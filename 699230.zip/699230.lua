-- Lua provided by SkyAPI 
-- Game: AppID 699230
addappid(699230)
addappid(699231, 1, "b00317cd548d772eb52f56df00ccf17af2a69e10656fe5cd6c8cae6afbfc7362")
