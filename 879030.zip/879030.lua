-- Lua provided by SkyAPI 
-- Game: AppID 879030
addappid(879030)
addappid(879031, 1, "626ed683b1eff64d9c5b2df1ac0d9283b3f0f27c48fcc0de17df6fe4090973ad")
