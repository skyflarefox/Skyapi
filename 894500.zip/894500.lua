-- Lua provided by SkyAPI 
-- Game: AppID 894500
addappid(894500)
addappid(894501, 1, "9a3b30dba6a57db7763bdae341326a2febb23becd089d7d81d719a58a2453a95")
addappid(894503, 1, "898f4175d0eb4e2b4b70660c21376446d884defb47b365f49b262011cc821043")
addappid(894504, 1, "2e6eae4c82ef1f2351d4bf54ef66e3c03db9e2353cd29c4d5e67f1943cb0cbce")
