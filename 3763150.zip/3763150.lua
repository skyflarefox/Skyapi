-- Lua provided by SkyAPI 
-- Game: Gorilla Smash
addappid(3763150)
addappid(3763151, 1, "575cb3f87960943e9a22c3d131270330a046134637d0d818020d91d16137e066")
