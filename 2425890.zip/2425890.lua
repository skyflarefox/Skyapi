-- Lua provided by SkyAPI 
-- Game: Crossing Damaged Bridge
addappid(2425890)
addappid(2425891, 1, "69503c3a11eb6a68267fb8ee8d5bf836e9669d2c18a4683b61fca543317a0cc6")
