-- Lua provided by SkyAPI 
-- Game: Loopmancer
addappid(1650810)
addappid(1650811, 1, "320d82338aaaaa9f587391d29251c3bc8cc8711b11b755a7d2e4c945f0ee1fb1")
