-- Lua provided by SkyAPI 
-- Game: AppID 1311980
addappid(1311980)
addappid(1311981, 1, "088cc36c64af623dfba79214c5ba2b409fd85671ab20b0d26caf143aa122e015")
