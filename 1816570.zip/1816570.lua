-- Lua provided by SkyAPI 
-- Game: 江湖十一
addappid(1816570)
addappid(1816571, 1, "716a4188694fe49c4a275171e72381e4339eda28a87f93d229ff22673e96c1dd")
