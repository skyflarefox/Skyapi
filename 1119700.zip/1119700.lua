-- Lua provided by SkyAPI 
-- Game: AppID 1119700
addappid(1119700)
addappid(1119701, 1, "2bc5bfb9449150f2b5a57bc5eda980b0d5899247d1ace46eff1b18e626af6eac")
addappid(1359670, 0, "d1a99458d33b55da7205e7ac1ebfd2413f150fccc2e39967c50e879e7f07f583")
