-- Lua provided by SkyAPI 
-- Game: Time Agent
addappid(1306760)
addappid(1306761, 1, "7e6a2db454b6386a027771a1b352c213f179312e72ffd490925c9d9ccfb676e0")
