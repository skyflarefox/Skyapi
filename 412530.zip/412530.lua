-- Lua provided by SkyAPI 
-- Game: Atlantic Quest 2 - New Adventure -
addappid(412530)
addappid(412531, 1, "8f57859357ca28c979ef5ef94bc1b8b0abe8f64cd19b697f7968f487e3c9856a")
