-- Lua provided by SkyAPI 
-- Game: Fragmental
addappid(424040)
addappid(424041, 1, "736c789c4186b81ecac7f5433cfe4ad2ce18c35c6638d2cdb042e6eedadf0477")
