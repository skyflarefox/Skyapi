-- Lua provided by SkyAPI 
-- Game: FARAWAY TRAIN
addappid(1601410)
addappid(1601411, 1, "a2e12983d56d61b564114c9be621e0b117c653f658d3c9cba05e7914d149f5e7")
