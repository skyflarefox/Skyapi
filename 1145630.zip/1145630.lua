-- Lua provided by SkyAPI 
-- Game: AppID 1145630
addappid(1145630)
addappid(1145631, 1, "f0708b5e7fda6c602abd3d191dcb0def4f7b6005d0d022949233db4652766405")
