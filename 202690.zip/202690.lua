-- Lua provided by SkyAPI 
-- Game: Hegemony Gold: Wars of Ancient Greece
addappid(202690)
addappid(202691, 1, "a8a92553bec66e4f3392f13ee96cc7c24e9c832bea03dbfe6e8123ba175d8cc6")
