-- Lua provided by SkyAPI 
-- Game: Aeronautica Imperialis: Flight Command
addappid(610160)
addappid(610161, 1, "0eb97aebb3806e0ee5ec9ebaf5a85d5285621f023a17336d6b38ce0bdbbaaa4e")
