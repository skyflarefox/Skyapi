-- Lua provided by SkyAPI 
-- Game: AppID 885140
addappid(885140)
addappid(885141, 1, "d151c2fd353b6ce9fcaad8fa276a9dc8f0e7fc933ae40811cf2708af1f07f892")
addappid(1009540, 0, "3beab324adb97e87e148e239aac8282dcadff6499c8a4348cf1c091dc183d2a2")
