-- Lua provided by SkyAPI 
-- Game: Medieval Delivery
addappid(2338200)
addappid(2338201, 1, "3b5e23d2df38bc4eadcbdd38bdc23c95847f0ee58d56f6406196c94a305aab0b")
