-- Lua provided by SkyAPI 
-- Game: Do Not Feed the Monkeys
addappid(658850)
addappid(658851, 1, "9ce3f6aad8b8ab695875d3ef8fac19989b4781130e04efe07829ce7f373edb55")
addappid(658852, 1, "cb0611051759ac48deceed8f16250e8d66069e812f7bc662a1af103dfeacd1c8")
addappid(658853, 1, "e5ef80dbc5ba812f9fbb5605fc7ea6e43abc9a1a3adb27ff3970a9ca2dbe511e")
addappid(658854, 1, "4586929f7b4eac5f03688d898266a9749bc909264c0f6ad95a817e38805b7dfb")
addappid(658855, 1, "77e4e8dbb6920cee5de31aac734ff46e547c3bd7b3db5a6f5200cd074a9f7fca")
addappid(1205930, 0, "52044193dc456f453173e18e3ddb0a1c368186a8527b33d3e04a53d1e33354ad")
