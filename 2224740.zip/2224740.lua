-- Lua provided by SkyAPI 
-- Game: DreamWorks All-Star Kart Racing
addappid(2224740)
addappid(2224741, 1, "f406519329155b7eef28b776311e4162923233f07b2c0955cf5c5322bc007c1f")
addappid(2518390)
