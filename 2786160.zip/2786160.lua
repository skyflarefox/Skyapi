-- Lua provided by SkyAPI 
-- Game: Skeleton War
addappid(2786160)
addappid(2786161, 1, "87d2025fd57bbe36b7f7b56a42163f6455e43af6d8767731c6fa0666fb5867b5")
