-- Lua provided by SkyAPI 
-- Game: Zen Chess: Mate in Four
addappid(1043000)
addappid(1043001, 1, "10bbb4cf8b000745ee1d9a46ae2f489f0cb4e73be93b9809aa23eec40e5a78fd")
