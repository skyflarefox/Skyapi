-- Lua provided by SkyAPI 
-- Game: SYMMETRY
addappid(537520)
addappid(537521, 1, "04f66cbe7be3fa6930c3d6e8689427b9530b6ce01172dba8733bf8f98a83b21c")
addappid(537522, 1, "74375a713120d2994a9a0486e7c99988a75c626b6cda79cfa496b9a363e5638e")
