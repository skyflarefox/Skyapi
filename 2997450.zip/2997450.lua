-- Lua provided by SkyAPI 
-- Game: Only Up: SKIBIDI
addappid(2997450)
addappid(2997451, 1, "0c891ceace39a9fbb1a709cd3b2d6d75d2154736c9cd2f1c3b558e625586a1af")
