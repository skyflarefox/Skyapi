-- Lua provided by SkyAPI 
-- Game: Lost & Found Collection
addappid(3325690)
addappid(3325691, 1, "e10b417aa292316164706cc21bfc56f4861b992a89a7df9c78d896862e619459")
addappid(3325990)
