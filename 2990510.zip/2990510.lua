-- Lua provided by SkyAPI 
-- Game: SkyBrew: Entropic Strategist
addappid(2990510)
addappid(2990511, 1, "d808ccfc425a300b530f2d6c3798d3fbfe5802a5a4d499a6f618ffe7a3ba8063")
