-- Lua provided by SkyAPI 
-- Game: IL-2 Sturmovik: Battle of Stalingrad
addappid(307960)
addappid(307961, 1, "23b7d427a0663be8f3d3540b80b7a0bb9d98b7f4e6d17ddc7a7224ac5d20e947")
