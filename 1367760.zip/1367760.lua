-- Lua provided by SkyAPI 
-- Game: AOD: Art Of Defense
addappid(1367760)
addappid(1367761, 1, "5f666bc1f9b300d9e5a54721a4c748feaf938a975e47ea9d508740bcabb11483")
addappid(1367762, 1, "5b27ba26258cc9301b36de28ccc78a963e1b26f49c38b9862d1fc054cb81e06d")
addappid(1367763, 1, "08e1ec55fb7504350eaa90bba4fed63d6ef97e4fb381fbd9368677ff633570e2")
