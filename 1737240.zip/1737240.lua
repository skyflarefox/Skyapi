-- Lua provided by SkyAPI 
-- Game: 天气
addappid(1737240)
addappid(1737241, 1, "e913242c1360f7c1c5c854664c0cfd91a03267f3f567b9af16116cb4d838a8c6")
