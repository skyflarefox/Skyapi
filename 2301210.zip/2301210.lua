-- Lua provided by SkyAPI 
-- Game: Busway Islands - Puzzle
addappid(2301210)
addappid(2301211, 1, "60cc0e4be0ac791d9e64d250967c563fc44f463d0abda3ec21ce94a46a8f8ce1")
