-- Lua provided by SkyAPI 
-- Game: PROPHUNT
addappid(1600950)
addappid(1600951, 1, "0f3ccec2df340443a7334c45793f27ee0ca17f2cc7e822cb698a684d33e9f0bb")
