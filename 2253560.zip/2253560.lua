-- Lua provided by SkyAPI 
-- Game: Terix Survivors
addappid(2253560)
addappid(2253561, 1, "9750b2450999457de2946595944257c60628b692cb10a5f5646fcf6c8b3b0c73")
