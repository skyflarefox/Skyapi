-- Lua provided by SkyAPI 
-- Game: AppID 766730
addappid(766730)
addappid(766731, 1, "8c6d2051b8f31d606f9eb45c340d5884186b7b3450cad7dbd57899c4ed724563")
