-- Lua provided by SkyAPI 
-- Game: AppID 727220
addappid(727220)
addappid(727221, 1, "8936720abebea11fcdc62e71a92d7f7ca04f9c59e10448d69058029c255ba2e5")
