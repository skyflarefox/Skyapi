-- Lua provided by SkyAPI 
-- Game: AppID 1454490
addappid(1454490)
addappid(1454491, 1, "f70ce39b1cf4f708abf85963dba022691bd4d5c63530a90f5f16f08f3d59b96f")
