-- Lua provided by SkyAPI 
-- Game: Shank
addappid(6120)
addappid(6121, 1, "6ed17075d0fa3d2a0d7a26e7b55b3515640c2cc3aedb9bb676cfa5ffde3a8411")
addappid(6122, 1, "5dbfdd024ec5a74f41375e885bcd8322748665a80a90b55c6de080b8581d1b22")
addappid(6124, 1, "5170151ab3416bbe62e8825156c04a76e49ab2c329e2d2e5f770dd01e70afccb")
