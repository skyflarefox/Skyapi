-- Lua provided by SkyAPI 
-- Game: Playcraft
addappid(805270)
addappid(805271, 1, "82c17132124a039d4e9c66f7382657c819256a016c1c1a4db0873ac332efe864")
