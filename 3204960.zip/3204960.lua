-- Lua provided by SkyAPI 
-- Game: Bullet Noir
addappid(3204960)
addappid(3204961, 1, "7c7a7e5f2ef90c1deca53409f64d05c13f4c685b755c03aa148e64a8a20b65ce")
