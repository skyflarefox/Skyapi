-- Lua provided by SkyAPI 
-- Game: AppID 1015090
addappid(1015090)
addappid(1015091, 1, "9ed34d4b75c62ce0b15c93629d3f38a85be7b3550cdad413c9e3da6acc4d5cec")
