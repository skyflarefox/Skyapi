-- Lua provided by SkyAPI 
-- Game: AppID 1229580
addappid(1229580)
addappid(1229581, 1, "c60f99b9746495a9940de03b0940fea83643629c8f0b7c72b56efc4f45396644")
