-- Lua provided by SkyAPI 
-- Game: Redout 2
addappid(1799930)
addappid(1799931, 1, "f3cadeab1aede0dcfe25f75d2fdea7be1afcd116f476929316284db09374164b")
