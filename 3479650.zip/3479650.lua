-- Lua provided by SkyAPI 
-- Game: El Pasante Elementalista
addappid(3479650)
addappid(3479651, 1, "543e91564e85372262e27e4b54e173951cb848ad19b6bcdc8c1d9a1ed9a030e8")
