-- Lua provided by SkyAPI 
-- Game: CODA
addappid(2420390)
addappid(2420391, 1, "25fa93e405fbfb60370b675c477a0daebadca45d8fb0f1e83c0305f8cc32407e")
