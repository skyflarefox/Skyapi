-- Lua provided by SkyAPI 
-- Game: AppID 1054590
addappid(1054590)
addappid(1054591, 1, "86c854a982cdebdfc38df6b75fd6431c348ecc656f38797b939c80b9d70a1013")
