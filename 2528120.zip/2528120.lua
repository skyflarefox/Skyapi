-- Lua provided by SkyAPI 
-- Game: AppID 2528120
addappid(2528120)
addappid(2528121, 1, "7b8af7d0b6cd85e44eafc69a954643a85d1d19671ce8b5475ae946dfb22b9b0a")
