-- Lua provided by SkyAPI 
-- Game: Exotic Kosmos
addappid(1405010)
addappid(1405011, 1, "483b99b67a15d40c9721490ff619311ba47e73bf2810eb1ee79e1a65d7406ebc")
