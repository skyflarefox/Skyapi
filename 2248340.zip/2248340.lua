-- Lua provided by SkyAPI 
-- Game: UNRESTRAINED
addappid(2248340)
addappid(2248341, 1, "3339233aa6a2a4eef1edf0fca74b77795387e3e54e98e1485c2ee55cae7a7a25")
