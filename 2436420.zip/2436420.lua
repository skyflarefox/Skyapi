-- Lua provided by SkyAPI 
-- Game: AppID 2436420
addappid(2436420)
addappid(2436421, 1, "84e42ee7dc5ae4ff89e6edf117ee5a173a30e1ce9ec86ae4079f56cdaae6d84c")
