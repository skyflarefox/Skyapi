-- Lua provided by SkyAPI 
-- Game: Succubus: Hunt For Meal
addappid(1642820)
addappid(1642821, 1, "148784e27e85d5d5d6f29408febe2cd4138fba35e90b10e3ad8cbbb40a34804e")
