-- Lua provided by SkyAPI 
-- Game: AppID 317110
addappid(317110)
addappid(317111, 1, "85725af9fead8ad6fa6d4a4284741c61bd3d62db97771c4eccdbc40ac3fb37e7")
