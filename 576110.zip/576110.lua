-- Lua provided by SkyAPI 
-- Game: AppID 576110
addappid(576110)
addappid(576111, 1, "c59efe152698015e001986338d24d3d27e59411288c5b651c950849bd2d7b8e9")
