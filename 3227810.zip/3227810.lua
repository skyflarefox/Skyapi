-- Lua provided by SkyAPI 
-- Game: Sucker head: Bodycam
addappid(3227810)
addappid(3227811, 1, "184d7e6dff6a9e3faf0d863f810c6334c7b1254a22a15dc30ab4cddba7501259")
