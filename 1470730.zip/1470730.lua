-- Lua provided by SkyAPI 
-- Game: Russian Reality
addappid(1470730)
addappid(1470731, 1, "74105369820519690efb51676683bbb2b98998ec1b1a0d3e5c0b1e0305725fca")
