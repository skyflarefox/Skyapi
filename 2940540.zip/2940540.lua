-- Lua provided by SkyAPI 
-- Game: AppID 2940540
addappid(2940540)
addappid(2940541, 1, "471c8bacc434fbeb0d99795f77060010ef28b7290ff026d293f159c934edbc4c")
