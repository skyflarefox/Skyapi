-- Lua provided by SkyAPI 
-- Game: Succubus x Saint
addappid(1078370)
addappid(1078371, 1, "5e4f88e60ac1f61a467de5e1110a6ca01abf5c8d7184f02e27f7f0e59a13a516")
addappid(1078372, 1, "ccbf3e00c289d278f7876c7075bf97f28f3b537a92aa4738d2c77b9c8334f917")
addappid(1078373, 1, "58d849725b0df891a17533f21a576c4c2cb0232cc206ae6b79be262f9c06ab30")
