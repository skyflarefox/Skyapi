-- Lua provided by SkyAPI 
-- Game: Hotel Tutwin
addappid(1049420)
addappid(1049421, 1, "691f247143b09547504121d77caa120e3812b4390c1eef65d0798a8a20512f86")
addappid(1049423, 1, "ce451f8ef6861cd6f911159c8e3931dd253e52edf0b75998ca1d6afc96b4d268")
addappid(1053080)
