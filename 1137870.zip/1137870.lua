-- Lua provided by SkyAPI 
-- Game: Mosh Pit
addappid(1137870)
addappid(1137871, 1, "745dba692100e9ce07ed4dddb098bd018e6815a381448df4bbdc0091ce83434b")
