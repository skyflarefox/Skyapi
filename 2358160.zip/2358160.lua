-- Lua provided by SkyAPI 
-- Game: Little Crab Fisher
addappid(2358160)
addappid(2358161, 1, "dd84e110419fa31b1e98aa22f86163d8a8a83346c25e4a4ce2499c9d3bb0b9b4")
