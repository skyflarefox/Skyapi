-- Lua provided by SkyAPI 
-- Game: AppID 445230
addappid(445230)
addappid(445231, 1, "5b2e3e182b671e1cb70d1f10c494e80b381cf4c24614b3cb771489f1e4d99cc5")
addappid(445232, 1, "e51939221a01ca71f23bed844a7659d99a5d144a46b40c1da4a7d5307d1851ee")
