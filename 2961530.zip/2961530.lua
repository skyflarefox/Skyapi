-- Lua provided by SkyAPI 
-- Game: Fears to Fathom - Woodbury Getaway
addappid(2961530)
addappid(2961531, 1, "dff8b76588bfbefe7aceedf3312c31c7eab25b590d1a95485d82bad8d4ba225b")
