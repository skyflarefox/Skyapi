-- Lua provided by SkyAPI 
-- Game: Revue Starlight El Dorado
addappid(2849960)
addappid(2849961, 1, "1eb8cc0a3368b2ba3005190bfd70ee3b53a8fca2b7f09369aff9f64e4053bb63")
