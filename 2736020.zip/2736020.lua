-- Lua provided by SkyAPI 
-- Game: Fuck You Witch
addappid(2736020)
addappid(2736021, 1, "3f8343ed6fe767d7d0390f44d78480a9b9b52a5f128000a87d3b0941fefe194b")
