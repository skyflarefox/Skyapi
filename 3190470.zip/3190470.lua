-- Lua provided by SkyAPI 
-- Game: Commando Collection Soundtrack
addappid(3190470)
addappid(3190471, 1, "1e99918419d4bb9fe95bdeaed7233f0c7804aa47710a271ba30c9f7ce09a80bf")
