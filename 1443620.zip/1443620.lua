-- Lua provided by SkyAPI 
-- Game: Pirates VR: Jolly Roger
addappid(1443620)
addappid(1443621, 1, "1830a3a2b0baf49cc942d6979631b07c2b1ad486ef05ba95d2dd169c727312ee")
