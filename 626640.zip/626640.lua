-- Lua provided by SkyAPI 
-- Game: Lost Lands: The Wanderer Collector's Edition
addappid(626640)
addappid(626641, 1, "a61d75c6e33bb158f545d626e75c9c20208b2b8c330b3896080a87280d300588")
addappid(626643, 1, "41e34f1ac0133b07fd5da3ab03ae5ae15763102655e943b7711642400e65bf53")
addappid(626644, 1, "64954ced3227d09fc272147de5aa100e58ebe69f89e9c3b2227dde97a77f24a9")
