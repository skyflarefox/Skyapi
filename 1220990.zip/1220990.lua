-- Lua provided by SkyAPI 
-- Game: Great Utopia
addappid(1220990)
addappid(1220991, 1, "cf63423f8e272ec716af64fc6afd5c68dce97ca8a87a64087071cd8b870896c4")
addappid(1220992, 1, "96b2de6e48f91cb1a651866cdd8136be3b3e425ff879b9ae0a814398921ae8ca")
