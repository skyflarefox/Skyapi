-- Lua provided by SkyAPI 
-- Game: Tiny Civilization
addappid(2230280)
addappid(2230281, 1, "6907470a25cd285b128bcbbb1b183192afd4491ec29a00a72356e2078a33a771")
