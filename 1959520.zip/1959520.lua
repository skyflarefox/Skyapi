-- Lua provided by SkyAPI 
-- Game: Story Of Eve 2
addappid(1959520)
addappid(1959521, 1, "b99f0b1a0ddb2cc6b26f314c9a857a65fb961f556a4aef394d65a4ec5ba1cbd9")
