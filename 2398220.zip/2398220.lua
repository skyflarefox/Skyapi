-- Lua provided by SkyAPI 
-- Game: The Hero's Way
addappid(2398220)
addappid(2398221, 1, "999b637880d76f6b52f3792a834db4eb6a5b106300906684d8633496e3972d75")
