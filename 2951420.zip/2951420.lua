-- Lua provided by SkyAPI 
-- Game: Jin Ping Mei
addappid(2951420)
addappid(2951421, 1, "eef89d641db2d2a644d85caee59d83b4f9d62e4bb16699029909b8fe6df6e00c")
