-- Lua provided by SkyAPI 
-- Game: Universe in Cum 2 💦 🌎
addappid(2512200)
addappid(2512201, 1, "03ec4aba92f6f0500b8a00e69766e9031cd0c937ce727bdc57f984667f0a2bf1")
