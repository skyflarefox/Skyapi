-- Lua provided by SkyAPI 
-- Game: AppID 1084970
addappid(1084970)
addappid(1084971, 1, "f6b789fa3fe550f6f593dea5b5117f6928e0bd6fdc18fd70439a1242e31a7da0")
