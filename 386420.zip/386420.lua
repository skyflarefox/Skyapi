-- Lua provided by SkyAPI 
-- Game: Job the Leprechaun
addappid(386420)
addappid(386421, 1, "f16b8fbdb54411cc73bae96760d651ad0ddd39603501f4b650613bab4df5aa66")
addappid(386422, 1, "64554394dc2e8c05f8cfce49c3d4f5e9301133e38d3fe9c0f5055c79ee084460")
addappid(386423, 1, "a73555f19a69d19339d4396bc458381e79e3da021f00d79c963485ed2d1ccd0c")
