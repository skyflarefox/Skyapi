-- Lua provided by SkyAPI 
-- Game: Murder House
addappid(1064460)
addappid(1064461, 1, "e53b6e40c543144630fa39758e6c97913fed7c678f9b01c4868d98580dbc8cfb")
