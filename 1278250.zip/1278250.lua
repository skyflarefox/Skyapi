-- Lua provided by SkyAPI 
-- Game: AppID 1278250
addappid(1278250)
addappid(1278251, 1, "27fc6849935fce8848a6239c2e71b59c980519c6cbb3565f78ea12348b396e25")
