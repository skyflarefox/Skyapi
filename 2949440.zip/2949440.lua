-- Lua provided by SkyAPI 
-- Game: 与从画面中出来的我推Vtuber的同居生活 想跟庶民派的吸血鬼大小姐签下契约
addappid(2949440)
addappid(2949441, 1, "c937238ffb302b2f7dd5920fe37e93e01743ba7ae1e4423b26ec5bd0efb55b1a")
