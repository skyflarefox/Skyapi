-- Lua provided by SkyAPI 
-- Game: AppID 2294710
addappid(2294710)
addappid(2294711, 1, "72c31f114680a73f0b98d3834301de114fd8fb3cf4de55d9e27cc5834823912d")
