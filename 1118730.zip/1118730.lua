-- Lua provided by SkyAPI 
-- Game: AppID 1118730
addappid(1118730)
addappid(1118731, 1, "360563c4d37f2a9fcb69b1516a318efca13351642f0110e838fb39d831d57a75")
