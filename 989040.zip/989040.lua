-- Lua provided by SkyAPI 
-- Game: After Hours
addappid(989040)
addappid(989041, 1, "1371e4954b71094c30620a9cdebd82ce6d81a886e5c0f07b4787643c27a28602")
