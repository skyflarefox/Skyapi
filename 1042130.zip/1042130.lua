-- Lua provided by SkyAPI 
-- Game: AppID 1042130
addappid(1042130)
addappid(1042131, 1, "5fdb090ac3f2cf341b9ec0c8067fed04e875e11cf95a58550ffe771b9bdc901b")
