-- Lua provided by SkyAPI 
-- Game: Shadow of the Depth
addappid(2100150)
addappid(2100151, 1, "4c275f0c8c843b7c9d9636e1929dd2cd1ee1ce0f1d0ffb0746cc2c0468f2b161")
