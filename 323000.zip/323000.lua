-- Lua provided by SkyAPI 
-- Game: Roaming Fortress
addappid(323000)
addappid(323001, 1, "7d954583deacb4dbd44bd7594eae4318e72c8303b6011f442dae92e7e51e990c")
