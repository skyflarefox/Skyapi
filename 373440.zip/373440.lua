-- Lua provided by SkyAPI 
-- Game: Stargazer
addappid(373440)
addappid(373441, 1, "e1a16afe8ccfdb97bbf910c3ec3e66096f90dc688f19131c7ed6c3fb1825a978")
