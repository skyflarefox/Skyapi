-- Lua provided by SkyAPI 
-- Game: Reactor Tech²
addappid(1444020)
addappid(1444021, 1, "52a5969d2ab6984b468a7a02f5531fce7b65f7f3f6256d7e2611752a1c09e6ba")
