-- Lua provided by SkyAPI 
-- Game: AppID 491420
addappid(491420)
addappid(491421, 1, "90ec7dc750ea6bd728ad11626fe8ee4eee4ff262beee4134d1630839271e1a80")
