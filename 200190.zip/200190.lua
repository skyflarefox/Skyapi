-- Lua provided by SkyAPI 
-- Game: AppID 200190
addappid(200190)
addappid(200191, 1, "b12e6d601bb858158f40afa55fd643c88d66ee1f1967af24e749f5dba6965e1d")
