-- Lua provided by SkyAPI 
-- Game: AppID 2319580
addappid(2319580)
addappid(2319581, 1, "9e4bf8248cd6d565643c86057112a127accc9457bcf90a97589f5f49857115b0")
