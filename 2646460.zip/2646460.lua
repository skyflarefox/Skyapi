-- Lua provided by SkyAPI 
-- Game: Soulmask
addappid(2646460)
addappid(2646461, 1, "b888b7fdf975bfc80d87df6beb2c5d56ada854d2adb6537fce281905a5d74d2a")
