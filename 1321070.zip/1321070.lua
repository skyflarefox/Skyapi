-- Lua provided by SkyAPI 
-- Game: Death Come True
addappid(1321070)
addappid(1321071, 1, "f1c794f604d95003c1d38ca9fe3153e711c020eb48cf78873b294e74315f2c4f")
