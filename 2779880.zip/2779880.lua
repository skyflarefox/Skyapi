-- Lua provided by SkyAPI 
-- Game: AppID 2779880
addappid(2779880)
addappid(2779881, 1, "193934f9759e3dc53e32cd2677fb076c3cc889e268f6270ab8305ec6dd1b75c5")
