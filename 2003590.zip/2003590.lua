-- Lua provided by SkyAPI 
-- Game: The Invisible Man's Stealth NTR: Convincing and Inseminating the New Announcer with an Invisible Boner
addappid(2003590)
addappid(2003591, 1, "80c0fd7cf8725e5c1b5dd774ce1ac2950274fc2df0512f5da167b5bdaa054678")
