-- Lua provided by SkyAPI 
-- Game: AppID 1171040
addappid(1171040)
addappid(1171041, 1, "93c908b14975b7b6f8fc2e27354c04df171cb42bb806beaf9e2e729b3ae9109d")
