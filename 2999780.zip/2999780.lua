-- Lua provided by SkyAPI 
-- Game: Skeletos Sword
addappid(2999780)
addappid(2999781, 1, "9f5d4dc7148010aae97aaeec8e6e7e69fb688a604c72c7d339b22f21fecdf74f")
