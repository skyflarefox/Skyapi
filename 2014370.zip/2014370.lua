-- Lua provided by SkyAPI 
-- Game: 魔塔三国之群雄争霸
addappid(2014370)
addappid(2014371, 1, "88670a9162023a5b412104f81d8d5a5a2fc9d69e1fd233054d465752088639ab")
