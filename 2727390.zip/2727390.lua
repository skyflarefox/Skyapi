-- Lua provided by SkyAPI 
-- Game: AppID 2727390
addappid(2727390)
addappid(2727391, 1, "1a9b4d029fac9147b8a27e8034d4c11de87da8af382704d5df53cd67888e5679")
