-- Lua provided by SkyAPI 
-- Game: MagicTowerReset
addappid(3243990)
addappid(3243991, 1, "68be552c9ea36c3c307a54ca25e8fd6335c04184fe46b8f12718ac620cc1648b")
