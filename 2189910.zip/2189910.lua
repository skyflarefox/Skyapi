-- Lua provided by SkyAPI 
-- Game: Mystic Forest
addappid(2189910)
addappid(2189911, 1, "bdffc82c59767283f8c7342f641313cee7384cf69f3c9a608fc4c7fc55531984")
