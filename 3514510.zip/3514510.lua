-- Lua provided by SkyAPI 
-- Game: Trump Tariff
addappid(3514510)
addappid(3514511, 1, "7ae2ea210e6ff9192171d509d08d091242c92d3a0664082cff9b204c3a20ed57")
