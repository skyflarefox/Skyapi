-- Lua provided by SkyAPI 
-- Game: Escape the Clinic
addappid(1355930)
addappid(1355931, 1, "795b73e90e8549d52f54e17cac309c1258db50b6b817b5218508649353c818f8")
