-- Lua provided by SkyAPI 
-- Game: Super Seducer 2 - Advanced Seduction Tactics
addappid(863570)
addappid(863571, 1, "fb2d93c02635569ff2bf7ef5b07f3dbdba2bcd6cd066d7e2fc50577cb106e82e")
addappid(932740, 0, "e59d01c8887583f31b255d621aa8230ee7b20a1e71d2fd31896345dbcfdf7501")
addappid(932741, 0, "5a340aed95a5a9fea2f808de34a4c3d8abd23cdd82a43bdb917b27a73346736d")
addappid(932742, 0, "08cf4544b0421f0c8f633f15898bb283a3f4aa8e5af4911e404f05b4aaeb82eb")
addappid(932743, 0, "9f07687271a466cefca7d5fbbff14debcf55b98163eabae5a19df99b9df79725")
addappid(932744, 0, "eb8580fb3a675448b1af6da8f9c37c123bc7435a318939bf45edb211375e78b2")
addappid(938950, 0, "d8c6f0c486d35026a9c0dc38a3e56e3c4e9291f71a7653c62006a82984cb98b8")
