-- Lua provided by SkyAPI 
-- Game: AppID 577490
addappid(577490)
addappid(577491, 1, "4c0d8952195d5b939c328cd35c415411b57f8db6a12fc002fccf096787cf4578")
