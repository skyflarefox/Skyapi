-- Lua provided by SkyAPI 
-- Game: Devils Adventure
addappid(3145860)
addappid(3145861, 1, "68938e4097613bb411fb4c6f179b7df1421cbea62d7967e0fc3084cdfc3f3fc2")
