-- Lua provided by SkyAPI 
-- Game: AppID 1682610
addappid(1682610)
addappid(1682611, 1, "090ad184e5d6b6f2f7f3e6fcf4548b74fb84c99fa549e3d905b89c90013d2672")
