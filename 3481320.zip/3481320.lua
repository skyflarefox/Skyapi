-- Lua provided by SkyAPI 
-- Game: Deckline
addappid(3481320)
addappid(3481321, 1, "3f8cf034015d65424c4a36c2923b3570b9f833b4966d4cba5409fdd796dbc13f")
