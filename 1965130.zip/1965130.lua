-- Lua provided by SkyAPI 
-- Game: Key Puss
addappid(1965130)
addappid(1965131, 1, "3d8ea664cb43913dccd0134f78053ff3a5fc353d121ce7c754a3296aadbca8b7")
