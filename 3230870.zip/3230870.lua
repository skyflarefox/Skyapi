-- Lua provided by SkyAPI 
-- Game: Archaeology - FROZEN WALL
addappid(3230870)
addappid(3230871, 1, "569737f9ddab7a6a817123f988b63ecea5cdce90250e2f6b17b107b6cb2c0e89")
