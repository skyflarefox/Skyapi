-- Lua provided by SkyAPI 
-- Game: Bouncy Goat Climb
addappid(1541220)
addappid(1541221, 1, "c2435782750536894a54afe79f42d55d97c7a1a6f30667bfb922018eae013736")
