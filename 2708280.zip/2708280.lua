-- Lua provided by SkyAPI 
-- Game: ESCAPE FROM BOYKISSER
addappid(2708280)
addappid(2708281, 1, "a9d2ff9cb02a90e64fda772adb7810588d98c52ed0f5d473495b4c97d13be57a")
