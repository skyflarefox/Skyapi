-- Lua provided by SkyAPI 
-- Game: Crunch Time! Beat the Clock
addappid(2251500)
addappid(2251501, 1, "5c3ff4e22f66988e9ce07b4f80d6a844d041ec9d3d732843f6a2601813da7478")
