-- Lua provided by SkyAPI 
-- Game: KOJOUJI
addappid(1327260)
addappid(1327261, 1, "baa1935acc3818cdc01c5a6402bb14be6ee099710cd4eca1871460dd9b19a83b")
