-- Lua provided by SkyAPI 
-- Game: The Chronicle
addappid(2004520)
addappid(2004521, 1, "7bf91424a6d46085403cc6e98509ff54017a3dd90647096b149d6ebed1279215")
