-- Lua provided by SkyAPI 
-- Game: The Spirit
addappid(1389450)
addappid(1389451, 1, "e233a9d3dc6b77a4d287efb0e74b2987ac1175d79266ea3c330b40cd872f114b")
