-- Lua provided by SkyAPI 
-- Game: BATTLLOON - バトルーン
addappid(985800)
addappid(985801, 1, "65334f7c385ec066bb32f86ea56901e37ffc44747869302e99d5ac47369b5df1")
