-- Lua provided by SkyAPI 
-- Game: RUINSMAGUS
addappid(1701560)
addappid(1701561, 1, "650ec4bb79057dc05e0d66ddc8e5b63d3fe734cf365dcc71ced82ed4dbcd8a55")
addappid(2161300, 0, "934f627a5916fd194b190966defdf621730528ef01812e55ec0b0b4dbfa9c33d")
