-- Lua provided by SkyAPI 
-- Game: Moonstone Island
addappid(1658150)
addappid(1658151, 1, "a0087e864bcd67b31d88085e60a8b344db7098cbe6d6730e9b6ebf40cb025e3f")
addappid(2577920, 0, "19d1545edc1525760b1ab0a4b3e8ddc86ecee76712b30fef6235cd3fbb7f8af5")
addappid(2581340, 0, "4b9863518cd49b73ec6241ef7d465e9d1bb1d9f3d8505e3ed778a407ec5bbd23")
