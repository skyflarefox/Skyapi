-- Lua provided by SkyAPI 
-- Game: Memento Mori
addappid(2974290)
addappid(2974291, 1, "4a547bbfdee33698a14c535a811daf0f901a1397a8f2ea123c5c98c4033f1663")
