-- Lua provided by SkyAPI 
-- Game: AppID 1179560
addappid(1179560)
addappid(1179561, 1, "d6e7b45bc46e28e9d37f8255d74d04334971e3a95127d2928d7af1dbd5e1ea7c")
