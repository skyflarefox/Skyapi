-- Lua provided by SkyAPI 
-- Game: AppID 765810
addappid(765810)
addappid(765811, 1, "bb4e7dfff5f3dd3c28780b58a5ad405ec3718089674b9540cd6a8020511ca92b")
addappid(765812, 1, "b33a879f38bb057eafe8eb554b9a924f5c2309ed442754c1318e35b1d6dcd015")
