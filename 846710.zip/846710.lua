-- Lua provided by SkyAPI 
-- Game: AppID 846710
addappid(846710)
addappid(846711, 1, "2c1b43454092a764ad63db7c66aa4d005ffee3e880fed95d2c8252c7d20c2bcf")
