-- Lua provided by SkyAPI 
-- Game: AppID 463510
addappid(463510)
addappid(463511, 1, "f09e07b5616b15d4686b89811bfe2a733d1b215092827edd37b976df77c5829f")
