-- Lua provided by SkyAPI 
-- Game: AppID 497100
addappid(497100)
addappid(497101, 1, "d8c58b751eaf552c87b35b9644ae68fde4c21d08b08275afdd44d271690f74fe")
