-- Lua provided by SkyAPI 
-- Game: AppID 1704070
addappid(1704070)
addappid(1704071, 1, "d286a0f10803f698747e1932cb792af65e7b2308db8ecb92cb809ba71754b6ec")
