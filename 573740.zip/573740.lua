-- Lua provided by SkyAPI 
-- Game: Northern Tale 4
addappid(573740)
addappid(573741, 1, "f346c6b2a488c0097222d7d03fd9e3675d977ed66a3c1d49536c35df67a5e2b5")
addappid(573742, 1, "b75cb5c2047cd544360dc6b5067fa8b2a1538ba3bfe7bb2e23a5eab3fab1931f")
