-- Lua provided by SkyAPI 
-- Game: VITAL
addappid(1155620)
addappid(1155621, 1, "534d3c41b23990f7e7f74fc97a6b92ef60b4d9b4b0b76c4a4e71f9b3b244569f")
