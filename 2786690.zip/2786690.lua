-- Lua provided by SkyAPI 
-- Game: AppID 2786690
addappid(2786690)
addappid(2786691, 1, "6f8de80f706ca18a05b608de852609b764e8fa77580717415cd2d22179338da5")
