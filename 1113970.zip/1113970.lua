-- Lua provided by SkyAPI 
-- Game: AppID 1113970
addappid(1113970)
addappid(1113971, 1, "e4edaed8759e1a705c580da8221e32c962e003e94f40432286131c93cf65e3d2")
