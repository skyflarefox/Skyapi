-- Lua provided by SkyAPI 
-- Game: AppID 1978250
addappid(1978250)
addappid(1978251, 1, "60783f3c2693ca809f9ae59ed318fbfc2c7b4017127b10be904e157f17080ab6")
