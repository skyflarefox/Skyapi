-- Lua provided by SkyAPI 
-- Game: Daemon Detective Gaiden
addappid(377200)
addappid(377201, 1, "180aa3390e913770ec3401c85437afe018b507fdbcfed3e2c437ae8b0bae832f")
