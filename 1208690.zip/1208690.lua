-- Lua provided by SkyAPI 
-- Game: Ailuri
addappid(1208690)
addappid(1208691, 1, "a7f09410732c190ad97b6addc7d3a1bd97c57a073a5a6a288eef91a6f3fd5101")
