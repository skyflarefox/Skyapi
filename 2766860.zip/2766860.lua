-- Lua provided by SkyAPI 
-- Game: MY DESTINY GIRLS
addappid(2766860)
addappid(2766861, 1, "049a8c23198e05bdb105aa8d39cee47477fc19be40d5e42018652d6f70b20642")
