-- Lua provided by SkyAPI 
-- Game: AppID 432760
addappid(432760)
addappid(432761, 1, "8f931418f0dedd686bd87a6a380fb6c24ba6e0ba47a0312bf90cca878af28db3")
addappid(432762, 1, "534fafd5b9a237e1c91397d0331d6afe867d5e720ef2506a603b29ec65190b3f")
addappid(432763, 1, "b8cd04d0f1f34a26ffdb7b9210f2683487338af9acd0181ba9606adf45a5dcaf")
