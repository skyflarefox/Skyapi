-- Lua provided by SkyAPI 
-- Game: AppID 1145770
addappid(1145770)
addappid(1145771, 1, "8fe34edf0a81503a45f86a2595f9b90589a0b11e8b773eaca69962a32a202de9")
addappid(1188500)
