-- Lua provided by SkyAPI 
-- Game: Beyond Hanwell Teaser: The Royal Hallamshire
addappid(2573320)
addappid(2573321, 1, "bbb664a34546ab26eed89b99953da81d655214722e0eeaa4886d92ff83364654")
