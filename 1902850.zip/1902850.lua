-- Lua provided by SkyAPI 
-- Game: Dreams in the Witch House
addappid(1902850)
addappid(1902851, 1, "37d28a0c949df7a3c8bc65f0c0f9062402cd761b503215317f7bdb3d0d8d5432")
