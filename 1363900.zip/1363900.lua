-- Lua provided by SkyAPI 
-- Game: Farworld Pioneers
addappid(1363900)
addappid(1363901, 1, "653f6e5c720026b4c31c14cb408e83c2f59998b8505b9d67a9e5c250b486d8a0")
