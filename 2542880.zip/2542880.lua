-- Lua provided by SkyAPI 
-- Game: AppID 2542880
addappid(2542880)
addappid(2542881, 1, "fa869379e5573b05d76f4063184c7c3c56884e07d8d60f87b5a00c74902e404a")
