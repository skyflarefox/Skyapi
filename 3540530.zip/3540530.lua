-- Lua provided by SkyAPI 
-- Game: Lost Child
addappid(3540530)
addappid(3540531, 1, "847a6752f7a4a051605c3db60b20ba646c28e935d1f5cf01ef2b5b01c2e64fe9")
