-- Lua provided by SkyAPI 
-- Game: Let's Learn Shogi
addappid(1486050)
addappid(1486051, 1, "8c9b6586186c38a0e207b4b3d496504ed309d9b46f3820a1f45973b701263644")
