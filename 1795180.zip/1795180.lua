-- Lua provided by SkyAPI 
-- Game: Ice Station Z
addappid(1795180)
addappid(1795181, 1, "67ca3570e4cc9e9744a64d31eeebd974ee13adfda506bf127b308dd65a15afa8")
