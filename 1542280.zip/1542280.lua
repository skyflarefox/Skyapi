-- Lua provided by SkyAPI 
-- Game: 明星志願2
addappid(1542280)
addappid(1542281, 1, "560c7e22f81173050371d691e22eadb308d3bea43f7cd234e50665ffc85e07dd")
addappid(1856620, 0, "9758fe0604f48f09fa9b8c0ca6376c9c345e9488a55c857d5a0472ab54332d8c")
