-- Lua provided by SkyAPI 
-- Game: Oceanhorn 2: Knights of the Lost Realm
addappid(1622710)
addappid(1622711, 1, "1a209fc8033f23d611fd4b263309c3d0a5c3ab21b453d46063b0f1041f0c6ba3")
