-- Lua provided by SkyAPI 
-- Game: AppID 2022150
addappid(2022150)
addappid(2022151, 1, "e1a1bb90408612d28fe6f0af40aa5595c4941fdd0e1fc69137875491a265fb5c")
