-- Lua provided by SkyAPI 
-- Game: Quest of Wizard
addappid(1723570)
addappid(1723571, 1, "2c6325683a7f7e59eb9f32f88dfd7546d965c4e2eef61e70a30c686b78cbc32c")
