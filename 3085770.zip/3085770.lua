-- Lua provided by SkyAPI 
-- Game: Cat On My Desktop
addappid(3085770)
addappid(3085771, 1, "6278e42ea5727ecf4f4981a734c8a22d8258c6cadc469270b0ac3e8bcfe43526")
