-- Lua provided by SkyAPI 
-- Game: Time Mysteries 2: The Ancient Spectres
addappid(313650)
addappid(313651, 1, "0d46169c31d8537cc9bb397176a9cfbf0077d49ca7114604994af7d0cec228bc")
addappid(313652, 1, "ca76b0c81ec178386d6c03fb4970964422e270d13679709e425e42732ecd762c")
addappid(313653, 1, "6f1729e881241067b153ed34bd5811e3015aaf80314e4010c1426f1abdc8c056")
