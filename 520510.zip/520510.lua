-- Lua provided by SkyAPI 
-- Game: Tribocalypse VR
addappid(520510)
addappid(520511, 1, "5831eb02dc39201d2c2e4d16daa36cd5498115504c2ab30d1ed9a99aab129a61")
