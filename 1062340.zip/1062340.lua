-- Lua provided by SkyAPI 
-- Game: KATANA KAMI: A Way of the Samurai Story
addappid(1062340)
addappid(1062341, 1, "72b8a6c5b00b50902c770e3632ca098dc69d07065d36f86eadb1c275f54fda23")
addappid(1100060, 0, "9391de225393b7aabec74cd6151fe7798754c0a37342e721c72e60f92ed27f68")
addappid(1109510, 0, "9af4409ea3b4b55d47ca4bc366f32e7e6832b91d207bca13af5945a1abd472f1")
