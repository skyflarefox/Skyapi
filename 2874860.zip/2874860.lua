-- Lua provided by SkyAPI 
-- Game: The Russian Roulette Game : PR
addappid(2874860)
addappid(2874861, 1, "25d36ab96cad74a9b15e8a2b11e41b25dae55276e82bc7adc27156ddecfc206a")
