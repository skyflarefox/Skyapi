-- Lua provided by SkyAPI 
-- Game: AppID 1381980
addappid(1381980)
addappid(1381981, 1, "08a595e4f1eab1caafaee514a4e2317a9790aa310576c306d5bd992bf697aaef")
