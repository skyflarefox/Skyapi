-- Lua provided by SkyAPI 
-- Game: Our Adventurer Guild
addappid(2026000)
addappid(2026001, 1, "84cc41d4a398837fe7ba525ebdccd5e5e3a671b5165418a1a88733b1dee4322c")
addappid(3983380)
