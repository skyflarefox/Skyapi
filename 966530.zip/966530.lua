-- Lua provided by SkyAPI 
-- Game: AppID 966530
addappid(966530)
addappid(966531, 1, "abd3624908fe7b8e59334ced87f76a404579b1203a10cbf49f3fffc74f04a2c4")
