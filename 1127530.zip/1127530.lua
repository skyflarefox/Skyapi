-- Lua provided by SkyAPI 
-- Game: SKYCAT
addappid(1127530)
addappid(1127531, 1, "a40fb257c5f6ea3f76a8b94ac8c55e67da09b5730323800ee75988bae27f5567")
