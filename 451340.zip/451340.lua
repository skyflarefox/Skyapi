-- Lua provided by SkyAPI 
-- Game: Gold Mining Simulator
addappid(451340)
addappid(451341, 1, "b066f0d640f9c9fbf1bc5f75f7299e5f826fa03a7c67c1f83a2779884af57c16")
