-- Lua provided by SkyAPI 
-- Game: Escape From Lighthouse
addappid(2435750)
addappid(2435751, 1, "62a5eebf47e3b6a1cc29795e76252f45364bd292b2a4d689d3e725e7652c770c")
