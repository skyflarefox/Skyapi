-- Lua provided by SkyAPI 
-- Game: Fun Hospital
addappid(829420)
addappid(829421, 1, "b48977f7983b3d69c250073b4c1cb7b258cd33fcb91419f7461a96e976588fcb")
addappid(829422, 1, "9aad6caf3b710a4178579a1734cc8c8267418169c2935f3f4b8d98d25d4de929")
