-- Lua provided by SkyAPI 
-- Game: Ladybird Reflect
addappid(778770)
addappid(778771, 1, "75f5f0eddd4e38bb13297cc1c20a35518aaf9fc7cca225cac8f3bc1df4fe65ea")
addappid(786160)
