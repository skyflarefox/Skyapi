-- Lua provided by SkyAPI 
-- Game: Escort Simulator
addappid(1347800)
addappid(1347801, 1, "02a1679c56e228f82b69222ea9ebe231ddcf2438b918dce0443bd55b49c14baf")
