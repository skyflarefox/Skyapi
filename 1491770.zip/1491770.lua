-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1491770)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1491771,0,"9c7565df9c2c6363c7fd3236f1bdc43486cd24ee4298e212ee06f118c4691e70")
setManifestid(1491771,"2668348844062053150")