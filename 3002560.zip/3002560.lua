-- Lua provided by SkyAPI 
-- Game: Containment Initiative 2
addappid(3002560)
addappid(3002561, 1, "a97bd7c3d7b4acffe437bd63209d6472cc345cf7e6ee7ac140c62931a68b3b45")
