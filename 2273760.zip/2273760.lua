-- Lua provided by SkyAPI 
-- Game: AppID 2273760
addappid(2273760)
addappid(2273761, 1, "9eba0148408c2229c3e534518a06434f74518634ae688804fc14633e0c72e777")
