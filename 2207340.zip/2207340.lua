-- Lua provided by SkyAPI 
-- Game: AppID 2207340
addappid(2207340)
addappid(2207341, 1, "0c42c5aa0d34f87b1ca88e5fea09fb3ba987c3c8a4c0078b3e76c861f5c83583")
