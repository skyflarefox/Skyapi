-- Lua provided by SkyAPI 
-- Game: AppID 316390
addappid(316390)
addappid(316391, 1, "1a0383b08db30c30253c637f2a387b517fb804d95de8907c5e777b033f45299d")
