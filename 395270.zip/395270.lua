-- Lua provided by SkyAPI 
-- Game: AppID 395270
addappid(395270)
addappid(395271, 1, "5a02329a5a98c0d1820701fc19e139523fb635536c14ab16841583f05c0485c4")
