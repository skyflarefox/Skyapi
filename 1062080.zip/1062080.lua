-- Lua provided by SkyAPI 
-- Game: AppID 1062080
addappid(1062080)
addappid(1062081, 1, "f3a8f1f36bff32c05ee05b49636e61f61368e839b406c1146a443a5e126fc98f")
