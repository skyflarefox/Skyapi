-- Lua provided by SkyAPI 
-- Game: Hazy Mind
addappid(2380340)
addappid(2380341, 1, "2daf1c8c66986ffa8eea8ff92e99827c5079e070ba669a9715b689c812cd8890")
