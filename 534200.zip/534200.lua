-- Lua provided by SkyAPI 
-- Game: Ultimate Solid
addappid(534200)
addappid(534201, 1, "b42e44e94afbf27b856072f1703b61b0e81623c1cad5479d0b2173a890ef7255")
addappid(534202, 1, "d2209028f2007583e8e79fe98ce6208c28689ba342a4da323248a783271fdf00")
