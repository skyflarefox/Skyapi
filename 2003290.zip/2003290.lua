-- Lua provided by SkyAPI 
-- Game: Garden Galaxy Demo
addappid(2003290)
addappid(2003291, 1, "2d65fc1e85cacd2cb1e916d057c645c951183e202c2903e0ae456c1debe7e12f")
