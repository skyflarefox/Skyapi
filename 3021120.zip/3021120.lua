-- Lua provided by SkyAPI 
-- Game: Bureau of Contacts Demo
addappid(3021120)
addappid(3021121, 1, "5d7f68e46753c6d89e3152d67d9c921a690e970b120f61d2a84943451e553539")
