-- Lua provided by SkyAPI 
-- Game: AppID 521980
addappid(521980)
addappid(521981, 1, "12343bb3753e9ef434bbbe0f097b5f4ced8177c1dc5b15df6ed8d02c59637333")
