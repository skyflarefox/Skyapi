-- Lua provided by SkyAPI 
-- Game: Last Knight: Rogue Rider Edition
addappid(262210)
addappid(262211, 1, "8050f39bbec5df133b475b9f6eaa0c7c885553310d1edb3f95584e0c90b52599")
addappid(262221, 1, "1196a8c110a03ac82acf13395470ea4aaebf3f3f56f650431cc2b38041323f5e")
