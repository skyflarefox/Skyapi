-- Lua provided by SkyAPI 
-- Game: Project: Snowblind
addappid(7010)
addappid(7011, 1, "690a9ee40bd9b181359eadfd487b70b857af5c13d5ee38917cc69b6d6cd4cebb")
addappid(7012, 1, "d31fd87ceeb1c6d45ea834f7ad3b13846bf4ada7dbcdbb0b8077c88683df2150")
addappid(7013, 1, "36338c9b16f0e4f617d8f0ffd1c7109c643f89dcc4dc979329361b6c7ead697c")
