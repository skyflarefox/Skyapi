-- Lua provided by SkyAPI 
-- Game: EggGarden
addappid(3075040)
addappid(3075041, 1, "d70545615dcb7034085e68d9d1610d4a9934eedd9eaae8f2e0511d624eafa78e")
