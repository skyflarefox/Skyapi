-- Lua provided by SkyAPI 
-- Game: Zombie Demolition: Infinite Zombie Shooter
addappid(3599220)
addappid(3599221, 1, "d23b90969ae98d2f2586aa3f16f98b2e73d08ad114a7f4a341f859f8ea7d75df")
