-- Lua provided by SkyAPI 
-- Game: Kemopop!
addappid(3093590)
addappid(3093591, 1, "bb1643f6f7a3b4bd4f286d307082298064737c237f7cd8a8546dc399590f82d7")
