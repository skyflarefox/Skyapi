-- Lua provided by SkyAPI 
-- Game: Semblance
addappid(700160)
addappid(700161, 1, "820987c9112e222a193ad0411e36ea8ef6a0ad996057d4a46fe172d662e9425b")
