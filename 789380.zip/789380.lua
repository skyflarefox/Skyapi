-- Lua provided by SkyAPI 
-- Game: AppID 789380
addappid(789380)
addappid(789381, 1, "a4e302f93dcfbe6e477fa4f0db7edd9ab846d0e5df4585bbad234396986b33af")
