-- Lua provided by SkyAPI 
-- Game: Skidaddle Skidoodle
addappid(3113510)
addappid(3113511, 1, "bc161ad1c53bfb16d83e79978e4cfdd364f1cb4793c9f122157c7e8009ce82fd")
