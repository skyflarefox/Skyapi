-- Lua provided by SkyAPI 
-- Game: Divine Knockout (DKO)
addappid(1294660)
addappid(1294661, 1, "83d760dd993d2c2dbcd973dc03c2e30b5395c9a3451946d61b9e68069142d109")
