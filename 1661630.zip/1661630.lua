-- Lua provided by SkyAPI 
-- Game: KarmaZoo
addappid(1661630)
addappid(1661631, 1, "3df84994234aeeabe1560a3021763a3ecd231c6c5d53267e67a2e7282d17155c")
