-- Lua provided by SkyAPI 
-- Game: Rummy 3D Premium Playtest
addappid(1967780)
addappid(1967781, 1, "18e3591b15bb2a08c40d232faa58131555071856bef910482a52e64cd783021a")
