-- Lua provided by SkyAPI 
-- Game: AppID 1788410
addappid(1788410)
addappid(1788411, 1, "a292c31db85c676c45165f3db8852832b405ae53a92fc783c7351a175e24d63c")
