-- Lua provided by SkyAPI 
-- Game: AppID 2659950
addappid(2659950)
addappid(2659951, 1, "1d7b7809eec1c3dea2c27ab0a5d08a512b91841593dbda1e1c14c6490a805439")
