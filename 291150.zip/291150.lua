-- Lua provided by SkyAPI 
-- Game: Evolution RTS
addappid(291150)
addappid(291151, 1, "a1389316fe7deeef48b1bdc41f6446e6b3af7121874df1ad3f100f59c38d8775")
