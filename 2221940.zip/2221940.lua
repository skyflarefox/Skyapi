-- Lua provided by SkyAPI 
-- Game: The Feast
addappid(2221940)
addappid(2221941, 1, "834026ddc2a025c752a2eb0e86d2f177fcff166a6191ab1c703e3226965d4e1f")
