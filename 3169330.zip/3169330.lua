-- Lua provided by SkyAPI 
-- Game: The Exit of Nightmare
addappid(3169330)
addappid(3169331, 1, "e03083ac205170373f7c17df2a1bde065b8ed378385d3d24bbeab357a6f32d8c")
