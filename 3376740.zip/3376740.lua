-- Lua provided by SkyAPI 
-- Game: Myrmidon Demo
addappid(3376740)
addappid(3376741, 1, "ad8ae34e7e76205b403905fddc83515defae12a7e8c1ebdd7d52faf5ebc1b126")
