-- Lua provided by SkyAPI 
-- Game: Alien Maze
addappid(1631090)
addappid(1631091, 1, "c501d44b7e0cec0a4bcff457888ba76bcf2cddf752cb85cf2d09a63fef76fd21")
addappid(1641280, 0, "99d5f372fcc1708f952d48fe0d6c19c49d3749eac181222cd80457a3dfdaf2ba")
