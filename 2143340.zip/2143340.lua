-- Lua provided by SkyAPI 
-- Game: Dark Nights
addappid(2143340)
addappid(2143341, 1, "e5135766af8c4702e82a6e6f4e13c2d4bfb5eddeec93f53287a4dcdab67ec368")
