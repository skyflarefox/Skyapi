-- Lua provided by SkyAPI 
-- Game: AppID 804810
addappid(804810)
addappid(804811, 1, "9476f2612188749f9c3fe3d5055c597e000ec200652fe9912df0cfdad8d15cc2")
