-- Lua provided by SkyAPI 
-- Game: Hentai Elf
addappid(1791310)
addappid(1791311, 1, "97dd67c9a060320e6910c9855c90ddfeae49f5bc7325761b1027a439ca9c26eb")
