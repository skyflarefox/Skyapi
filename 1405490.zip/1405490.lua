-- Lua provided by SkyAPI 
-- Game: Xuan-Yuan Sword VII Demo
addappid(1405490)
addappid(1405491, 1, "137fee59833feb1de8219a39de52674c03b2264f58cd7c05713fe6fac0bba261")
