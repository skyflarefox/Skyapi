-- Lua provided by SkyAPI 
-- Game: AppID 499460
addappid(499460)
addappid(499461, 1, "a67acfca3f08bce854106051f54b148712dc23d22f93d0a55e7badda2df30a62")
