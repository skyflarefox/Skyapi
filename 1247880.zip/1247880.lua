-- Lua provided by SkyAPI 
-- Game: 听见我的心 Listen to My Heart
addappid(1247880)
addappid(1247881, 1, "be437262832092be8461a6f22360a5a82ff817b9fc11a657ec5be0e5ad9a36d8")
