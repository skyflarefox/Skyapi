-- Lua provided by SkyAPI 
-- Game: They came from another planet
addappid(1742290)
addappid(1742291, 1, "b326437c6395124dc1a159cf8c3790ac427710d18e7cd8bad4f6d224e1d8427b")
