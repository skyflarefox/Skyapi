-- Lua provided by SkyAPI 
-- Game: AppID 1232080
addappid(1232080)
addappid(1232081, 1, "0736dfc32d8d3c4eb3be29e0f0e5d0c1c00b800627e460427e21c3db1ebaf35a")
