-- Lua provided by SkyAPI 
-- Game: Souls Lore
addappid(1389510)
addappid(1389511, 1, "50e30289034e45021aaa027306a621c3f799c922d9ac9bc5028ffcf1f5fa51df")
addappid(1389512, 1, "5c63fa93ce39f1ef9a54a1a5e57e4b4cf8df3e6b4088cdf3c07bea68843b01c2")
