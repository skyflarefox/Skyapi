-- Lua provided by SkyAPI 
-- Game: Save Home
addappid(535260)
addappid(535261, 1, "3f9a528212327c26c92266391d2a446c9fc9bc29c80364aadc286244b5ed8184")
