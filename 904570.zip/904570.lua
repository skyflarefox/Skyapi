-- Lua provided by SkyAPI 
-- Game: AppID 904570
addappid(904570)
addappid(904571, 1, "1408f4def49a24d9b460c443444dc5580fa2f416044c1d1f51a452ef1c132abb")
