-- Lua provided by SkyAPI 
-- Game: AppID 860950
addappid(860950)
addappid(860951, 1, "cc1edd2b80374b31917911123d97ff8a647c5b0ad18eb9bb36b32cb9e33f9542")
