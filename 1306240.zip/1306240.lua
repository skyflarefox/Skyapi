-- Lua provided by SkyAPI 
-- Game: Freelance Trucker: Insurance Fraud Edition
addappid(1306240)
addappid(1306241, 1, "da6240322cc2e0c0f6dc7b2256a7eed1714cd6f3bf7a99276b47f98498370562")
