-- Lua provided by SkyAPI 
-- Game: Fap & Cum 💦
addappid(2229680)
addappid(2229681, 1, "b323d7056e57d8121cf740ad81155edee669b93e5f1e40b031d5ba8dafeab76f")
