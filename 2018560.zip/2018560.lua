-- Lua provided by SkyAPI 
-- Game: AppID 2018560
addappid(2018560)
addappid(2018561, 1, "557748073fa4aa6e93b7c2e36c7259ae3f5ca79b17803fd304a63e9ada8af9d8")
