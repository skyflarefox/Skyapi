-- Lua provided by SkyAPI 
-- Game: AppID 1269950
addappid(1269950)
addappid(1269951, 1, "31313d5df0a41592bf3f37e07e12f26695c1df36f66d22655aad20ed92c40e86")
