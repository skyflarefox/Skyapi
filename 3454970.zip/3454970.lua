-- Lua provided by SkyAPI 
-- Game: AFFRAID Demo
addappid(3454970)
addappid(3454971, 1, "01e6d6056f14263d36cee7b268454336222703973a5327141c1231d341ff8418")
