-- Lua provided by SkyAPI 
-- Game: Choice of Life: Wild Islands
addappid(2380320)
addappid(2380321, 1, "6baf4275eb4bae5c3183abaa536209fdd257bfc8dc2ab189e516dd96923f2e63")
addappid(3238700, 0, "d1b481f471307653168566b4cecabc2e1b7b7f99085f3cf6d9837aa2859e1dfd")
