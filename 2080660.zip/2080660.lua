-- Lua provided by SkyAPI 
-- Game: AppID 2080660
addappid(2080660)
addappid(2080661, 1, "abe54730e31f9ebf55b9097770fbd9b5e1c5310f37ec76069ac34b4872684b67")
