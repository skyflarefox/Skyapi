-- Lua provided by SkyAPI 
-- Game: Bloody Efforts
addappid(1705410)
addappid(1705411, 1, "f782154f0073d8b41480bc75bde6f45405d2b8c6634decef750beb4fbd733003")
