-- Lua provided by SkyAPI 
-- Game: Capital Simulator
addappid(1388490)
addappid(1388491, 1, "f92b6dc35ab727c8e5b41d6ec4961c4e3fa1c9f593f3565d73716b8909afa6a3")
