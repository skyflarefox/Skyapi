-- Lua provided by SkyAPI 
-- Game: MegaFactory Titan
addappid(1803550)
addappid(1803551, 1, "38c6ceefea1d6ebdb69e27c29b2e0f7399b4aa22919e878c398cd4bb12c96fa0")
