-- Lua provided by SkyAPI 
-- Game: AppID 2497200
addappid(2497200)
addappid(2497201, 1, "6a5986ecfcf8e22fefdf99598e35afdb128045a18edb0af02da379b20554c370")
