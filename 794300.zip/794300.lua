-- Lua provided by SkyAPI 
-- Game: AppID 794300
addappid(794300)
addappid(794301, 1, "52865b06f37ecd38a52e320d633562fe17b694b95ede1f7956ee5e6b7e9a0fc4")
addappid(823000)
