-- Lua provided by SkyAPI 
-- Game: Sick Way
addappid(1200430)
addappid(1200431, 1, "90d0e96ecdca3791edd63e2dfe7ff1d44ea37ee173c1d27c7b62dbe78b03860f")
