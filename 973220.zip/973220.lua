-- Lua provided by SkyAPI 
-- Game: SiNKR 2
addappid(973220)
addappid(973221, 1, "07fa046001faaacf22f395e4041b446f972a7b63006e53bb944037e2a3c212b3")
