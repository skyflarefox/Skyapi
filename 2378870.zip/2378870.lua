-- Lua provided by SkyAPI 
-- Game: CLOSED BETA TEST LWO
addappid(2378870)
addappid(2378871, 1, "2689fa70ad854f34082635f5d54b6b1d2b3a818e9bffe251c9fc25f9079445b6")
