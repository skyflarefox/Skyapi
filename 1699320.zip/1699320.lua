-- Lua provided by SkyAPI 
-- Game: AppID 1699320
addappid(1699320)
addappid(1699321, 1, "348a511fc9e4e597822facce545c8490db54b571adac20dad31e795b1826e0d7")
