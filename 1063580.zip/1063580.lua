-- Lua provided by SkyAPI 
-- Game: AppID 1063580
addappid(1063580)
addappid(1063581, 1, "08ad1e0a465543f8e67d3c90d86c35b17065cc3d671632d03d04307f1082d42f")
