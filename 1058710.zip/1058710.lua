-- Lua provided by SkyAPI 
-- Game: Monarch : Medieval Remastered
addappid(1058710)
addappid(1058711, 1, "38fbc0d3f950e52b250083320bc51463b7ac6996443c641b41152fd3bbe34a16")
