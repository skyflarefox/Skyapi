-- Lua provided by SkyAPI 
-- Game: Yuzi Lims: Puzzle
addappid(1747520)
addappid(1747521, 1, "810f176cad40b4cb5bad94e12f8865b67a7ff00635c848d1a64c0d5f7720f5d5")
