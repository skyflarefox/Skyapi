-- Lua provided by SkyAPI 
-- Game: AppID 717020
addappid(717020)
addappid(717021, 1, "e65890acdb6646428d31bbb8c96155818adaa2724e0f7df8baf9ffe975b4eea4")
