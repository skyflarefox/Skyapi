-- Lua provided by SkyAPI 
-- Game: AppID 893180
addappid(893180)
addappid(893181, 1, "fb859cb2119e43c326bcbd6cebcc8295d19dc46bda4c89b1689ebb9a5533470e")
addappid(893182, 1, "2bd7675876f35e778037e9749f8696e41f2a2d469b231ac7adae2fecb815fcc6")
