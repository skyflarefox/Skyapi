-- Lua provided by SkyAPI 
-- Game: AppID 2738410
addappid(2738410)
addappid(2738411, 1, "b20747cab7f797dfd494abf64140792dd9e2f3de872ac912d2039e65e5997c1b")
