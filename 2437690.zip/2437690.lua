-- Lua provided by SkyAPI 
-- Game: Zoo Park Story
addappid(2437690)
addappid(2437691, 1, "45c03bef6f120e1435771b010372942b14aaa78a9ab929c326b63293dfad5bb9")
