-- Lua provided by SkyAPI 
-- Game: Actual Multiple Monitors
addappid(241680)
addappid(241681, 1, "6c1c3ec9c3f3e8b9364a12a1681cccff5825478e6399fd9097a66b3a10c2cfe4")
