-- Lua provided by SkyAPI 
-- Game: Smash Up
addappid(446540)
addappid(446541, 1, "d6b28056a819512ddd8d605b8391f58cb468633c33ba808a01d66c5e73e53b76")
addappid(446542, 1, "da0b651a32cbfd585b81dbe29acd19e53ee02fe28d12b8ee03710e2df4f40a4b")
addappid(446543, 1, "558921676289f7f2daa87ffad9c5d5e16bae0bea9242ad9d05d945214e9c5989")
addappid(852580)
addappid(1232030)
