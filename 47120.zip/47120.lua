-- Lua provided by SkyAPI 
-- Game: Escape From Paradise 2
addappid(47120)
addappid(47121, 1, "c3a0212a1a022f824571264394511695757de1d9a4fbcbbaec468ea954b31d86")
