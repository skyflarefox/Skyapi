-- Lua provided by SkyAPI 
-- Game: 垃圾游戏
addappid(2369750)
addappid(2369751, 1, "fd8e36e59af082a9e2be28292ad719772c10377e68b64d737898068f6a56c875")
addappid(2608690)
