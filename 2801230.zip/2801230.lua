-- Lua provided by SkyAPI 
-- Game: GRR BOO I
addappid(2801230)
addappid(2801231, 1, "76e5fabcf80b486da0f68ef8554cd10d4f042ca2ccb42a4a7741074bc82a436c")
