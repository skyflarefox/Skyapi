-- Lua provided by SkyAPI 
-- Game: Love's Sweet Garnish 2
addappid(1419480)
addappid(1419481, 1, "44236353eb5c99ccaf194171339257cba18c3ccdfe434d649089ffc7d526093c")
