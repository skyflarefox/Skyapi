-- Lua provided by SkyAPI 
-- Game: 恋爱绮谭 不存在的真相
addappid(1777430)
addappid(1777431, 1, "0b65cb208d14760f1e96a4cd242e168b1e3c18290d149e17fd2a70eeb43365d3")
addappid(2166880, 0, "cc3ba5e18e2405ae01c915ef9208e9f271a0d17e3b1635f9140222b5a7ed34ce")
