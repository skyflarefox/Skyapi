-- Lua provided by SkyAPI 
-- Game: Inner Darkness
addappid(2678060)
addappid(2678061, 1, "aeabc9d14a6606362555421f7e9ff76c888c70f09d871f3932042e5ac8a3342b")
