-- Lua provided by SkyAPI 
-- Game: Magical Town
addappid(2369320)
addappid(2369321, 1, "e4a74fb947055b22c5cc20ebe8142ce6ede45b7defa0c23ae9613734a32e4a8b")
