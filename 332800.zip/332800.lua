-- Lua provided by SkyAPI 
-- Game: Five Nights at Freddy's 2
addappid(332800)
addappid(332801, 1, "a960d08a6fb0dab3a5d24ea11305bfa5068b866ad5d7d07cb60706321c1411f9")
