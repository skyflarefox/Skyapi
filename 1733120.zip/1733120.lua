-- Lua provided by SkyAPI 
-- Game: AppID 1733120
addappid(1733120)
addappid(1733121, 1, "b489c570626aff719fcc2522790876233f2fc26a4b7d6520504446010d403330")
