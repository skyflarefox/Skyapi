-- Lua provided by SkyAPI 
-- Game: Sexena: Arena Tales
addappid(1337590)
addappid(1337591, 1, "e2ef6de8526553f8c16c6b849098573c6d97a2cf0cdc6a02cb36e60831e8d2f0")
