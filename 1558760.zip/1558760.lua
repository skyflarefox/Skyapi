-- Lua provided by SkyAPI 
-- Game: Dread: The Cold Case
addappid(1558760)
addappid(1558761, 1, "702f70211e75de2c2ac276ce27b54c4fcb418b161b466ae51e8515c82c5287a1")
