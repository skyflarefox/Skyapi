-- Lua provided by SkyAPI 
-- Game: Industry Giant 4.0
addappid(1129570)
addappid(1129571, 1, "935ab3832e28a8b5f78e186f4fe8c126614978599d03ccc079bfcb638d5c26cf")
addappid(3225390, 0, "1b0d7f0259e77baed39b0ea0bdcd7207bc9e70452ff1e34d95858a78c18dffe0")
addappid(3265360, 0, "5e0c11cbb73a2b13463f8371493e7d790c38d40aa5569cb8162e27e2ca6247c4")
