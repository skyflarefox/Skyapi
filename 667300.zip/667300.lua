-- Lua provided by SkyAPI 
-- Game: aMAZE 3D
addappid(667300)
addappid(667301, 1, "98d679bfc52aa646f4a97fece7dede666e11c6694fa18489ae88532f03f93e42")
