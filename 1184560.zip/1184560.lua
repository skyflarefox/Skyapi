-- Lua provided by SkyAPI 
-- Game: AppID 1184560
addappid(1184560)
addappid(1184561, 1, "d05af4e8581d9d020ce5cee673f2e1c0323654d78848601b0064ebf091193f44")
