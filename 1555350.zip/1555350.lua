-- Lua provided by SkyAPI 
-- Game: AppID 1555350
addappid(1555350)
addappid(1555351, 1, "dcdcc6d0231af9c8fbdf3c1b662802c99bbcba47800791c498b7957ed181431c")
