-- Lua provided by SkyAPI 
-- Game: Throne of Bone
addappid(1866630)
addappid(1866631, 1, "8d4e37a64792e7272d0464ae8d793f8702fe1c24ede24f8185060fc493e896ff")
