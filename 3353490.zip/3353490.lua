-- Lua provided by SkyAPI 
-- Game: Another Hole to Seduce a Married Woman
addappid(3353490)
addappid(3353491, 1, "448865df39ea678c0f6a3caa36c6afd3e91a671b1a06fcc468ded7e534cc26c6")
