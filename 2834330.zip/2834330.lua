-- Lua provided by SkyAPI 
-- Game: Hidden in my Paradise
addappid(2834330)
addappid(2834331, 1, "ba91f161af8a8eb6eb43d230bcb94397f16f39e3573840bc6eed663ef7409148")
