-- Lua provided by SkyAPI 
-- Game: EcoGnomix - Coloring Book
addappid(3214930)
addappid(3214931, 1, "187b76b1cc6f2cf168c4f9f99c3f230678b7541f36e387f4ecbbaa30176c7454")
