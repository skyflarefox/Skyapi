-- Lua provided by SkyAPI 
-- Game: Devoul- Curse of the Soulless
addappid(1633050)
addappid(1633051, 1, "7e8be01494f00d6f92b463a41d1e70e68abddfabd3c7e80488d29fc4eee05fa1")
