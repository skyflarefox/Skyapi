-- Lua provided by SkyAPI 
-- Game: AppID 371320
addappid(371320)
addappid(371321, 1, "039333b393f567f2c4b215a5c54af2850d8c2a8da5ce807cb0a06120461f8307")
addappid(371322, 1, "a67bfb846ed4e3f1aedb4e1799e0e7faca4aca2a0ffb1202e637727abbb4f545")
