-- Lua provided by SkyAPI 
-- Game: AppID 953740
addappid(953740)
addappid(953741, 1, "7660c34eeeef9907b0170d86c74ea51909daf0dfdbe9f33d803171ec825de408")
