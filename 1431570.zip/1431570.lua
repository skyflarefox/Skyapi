-- Lua provided by SkyAPI 
-- Game: GLASS
addappid(1431570)
addappid(1431571, 1, "5c8ec50eb57dbc188d9fcd63de6b3e27b2fb769f4d700c95158ea15a80d5d34a")
