-- Lua provided by SkyAPI 
-- Game: Xenus 2. White gold.
addappid(546230)
addappid(546231, 1, "88b1e2f4d6a87110f0a0bb85e59c5a44004036f96e703c8a390256a810a56808")
addappid(546232, 1, "d1a4c19dd01588b950a3611f03a47e4e54eac19224595ffcaf8bca7a6389f1ef")
