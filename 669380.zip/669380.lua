-- Lua provided by SkyAPI 
-- Game: AppID 669380
addappid(669380)
addappid(669381, 1, "cdfa62527bbe202a380026cc153b4e2f952d83b4684a4d0347c252536c8df9dc")
