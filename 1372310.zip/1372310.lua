-- Lua provided by SkyAPI 
-- Game: AppID 1372310
addappid(1372310)
addappid(1372311, 1, "39562659abff8610ed17edd652e30b2c09ec3cc84ee546be1c3a7d3fee2a34e6")
