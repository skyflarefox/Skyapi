-- Lua provided by SkyAPI 
-- Game: Stories of Mara
addappid(1647780)
addappid(1647781, 1, "6db9e5defb40aa0ae3b315a60f59f75a506f9a71fbd82d4674de3128ca54165b")
