-- Lua provided by SkyAPI 
-- Game: Nux
addappid(307350)
addappid(307351, 1, "ff7b9ed6861588e4f45ef03ca024e68c099835155e6768f8a067ec227c6835b5")
