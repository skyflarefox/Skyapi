-- Lua provided by SkyAPI 
-- Game: Nature Calls
addappid(857940)
addappid(857941, 1, "f4c6b9ecc44e1542a8ca82b896aafa4792591c2c7473456efaabdfb32fb0c31f")
