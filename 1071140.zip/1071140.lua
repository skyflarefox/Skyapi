-- Lua provided by SkyAPI 
-- Game: AppID 1071140
addappid(1071140)
addappid(1071141, 1, "cfca9b213522aef8efe267e309eb6060eebc45f4627489c24c7d36393a718e1c")
