-- Lua provided by SkyAPI 
-- Game: Beneath a Steel Sky (1994)
addappid(1368340)
addappid(1368341, 1, "e1c9feb5881d705ac791d3cf6bec06e6a0b4ad1e51b3091d40d0a92decc70ae0")
addappid(1368347, 1, "a272801b3cf31b22112805490442bcd7d127b14ae5cd769ca007f1a74960fa67")
addappid(1392830, 0, "078e06ae64f879e8d05b4bb6035ec6a5a4a5094676ea1350ea5166c9294298a7")
