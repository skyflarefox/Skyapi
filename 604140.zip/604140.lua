-- Lua provided by SkyAPI 
-- Game: Broccoli Bob
addappid(604140)
addappid(604141, 1, "ad71cb97995a5b0e15f99cb33089d0bc7e0d1be27e71f13f00eb360dd3f56d3a")
