-- Lua provided by SkyAPI 
-- Game: AppID 905460
addappid(905460)
addappid(905461, 1, "486be426f276f6111bca58717455c14481a7de9e8cafebf15133806e4d8d3f37")
