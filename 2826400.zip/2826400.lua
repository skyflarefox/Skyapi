-- Lua provided by SkyAPI 
-- Game: CASE RECORDS: Fear of Abduction
addappid(2826400)
addappid(2826401, 1, "e56e3248a19c365e23aa8eaa1f00e703ed57725d877c40945441f6b8d364a1a5")
