-- Lua provided by SkyAPI 
-- Game: Vstar
addappid(2774120)
addappid(2774121, 1, "ef41f2068aa77f8f85ac087d47da228239c3c11d14f65be019c2470ca54850bc")
