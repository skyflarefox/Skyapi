-- Lua provided by SkyAPI 
-- Game: AppID 3213990
addappid(3213990)
addappid(3213991, 1, "6ddb18eb0ce6e98761b559fbe95a369b10e1aa429d905dc044e8a75ff3603359")
