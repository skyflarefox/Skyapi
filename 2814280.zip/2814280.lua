-- Lua provided by SkyAPI 
-- Game: Cellfish
addappid(2814280)
addappid(2814281, 1, "a9bce63f0feea3563669a621d2d0eaf899afda9e647805313e64e1deba758dcc")
