-- Lua provided by SkyAPI 
-- Game: Champions Online
addappid(9880)
addappid(9881, 1, "63608b6440b874f871229d78b491cef33a25decf6a30494c03221e37a8e34896")
addappid(228990, 0, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
