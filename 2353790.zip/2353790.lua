-- Lua provided by SkyAPI 
-- Game: Jump Puzzle
addappid(2353790)
addappid(2353791, 1, "476782a98165bbb41c926373d8d75a4571f31a8d993c406016ba808ef46029e1")
