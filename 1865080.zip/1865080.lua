-- Lua provided by SkyAPI 
-- Game: Idol Queens Production
addappid(1865080)
addappid(1865081, 1, "44b1997b5035bb614f6fe0c1057e45d16d72c9c0c2d0fae036fd9c278413d187")
