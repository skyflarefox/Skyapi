-- Lua provided by SkyAPI 
-- Game: Fantasy Quest Prologue
addappid(2363480)
addappid(2363481, 1, "c87a712176eadff10887d0eced8a1638f9f31e04181c96ae062baa4ef39049e2")
