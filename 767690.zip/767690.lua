-- Lua provided by SkyAPI 
-- Game: AppID 767690
addappid(767690)
addappid(767691, 1, "bde0068ddcbaf8c278261fe801f2888091d100f3373f2b086bc8c913e4f708da")
