-- Lua provided by SkyAPI 
-- Game: Fakeway
addappid(2568620)
addappid(2568621, 1, "6c7b0789b69eafaae5b4ef237ab877dbda98a8ed3d45195426f4d554266d14e1")
