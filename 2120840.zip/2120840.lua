-- Lua provided by SkyAPI 
-- Game: Peasant Jump Quest Extreme AI 8K
addappid(2120840)
addappid(2120841, 1, "2c05d6a7b9fc61b2251aa6f35695d1c5798e226e4c1dea8cb7c8b63eff12396e")
