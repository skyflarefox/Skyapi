-- Lua provided by SkyAPI 
-- Game: Axiom
addappid(2176310)
addappid(2176311, 1, "d823da9d39f75700939c19cc520bfe7af9bcb72e0cb6c47fe07fdb1c528f958d")
