-- Lua provided by SkyAPI 
-- Game: Holodance
addappid(422860)
addappid(422861, 1, "14b48ace4adc356204e3847ed692d28ad319af12f31fdecda407a897f2a29f2b")
