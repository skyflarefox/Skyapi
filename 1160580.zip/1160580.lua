-- Lua provided by SkyAPI 
-- Game: Model Melissa
addappid(1160580)
addappid(1160581, 1, "68e3fcc027264cb76a9187c79fc283139e780675370295d89d54c30e78c00410")
