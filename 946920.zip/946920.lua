-- Lua provided by SkyAPI 
-- Game: PARANOID
addappid(946920)
addappid(946921, 1, "220d4617d4f0ba306a3e11ab0530a73eb40f9c53b1689e9d03cf475f94f318c8")
