-- Lua provided by SkyAPI 
-- Game: AppID 2597760
addappid(2597760)
addappid(2597761, 1, "f9c53784a3e8202200dc7c89bb488dc448f15055ae85de60fe2f02533e159f90")
