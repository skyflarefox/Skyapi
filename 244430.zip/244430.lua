-- Lua provided by SkyAPI 
-- Game: realMyst: Masterpiece Edition
addappid(244430)
addappid(244431, 1, "7c164feb0e10bd85f50736a587f2efb6f6228ffa33714917bf72664195f050cb")
addappid(244432, 1, "55dfbf90fef3343b66a7b95c88d7f39b2fcd176cc81310d79e978233e10c5e7e")
