-- Lua provided by SkyAPI 
-- Game: Superspy Steve
addappid(2300730)
addappid(2300731, 1, "de22af87c55e91c94ad4be69640a02da2b08f7103a9130f8658582631932ba93")
