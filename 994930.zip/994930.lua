-- Lua provided by SkyAPI 
-- Game: Soccer Manager 2019
addappid(994930)
addappid(994931, 1, "078e5a13418b1fce711f6930c02060c08fe22c97aa9be1cb95b70a230c05f7ef")
