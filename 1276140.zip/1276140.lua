-- Lua provided by SkyAPI 
-- Game: NuclearRifle
addappid(1276140)
addappid(1276141, 1, "9d53234dd05bac1a1b530b1051a7a4f600aebbf5b2f6e4dd62fef6c2303f7a61")
