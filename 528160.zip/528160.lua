-- Lua provided by SkyAPI 
-- Game: AppID 528160
addappid(528160)
addappid(528161, 1, "0dae17234537fba91da3c9ba144ebb731f3fb6fb1e4d7383f1de0d910ce15fd5")
