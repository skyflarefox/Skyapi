-- Lua provided by SkyAPI 
-- Game: HOT MILF VR
addappid(2677720)
addappid(2677721, 1, "f4751e13a871ad9e825ec018e5b56752fcbda478f5a7d1f4f9d9955dbbbb475f")
