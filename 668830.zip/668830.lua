-- Lua provided by SkyAPI 
-- Game: Raid On Coasts
addappid(668830)
addappid(668831, 1, "5827fabf38630441e70a3c2887ba4fdad0f8dcdc352577f53bc6bdfa2a4a7228")
addappid(668832, 1, "dc58f5c4884c4e555d69b7de39e6227edc8209a19832d1effc47fb00809f1d45")
