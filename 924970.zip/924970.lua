-- Lua provided by SkyAPI 
-- Game: AppID 924970
addappid(924970)
addappid(924971, 1, "783767a483d935235bc2a46262a58b4acc3524bdf6d52116f090fcccc0a89024")
