-- Lua provided by SkyAPI 
-- Game: Deuterium Wars
addappid(455300)
addappid(455301, 1, "2a1d9885d3b102bc72406f151f2199b9aea8e86290218def6cac6fbe433877ac")
