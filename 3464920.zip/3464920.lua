-- Lua provided by SkyAPI 
-- Game: AppID 3464920
addappid(3464920)
addappid(3464921, 1, "eddc06a60019af16c61c8c7a8ab2980d012770a68a9a7b6bb9a70f2b096922f2")
