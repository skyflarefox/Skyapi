-- Lua provided by SkyAPI 
-- Game: AppID 1610120
addappid(1610120)
addappid(1610121, 1, "71ca223dec87837f6b60056aab238a1581498efd2079e77d9798bf9321f4ca5d")
