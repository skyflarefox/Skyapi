-- Lua provided by SkyAPI 
-- Game: Touhou Blooming Soul
addappid(1970030)
addappid(1970031, 1, "9a290d6e0f330eb905b5d539cc93de2c5f8eba6017776e65a4824e89c8907072")
