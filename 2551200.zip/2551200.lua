-- Lua provided by SkyAPI 
-- Game: KILLFISH
addappid(2551200)
addappid(2551201, 1, "78577c62dc264a1deff636db54e34f1f3161f9798f7aed582277874744f4a329")
