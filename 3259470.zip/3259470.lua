-- Lua provided by SkyAPI 
-- Game: Papa's Pizzeria Deluxe
addappid(3259470)
addappid(3259471, 1, "ad754a5ef122cf73d3e716b098147852b772657134f530db751d180073d74e83")
