-- Lua provided by SkyAPI 
-- Game: Sea of Craft
addappid(990920)
addappid(990921, 1, "01a96f6c25cb5e7efdc4f8c90f5599ca8a3bc37de213a04c58acb61d3a53b38d")
