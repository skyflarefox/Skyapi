-- Lua provided by SkyAPI 
-- Game: Fantasia Sango Mysteria
addappid(1597460)
addappid(1597461, 1, "3fbb62daedf9d83e117a4b52630e8506a2ee68467c2e0f4f4c7f2cf5418f1453")
