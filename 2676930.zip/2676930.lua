-- Lua provided by SkyAPI 
-- Game: Rebel Duet
addappid(2676930)
addappid(2676931, 1, "b9a943e9928ea24b4f5d60393a9d674f2659937160af72e8c7339dc11f8bce85")
