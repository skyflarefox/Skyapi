-- Lua provided by SkyAPI 
-- Game: AppID 3173880
addappid(3173880)
addappid(3173881, 1, "0e5a3cfd3d9efbd54b4164291b1d460d41775ce166b64b27ee0f73e684251add")
