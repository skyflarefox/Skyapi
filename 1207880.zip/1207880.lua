-- Lua provided by SkyAPI 
-- Game: Nasty Rogue
addappid(1207880)
addappid(1207881, 1, "356ea029af090481e2d71acdb0904ede3787cb34b9924df237fc545e72810f79")
