-- Lua provided by SkyAPI 
-- Game: Evil Shogun
addappid(1505830)
addappid(1505831, 1, "78e7472501d7a53056fd814084d78b9bdad4de43f4df002b76b7752eb8d604c2")
