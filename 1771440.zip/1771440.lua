-- Lua provided by SkyAPI 
-- Game: Bomb Club Deluxe
addappid(1771440)
addappid(1771441, 1, "8b9925e49641963e88c851e566a207739b2663107f8bda92b451345ffaa5ebf9")
