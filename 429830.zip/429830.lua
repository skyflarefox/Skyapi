-- Lua provided by SkyAPI 
-- Game: Unseen Diplomacy
addappid(429830)
addappid(429831, 1, "cf62e4bde840b03566d39dc0d05aaaf881f2ef7ab65b9b292cd6639ff70dd176")
