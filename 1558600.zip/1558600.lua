-- Lua provided by SkyAPI 
-- Game: AppID 1558600
addappid(1558600)
addappid(1558601, 1, "f20fe5e89ded95929382d336803e000e6bdc28ab4b8eddb220bd3349618b0a9b")
