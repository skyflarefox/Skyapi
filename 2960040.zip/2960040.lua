-- Lua provided by SkyAPI 
-- Game: AppID 2960040
addappid(2960040)
addappid(2960041, 1, "bdb98dbd1a34b69d8da2c36a9c5dd2554f25e60b158fda14f2a8bb8b14b755a8")
