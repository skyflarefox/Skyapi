-- Lua provided by SkyAPI 
-- Game: AppID 311700
addappid(311700)
addappid(311701, 1, "1d49ad425da5645446805a607f4ec34efa0f369309611feed439e50832ec1ae8")
addappid(311702, 1, "0c0b7bc90ebd492b4bfef72d9973fe28f20e119493812ea7f3005a77088d1865")
