-- Lua provided by SkyAPI 
-- Game: AppID 2082270
addappid(2082270)
addappid(2082271, 1, "bd6cf37cad5ec2f580323ed01bc2e352f1670445ed1d8d2c12d145fc94735f3d")
