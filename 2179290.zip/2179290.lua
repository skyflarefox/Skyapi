-- Lua provided by SkyAPI 
-- Game: HerrAnwalt: Lawyers Legacy
addappid(2179290)
addappid(2179291, 1, "e27b2a99992f3991e10dae9ca31102dcb1c29aba1609739cfcb81c752f57b306")
