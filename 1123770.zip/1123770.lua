-- Lua provided by SkyAPI 
-- Game: AppID 1123770
addappid(1123770)
addappid(1123771, 1, "1a98ebf1f0691fe81c354b0a0d89224f4652aa3696853b7040d5492e272bb48a")
