-- Lua provided by SkyAPI 
-- Game: Downbreak
addappid(667790)
addappid(667791, 1, "bc60d3d809e8ecd434acdab99f04a8e4a296c907ddef7e37a5d39c1509fa7ba8")
