-- Lua provided by SkyAPI 
-- Game: Jurassic World Evolution
addappid(648350)
addappid(648351, 1, "4fd37bc5e006aad39f9082a111b9e6ab7d94dd90024a7ac60f2b96d05327f8ec")
