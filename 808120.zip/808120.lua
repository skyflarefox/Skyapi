-- Lua provided by SkyAPI 
-- Game: Anark.io
addappid(808120)
addappid(808121, 1, "875b32599caa1a6d8846c504057bf16c88ccae8d2ad509385a7abf84cba48836")
