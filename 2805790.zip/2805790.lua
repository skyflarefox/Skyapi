-- Lua provided by SkyAPI 
-- Game: AppID 2805790
addappid(2805790)
addappid(2805791, 1, "d8e8d6491b67a845294c612377e0dc9c0ae4330d3f611fea256f9ec684013bf7")
