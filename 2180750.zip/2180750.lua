-- Lua provided by SkyAPI 
-- Game: Five Nights At Furry's
addappid(2180750)
addappid(2180751, 1, "745ee81ca8c8dbcd93b21aefa82adda0b9c68d1d19c195e1b9b534743f210c68")
