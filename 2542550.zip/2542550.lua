-- Lua provided by SkyAPI 
-- Game: AppID 2542550
addappid(2542550)
addappid(2542551, 1, "dfc4288d705b7a01a2b460d39631b6fa9578cbcdb732deda92b57b99fc1587f5")
