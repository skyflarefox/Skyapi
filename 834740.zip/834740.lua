-- Lua provided by SkyAPI 
-- Game: AppID 834740
addappid(834740)
addappid(834741, 1, "7bfe58a00b7c4b4a9c41e847f39cd17897aa4f65f6031833dd7392c2b7c67b35")
addappid(834742, 1, "6adb087afb8b263b873c9386219fe173640fc98619cb3ad22f2cfb9e9d81ffbf")
addappid(834743, 1, "abdc582e5feb0952e1855f2429bf4c4fd183c999f77002884e79cc8423f8c87f")
addappid(951460)
