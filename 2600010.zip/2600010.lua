-- Lua provided by SkyAPI 
-- Game: Earthless Demo
addappid(2600010)
addappid(2600011, 1, "5380f23f8a71ee62599441e0f1e686e95224baf535d54c9cec5a3f6c699c2e27")
