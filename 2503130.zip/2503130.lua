-- Lua provided by SkyAPI 
-- Game: AppID 2503130
addappid(2503130)
addappid(2503131, 1, "d4223e9e811a6f211eed1e667804f2cbaeefd7b06e0d474f37b1945993a749c0")
