-- Lua provided by SkyAPI 
-- Game: Sam & Max 101: Culture Shock
addappid(8200)
addappid(8201, 1, "1c86a587cc9065c1ff65e6c56f938f0d896730d418beaa3ac6f636d17678418d")
addappid(8202, 1, "ceea230a4c02f10ad3fa122c31e08e399ebf15e198a704198a09cc5570b26e33")
addappid(8203, 1, "ffa3ddd5de1dbb3c70e2b507d92512b82a66ca82105b7432d1fa5c452b913a8e")
addappid(8204, 1, "5ded81cd7073266422ff75615be7a953495b730ac0c4bf9780b4fe8710b7985a")
