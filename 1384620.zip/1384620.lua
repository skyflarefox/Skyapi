-- Lua provided by SkyAPI 
-- Game: Ninja Hanrei
addappid(1384620)
addappid(1384621, 1, "e16db1bd0d6ff6be8a081b9015a820855ee1151fd082227ecbf3c9df0790d3f7")
addappid(1471360)
