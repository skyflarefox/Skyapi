-- Lua provided by SkyAPI 
-- Game: SHOWTIME 2073
addappid(411080)
addappid(411081, 1, "e57e3bb8eab44b6abf242f249340115c9ff796fafb6da9c74698dfefc6599495")
addappid(411082, 1, "128977a41e988a8eeb0bf3639b60b7844ad17db002fe625e1d67e03fd2419f0b")
addappid(411083, 1, "308249aa1b76f933b2d3cf183b4d9a2d8b2fe9c6987c0cff38a7e383e568237d")
