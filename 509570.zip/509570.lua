-- Lua provided by SkyAPI 
-- Game: AppID 509570
addappid(509570)
addappid(509571, 1, "578ceaab2a4f6853acfa8d8bd18decd194386ceda36315a3f7e80cc83747ac03")
addappid(509572, 1, "21dfbab9ef68f98e20fc269dcc0db63676855ca97db62cb6e0cbdf0d4ca35afd")
addappid(509573, 1, "1011d2d8a796687d8958854efa41cf64195abd2dac044610aa40c8d1999fcb47")
addappid(509574, 1, "2c766e627409b111f90a0bede953c0eeedd95a293c6c887441ddf0774162401d")
