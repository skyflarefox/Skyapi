-- Lua provided by SkyAPI 
-- Game: AppID 1015800
addappid(1015800)
addappid(1015801, 1, "ffc94a35403d38734ad9270a96e1dcc4c9f3dfeabe67931e71949aefef4501d5")
