-- Lua provided by SkyAPI 
-- Game: A-Escape VR
addappid(538330)
addappid(538331, 1, "ce9feda21ec39a4e5900faf08c882b316600e49876f0409f80c9e74e6e6d4046")
