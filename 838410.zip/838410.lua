-- Lua provided by SkyAPI 
-- Game: AppID 838410
addappid(838410)
addappid(838411, 1, "dbdc004cf38063713442eb653ef701651ec5491c2d31db24a137e65ae9a8b2d3")
