-- Lua provided by SkyAPI 
-- Game: AppID 1081090
addappid(1081090)
addappid(1081091, 1, "dc8f9ca6142dfc56aaadb3ef82c58abf7462d82688dfa852f3995c152ccc7cbd")
