-- Lua provided by SkyAPI 
-- Game: Blood Bowl - Legendary Edition
addappid(58520)
addappid(58521, 1, "fac1efa2277d72d4501af0acbc2bfc55382d08ac2710b6294271b53f2f2f26f3")
