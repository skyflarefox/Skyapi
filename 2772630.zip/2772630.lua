-- Lua provided by SkyAPI 
-- Game: I got STICKY with a FEMBOY
addappid(2772630)
addappid(2772631, 1, "e1d4f9bfc85f2436a7e0f1b115b228e049d50dc710589d4130ca58ad1b73abff")
