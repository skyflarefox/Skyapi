-- Lua provided by SkyAPI 
-- Game: AppID 1195560
addappid(1195560)
addappid(1195561, 1, "568121e318794056b2f3d6e5dbb0eaca592c9837ddd1392c93d86db87babf6ec")
