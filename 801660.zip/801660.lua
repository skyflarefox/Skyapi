-- Lua provided by SkyAPI 
-- Game: Swapper Tiles
addappid(801660)
addappid(801661, 1, "e3d52290e46911cde4a33a4ce6ebcb865901cc9cb08c131bca8c461c673f26e4")
