-- Lua provided by SkyAPI 
-- Game: Vampires' Melody
addappid(1377360)
addappid(1377361, 1, "122b2d74b3bc9e514ca9e517200f26335af59d33bc10e8d4414a0df8e7e6c17c")
addappid(1437810, 0, "201a81323141888982660d0385473b34b4e39a93e9a98fd5dbf11edba49f4616")
