-- Lua provided by SkyAPI 
-- Game: As Dusk Falls
addappid(1341820)
addappid(1341821, 1, "b4b3c75f07674df3633110d82ab2742027941b6c10b70efa8e634ca8a6a7f751")
addappid(1763020, 0, "9c33325578043692ecefdf9da14c0da18036afc3a8e28b467f163f3c35a1934a")
