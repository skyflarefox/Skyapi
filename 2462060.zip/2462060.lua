-- Lua provided by SkyAPI 
-- Game: Graveyard Gunslingers
addappid(2462060)
addappid(2462061, 1, "e63dbdfbdf3072159788b8a50467771e5f72e8447d73185a29169f3c1c68445d")
