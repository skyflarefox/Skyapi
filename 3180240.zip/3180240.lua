-- Lua provided by SkyAPI 
-- Game: Tetris® Forever
addappid(3180240)
addappid(3180241, 1, "07212c3fa4398f303f3a308f7ff9253dc060d732095cf5725710525cd3a9dcc7")
