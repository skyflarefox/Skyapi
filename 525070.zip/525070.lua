-- Lua provided by SkyAPI 
-- Game: Captain Lycop : Invasion of the Heters
addappid(525070)
addappid(525071, 1, "30cb3e4b891a975e103e83b7ec9e3b09a5c43a72509493f4bb239a86b4056760")
addappid(525072, 1, "667873095c53371bf06be51745f39bca3ce592ed4f4f9730b0c7da30d32d32f2")
addappid(525073, 1, "a6dab56642296e15b1e178e710a0c94cbfeaa883ba709528ec2fe6eb77b8ee44")
addappid(525074, 1, "8db04d078e4f95a1ae3e2fea7b3aa859196429f607731994efabc7ef86fe4bf0")
