-- Lua provided by SkyAPI 
-- Game: Game Of Evolution - Season 1
addappid(2424660)
addappid(2424661, 1, "386554c31a0622543a8fcde1de35281f0b9875170bde5189a93b484146e23ed4")
