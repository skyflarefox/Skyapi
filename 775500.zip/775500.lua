-- Lua provided by SkyAPI 
-- Game: AppID 775500
addappid(775500)
addappid(775501, 1, "aa87f6b43f8263958e7662d3e0095761102c84d52e367598ab25b9078f8402d0")
