-- Lua provided by SkyAPI 
-- Game: AppID 2667170
addappid(2667170)
addappid(2667171, 1, "46a3d098185015dd9a35942fb411c27befe15d521960d5937af18e25ef366fc2")
