-- Lua provided by SkyAPI 
-- Game: 100 Cats Berlin
addappid(2791650)
addappid(2791651, 1, "6f5992c7a4d88956561927c1186e7d4797b397848d0c3d75c5082d112f965313")
