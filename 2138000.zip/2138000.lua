-- Lua provided by SkyAPI 
-- Game: Hoshizora no Memoria -Eternal Heart- HD
addappid(2138000)
addappid(2138001, 1, "997d595f66b1196d3e0326c199aeadee0499c2f67bf545b49a1a4a0ab1c391d4")
