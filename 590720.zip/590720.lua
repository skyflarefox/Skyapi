-- Lua provided by SkyAPI 
-- Game: AppID 590720
addappid(590720)
addappid(590721, 1, "ce130e093abca50f6b25a5e649d421db9c932d58240f082bfe0d0e30ab195589")
