-- Lua provided by SkyAPI 
-- Game: BATTLE STEED : GUNMA (배틀 스티드 : 군마)
addappid(1661020)
addappid(1661021, 1, "9954e57d257be5dcb66076682dec841cd30744b580b71294c2d018b335d52d06")
