-- Lua provided by SkyAPI 
-- Game: AppID 2568430
addappid(2568430)
addappid(2568431, 1, "3043ee735967f05399500b742177224d438205acf827a79fc47e41e84823bd6d")
