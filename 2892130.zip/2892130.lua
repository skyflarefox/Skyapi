-- Lua provided by SkyAPI 
-- Game: Rage of the Dragons NEO
addappid(2892130)
addappid(2892131, 1, "0e45dd03a01edf84554d55231a702b8fab38e3fbd9e039063de445ce3d2c916c")
