-- Lua provided by SkyAPI 
-- Game: AppID 3224000
addappid(3224000)
addappid(3224001, 1, "5d56a31996742910acef5ce4e13869ec6ebe93f5558d110b035756d759e9c086")
