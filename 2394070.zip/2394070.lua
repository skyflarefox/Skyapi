-- Lua provided by SkyAPI 
-- Game: Melody Mania
addappid(2394070)
addappid(2394071, 1, "1fdf45dcfd05ab8bb2dbe8a5a4523600137e4914eb130a034f05845fa8d2320f")
