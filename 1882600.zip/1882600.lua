-- Lua provided by SkyAPI 
-- Game: ...Knew the Beginning
addappid(1882600)
addappid(1882601, 1, "09acf5cda544a02b4a1b531b089b5d84fc0fdfa6186a2b0704e9aa493f8c3891")
