-- Lua provided by SkyAPI 
-- Game: Perish Song
addappid(1742600)
addappid(1742601, 1, "f78ae23f33e51d6464c64edc425d664cdb0acc6b1be9af10d4f5faeb1c4061f9")
