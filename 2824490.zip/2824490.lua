-- Lua provided by SkyAPI 
-- Game: He is Coming
addappid(2824490)
addappid(2824491, 1, "45177edbe7628464050348bfcda5ce52d6fbdb93077801632ef6f85821601920")
