-- Lua provided by SkyAPI 
-- Game: Pool Party
addappid(1777790)
addappid(1777791, 1, "5540f8c7acc330d058e6b82957d81a45f43a45476e9d25545aedee1561cf0d69")
