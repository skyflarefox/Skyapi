-- Lua provided by SkyAPI 
-- Game: AppID 1021000
addappid(1021000)
addappid(1021001, 1, "7a0b82be234693044e6c268d9bae8c149420b9d61a389bfc67aef13f70e3efdf")
