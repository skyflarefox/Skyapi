-- Lua provided by SkyAPI 
-- Game: 1001 TVs: Screen Mirroring
addappid(2874180)
addappid(2874181, 1, "d2d0b62e2c1831ef06eb53f7560242215b0944f373a5fd45ce18d9346961a5a1")
