-- Lua provided by SkyAPI 
-- Game: Wake
addappid(233530)
addappid(233531, 1, "6192f1530fb576356cb454c6ef67124be0fe0540ba8e4b6693b19f2713af6dc5")
