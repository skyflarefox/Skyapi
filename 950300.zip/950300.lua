-- Lua provided by SkyAPI 
-- Game: AppID 950300
addappid(950300)
addappid(950301, 1, "b38c8dbd7ee1d23e2b83ceb4a2d896084029b2c44fd80e389581f5115b0e1b05")
