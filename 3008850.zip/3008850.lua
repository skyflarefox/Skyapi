-- Lua provided by SkyAPI 
-- Game: AppID 3008850
addappid(3008850)
addappid(3008851, 1, "a703992055deb3ddf8a4ac2e13493d95e9427bcfe9f015a9da5d2219342e0052")
