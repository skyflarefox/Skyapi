-- Lua provided by SkyAPI 
-- Game: PhaRaBis
addappid(3650550)
addappid(3650551, 1, "6fa4db918f92c2bc80bec590a1a7c1e9f871f40a7a13950f67a6d486a9bd193d")
