-- Lua provided by SkyAPI 
-- Game: Partisans 1941
addappid(1227530)
addappid(1227531, 1, "e45240b32195cd1d4d03b178adb9468267ac2d874a9c0755c3b4980a3eeb9593")
addappid(1439000, 0, "44119551dd77619de388a37d0f6c8c95f21d1f0bc7e537eb123e5f64464a4cd3")
addappid(1439001, 0, "9efe86810f2eda333cc64abbb68742ff689326ea6e1e4a5d78adf4afd5ee3f2b")
