-- Lua provided by SkyAPI 
-- Game: CAT Interstellar
addappid(384740)
addappid(384741, 1, "fcdaaa96684f722e080cdccf5fab40da94da7b253e0ae3a946e2b6e829d1c044")
addappid(384742, 1, "5e70abf03da78c662c8bd877db6e57cda04e306e6642c509d162ce641bb944c2")
addappid(384743, 1, "3aba5e3d2ac30559d3bfae19e7c7daf352e56daeb41f3fc58301f578ccc3c903")
addappid(693760, 0, "ef5e0a08d2502c389417f72c174b559be5979b6291d7c230be7f3230fc477046")
