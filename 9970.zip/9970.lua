-- Lua provided by SkyAPI 
-- Game: Star Raiders
addappid(9970)
addappid(9971, 1, "7ebebcb0f4d6b750675f633da1b6662f34ee7a8bb5c0f508c0776d164a52def8")
