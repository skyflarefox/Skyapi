-- Lua provided by SkyAPI 
-- Game: Haus Of Irndrous
addappid(2914740)
addappid(2914741, 1, "c2e8fd0068dfe562f6b3da00577f8002a401834fee2ca6166ca8560dd3954187")
