-- Lua provided by SkyAPI 
-- Game: LandPort
addappid(1956110)
addappid(1956111, 1, "1ed1e5c5a23cf1c43f04c1be9bfdd6644446c6c764112f71b41478f1ee56cc80")
