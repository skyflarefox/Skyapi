-- Lua provided by SkyAPI 
-- Game: Cosmic Star Heroine
addappid(256460)
addappid(256461, 1, "9bd71ffa9ba8ba03390c268220baac42fd5486739eabcc68c55551d57cda5b52")
addappid(621210, 0, "08eb8e3ff8a6d5453625abab5c296436655a5c39586aa3f85a3b498e248b0090")
