-- Lua provided by SkyAPI 
-- Game: AppID 917550
addappid(917550)
addappid(917551, 1, "76f7bebb665c4712d49a9f29bcade577793e062bca63fce85aac7f2e2e6649d5")
