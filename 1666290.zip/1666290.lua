-- Lua provided by SkyAPI 
-- Game: Audioclash Playtest
addappid(1666290)
addappid(1666291, 1, "596e6975ff760ac934b10ad981e6df46b508029d9376d43f40f0b41094868cc1")
