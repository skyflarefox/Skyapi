-- Lua provided by SkyAPI 
-- Game: Cthulhu Saves the World
addappid(107310)
addappid(107311, 1, "3b1e91d89222dd1113c7dee9ccf23cf9f0fd702a217968c35e1bee443c729af6")
