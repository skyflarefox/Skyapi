-- Lua provided by SkyAPI 
-- Game: Ruzar - The Life Stone
addappid(366510)
addappid(366511, 1, "d116ae282347567da442a443df85ed2837549ec793f1554cb458d739149c0083")
addappid(366512, 1, "8e02a516988d68b9776a3a902107afa18435dc73fda2062dec2113624a2038db")
addappid(366513, 1, "67d5eba322bb552b9720e68a5553e09ad8e5b3a546c15ea13e8abdb68e0df9b3")
addappid(426060)
addappid(426070)
