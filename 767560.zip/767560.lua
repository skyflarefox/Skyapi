-- Lua provided by SkyAPI 
-- Game: War Robots
addappid(767560)
addappid(767561, 1, "bb79a2cf61943a54f704be20c5f046d14b12de3456b3ee9e374b384d6f69868c")
