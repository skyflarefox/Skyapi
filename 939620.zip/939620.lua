-- Lua provided by SkyAPI 
-- Game: Pleasure Puzzle:Portrait 趣拼拼：肖像画
addappid(939620)
addappid(939621, 1, "8b6fc8f2a8bb111d0457c5352cea414bafd02ecb69cf4fa0653568b9467e043e")
addappid(946820, 0, "3c63f481c93b8e9baeec5cd75dd69e995b975e9cb13e641980e93334888614ae")
