-- Lua provided by SkyAPI 
-- Game: Love Relaxation
addappid(2676010)
addappid(2676011, 1, "608fb8ef7d59fdb6418aeb453122e7a63dbc493f671052fcdf719e1000f639d9")
