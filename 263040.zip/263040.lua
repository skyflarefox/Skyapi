-- Lua provided by SkyAPI 
-- Game: Bot Colony
addappid(263040)
addappid(263041, 1, "04f0186615d3f23657ee679121e008b71fdd5c5b01c52a6886eed9b12c02f02a")
