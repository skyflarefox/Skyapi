-- Lua provided by SkyAPI 
-- Game: AppID 871850
addappid(871850)
addappid(871851, 1, "c1100c02a4ed343cc20d005721cbd1f7ff41cb9ad8597f9c38e2d4bd60f895f7")
