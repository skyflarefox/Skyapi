-- Lua provided by SkyAPI 
-- Game: My Coworker is an Idiot
addappid(2131350)
addappid(2131351, 1, "d76a684923c6f5b192fb66db174b1c77f210a7ed333f5437b7607e5d62c83031")
