-- Lua provided by SkyAPI 
-- Game: AppID 1773690
addappid(1773690)
addappid(1773691, 1, "e760020436097aec91e5ae32be9c12a63926fed706e53b1584435039e6b7336d")
