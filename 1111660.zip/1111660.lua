-- Lua provided by SkyAPI 
-- Game: C15
addappid(1111660)
addappid(1111661, 1, "8f1b3521efd255b91ae7629a169fdb4c3dc5223446f6e836c56906356f22ff78")
