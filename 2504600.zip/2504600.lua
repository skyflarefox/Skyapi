-- Lua provided by SkyAPI 
-- Game: AppID 2504600
addappid(2504600)
addappid(2504601, 1, "748a138e138f241d762920fadfcc7161080d43c424d5c0aed4a5232b366db48a")
