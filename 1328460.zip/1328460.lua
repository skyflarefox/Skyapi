-- Lua provided by SkyAPI 
-- Game: The Host
addappid(1328460)
addappid(1328461, 1, "816e8c237d15023bd89a656455e2cffbe917cdf337955a6ed3a8314ecc988426")
