-- Lua provided by SkyAPI 
-- Game: Simmiland
addappid(932850)
addappid(932851, 1, "bed960827d698c68caabe0474a4cc75e2bf339a0cd393c9ab3084465f0aaffef")
