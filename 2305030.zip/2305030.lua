-- Lua provided by SkyAPI 
-- Game: Sex Simulator - The Yacht
addappid(2305030)
addappid(2305031, 1, "b4d06a3e9fb994879bece1fd425083bcd00bb7e31f30fb0573aef16ffe1e2738")
