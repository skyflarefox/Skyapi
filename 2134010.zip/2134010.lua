-- Lua provided by SkyAPI 
-- Game: AppID 2134010
addappid(2134010)
addappid(2134011, 1, "5212873b53bbdee77894bcca5c9bb2745c14b0773ec040af217872346b242b64")
