-- Lua provided by SkyAPI 
-- Game: Magurele Mystery
addappid(1751560)
addappid(1751561, 1, "7e937fecc5612223716a940dc31cd6f16a287f3ab0b2329604a3fb52a99fc680")
