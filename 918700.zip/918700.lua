-- Lua provided by SkyAPI 
-- Game: AppID 918700
addappid(918700)
addappid(918701, 1, "1f4c1c0d19d8e4372ad69b1108ab4520208f437e795260bec1992fd743d5bde1")
