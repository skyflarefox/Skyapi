-- Lua provided by SkyAPI 
-- Game: AppID 443860
addappid(443860)
addappid(443861, 1, "956dff003c9a6712b0ef70b70d4946e12bd4d1eb1b6a86f0e345589b36d52b37")
