-- Lua provided by SkyAPI 
-- Game: Everdeep Aurora
addappid(2251400)
addappid(2251401, 1, "764d3b25a6137d9b57a29b8b0c012befe232474a74ad6789a8dba423bed4b5a5")
