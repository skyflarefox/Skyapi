-- Lua provided by SkyAPI 
-- Game: Chess Opening Repertoire Builder
addappid(2755460)
addappid(2755461, 1, "d501ad2aa6edb1ae486263fc3aeeb7973ee4c37ce35857add0faefa2e69ab2a1")
