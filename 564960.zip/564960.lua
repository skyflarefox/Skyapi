-- Lua provided by SkyAPI 
-- Game: Return to Krondor
addappid(564960)
addappid(564961, 1, "cce5053dada54d274440252f2866bb87450a7b7052240386163255f9ff7153d6")
