-- Lua provided by SkyAPI 
-- Game: Saint Maker - Horror Visual Novel
addappid(1785300)
addappid(1785301, 1, "3cdd3b05f107492d1a560f7e6e1336943071cab8d7ba02d306a47973cbf0d9f3")
