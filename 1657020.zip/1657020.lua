-- Lua provided by SkyAPI 
-- Game: Word Escape
addappid(1657020)
addappid(1657021, 1, "772ee3f53b1ed1ec81225f81015afcc114aa20bfc366df37444534a64829d949")
