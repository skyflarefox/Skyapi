-- Lua provided by SkyAPI 
-- Game: ELDR  LEGACY
addappid(825480)
addappid(825481, 1, "25e246ba354d529689ae26c1f23399c783a37a37366706ac2863a804314d0d07")
