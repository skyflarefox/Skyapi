-- Lua provided by SkyAPI 
-- Game: AppID 1199610
addappid(1199610)
addappid(1199611, 1, "f32a869af5ff86d41f64c1c7414b29f246186ed56f4608e41a2e78fc11904459")
