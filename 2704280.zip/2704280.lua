-- Lua provided by SkyAPI 
-- Game: Fractured Horizon
addappid(2704280)
addappid(2704281, 1, "428b6031d85b907aa0d11e4324940d8cd739252b992fc7d160eea580a149d306")
