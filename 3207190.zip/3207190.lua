-- Lua provided by SkyAPI 
-- Game: 摧毁模拟器 - 街头判官（Smash simulator）
addappid(3207190)
addappid(3207191, 1, "8b481b3e94017e5133f7c44dbed18e78220203e14954ecc693d326e57d50390f")
