-- Lua provided by SkyAPI 
-- Game: EarthRoyale Demo
addappid(2169240)
addappid(2169241, 1, "ee48c2e142c4e43c23f303e0f4628aa93473091b1220110924da539f211ac866")
