-- Lua provided by SkyAPI 
-- Game: Firework Simulator
addappid(2271890)
addappid(2271891, 1, "0485c146bf83fc6c4f9106970a5fd34bd909a79c8e8a63268a043b3418fcef53")
