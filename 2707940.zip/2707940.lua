-- Lua provided by SkyAPI 
-- Game: FPV Kamikaze Drone
addappid(2707940)
addappid(2707941, 1, "6660644ddd76643cb6e2fed1f8da977636b5677060ef6338cf9d2e8d3ecc0c07")
