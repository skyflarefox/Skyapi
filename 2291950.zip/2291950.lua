-- Lua provided by SkyAPI 
-- Game: Samira: Taken From Time
addappid(2291950)
addappid(2291951, 1, "4113da1d6e4e529fb168c4b78707cd1d8392087301fe2d2049fb894c775638b3")
