-- Lua provided by SkyAPI 
-- Game: AppID 654300
addappid(654300)
addappid(654301, 1, "77cdeaf227e2a8d5823e10c76103f7be20d0ab93a7811dafb87375962b5793e3")
