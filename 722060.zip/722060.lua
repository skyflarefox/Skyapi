-- Lua provided by SkyAPI 
-- Game: AppID 722060
addappid(722060)
addappid(722061, 1, "40ebac3276fadce4a824a5b1b65378300d3ccd8d0389b1a2641c9e06ba7b464b")
