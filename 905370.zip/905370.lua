-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(905370)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(905371,0,"1dabe6de9e609499c97417707d6b45f073663e8905a98f67290fd7e6da9362a4")
setManifestid(905371,"2610860857680803864")