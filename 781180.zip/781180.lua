-- Lua provided by SkyAPI 
-- Game: Technicity
addappid(781180)
addappid(781181, 1, "b0c880f01d4dda1d522028ce42ea7834124f6e31b6076c0cbdf32302d01154a8")
