-- Lua provided by SkyAPI 
-- Game: Culpa Innata
addappid(12310)
addappid(12311, 1, "0c39924f9fc6b56119b0ad4c21ad93d853c28265e9c02901fa1469f1957f44dc")
addappid(12312, 1, "d41a4bab7fc03a4c955c0f94791182d915661e3f35b0d742f7d5253627bd9030")
