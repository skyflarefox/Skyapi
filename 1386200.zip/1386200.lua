-- Lua provided by SkyAPI 
-- Game: Sex Lesson
addappid(1386200)
addappid(1386201, 1, "7a12b7bd57d0887f826269ac0ae5fec429c3607da86e017f3736cf361e4b31f0")
