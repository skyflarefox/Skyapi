-- Lua provided by SkyAPI 
-- Game: AppID 1357560
addappid(1357560)
addappid(1357561, 1, "bbc5dd4ff46560488015d56d15cffd7a75d9c6ea904f53d17d3d8068bbf43d21")
