-- Lua provided by SkyAPI 
-- Game: Prison Boss VR
addappid(673600)
addappid(673601, 1, "ba5c317d817cb0b27a9f36835adbe76e1a31a7cf8258a0bf9225cf740aba5ccf")
