-- Lua provided by SkyAPI 
-- Game: STRETCHER MEN
addappid(2884650)
addappid(2884651, 1, "dc26307acf43372560a41c67f5b684576923d6fa7a466a7ee9816eebe9e96669")
