-- Lua provided by SkyAPI 
-- Game: The Sacred Stone
addappid(432410)
addappid(432411, 1, "8513f3bde1dd801828e487ccf4236e50fb1d4f32752b2f30ed2379ef2826d848")
