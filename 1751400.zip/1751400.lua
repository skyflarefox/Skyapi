-- Lua provided by SkyAPI 
-- Game: Winter Warfare: Survival
addappid(1751400)
addappid(1751401, 1, "9289adf6f6c07a5b69d3b59d1061c7a052ee9e9bd9076c55b2625148c265ef83")
