-- Lua provided by SkyAPI 
-- Game: AppID 495760
addappid(495760)
addappid(495761, 1, "195e27b1cc936217256cbbd010f427fe426badd02b1c19dc689b97caef3c648a")
