-- Lua provided by SkyAPI 
-- Game: HOME
addappid(1067900)
addappid(1067901, 1, "375eab5c5353493cc195a10e90134b8ed785a33136949c40954335f67bf534a7")
addappid(1067902, 1, "a3b38eae3b3c30b497de65d1c196f6db043b4c37227332534b3dfeda0dff4ed9")
