-- Lua provided by SkyAPI 
-- Game: AppID 461370
addappid(461370)
addappid(461371, 1, "ae83d0018a73f3113aa12c4316ea84edc64e288fda241583acb74406231d87be")
