-- Lua provided by SkyAPI 
-- Game: Girls of The Tower - Prologue
addappid(2712660)
addappid(2712661, 1, "e99d395d8c51fd579c4e52c8c238d2993128a2dd3e6ed8dd932016a161dafb48")
