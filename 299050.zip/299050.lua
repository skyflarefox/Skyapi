-- Lua provided by SkyAPI 
-- Game: Blood II: The Chosen + Expansion
addappid(299050)
addappid(299051, 1, "955a613ec3f1ac594c38e62983096752f30bc7a0d28dd13b7885a625be8e0905")
