-- Lua provided by SkyAPI 
-- Game: Two Cubes
addappid(2511290)
addappid(2511291, 1, "f60d9f94fd18b89b4f967c66191680d6b1ef9057aa6f23c8e77dd4245e3326c7")
