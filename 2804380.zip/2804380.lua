-- Lua provided by SkyAPI 
-- Game: AppID 2804380
addappid(2804380)
addappid(2804381, 1, "3ef34037036d832c7af97e7fcaa469d49e6fdc6d236a3b77ae611ab294b0e090")
