-- Lua provided by SkyAPI 
-- Game: Machines At War 3
addappid(303860)
addappid(303861, 1, "561988f81a257150710d4db5fc29c42653202d2186590211040ca11fae0b6d5a")
addappid(303862, 1, "c51ae744190d6ca2cffeb20a5ff3c562dd66951c5e76ce469c202c8057a73867")
