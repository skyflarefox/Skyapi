-- Lua provided by SkyAPI 
-- Game: The Last Tree
addappid(605210)
addappid(605211, 1, "d293206ec87541790ff702fecda29f5f73985928ea1ec6d7d5e4fde4256be556")
addappid(646140, 0, "bf8b1d51fa4ce203b63776d38408f75fa0a15e11cd1f88f6f193784d34383b80")
