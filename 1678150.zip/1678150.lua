-- Lua provided by SkyAPI 
-- Game: World of Shooting
addappid(1678150)
addappid(1678151, 1, "51f15b6faf77a1c9d168d7d9fc6efb716bd615358ba4329276934ea4c508cff8")
addappid(1846650, 0, "14eeef30e798998e1b776473ec73dd26bf189ba35618ccc1ce7386bd67b6f989")
addappid(1847531, 0, "ce49faa259356c4b0bafe4152c3dbf30ff2fdff71f0b1cfed0883843a973a4f1")
addappid(1847532, 0, "f086f2b5adf7ed38e02a4ee1056aeea799964111153924bf00dc525274fba5ed")
