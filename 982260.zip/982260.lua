-- Lua provided by SkyAPI 
-- Game: AppID 982260
addappid(982260)
addappid(982261, 1, "f003c429c9fd431bc162434ba34c113dd1b91bca6dd500ad2ae338f1b6f72674")
