-- Lua provided by SkyAPI 
-- Game: PRiO
addappid(428410)
addappid(428411, 1, "72af0d5d562535e4db1817bea389b45c6ad7f0bfbe68bd3b8a1eedc08002738d")
