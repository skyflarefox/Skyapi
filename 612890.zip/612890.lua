-- Lua provided by SkyAPI 
-- Game: Link Twin
addappid(612890)
addappid(612891, 1, "76190cf960f22bb0e760209e160856d47ee7b0620219aa6d4d6a7c16cee43ecd")
