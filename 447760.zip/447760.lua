-- Lua provided by SkyAPI 
-- Game: AppID 447760
addappid(447760)
addappid(447761, 1, "1595a4a27377995552b03e26ffcc175823416e264e963226cb71c0a47674fbf1")
