-- Lua provided by SkyAPI 
-- Game: DUELEUM
addappid(689830)
addappid(689831, 1, "b0d7b8fd7924885ec02266da3bd55356d1ec64a3584e945ab4b3684bea7bd8ab")
