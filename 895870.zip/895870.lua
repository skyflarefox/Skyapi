-- Lua provided by SkyAPI 
-- Game: Project Wingman
addappid(895870)
addappid(895871, 1, "baec9f1a727613a15b8f270c022c13daaf28f3558205a542970c8f8cb3ee7569")
addappid(2536180, 0, "5288aed61347456ecab313d510bea0e96f2cef2694172a9bc427278a45e518b6")
