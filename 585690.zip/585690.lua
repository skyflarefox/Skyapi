-- Lua provided by SkyAPI 
-- Game: Minimalism
addappid(585690)
addappid(585691, 1, "3ce41a02b048c40521bbac8e5dbb8adfa08989fa108240512204a3f5d1748d56")
