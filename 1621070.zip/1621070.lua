-- Lua provided by SkyAPI 
-- Game: DeadPoly
addappid(1621070)
addappid(1621071, 1, "951c583576350f9dc860d4bfbb2e454318d1d09c31f9c2e57f7bbee6986407f8")
