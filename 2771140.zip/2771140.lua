-- Lua provided by SkyAPI 
-- Game: BlazBlue Entropy Effect - Soundtrack A
addappid(2771140)
addappid(2771141, 1, "4ea322c9278e847cc773c832e891c5d181c97706fe6327de5dcb50376c1be9c1")
