-- Lua provided by SkyAPI 
-- Game: Project L33T: Founders Edition
addappid(2803360)
addappid(2803361, 1, "6baf81f704f545a4cdd39adc0400334745f08d31ed765e00b6ac7a213ddcdcf6")
