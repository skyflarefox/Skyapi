-- Lua provided by SkyAPI 
-- Game: Umbraclaw
addappid(2428420)
addappid(2428421, 1, "e4d8889b4407f1f7047b22017062396bfae8465f6bd0fb1f3d64fa2d2dc4d3f9")
