-- Lua provided by SkyAPI 
-- Game: Her Feet
addappid(2267590)
addappid(2267591, 1, "0ebb934192be947bfb0a47ec549a67a11fed31c40c71738e71e78ded52cd6414")
