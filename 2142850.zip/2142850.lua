-- Lua provided by SkyAPI 
-- Game: Conjury Revell
addappid(2142850)
addappid(2142851, 1, "0cfb1246afc29ec7c090131b4342d3c12c29b14fc24c73f24211cf1ede16b58f")
