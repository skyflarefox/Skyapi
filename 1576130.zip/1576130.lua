-- Lua provided by SkyAPI 
-- Game: IdolDays
addappid(1576130)
addappid(1576131, 1, "a66f4924cf5369eff548eb10add26908f511c839bd36aa45e9c2c3cefd0c1ac6")
