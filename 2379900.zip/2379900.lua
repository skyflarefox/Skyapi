-- Lua provided by SkyAPI 
-- Game: Rooted Playtest
addappid(2379900)
addappid(2379901, 1, "86a0ae3490e1362934063cc77a96957efed11148703a4938a7f8196a6e7db119")
