-- Lua provided by SkyAPI 
-- Game: Grow Empire: Rome
addappid(3118070)
addappid(3118071, 1, "e9a2a85c3ab9fc090658a9150dc3701a8f3991b419f122582adffab494d3c6bb")
