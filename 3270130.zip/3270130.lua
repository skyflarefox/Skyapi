-- Lua provided by SkyAPI 
-- Game: Chroma Zero Demo
addappid(3270130)
addappid(3270131, 1, "4c177dca2c27a814ef8bc93fba2a348b6bde21eb640899ac934cd23cb8f343ab")
