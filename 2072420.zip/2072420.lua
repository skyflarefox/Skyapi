-- Lua provided by SkyAPI 
-- Game: Beastie Bay DX
addappid(2072420)
addappid(2072421, 1, "92a83bae26df4f7e9d68f5543b77c107460ac34b33b96cefa7a152a4c37c6f65")
