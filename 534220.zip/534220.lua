-- Lua provided by SkyAPI 
-- Game: Dragon's Sin
addappid(534220)
addappid(534221, 1, "1065ce585521ebf5bb11d7afd6ff92cfc455f0ef372e305c6e0009b321eacf66")
