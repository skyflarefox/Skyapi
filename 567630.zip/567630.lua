-- Lua provided by SkyAPI 
-- Game: AppID 567630
addappid(567630)
addappid(567631, 1, "467a0118cf9a28bd21e9c6b2974eda835512b4c9a8dd385e082d98ba9daeecce")
