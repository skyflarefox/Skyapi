-- Lua provided by SkyAPI 
-- Game: Nitro Kid
addappid(1709050)
addappid(1709051, 1, "79ad684a306bd3ac9c0946906053c835f53135bbab5257f4fb30967aa4ef1d57")
