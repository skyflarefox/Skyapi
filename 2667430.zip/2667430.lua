-- Lua provided by SkyAPI 
-- Game: Grimhook
addappid(2667430)
addappid(2667431, 1, "5ee472bfd11ead7ded06543e15b3d4f9393322bf0e3f3038ef78f26977752cb6")
