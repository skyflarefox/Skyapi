-- Lua provided by SkyAPI 
-- Game: G.O.P.O.T.A 2
addappid(2774540)
addappid(2774541, 1, "a6c04cac425ab4d9397a54a132d21729ff1ad10a80781568c62375d0752425c9")
