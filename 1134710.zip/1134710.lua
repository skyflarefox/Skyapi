-- Lua provided by SkyAPI 
-- Game: AppID 1134710
addappid(1134710)
addappid(1134711, 1, "e4c5307d44d1e6057d21c3828bc766b625266bc61281e682b3ace83b0612f7d0")
addappid(1134712, 1, "6aca6ce3dd1188b29e3251d88aeef183ffd6bfe5f89260be29c375811ba92903")
