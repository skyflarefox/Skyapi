-- Lua provided by SkyAPI 
-- Game: Glider Simulator
addappid(3384610)
addappid(3384611, 1, "e7fd5a9f979c9de4cbcd38cafc9b53d7fedf5a7d5fe83506fcf3f1c4342ebe5f")
