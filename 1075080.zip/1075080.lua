-- Lua provided by SkyAPI 
-- Game: AppID 1075080
addappid(1075080)
addappid(1075081, 1, "4d34474c7405b56f018c072394a9311146448e8c5b37285dabe051942aaafaac")
