-- Lua provided by SkyAPI 
-- Game: Chefs Together
addappid(2764690)
addappid(2764691, 1, "ee878e64cabd1cc20d8babc469f741ef743e1662beb88f951e080491da6757a9")
