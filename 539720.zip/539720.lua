-- Lua provided by SkyAPI 
-- Game: Razortron 2000
addappid(539720)
addappid(539721, 1, "288af1317836cb52acf7bfd0fecd493ec96925c4bf0201159e7e74edb1fdd475")
addappid(539722, 1, "3a3b6b5be44c89b18aa3cba5afb908a523a683894db1443965f19a56d7456469")
addappid(545170, 0, "6cee711287d4ab31228cb2da41ea01787fdd3eccb95a7da6dd461cabdb2921de")
