-- Lua provided by SkyAPI 
-- Game: Soul Cards
addappid(3408690)
addappid(3408691, 1, "c937956458a51b03aec1edb69b41dc4be80038fbe2bcfe6cbe62ea4061314cb6")
