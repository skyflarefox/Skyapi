-- Lua provided by SkyAPI 
-- Game: AppID 1878970
addappid(1878970)
addappid(1878971, 1, "d701293c84eb0a11cb898108b4457ba2ec0c9c90cee5cb2cdcd7f46e958d4078")
