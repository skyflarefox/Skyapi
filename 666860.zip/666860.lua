-- Lua provided by SkyAPI 
-- Game: Bit Heroes Quest
addappid(666860)
addappid(666861, 1, "c498c13aa88dd537af14fd6372d32ed204cf775bf48fc678b55bdad07aa1a756")
