-- Lua provided by SkyAPI 
-- Game: Welcome, Get Out!
addappid(1949290)
addappid(1949291, 1, "2434d587ae6c34c49f6d039e52c62b27a8b340da6c968bb65186dd02d1d59f56")
