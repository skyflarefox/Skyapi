-- Lua provided by SkyAPI 
-- Game: Perseus: Titan Slayer
addappid(2003050)
addappid(2003051, 1, "8f2b8deb4126a734260ce7a467645c0bca05d2c8cbc87fd207faf63687084ee1")
