-- Lua provided by SkyAPI 
-- Game: Him & Her Collection
addappid(1942390)
addappid(1942391, 1, "46836f99ac922c563d932c635a94eb8f26454c6c51275cbe0391bb3e47d392bf")
