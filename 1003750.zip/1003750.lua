-- Lua provided by SkyAPI 
-- Game: AppID 1003750
addappid(1003750)
addappid(1003751, 1, "0421db61b77345ada6944b15da5a6fb9e1325abc4fe0fec5724b22f0a9d43aea")
