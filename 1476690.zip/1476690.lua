-- Lua provided by SkyAPI 
-- Game: 15 puzzle
addappid(1476690)
addappid(1476691, 1, "3ae83c307f9ee03cef9f587f8109161f11fe3c228e439c1e5f52a3520d55b5c6")
