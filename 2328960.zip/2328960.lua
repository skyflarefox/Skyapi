-- Lua provided by SkyAPI 
-- Game: Flappy Souls
addappid(2328960)
addappid(2328961, 1, "3008f63ffdefceddab1b7c9038e1a5c550e4558037ee1ebcb64c5de826648d7b")
addappid(3228410)
