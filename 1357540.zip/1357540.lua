-- Lua provided by SkyAPI 
-- Game: Altered Destiny
addappid(1357540)
addappid(1357541, 1, "6f90b21e4a0281f28c8dac09e5b694abc1efa99413fd0cd23d5be23b9f1fbf9a")
