-- Lua provided by SkyAPI 
-- Game: Road to Vostok Demo
addappid(2141300)
addappid(2141301, 1, "1b085d6afb0ae1a8eb0064b6158944ed7d5079c401343ee8830bcef79efe195a")
