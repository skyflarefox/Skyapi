-- Lua provided by SkyAPI 
-- Game: Albacete Warrior
addappid(1605480)
addappid(1605481, 1, "a9cb654f38ee30f9d5e773aec0ed582f6df846a9610770d4ec9ee7bbc46a9e9b")
