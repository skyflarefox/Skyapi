-- Lua provided by SkyAPI 
-- Game: King Arthur: Legends Rise Playtest
addappid(2457550)
addappid(2457551, 1, "50d4f8cb17e763af1052478a8e11132cf0026fd0679c1469b1f4306d239107b1")
