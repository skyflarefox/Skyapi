-- Lua provided by SkyAPI 
-- Game: AppID 420760
addappid(420760)
addappid(420761, 1, "3e52320e921a3add7eaaea129ffca9f57d63648685c00d1fc9cac283db59f24c")
