-- Lua provided by SkyAPI 
-- Game: AppID 846790
addappid(846790)
addappid(846791, 1, "661e36418b9a5cdb06b0f00ac20c1b5acb6611b8b4e9618236669b8930ce6c4f")
