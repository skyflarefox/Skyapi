-- Lua provided by SkyAPI 
-- Game: AppID 1393790
addappid(1393790)
addappid(1393791, 1, "5a8a09600f41a03eb45fb86d7d29b10c3c603bc3a0653823c5dde9fd5b3da3d2")
