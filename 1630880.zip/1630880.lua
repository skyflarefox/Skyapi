-- Lua provided by SkyAPI 
-- Game: Sweeping the Ruins
addappid(1630880)
addappid(1630881, 1, "398dc29fb86244c37723e81a36fba2654f8f42242fb1778a96dca099b16d550b")
