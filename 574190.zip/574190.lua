-- Lua provided by SkyAPI 
-- Game: VR Snowballs
addappid(574190)
addappid(574191, 1, "8e0ea60e01d394fec8fb3c8774f36381bd2597cf127fe1165670ebd0a9346d4d")
