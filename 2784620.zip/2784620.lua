-- Lua provided by SkyAPI 
-- Game: ROGUE FLIGHT
addappid(2784620)
addappid(2784621, 1, "876d6619d7dd81c6b63a28f3d90a1f09fb0cc35f75d50b8c5e9d2c92a89fbc99")
