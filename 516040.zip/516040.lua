-- Lua provided by SkyAPI 
-- Game: AppID 516040
addappid(516040)
addappid(516041, 1, "ad4c4f8cd6e5765f39990aff22fbff48e2faf8750f3dfba24dd01b99235d7255")
