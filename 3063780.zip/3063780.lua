-- Lua provided by SkyAPI 
-- Game: Horror Simulator VR
addappid(3063780)
addappid(3063781, 1, "32c5e402bcb2daeb106b8a99a879cf63001aa7ca28a805d10edac344111a1bd8")
