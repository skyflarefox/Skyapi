-- Lua provided by SkyAPI 
-- Game: Atomic Picnic
addappid(1903560)
addappid(1903561, 1, "101090ea8a8c59cbcf29efee18361bfa5058a83a4a1a237659147e10c0d19108")
