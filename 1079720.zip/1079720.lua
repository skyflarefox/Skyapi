-- Lua provided by SkyAPI 
-- Game: AppID 1079720
addappid(1079720)
addappid(1079721, 1, "a77a6e77e5217d6e9746d75c0e7d4c8c060a79b859e1fc49e2788781f355814e")
