-- Lua provided by SkyAPI 
-- Game: Prop Hunt
addappid(1509230)
addappid(1509231, 1, "1129e55d7d0e2e4ff82133e0ada1525bafad3607f85deb67a3a9980590ade596")
