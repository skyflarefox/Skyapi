-- Lua provided by SkyAPI 
-- Game: 天下为棋 Demo
addappid(1662240)
addappid(1662241, 1, "c5d65385d66c5e8469dbb57c86bc0837b4d78bc777dcd1ec13b5c044294aa8be")
