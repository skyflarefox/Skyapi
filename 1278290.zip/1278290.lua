-- Lua provided by SkyAPI 
-- Game: xDasher
addappid(1278290)
addappid(1278291, 1, "c4a557982a0d2f10d8cd9a549d04d9cb2a0f3cb2594fc8719f0faea36118aaf6")
