-- Lua provided by SkyAPI 
-- Game: Salt Demo
addappid(327870)
addappid(327871, 1, "75cb574d42e60ab7fbbcd4635e5a2911e8520b9f6e246342866045bcac9c0c3e")
