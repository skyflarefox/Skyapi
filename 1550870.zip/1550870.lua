-- Lua provided by SkyAPI 
-- Game: The Indigo Parallel
addappid(1550870)
addappid(1550871, 1, "cb594119b55c946a3dec419f5a51dfafb23e73039000268ba0d138d76e7aae06")
