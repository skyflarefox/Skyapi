-- Lua provided by SkyAPI 
-- Game: AppID 639490
addappid(639490)
addappid(639491, 1, "831f1ba78907bc9bb0b6068d040a726fb629e564c57dc540b0bc258e040e2a00")
