-- Lua provided by SkyAPI 
-- Game: Sci-Futa
addappid(3450810)
addappid(3450811, 1, "0fecfa136c0fd0539b55b76864afcd12985d58043fcd9e0576864f5d721d93d3")
