-- Lua provided by SkyAPI 
-- Game: Boti: Byteland Overclocked - Prologue
addappid(2426410)
addappid(2426411, 1, "bed50cf82ef1454942f612c3fadedfb13d0e5853ab0746d5592b939625d0e7b5")
