-- Lua provided by SkyAPI 
-- Game: Stormgate
addappid(2012510)
addappid(2012511, 1, "50377f4e0ebc8c49d0f5f557620f904411b78fbab190a3d88e50c8cc3a346d10")
