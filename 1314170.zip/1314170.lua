-- Lua provided by SkyAPI 
-- Game: dungeon & heros
addappid(1314170)
addappid(1314171, 1, "f5021c637fdd2bdfa73f38bc2df383697c073a43fa909717aedcf50d40df0430")
