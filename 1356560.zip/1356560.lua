-- Lua provided by SkyAPI 
-- Game: AppID 1356560
addappid(1356560)
addappid(1356561, 1, "b4b58b9bbb6a1a0ee00cfeee5866b1ad94c05ac4eedeb45a96d8f4021e28b67a")
