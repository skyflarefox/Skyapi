-- Lua provided by SkyAPI 
-- Game: AppID 497360
addappid(497360)
addappid(497361, 1, "811924df5946951ab0f2d5f0be7a072fafa55b0ee6b56b84453a963f4c5db987")
