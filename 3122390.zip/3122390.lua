-- Lua provided by SkyAPI 
-- Game: AppID 3122390
addappid(3122390)
addappid(3122391, 1, "abc264fdf0c95e7be2501218392b6e6da03b1c919dfb714f346df637cd1e7045")
