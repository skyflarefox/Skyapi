-- Lua provided by SkyAPI 
-- Game: A Few Days With : Amber
addappid(3272930)
addappid(3272931, 1, "5497435ad57d66e673db7a1a652c86d0b5db54ad2071010d21805bbb7fe186b5")
