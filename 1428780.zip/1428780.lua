-- Lua provided by SkyAPI 
-- Game: Animal Rescuer
addappid(1428780)
addappid(1428781, 1, "4dd08298b0c1e9a94bd72be927f17bd9d515adfb3d137833508faf0cd5d12235")
addappid(1428782, 1, "10b945128684f76165a0256724d28c8b16f76307567154c0f953227d5f8e3f01")
