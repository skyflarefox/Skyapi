-- Lua provided by SkyAPI 
-- Game: PUSHER - Drug Tycoon
addappid(2497210)
addappid(2497211, 1, "2e37165b9d752c11dd9b503b76b626a9015fe05669e4907235d1d790d8b4c425")
