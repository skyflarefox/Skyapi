-- Lua provided by SkyAPI 
-- Game: Fruit for the Village
addappid(528930)
addappid(528931, 1, "a8943da84db0516d72da720410c81c86e95e3956f66fb801865072d7d6f69395")
