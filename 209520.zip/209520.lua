-- Lua provided by SkyAPI 
-- Game: Mini Motor Racing EVO
addappid(209520)
addappid(209521, 1, "22f2ff277eeefc500a6d7181b321656a82138baae5262ae639f9ba2e059b0308")
