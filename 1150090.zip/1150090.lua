-- Lua provided by SkyAPI 
-- Game: AppID 1150090
addappid(1150090)
addappid(1150091, 1, "665c97034c7ae21a81c9c82e352ed9ff3c7e70626ed7afe9233db0bbed1cd939")
addappid(1545770, 0, "b1ca321815b0580c756f28ee5ddf0a4386ad33c6f969d59b33b39a43b30fff83")
