-- Lua provided by SkyAPI 
-- Game: Draft of Darkness Soundtrack
addappid(2633130)
addappid(2633131, 1, "f0666b5ab05d4759b7668d85740add11c531adb182d9943bda28f9013a4ff4f2")
