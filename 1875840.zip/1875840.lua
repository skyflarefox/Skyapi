-- Lua provided by SkyAPI 
-- Game: Illusion OST
addappid(1875840)
addappid(1875841, 1, "f965ef4e5d53b287565b3a30075c8745fd64379c8457081f6ef32712c1e1c414")
