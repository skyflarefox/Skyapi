-- Lua provided by SkyAPI 
-- Game: AppID 1155810
addappid(1155810)
addappid(1155811, 1, "e841aefa0ce792b4ed4847afaf8cdee8a64b7f1393c662b8db476df6f269f256")
