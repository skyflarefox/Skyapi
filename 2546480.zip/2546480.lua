-- Lua provided by SkyAPI 
-- Game: Infinity Islets
addappid(2546480)
addappid(2546481, 1, "c715a9605d1b2f5e8593907746b8a0e81a7001f9c9dea309d2721bd7a5a030ad")
