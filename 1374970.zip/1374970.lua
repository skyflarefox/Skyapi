-- Lua provided by SkyAPI 
-- Game: Moonscars
addappid(1374970)
addappid(1374971, 1, "4ff7e99f6b071b13fc4e48f60f418040c9793a3c4f405ad2aea4d264008a48e9")
