-- Lua provided by SkyAPI 
-- Game: AppID 1060570
addappid(1060570)
addappid(1060571, 1, "b8c57faceb3f807fb7ea52026184abb5920963097bcf2e98ebc7261be45229c0")
