-- Lua provided by SkyAPI 
-- Game: ENTITY: THE BLACK DAY
addappid(2517220)
addappid(2517221, 1, "172154d86126f1a6c064d6901fd4f1a346dc8a781f9e3e35eb98973b29574d93")
