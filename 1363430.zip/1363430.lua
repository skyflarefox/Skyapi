-- Lua provided by SkyAPI 
-- Game: Propagation VR
addappid(1363430)
addappid(1363431, 1, "a60fcd8f86ea5f14805c6201b5021353343fa5e5f71f5aa206a45ca420aef1ff")
