-- Lua provided by SkyAPI 
-- Game: Forest Heroes
addappid(3001330)
addappid(3001331, 1, "8f6bb53ae79817fe5609ad0e7eefd94ad6e3844c4a4819607350f6845ba2e24a")
