-- Lua provided by SkyAPI 
-- Game: Streamer Shall Not Pass!
addappid(1191540)
addappid(1191541, 1, "6706723ab15d5e045bf6ae25a15651c004399be106f8d5e8990acc479d0c3c3c")
