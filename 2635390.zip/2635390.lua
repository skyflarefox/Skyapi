-- Lua provided by SkyAPI 
-- Game: Crazy Cursed Grandma's House
addappid(2635390)
addappid(2635391, 1, "a72f9a5a7c0b9f8fb938bfb347dda728f6ec1791f8bbac4ed21720fc78f39f3f")
