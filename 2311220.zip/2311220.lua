-- Lua provided by SkyAPI 
-- Game: Maybe tomorrow
addappid(2311220)
addappid(2311221, 1, "718530237c1b73524e5eb036d4e61960c87ea69c330f224383b112543a671622")
