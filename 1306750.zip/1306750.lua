-- Lua provided by SkyAPI 
-- Game: AppID 1306750
addappid(1306750)
addappid(1306751, 1, "2e9021ae1c27bb8103dab2083d00812ba99bf7a46308a967caf5913f9616ae01")
