-- Lua provided by SkyAPI 
-- Game: Observation
addappid(906100)
addappid(906101, 1, "eaf8fb906047cccdad5ede11c9e245c208dba0786626b04299d7890638315bbc")
