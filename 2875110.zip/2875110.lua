-- Lua provided by SkyAPI 
-- Game: Commander Quest Demo
addappid(2875110)
addappid(2875111, 1, "c444b10780747e9fd5b6b9614b0216d7f17ada50d6748a09ba41b4483bc0efe5")
