-- Lua provided by SkyAPI 
-- Game: They Come In Waves Demo
addappid(2769720)
addappid(2769721, 1, "392cfb4426fd384b619a21712ebd301e04eab7d1b4e3548db0ac24cc411e533d")
