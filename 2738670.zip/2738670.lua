-- Lua provided by SkyAPI 
-- Game: PMC Promiscuity
addappid(2738670)
addappid(2738671, 1, "1a90107a65dd2558c3929d4f7223b6aa8585a2173994c65751f6f4360c17aa9c")
