-- Lua provided by SkyAPI 
-- Game: The Stalin Subway
addappid(311140)
addappid(311141, 1, "218238660b256ed1d197e43dfc08f373ea2ce7c0b1262d507d61b8560b8866bf")
addappid(311142, 1, "c541e5e29c6c8f3be15402b7aba909483e5ae8addb05ba1ef35253029044e74a")
