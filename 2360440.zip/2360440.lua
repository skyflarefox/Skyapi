-- Lua provided by SkyAPI 
-- Game: Dreamians: Card Battle
addappid(2360440)
addappid(2360441, 1, "d882b0b0412eecc3c0df2d513a82e60a2f577095429e533f2052784b38d6d688")
