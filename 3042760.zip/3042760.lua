-- Lua provided by SkyAPI 
-- Game: Shoot to Shoot demo
addappid(3042760)
addappid(3042761, 1, "281ebd47b0bec3cc676420729d8b2344e101cba5e42d32c75e69fb82b1b7c2f8")
