-- Lua provided by SkyAPI 
-- Game: AppID 3272110
addappid(3272110)
addappid(3272111, 1, "50f934f86bb0909d4e11f77e3926fd54320d82ee2bcf80e1d602fb2eb882201f")
