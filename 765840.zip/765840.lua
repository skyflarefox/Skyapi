-- Lua provided by SkyAPI 
-- Game: AppID 765840
addappid(765840)
addappid(765841, 1, "71816ec513874f98fda7a2a4bf34f92fdb3c404d340ca2d09a933b2528789782")
