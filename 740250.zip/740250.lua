-- Lua provided by SkyAPI 
-- Game: AppID 740250
addappid(740250)
addappid(740251, 1, "da2dc28d9565bacbe71c04cd1dc416c5ee0d332300beee06b783b61fd12bc5e9")
addappid(740252, 1, "a962ac67e8403280d07ecdc66bdb161d7e0293596614a543da91593ad3a81c95")
