-- Lua provided by SkyAPI 
-- Game: AppID 3339350
addappid(3339350)
addappid(3339351, 1, "7fedf21ffcc8a694b83cb7a6233b6fd6dec60afbed54325244e81f77579b6d55")
