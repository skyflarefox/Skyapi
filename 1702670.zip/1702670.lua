-- Lua provided by SkyAPI 
-- Game: Game of Lust
addappid(1702670)
addappid(1702671, 1, "014b60600ed663f399479cb97baa555d37d817f067219513082ed8dbbe712e9d")
