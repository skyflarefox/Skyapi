-- Lua provided by SkyAPI 
-- Game: AppID 40920
addappid(40920)
addappid(40921, 1, "0435c1819b7cd6f060439de2762ae312a4abee2c74cf9b828057f84cc48be8e2")
