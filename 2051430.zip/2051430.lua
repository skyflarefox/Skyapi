-- Lua provided by SkyAPI 
-- Game: Deadlink Demo
addappid(2051430)
addappid(2051431, 1, "0cd952ff75b4b40f9d60506e06a14c686aebd9c115b3167a7cc7da8de6547f40")
