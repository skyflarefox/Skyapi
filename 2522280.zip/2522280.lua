-- Lua provided by SkyAPI 
-- Game: 心跳女友-千雅篇
addappid(2522280)
addappid(2522281, 1, "f535b00f6f4b6cadad87d857f6e8e221057afaabaedd6b17cd777290ee44fecf")
