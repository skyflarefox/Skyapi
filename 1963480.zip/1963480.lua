-- Lua provided by SkyAPI 
-- Game: Race to Kyiv
addappid(1963480)
addappid(1963481, 1, "01b1e292b66bdd3cc199f3e1125ffae8d2e3a50953d7e71f7fabf816d5d85991")
