-- Lua provided by SkyAPI 
-- Game: The Hepatica Spring
addappid(1883990)
addappid(1883991, 1, "48873068b1f0b2d5d2494d984faee1a1a23068a692c8dffe8f544aba9ea34596")
