-- Lua provided by SkyAPI 
-- Game: Transpile Girl Rescue Operation!
addappid(2613010)
addappid(2613011, 1, "22f4812197ab3a7adaacf69a70e4d858eb85a8ee72387268e57be04daaf01a4e")
