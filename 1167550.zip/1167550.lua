-- Lua provided by SkyAPI 
-- Game: VR MEDIA VIEWER
addappid(1167550)
addappid(1167551, 1, "28e5b45cd1f8fd0c03eb6d95d0daf8b517df3573801ffe9fda8af472dc786d9d")
