-- Lua provided by SkyAPI 
-- Game: Minesweeper Classy
addappid(1451720)
addappid(1451721, 1, "0ddf0f1e7857d10b5daba7ab3c4aba9e375682475eb40db37a777d4be438ddde")
