-- Lua provided by SkyAPI 
-- Game: Archaeology - Sand Fantasy
addappid(3385430)
addappid(3385431, 1, "31d5c9dc68f7c5c890895a552dfe8ff870ba19aa44822dff8243c4a5df514da2")
