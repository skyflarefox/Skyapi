-- Lua provided by SkyAPI 
-- Game: ZSGO Demo
addappid(2513920)
addappid(2513921, 1, "0e021ee3787b77d7859350c20dfdd85353bfa76f1c186ecaa195a7ac15c8d846")
