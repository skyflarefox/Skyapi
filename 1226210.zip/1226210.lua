-- Lua provided by SkyAPI 
-- Game: Fever Cabin
addappid(1226210)
addappid(1226211, 1, "91d4acd6928a946c4fe16f4657dd5d6de3c8e3f30c2eafbd818b45ec64c9903f")
