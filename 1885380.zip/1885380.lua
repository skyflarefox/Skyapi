-- Lua provided by SkyAPI 
-- Game: AppID 1885380
addappid(1885380)
addappid(1885381, 1, "6961d1b023eb36d2a260bda469b37998c5dab10d948a71815d7aac1e9ae69d51")
