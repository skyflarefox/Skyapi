-- Lua provided by SkyAPI 
-- Game: The Life and Suffering of Sir Brante
addappid(1272160)
addappid(1272161, 1, "53de837357e82a75c4841b54e2813b4c7d500f7e38eedfd41b1d53d1555275b3")
addappid(1566770, 0, "6b36c0d372f8440828dca7c6a09377cd24aea09f2b8917a9942a33857b4bb21d")
