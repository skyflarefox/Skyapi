-- Lua provided by SkyAPI 
-- Game: AppID 329830
addappid(329830)
addappid(329831, 1, "55d84d6f8867edc456fb5c4be3df83c08f1450361eeb240efe908b5039eedbd7")
