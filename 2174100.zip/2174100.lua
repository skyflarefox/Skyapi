-- Lua provided by SkyAPI 
-- Game: DRAKE Demo
addappid(2174100)
addappid(2174101, 1, "d48859ce9e673d50dfc3fe2d8177df140e9b2930a9bc1bc4b86d2dad64add572")
