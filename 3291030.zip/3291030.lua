-- Lua provided by SkyAPI 
-- Game: SLASHING NIGHT
addappid(3291030)
addappid(3291031, 1, "82fde7dc4e4be05e7569a30a0c08f2f51ba8c5fa76b438facf08f70630b16812")
