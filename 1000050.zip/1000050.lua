-- Lua provided by SkyAPI 
-- Game: AppID 1000050
addappid(1000050)
addappid(1000051, 1, "3accd906f5b479163db6b3aac72a36ac5da9646bdf01edada5baf0554a1c0b73")
