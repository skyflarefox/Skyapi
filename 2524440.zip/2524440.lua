-- Lua provided by SkyAPI 
-- Game: TEKKEN 8 - DEMO
addappid(2524440)
addappid(2524441, 1, "032fd255f852233015c9501b693c1f8e09c7faae6ee46ae642111d61f5557a40")
