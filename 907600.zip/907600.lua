-- Lua provided by SkyAPI 
-- Game: Towaga: Among Shadows
addappid(907600)
addappid(907601, 1, "d3d8301b9606d1db09a2be5c357f9abb120a44e6b232f1a3791f6c699fac67c4")
