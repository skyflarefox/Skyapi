-- Lua provided by SkyAPI 
-- Game: Spectral Scream
addappid(2620240)
addappid(2620241, 1, "ddf1b6bf9dc3109068d5264de32ea63f2f97d63b26ff6f5b6b67e80337e58174")
