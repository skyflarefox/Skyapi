-- Lua provided by SkyAPI 
-- Game: AppID 547440
addappid(547440)
addappid(547441, 1, "8edb35e155cebd75948ad2041c1d1b0cb1ef536f87d7330285c9eefcf29d3b17")
