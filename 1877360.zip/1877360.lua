-- Lua provided by SkyAPI 
-- Game: Mars Rover Simulator
addappid(1877360)
addappid(1877361, 1, "bd7f6d29f4a034b58be2f4a492a170dc1c21ed3ae4e56934286e4e542c4030b9")
