-- Lua provided by SkyAPI 
-- Game: Bouncy Butter Ball
addappid(837550)
addappid(837551, 1, "63bf7e0f8bf93f81fadd9aa20e017f5573408d7b6df983f0b91bd8b876ea213a")
