-- Lua provided by SkyAPI 
-- Game: Football Life Simulator
addappid(3158270)
addappid(3158271, 1, "ac1bf1ba8de713dc13d490e06bb72281575f7214229629432aabe5bd27fc85f2")
