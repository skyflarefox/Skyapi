-- Lua provided by SkyAPI 
-- Game: AppID 702680
addappid(702680)
addappid(702681, 1, "967acd271a5d728d1d8acfa61ae17cd333e2051f8b14abc3faa27e4ac0b6b088")
