-- Lua provided by SkyAPI 
-- Game: AppID 3745590
addappid(3745590)
addappid(3745591, 1, "599925ae10c55312b39617047b38e6c88442c7d04b2d520d0dc4aaf29df5308e")
