-- Lua provided by SkyAPI 
-- Game: AppID 887970
addappid(887970)
addappid(887971, 1, "db47d81c1894724b06cd8489fa33ace68cd492c8bb213e3ed9fc16dd88b66b50")
addappid(930753, 0, "ed5f39e2da46f7da8bd7098d6396deb6bd0758542ebd818cb18964534bee35ee")
