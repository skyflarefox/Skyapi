-- Lua provided by SkyAPI 
-- Game: AppID 214970
addappid(214970)
addappid(214971, 1, "efbb94253dd07c7252e45aea3fc5d2184488082efb3c1e71cc901a61edd701dd")
addappid(214972, 1, "268f555c73a762e86c7387ff7cd870f3b09cc62b5b320b4a058f0e15c697fd80")
