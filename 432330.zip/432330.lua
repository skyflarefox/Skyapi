-- Lua provided by SkyAPI 
-- Game: Rytmik Lite Chiptune Synthesizer
addappid(432330)
addappid(432331, 1, "ec19a066903f4ad50dd0596f819db8756dc59d1f818531387f584d77c7dfccf5")
addappid(432440, 0, "df364512a3ee7dadcd0e3f1a040f278a61450957ba52c4eee702731c23c37667")
