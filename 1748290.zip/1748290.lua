-- Lua provided by SkyAPI 
-- Game: Hardcore Cruising: A Sci-Fi Gay Sex Cruise!
addappid(1748290)
addappid(1748291, 1, "29624f834a67434a34774a577f48d99d7ce9e0ce4fdf526914af94a0db859164")
addappid(1942830)
addappid(1942831)
