-- Lua provided by SkyAPI 
-- Game: AppID 1184400
addappid(1184400)
addappid(1184401, 1, "88e7dd6a8a9ce3e1947596d857d20e040dfbc32ef84c35c0472152a26acc30c0")
