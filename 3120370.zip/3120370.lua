-- Lua provided by SkyAPI 
-- Game: Click on clocks together
addappid(3120370)
addappid(3120371, 1, "6558fc0c224fe00275c4b1f5a517164ecfdc461d3cc293727468a38d33c57400")
