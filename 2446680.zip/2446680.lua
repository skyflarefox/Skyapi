-- Lua provided by SkyAPI 
-- Game: Drive Me to Hell
addappid(2446680)
addappid(2446681, 1, "b944cface5238d50b658c633fded5839cad0cf1981fcdfe38702ca98fb8063b0")
