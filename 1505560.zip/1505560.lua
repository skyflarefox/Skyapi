-- Lua provided by SkyAPI 
-- Game: Little Lives
addappid(1505560)
addappid(1505561, 1, "5605d025af4b28d8c7e1c03599be5a31a4fd82a53cadcb1ba1baa2a58fe3c5ed")
