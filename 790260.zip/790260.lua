-- Lua provided by SkyAPI 
-- Game: AppID 790260
addappid(790260)
addappid(790261, 1, "f647fa8e5d8f0929a1fbf72ba9b9385f668a81e30ea6261436825897ffa818ba")
