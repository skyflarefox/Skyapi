-- Lua provided by SkyAPI 
-- Game: 云玩家:口口
addappid(2513090)
addappid(2513091, 1, "82318b2bcbf2b140527cf3cb98322f76768d33063c8f11e59e4eb53464eb523e")
