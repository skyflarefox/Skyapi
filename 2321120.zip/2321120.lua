-- Lua provided by SkyAPI 
-- Game: Voice Love on Air
addappid(2321120)
addappid(2321121, 1, "1d7072e2c9d2388fa7e05e5bab9ca43ec79cdc2d3270c3de29886d6fff26fc70")
