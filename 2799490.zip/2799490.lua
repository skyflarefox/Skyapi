-- Lua provided by SkyAPI 
-- Game: Project Rose
addappid(2799490)
addappid(2799491, 1, "c8e628f52b4a01848f749059397479f384b5470901b984c843812870ed1e047d")
