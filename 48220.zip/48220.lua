-- Lua provided by SkyAPI 
-- Game: AppID 48220
addappid(48220)
addappid(48221, 1, "6d9193587f64a7e023700a2ec1baf12b915e3173c7adf61ebcc77ea8feb0ba44")
addappid(48222, 1, "1bf9637de966da9d2c3384cc13cb0a4f241c994c087b42bc4c91feb309402fa0")
addappid(228982)
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
