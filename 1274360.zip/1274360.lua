-- Lua provided by SkyAPI 
-- Game: AppID 1274360
addappid(1274360)
addappid(1274361, 1, "c032b95c9244b930b7db2b104a4a634454d96cb0794cf8921bb0995da9bdcfea")
