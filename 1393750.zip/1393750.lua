-- Lua provided by SkyAPI 
-- Game: Ocean's Heart
addappid(1393750)
addappid(1393751, 1, "f698a01c1c7701d4d36bb8b36e4a667fbad6fab1a47f5276898ecc708cd6f36a")
