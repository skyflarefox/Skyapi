-- Lua provided by SkyAPI 
-- Game: 降灵 Demo
addappid(3081450)
addappid(3081451, 1, "572bf53c6ac5803201fc800f6ef7ede8bb75ae15a57a628a5d1663ebd12f75d4")
