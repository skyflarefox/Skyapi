-- Lua provided by SkyAPI 
-- Game: Super Jagger Bomb 2: Go East
addappid(3360930)
addappid(3360931, 1, "1d2e5f993d2b33e8243e204facab9dc4567e9908f72f3252c267674b60bf0344")
