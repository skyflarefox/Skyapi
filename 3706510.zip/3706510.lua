-- Lua provided by SkyAPI 
-- Game: Rise of Adou
addappid(3706510)
addappid(3706511, 1, "e62146e97196ad62af599dafe348c1c02260e7338a645927c0b60fc16fa50a03")
