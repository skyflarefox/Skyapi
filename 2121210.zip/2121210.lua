-- Lua provided by SkyAPI 
-- Game: Femboy Bangers 2
addappid(2121210)
addappid(2121211, 1, "42d1a1cc2b5474745f7d14c6710762a65b6fe3ef1d17a9d0a54dd12bc2e42e90")
