-- Lua provided by SkyAPI 
-- Game: TriggerHeart EXELICA
addappid(2685590)
addappid(2685591, 1, "9a14c975bd0c3dea7c37b8a178e51f414599fbc91c15065b22701ea3c4130093")
