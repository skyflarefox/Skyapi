-- Lua provided by SkyAPI 
-- Game: Aim Trainer X
addappid(2077170)
addappid(2077171, 1, "56d805ac401eb8b3e1f9a0eb8466803ea1824f9af86f0fd2f16ee252b6b702ae")
