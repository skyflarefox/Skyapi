-- Lua provided by SkyAPI 
-- Game: Return to Zork
addappid(585240)
addappid(585241, 1, "96d2fc95b7b266cd2b7ecff03b8211eb68676e59cf65edcf2f93526b95d68d7b")
