-- Lua provided by SkyAPI 
-- Game: Lights Off: Director's Cut
addappid(2787050)
addappid(2787051, 1, "ee09c2d1722de0b9c4fac681b02960b09a345a8abe726fdb6a62d7da08e52984")
