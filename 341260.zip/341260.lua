-- Lua provided by SkyAPI 
-- Game: Isaac the Adventurer
addappid(341260)
addappid(341261, 1, "6b3553c7783e3574083a97bec702e0208ce47d1999ed34272ceedb3dd5235de7")
addappid(341262, 1, "aef9854d24c08d4a4abb5bd3d620eec8465f07d8c7739fb66334b7f17a784b90")
