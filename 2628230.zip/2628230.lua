-- Lua provided by SkyAPI 
-- Game: Arcane Blast
addappid(2628230)
addappid(2628231, 1, "c67f344ac93372dabfb352c27eae11c79d8409b0c46156689ddff1c0c814accd")
