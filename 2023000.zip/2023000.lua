-- Lua provided by SkyAPI 
-- Game: Batsugun
addappid(2023000)
addappid(2023001, 1, "9d6fde66a154326fc97a1d9d950ff733888d0bbac740f7c2c39a0cf593aa293b")
