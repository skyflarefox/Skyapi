-- Lua provided by SkyAPI 
-- Game: 月影待蚀 / The Incomplete Lunar
addappid(1841520)
addappid(1841521, 1, "016982737a4c2d95afab09a6b939342adf93adbf718abe561a6997e3afa46446")
