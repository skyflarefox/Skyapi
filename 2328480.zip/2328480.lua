-- Lua provided by SkyAPI 
-- Game: Ascension
addappid(2328480)
addappid(2328481, 1, "09c5b59ae7b6e031e179e66a22db7336d6be2108dbd016fa23b5052619ba8f15")
