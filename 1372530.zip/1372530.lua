-- Lua provided by SkyAPI 
-- Game: Fly Corp
addappid(1372530)
addappid(1372531, 1, "ee71175e851e7655569c31bd02fd798ca6b30a59be0777ba513464d1e0828575")
addappid(1372532, 1, "cc336298fc4ffed6b7cc53c20707714dff3d2db523d70a0783a691968bd62607")
