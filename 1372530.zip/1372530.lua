-- Lua provided by SkyAPI 
-- Game: Fly Corp
addappid(1372530)
addappid(1372531, 1, "ee71175e851e7655569c31bd02fd798ca6b30a59be0777ba513464d1e0828575")
