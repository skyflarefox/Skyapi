-- Lua provided by SkyAPI 
-- Game: Flock of Dogs
addappid(812380)
addappid(812381, 1, "e2f1baa7d6adb2a12b28c39353e03da57caa2d947540e4c8e5c7bfe69dcca681")
addappid(2236640)
