-- Lua provided by SkyAPI 
-- Game: Poly Memory: Birds
addappid(1927580)
addappid(1927581, 1, "d419212d1ac94b63ba5123542e02ef2ac61109f843b1ca5f96d093f5bdbf1225")
