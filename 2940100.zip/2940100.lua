-- Lua provided by SkyAPI 
-- Game: King of Ping Pong: MEGAMIX
addappid(2940100)
addappid(2940101, 1, "5f38968f1d22d7fe807d99502d6342b77ac6df6f9b99c59754a6d24640554482")
