-- Lua provided by SkyAPI 
-- Game: F1® Manager 2024
addappid(2591280)
addappid(2591281, 1, "e371e0b7a49da6cdcd910edd1f1f9f7eaa93de33884db50e3778ec73f34800b2")
