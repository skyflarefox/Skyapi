-- Lua provided by SkyAPI 
-- Game: Beyond the Portal: Island's Salvation
addappid(2828960)
addappid(2828961, 1, "32766a7f154a6755d62620a3805d0e97e86f8f47119b17a46a1fd07bdadf29ac")
