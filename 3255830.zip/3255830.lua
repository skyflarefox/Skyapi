-- Lua provided by SkyAPI 
-- Game: Milf Selena and the Dungeon of Magic Stones
addappid(3255830)
addappid(3255831, 1, "03cefda2182dea4a98c95c90c56bcec2c2aaf373feb8030ef9a4b46147a587be")
