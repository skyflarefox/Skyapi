-- Lua provided by SkyAPI 
-- Game: 骸心 Mainbody
addappid(2189420)
addappid(2189421, 1, "8f9828aa261224eeb5675a855202a6aebaa8cab67ef77331772f288601b40563")
