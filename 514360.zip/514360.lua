-- Lua provided by SkyAPI 
-- Game: AppID 514360
addappid(514360)
addappid(514361, 1, "01064d2dec6dbd20694274f8d0c98fe66eef7d8e2cbb5d852e60360f69c37d51")
