-- Lua provided by SkyAPI 
-- Game: SALVATOR
addappid(795920)
addappid(795921, 1, "0fb7a33fa08617570be20407ecfff34b39ab95992381b4f7482b05ce0afd0721")
