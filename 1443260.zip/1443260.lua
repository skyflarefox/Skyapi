-- Lua provided by SkyAPI 
-- Game: Endless
addappid(1443260)
addappid(1443261, 1, "f1f0deb5e58d12250b02bde8187aac2cca07ab7923660fdd024ffee68b22b7dc")
