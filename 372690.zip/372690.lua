-- Lua provided by SkyAPI 
-- Game: AppID 372690
addappid(372690)
addappid(372691, 1, "61d1ef6f4c99e6cdc9603bfb89217a2fa708cf422719213660da59e035ae4a9e")
