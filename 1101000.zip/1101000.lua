-- Lua provided by SkyAPI 
-- Game: Nubla
addappid(1101000)
addappid(1101001, 1, "95613347e9d46b5d6e8aff900c2a096e4c05f2eb479b16d16a9e01b7696e8cd4")
