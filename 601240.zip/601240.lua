-- Lua provided by SkyAPI 
-- Game: AppID 601240
addappid(601240)
addappid(601241, 1, "005982f5f7b9013f5f305581be57994c8632ef212a6180fada302911f05e099d")
