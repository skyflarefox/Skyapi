-- Lua provided by SkyAPI 
-- Game: AppID 1223870
addappid(1223870)
addappid(1223871, 1, "ed678d14b3801b66a201ae3728ddf2cb007ac8108cecdb0f16b7dbf643ef773d")
addappid(1269790, 0, "a3e13d2bf785f8ff521331a42659d32b897d25557acf48190f80fa29201d8fb1")
