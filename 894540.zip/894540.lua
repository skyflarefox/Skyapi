-- Lua provided by SkyAPI 
-- Game: ShyChess
addappid(894540)
addappid(894541, 1, "8bf98832b448bb0ebdc160f48b2965da3f833450549c6405586383c26875040c")
