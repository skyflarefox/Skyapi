-- Lua provided by SkyAPI 
-- Game: Room No. 9
addappid(1354760)
addappid(1354761, 1, "ade6143b2aaa58c34f3be5c4f6927d98c389f228c83a0af3d16e730ef2324182")
