-- Lua provided by SkyAPI 
-- Game: Trash Patrol - Academic Version
addappid(1969130)
addappid(1969131, 1, "6c5ba7cd3cb1cdaf1339116b0239367dbc1754f764079c6a0b1b3476a8163e34")
