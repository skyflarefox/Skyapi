-- Lua provided by SkyAPI 
-- Game: Farmers' Market
addappid(1735640)
addappid(1735641, 1, "0c62b1e7e165ebf97467979732232585130523a3326b15a56c5b4427720bc740")
