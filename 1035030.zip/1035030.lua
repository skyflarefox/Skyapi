-- Lua provided by SkyAPI 
-- Game: Funbag Fantasy: Sideboob Story
addappid(1035030)
addappid(1035031, 1, "0134114223dfe558eca2cfd0e178c58630e1ebbd774b4ae34edda5a0d3a0d0e0")
