-- Lua provided by SkyAPI 
-- Game: 緋櫻白狐 Demo
addappid(2877520)
addappid(2877521, 1, "1f6ef577fe411b79893cf048aad5c8a16bf2fc3a1711a3bebd2b7b15b6e8d127")
