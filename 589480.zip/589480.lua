-- Lua provided by SkyAPI 
-- Game: AppID 589480
addappid(589480)
addappid(589481, 1, "2b0da5e47861bfffd53f48278885e8097990745ac42eab922ef8da4271982421")
