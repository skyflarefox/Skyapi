-- Lua provided by SkyAPI 
-- Game: AppID 3190970
addappid(3190970)
addappid(3190971, 1, "f7329bdda7d7f76bd0992cce2c2df72d5dc077082690917f064a0a491ee6569c")
