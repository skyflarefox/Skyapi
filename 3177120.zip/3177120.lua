-- Lua provided by SkyAPI 
-- Game: Fatal Midnight
addappid(3177120)
addappid(3177121, 1, "2430d46e641c4fbce08dca7865a96c7de9e0cfb40fdfeaa0478346be3e226e2f")
