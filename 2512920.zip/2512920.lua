-- Lua provided by SkyAPI 
-- Game: Garlic Builder
addappid(2512920)
addappid(2512921, 1, "9fca7e78672c35d13dd1df10071697cbe1cf8f938044bfe426d03140d0491486")
