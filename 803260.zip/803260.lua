-- Lua provided by SkyAPI 
-- Game: AppID 803260
addappid(803260)
addappid(803261, 1, "43d1f9c232657792db00574f5516df18c27c99054b58c72a094f5be8bbd498bb")
