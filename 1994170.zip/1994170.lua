-- Lua provided by SkyAPI 
-- Game: Constantine
addappid(1994170)
addappid(1994171, 1, "41d3571f7abd7b2cb89ee7edd3b7296e0987b24ead15206251a4276427cdc378")
