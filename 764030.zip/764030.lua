-- Lua provided by SkyAPI 
-- Game: Realm Revolutions
addappid(764030)
addappid(764031, 1, "946d5af4a42e0a63b2a7f4256c208b1dbc006409fb71851c55b822b49d707556")
