-- Lua provided by SkyAPI 
-- Game: Archangel
addappid(661520)
addappid(661521, 1, "16a7b2ca6b332dc324d7e8fc985f6e291f193b2786bd1c407def7ea0e56789bb")
