-- Lua provided by SkyAPI 
-- Game: Kitty Adventure
addappid(1705560)
addappid(1705561, 1, "784a0f1c46f894d0443b4fdc30d0bf0344cb822770b21eb7145fb87d0a21e221")
