-- Lua provided by SkyAPI 
-- Game: The Indie Mixtape
addappid(352640)
addappid(352641, 1, "5382d04d0db2857ac800beb4a1045e6e17a141c94eac6123493b025940005238")
