-- Lua provided by SkyAPI 
-- Game: SCP: Nemesi - Alpha Testing
addappid(2532230)
addappid(2532231, 1, "ed8840516504223867f00904e73079c0779dd9df4c463b2cba9b23c5c803105b")
