-- Lua provided by SkyAPI 
-- Game: AppID 2333030
addappid(2333030)
addappid(2333031, 1, "f204f69811b73a650407d3d375e3282f654c7f8c8a6e1014b6f32b622735597a")
