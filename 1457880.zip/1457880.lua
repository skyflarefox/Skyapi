-- Lua provided by SkyAPI 
-- Game: Genokids Demo
addappid(1457880)
addappid(1457881, 1, "206d3f637181e11ae8a969176627f8c0ab3281ab776e250ebb28b9e040ae9b61")
