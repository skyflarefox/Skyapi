-- Lua provided by SkyAPI 
-- Game: A Little Time
addappid(1628650)
addappid(1628651, 1, "42092263675628f40dd2b150c37b69b3d17af0ae5942202f33005bfb41adc839")
