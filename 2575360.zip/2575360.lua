-- Lua provided by SkyAPI 
-- Game: DOLL EYE: CHAPTER ONE
addappid(2575360)
addappid(2575361, 1, "3028a039f1c59b642f186ee789619ab0e1031f61ebb20462c1c00d31f0c9d97e")
