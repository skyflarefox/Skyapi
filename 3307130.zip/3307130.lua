-- Lua provided by SkyAPI 
-- Game: Shadows At Bay
addappid(3307130)
addappid(3307131, 1, "0761ebbb4ee3aa04d13dcbd5aba7daf3371b7c13e0dac56c2a3055d1b98cc983")
