-- Lua provided by SkyAPI 
-- Game: Lynked: Banner of the Spark
addappid(3159570)
addappid(3159571, 1, "8b67b11313f1da51f2ba40bab7831b79558154057a6270e935dfed05d85b9fef")
addappid(3269880)
