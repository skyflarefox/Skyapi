-- Lua provided by SkyAPI 
-- Game: BloodRayne (Legacy)
addappid(3810)
addappid(3811, 1, "3a818a8e22dbde320d2036c9b2155767929f631cf05719a02a449dc677445e3f")
