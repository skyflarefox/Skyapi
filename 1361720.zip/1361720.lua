-- Lua provided by SkyAPI 
-- Game: Space Fuel
addappid(1361720)
addappid(1361721, 1, "60427f62bb7b8f48295f0959a1f2cb0e7b6f73d903689143657366742e327ff3")
