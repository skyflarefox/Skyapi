-- Lua provided by SkyAPI 
-- Game: Mountain Troll
addappid(778590)
addappid(778591, 1, "d7607ebb0eb28cc873ceb4c9409534963f9d3b9a9324720c754799ce5ef9d4f5")
