-- Lua provided by SkyAPI 
-- Game: Spellbreak
addappid(1399780)
addappid(1399781, 1, "3865bdcfb996789447a5e30e98af2ec7e3bd6b878bac0921bb58f4457e9624e1")
