-- Lua provided by SkyAPI 
-- Game: Turnip Boy Commits Tax Evasion
addappid(1205450)
addappid(1205451, 1, "e86ef5924e98a210ff9a2b310845bf9e0c50952271a7ec3883e756c8b214a1e6")
