-- Lua provided by SkyAPI 
-- Game: Turnip Boy Commits Tax Evasion
addappid(1205450)
addappid(1205451, 1, "e86ef5924e98a210ff9a2b310845bf9e0c50952271a7ec3883e756c8b214a1e6")
addappid(1205452, 1, "2e1ed0491f1ef7445937fd04f0f1d77fbe7d4baf3b55e15d8c74e2a2e415d49e")
addappid(1205453, 1, "34528a540eb9a6bb12839c04b33c012f59323b52b929f3b97711284ca6be2e7f")
