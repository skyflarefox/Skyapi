-- Lua provided by SkyAPI 
-- Game: AppID 2209630
addappid(2209630)
addappid(2209631, 1, "d55d460b4e2f2e1c0e07fa6b1588f5e58b87f506ac313be50c2c28a37478548b")
