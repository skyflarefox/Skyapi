-- Lua provided by SkyAPI 
-- Game: Wall of insanity
addappid(1713720)
addappid(1713721, 1, "fa29614eb693d535d5e5c1ca757410c895c0eb5bf6b2d43a3a10653f12598c10")
