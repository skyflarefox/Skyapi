-- Lua provided by SkyAPI 
-- Game: 古巫竞技场 Ancient Witch Arena
addappid(2112200)
addappid(2112201, 1, "6cab0f6b85aa1b7c01e84144509969002559afbd1ee4a7cf417f0ccafd7d148a")
