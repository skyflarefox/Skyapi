-- Lua provided by SkyAPI 
-- Game: Atomic Heart
addappid(668580)
addappid(668581, 1, "b331448756a6614f7b9b52f56b71e329928370afb8034b8474e264ace0048928")
