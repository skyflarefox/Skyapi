-- Lua provided by SkyAPI 
-- Game: Shooter
addappid(2386670)
addappid(2386671, 1, "9b734b3ad3aec4ccddc0707b345424ac3783a1fa688dea4e42670a315b63d476")
