-- Lua provided by SkyAPI 
-- Game: Red Matter
addappid(966680)
addappid(966681, 1, "3792b2658f98c1380a4060863a60b3be1fe7e3b1462e7dc167c1c9df3ad647e7")
