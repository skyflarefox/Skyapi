-- Lua provided by SkyAPI 
-- Game: Metal Strike
addappid(3427010)
addappid(3427011, 1, "113436836eab4f450ae78147a7eb67a608874fd6e236612d27c9105ee0123a4f")
