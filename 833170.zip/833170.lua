-- Lua provided by SkyAPI 
-- Game: Burned Land
addappid(833170)
addappid(833171, 1, "2377d856aa81cc98799fe36e08a44930ea62c228be36494522656631ee2f488e")
