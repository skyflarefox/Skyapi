-- Lua provided by SkyAPI 
-- Game: Entropy
addappid(1860850)
addappid(1860851, 1, "3f643ad94e8e4d0d1639d6deb0362a1fa22a9dff3ad021e14e8b1b5569d55d93")
