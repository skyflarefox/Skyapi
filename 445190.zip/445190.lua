-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(445190)
addappid(445191,0,"682d06a2c1a5f09369743113b9daba8518c52793f48dcbe1f6a19341450bc871")
setManifestid(445191,"1136861154362798664")
addappid(592820,0,"9b7c56d46d045a76b3df540940245fcaa94aa8ff0a4cf4058b75caa9da55da0f")
setManifestid(592820,"7519957288883498924")