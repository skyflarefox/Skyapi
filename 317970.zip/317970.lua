-- Lua provided by SkyAPI 
-- Game: Dusk 12
addappid(317970)
addappid(317971, 1, "47e1371bc115bcc8b74ca1131a5dba214daae7ea2da8c66478ac42aa7f1f860a")
addappid(317972, 1, "beafe76d5f874d398a30605c5b2442dd1eb221bcce053344e0bf6db9556a729c")
