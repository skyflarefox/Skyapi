-- Lua provided by SkyAPI 
-- Game: Aquanox Deep Descent
addappid(254370)
addappid(254371, 1, "c271148d770f11cf880b81b0083e2cff0096bfbfc7c30b50bd249792cdea156f")
