-- Lua provided by SkyAPI 
-- Game: Parkour Labs
addappid(2469260)
addappid(2469261, 1, "b5453f89fd87ff2e87796abc0bf73c938f40f80a7145249537abb1ffd5b12a7a")
