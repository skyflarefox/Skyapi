-- Lua provided by SkyAPI 
-- Game: AppID 1050080
addappid(1050080)
addappid(1050081, 1, "06c90c4da897daaaebac65107e14408754fff693804eb748b014bb8ef297b6d1")
