-- Lua provided by SkyAPI 
-- Game: AppID 21680
addappid(21680)
addappid(21681, 1, "69fc6c2a65803d30cd4d521ccc4d54116ac6cb593259991cdb6d057add09a6ea")
addappid(21683, 1, "fc30304f42766023546b11a855753748f1fb0d5fe7d1f8e4dd30dfed7e16844a")
