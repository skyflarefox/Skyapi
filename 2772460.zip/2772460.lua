-- Lua provided by SkyAPI 
-- Game: The Femboy Next Door Thinks I'm Cute
addappid(2772460)
addappid(2772461, 1, "b54e4b2ad070987fcc25263fff60da241b5822835933302e4e6cdda1210cece4")
