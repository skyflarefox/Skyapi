-- Lua provided by SkyAPI 
-- Game: Mad Tracks
addappid(1202970)
addappid(1202971, 1, "90328195a93496e6601b3be0019e74d272bcd3147007038939fc9161a237cf3d")
