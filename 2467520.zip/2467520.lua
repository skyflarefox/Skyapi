-- Lua provided by SkyAPI 
-- Game: AppID 2467520
addappid(2467520)
addappid(2467521, 1, "7a75c5896192546bdd27c8f9ddf81fe24a4cf7b0b9089f0df0dd17ce16d69fef")
