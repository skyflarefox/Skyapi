-- Lua provided by SkyAPI 
-- Game: Happy Halloween
addappid(1559500)
addappid(1559501, 1, "26a208a72c4f236d40b25cca174c079fc1a9941e0a6af42dfe765aaa3f655678")
