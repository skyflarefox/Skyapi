-- Lua provided by SkyAPI 
-- Game: La Villa de la Muerte
addappid(1900530)
addappid(1900531, 1, "f8e0a87c8da59152ffc0b7ab0c1c9a9882d24b3b6ea547af3136855b86a3a356")
