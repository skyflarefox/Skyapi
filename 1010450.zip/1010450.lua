-- Lua provided by SkyAPI 
-- Game: Desire Den
addappid(1010450)
addappid(1010451, 1, "a72d97ce85ef8abdcd824f3f64ba0db9d28524be308dfa4e384192e2754da8e0")
