-- Lua provided by SkyAPI 
-- Game: Tape to Tape
addappid(1566200)
addappid(1566201, 1, "8f3f39af41a72b604a3b491bb89049d8ed52bcb81957bbb7883e802323eab406")
