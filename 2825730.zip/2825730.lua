-- Lua provided by SkyAPI 
-- Game: Nekokami: Internship - The Prologue Adventure
addappid(2825730)
addappid(2825731, 1, "5645ebc4d7e8cd8557e04ae03d57982d5bbf20b1d4666e34d7151f88a0938a85")
