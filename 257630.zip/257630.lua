-- Lua provided by SkyAPI 
-- Game: AppID 257630
addappid(257630)
addappid(257631, 1, "be44eec7b788e7f4b6a5bb2c71c3950fab28434ef9af18109ea905009ccc7a34")
addappid(272690)
