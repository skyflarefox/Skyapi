-- Lua provided by SkyAPI 
-- Game: Logica Emotica
addappid(1979700)
addappid(1979701, 1, "086d638bbbf0d8c01eea61d3a3dbf3930b79f13becc1a87383f4f603060f3a49")
