-- Lua provided by SkyAPI 
-- Game: Mazzle
addappid(3043540)
addappid(3043541, 1, "4155068577743e8384233f85dbf789457a578b7e91f6d4c3ac043a6f4a2d8e97")
