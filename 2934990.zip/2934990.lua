-- Lua provided by SkyAPI 
-- Game: Pocket Idler: Fishing Pond
addappid(2934990)
addappid(2934991, 1, "ed75b45ba7e2a7328ba78a8d42fbc6a7269becd6cb154d56d9f0f9ec5325aca0")
