-- Lua provided by SkyAPI 
-- Game: TRIZEAL Remix
addappid(465070)
addappid(465071, 1, "222abe2b63862f7f9e77dba22debcb190592069d416bb48c79ade4a509c32e59")
