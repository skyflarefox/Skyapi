-- Lua provided by SkyAPI 
-- Game: ObserVRtarium
addappid(634060)
addappid(634061, 1, "f922a6464c6e2df905964a8107b142019e701699817738f40dc8b3676559d84e")
