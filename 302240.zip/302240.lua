-- Lua provided by SkyAPI 
-- Game: AppID 302240
addappid(302240)
addappid(302241, 1, "e6959f0725b02dd81e519e729702ded7bae56f8927798da886608118128c5aa7")
