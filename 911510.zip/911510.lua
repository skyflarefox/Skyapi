-- Lua provided by SkyAPI 
-- Game: Paws and Soul
addappid(911510)
addappid(911511, 1, "9cd3276304edbef5d71f84d80aa26f8b2d5c89025a6584ada41c8cc6563b442a")
