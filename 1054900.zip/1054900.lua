-- Lua provided by SkyAPI 
-- Game: DevilShaft: TheTower
addappid(1054900)
addappid(1054901, 1, "7e082c0acf8ade3d0f2ff1511e30f3ccbd019cc9b5e1574501c1d26ac056d673")
