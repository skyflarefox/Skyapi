-- Lua provided by SkyAPI 
-- Game: AppID 817540
addappid(817540)
addappid(817541, 1, "f6d9aac4ffbfa6cb4a3ca69203948e45b6fa1f24d662d0ab9e794cb8d5e56eaa")
addappid(1093260, 0, "89df9a57631c1625fac25cb39bd9a9c5273e02309f53eeb8f3856830eae32138")
addappid(1161740, 0, "b970511d4666d1ef87faf2d22a19c7c15e0fab06555a12c7e43e8b0e810f4358")
