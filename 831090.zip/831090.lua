-- Lua provided by SkyAPI 
-- Game: OS:Path
addappid(831090)
addappid(831091, 1, "f37bf446a0318b3e874800fa05af830f27462835a0f80874d80249bcc5c070f9")
