-- Lua provided by SkyAPI 
-- Game: My Summer (InsanErotica) - Demo
addappid(2807530)
addappid(2807531, 1, "3e4879c25c413fc83a298db6edababc0cc8dcecc2b044ad34bb41cd3876947ba")
