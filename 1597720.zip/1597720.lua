-- Lua provided by SkyAPI 
-- Game: Feed All Monsters
addappid(1597720)
addappid(1597721, 1, "c0b6bcb89fbaf10f302f686c35b35c7c45235e2c0def560f0a9862704c5c1c01")
