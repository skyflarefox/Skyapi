-- Lua provided by SkyAPI 
-- Game: AppID 3361140
addappid(3361140)
addappid(3361141, 1, "38f23ccf4d58a8c2a06f8bbee0afb7357c31901d6aa688e70ebf487f69d11b96")
