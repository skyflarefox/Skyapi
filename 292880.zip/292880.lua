-- Lua provided by SkyAPI 
-- Game: Robin's Quest
addappid(292880)
addappid(292881, 1, "6440ec8da57d9bde607d7c94e88248b39b71b523469c8fdebdcc7479986e446a")
