-- Lua provided by SkyAPI 
-- Game: Discord Bot Builder
addappid(1119570)
addappid(1119571, 1, "ccfe1ed90bc1639c0d6a17e3f847da573ec8e623fa98aa32c1e3035961a29582")
