-- Lua provided by SkyAPI 
-- Game: Frog story
addappid(1555160)
addappid(1555161, 1, "4b19d78a599df846bfbd1dc487368d495876946e666e0218c89179354d91e4df")
