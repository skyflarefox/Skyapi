-- Lua provided by SkyAPI 
-- Game: Laughing to Die
addappid(2182400)
addappid(2182401, 1, "fa9d769b176ffdbe827c7672087c6eb112faf16d32b25883e93c75d5b0f2dd47")
addappid(3204580)
