-- Lua provided by SkyAPI 
-- Game: 幻想三国志
addappid(1457620)
addappid(1457621, 1, "1f3726f3b5d00ac2a30c73d871223d331b430037ccd72b11c7116690982b46d0")
addappid(1457622, 1, "1ed633a5d678119d7cbf81af8174df21b9819bd3c3ab3d9b2ffe80a8771fd49a")
