-- Lua provided by SkyAPI 
-- Game: Help Me!
addappid(1557780)
addappid(1557781, 1, "1bd0b6a4d07000e4cb7c373308bccb0f3e618f62f5b1b143082297dc13384aef")
