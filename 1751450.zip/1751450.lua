-- Lua provided by SkyAPI 
-- Game: Kaiju Wars Demo
addappid(1751450)
addappid(1751451, 1, "b5b34cb16fa839ef8dc47234be201a3785f663a835ef116c9bc24864e8f96afa")
