-- Lua provided by SkyAPI 
-- Game: BAFF 3
addappid(1142750)
addappid(1142751, 1, "17dde06addc97972cc010acbea667c1213e4c65c3c5c236d62b261bdfe24fe36")
