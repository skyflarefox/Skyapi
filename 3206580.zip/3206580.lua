-- Lua provided by SkyAPI 
-- Game: Remorse
addappid(3206580)
addappid(3206581, 1, "908af857835e320228054a11b2517f23c3a56406243c9f78fd0b212e11fe7804")
