-- Lua provided by SkyAPI 
-- Game: Abstract Driver
addappid(2415120)
addappid(2415121, 1, "73d37e459b60c4d04570975aade52beb685ec1054a5fd267001f217cc093403a")
