-- Lua provided by SkyAPI 
-- Game: Memory Lost: Chapter One
addappid(2129490)
addappid(2129491, 1, "0ac983068109aa74cad8b4fa2abbe4638e0438f3cd7b539378a2506f77de5ff1")
