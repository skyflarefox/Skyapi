-- Lua provided by SkyAPI 
-- Game: AppID 2075580
addappid(2075580)
addappid(2075581, 1, "4e2907c1b708f00bfe4a2e01a8a13d8ea62b619cf5a3cd06f69163c60956464e")
