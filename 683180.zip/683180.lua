-- Lua provided by SkyAPI 
-- Game: AppID 683180
addappid(683180)
addappid(683181, 1, "6e95238f1dbd24dbb454f7d37ee45d7831ebe8a50daf2f98fc36f97858c10131")
addappid(1068160, 0, "51b7f503f653694ec34aa96dfa0e91bd156fb015bbef22b4aa19b82239e369d9")
