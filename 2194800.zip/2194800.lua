-- Lua provided by SkyAPI 
-- Game: OnlyFap: Fitness Baby 🔞💦
addappid(2194800)
addappid(2194801, 1, "30f1292748d3260729cd412725b5fa54f4e151a01cfaad3fda32a6b8c0e34a89")
