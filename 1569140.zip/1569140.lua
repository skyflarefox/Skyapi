-- Lua provided by SkyAPI 
-- Game: P3TT
addappid(1569140)
addappid(1569141, 1, "068e850f0fc498bf294ae4b595f5f7986e522b4e11556996e499f7a53bd181d0")
