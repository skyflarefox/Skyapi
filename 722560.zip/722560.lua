-- Lua provided by SkyAPI 
-- Game: RAD
addappid(722560)
addappid(722561, 1, "608a77be01a9fac4c6d7daee00be931f18c0c5f69c70574053e98738aa018afd")
addappid(1476060)
