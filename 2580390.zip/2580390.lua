-- Lua provided by SkyAPI 
-- Game: AppID 2580390
addappid(2580390)
addappid(2580391, 1, "52a13772c6f76e3734b5a02a6e219ab4fa5b10f1560594c37d31f999a771b5a0")
