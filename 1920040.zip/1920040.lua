-- Lua provided by SkyAPI 
-- Game: AppID 1920040
addappid(1920040)
addappid(1920041, 1, "7ca0b6e596726c95f4531b2d663b9c27bf5797481ddd24c039f12dcf169462de")
