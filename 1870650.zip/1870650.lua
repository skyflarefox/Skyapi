-- Lua provided by SkyAPI 
-- Game: Werewolves Revenge Playtest
addappid(1870650)
addappid(1870651, 1, "2177f5bbe85adedd65a48e8eb352be31d82ea3c7e35376a3ba413109d23fa93b")
