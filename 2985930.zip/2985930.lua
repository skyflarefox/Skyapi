-- Lua provided by SkyAPI 
-- Game: I Am Part-time Worker!!
addappid(2985930)
addappid(2985931, 1, "3ca33f740cfdb2bd8f1bbcc4bf9ffd1c2e77c18f518030e35af44de3f7edb263")
