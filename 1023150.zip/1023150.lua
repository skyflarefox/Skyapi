-- Lua provided by SkyAPI 
-- Game: Cyborg Invasion Shooter 3: Savior Of The World
addappid(1023150)
addappid(1023151, 1, "6d2153a9848b73b7dee201a9b8b2a116665b02d82ee31f1425928db194d13d6b")
