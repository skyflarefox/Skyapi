-- Lua provided by SkyAPI 
-- Game: Project Parallel
addappid(2679430)
addappid(2679431, 1, "b5377f44999b2de2da6d3eb180bba1eda0c028f729e2b0666158cac58f9c8be4")
