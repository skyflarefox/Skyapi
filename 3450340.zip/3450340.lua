-- Lua provided by SkyAPI 
-- Game: Henshin MyBro!
addappid(3450340)
addappid(3450341, 1, "c112b2e9b62ed36a46b2d9f14645f60255ba5db0634d38e3d8d109471e3c82ba")
