-- Lua provided by SkyAPI 
-- Game: AppID 1458460
addappid(1458460)
addappid(1458461, 1, "6595a3a287151bfabd68cd2fe3b237432fadabb8415d916d78a87218bda29da3")
