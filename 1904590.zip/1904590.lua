-- Lua provided by SkyAPI 
-- Game: Project Medved
addappid(1904590)
addappid(1904591, 1, "ff80509b8d54ebd3546d7c71492ed5ca0c89d954ba58ad1161c134b080c5bbe3")
