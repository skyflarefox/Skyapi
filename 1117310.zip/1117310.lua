-- Lua provided by SkyAPI 
-- Game: Sandwich Sudoku
addappid(1117310)
addappid(1117311, 1, "e518183cd21a2410c8e87dcf05ebc10ed099e7ddf064de3c3f67fed55e2a6acd")
