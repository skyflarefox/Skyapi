-- Lua provided by SkyAPI 
-- Game: 100 hidden mice
addappid(1522560)
addappid(1522561, 1, "b378d34c4f11950fd70bfff4d944d0e6fd5c8d9d960104265beb69710f17b5b1")
