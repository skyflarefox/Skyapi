-- Lua provided by SkyAPI 
-- Game: Misha Adventures
addappid(1683240)
addappid(1683241, 1, "71cd27dfd51f31f2370a87748271cde77b06cc3e9e3917ef61cbd11787a690d0")
