-- Lua provided by SkyAPI 
-- Game: AppID 1064660
addappid(1064660)
addappid(1064661, 1, "f399883f76791ec6e7107ec4f9da972f1351cb5d43e3c8a0c4aac61ce0e288d7")
