-- Lua provided by SkyAPI 
-- Game: The B.L.O.O.M Initiative
addappid(3543740)
addappid(3543741, 1, "ff1bf59d9c03ed78044306070d55eadb325969205a4188a9853cd136fb3089f8")
