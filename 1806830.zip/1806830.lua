-- Lua provided by SkyAPI 
-- Game: AppID 1806830
addappid(1806830)
addappid(1806831, 1, "3e6bfc6b3185c26bd6d13748532897d72ba031446b5e36a4f066e4101f029a98")
