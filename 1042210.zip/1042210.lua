-- Lua provided by SkyAPI 
-- Game: Guts And Goals
addappid(1042210)
addappid(1042211, 1, "e9bd86926c0b6aa29a458eb53c4f64cc6ba1059c8b1675368aea1e41230f144b")
