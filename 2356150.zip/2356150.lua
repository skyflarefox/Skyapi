-- Lua provided by SkyAPI 
-- Game: Arcane Assembly
addappid(2356150)
addappid(2356151, 1, "3061395ab01738e6770d6b9d069f772ef613dfa197d38c259a7602e5f1e6d8d8")
