-- Lua provided by SkyAPI 
-- Game: Road 96 Demo
addappid(1597690)
addappid(1597691, 1, "11dad913601fd92dfd2d05e357818bb1065ec687028540d5021b2f6e01dbb996")
