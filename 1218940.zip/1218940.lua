-- Lua provided by SkyAPI 
-- Game: ETERNAL BLOOD
addappid(1218940)
addappid(1218941, 1, "113cabca68ac50aa4bbe4b2b7fff13427f7761d1ca17fd36865652b6a7a8a3b4")
