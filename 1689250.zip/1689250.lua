-- Lua provided by SkyAPI 
-- Game: AppID 1689250
addappid(1689250)
addappid(1689251, 1, "8bf0e792e50fd8203b7943785a6bd6bc941c85f026218d80085f1558a41753eb")
