-- Lua provided by SkyAPI 
-- Game: Choco Pixel 4
addappid(1275520)
addappid(1275521, 1, "e3db2e7deb52b164b96f3813e795b542ba93556e3e0f99964739d1d078677d40")
