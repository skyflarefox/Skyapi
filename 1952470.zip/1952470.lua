-- Lua provided by SkyAPI 
-- Game: Blaston Spectator
addappid(1952470)
addappid(1952471, 1, "a852177d5669e5193229e5c18c70a6d2f990ffa8294b3c016874246c6959b501")
