-- Lua provided by SkyAPI 
-- Game: Forest Battle 森林战斗
addappid(1493050)
addappid(1493051, 1, "10a31c49f81cff1413dd7cc6f87bbd0432fa58cf7f2c3d8ac7d5acd36036564e")
