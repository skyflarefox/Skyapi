-- Lua provided by SkyAPI 
-- Game: Technofumer
addappid(2498910)
addappid(2498911, 1, "d40b33beed184c007c5fe768bf0e9a69cf592c14ad48dc485a1ed34c988782d6")
