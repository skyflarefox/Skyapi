-- Lua provided by SkyAPI 
-- Game: AppID 686760
addappid(686760)
addappid(686761, 1, "92a2ab94230f5162c4bfab4a27184afd40ecb99b18a89f07abde348bbd8af062")
