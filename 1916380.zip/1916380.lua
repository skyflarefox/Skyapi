-- Lua provided by SkyAPI 
-- Game: Idol Hunter : Hentai
addappid(1916380)
addappid(1916381, 1, "6aec734f842ad589a018ce07afdf7c63edec122fa17d9e7c9573375131896d09")
