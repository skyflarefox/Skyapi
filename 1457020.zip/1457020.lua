-- Lua provided by SkyAPI 
-- Game: Temptations X
addappid(1457020)
addappid(1457021, 1, "62f4792e247ab7a8f3b4e27716161cb502982a73a21aa20dc3cf5f9d1c2d9541")
