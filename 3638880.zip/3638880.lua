-- Lua provided by SkyAPI 
-- Game: OddRoom Soundtrack
addappid(3638880)
addappid(3638881, 1, "e89e84970823bd4a2ccce7c3ca16a31648a5342312564b4e3c4f7eb854fc9900")
