-- Lua provided by SkyAPI 
-- Game: Naturallandscape - Grand Canyon (自然景观系列-美国大峡谷)
addappid(835440)
addappid(835441, 1, "faa8258c60ff2c60aaefb061c6ee5064abdf279f54726a0d04808b7fd9f9f8d1")
