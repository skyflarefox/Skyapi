-- Lua provided by SkyAPI 
-- Game: Roommates
addappid(2775110)
addappid(2775111, 1, "5d14e97ddcf9098d25a55fee9e31cf1ac5f5421dc4b0ba467c825acaf9260ca3")
