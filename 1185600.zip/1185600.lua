-- Lua provided by SkyAPI 
-- Game: AppID 1185600
addappid(1185600)
addappid(1185601, 1, "13e25e0d49d0fa13f5e83834e8203a653184578f78c88b9b9318ac020b4604a0")
