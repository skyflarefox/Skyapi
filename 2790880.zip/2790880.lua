-- Lua provided by SkyAPI 
-- Game: AppID 2790880
addappid(2790880)
addappid(2790881, 1, "9acd74c324b838aac03a10c24e49319411d94382535cf1fd8444f9ef8124e8be")
