-- Lua provided by SkyAPI 
-- Game: The Journeyman Project 1: Pegasus Prime
addappid(359420)
addappid(359421, 1, "db5c0d0c43df844a2ec95243c2bd4c26b4452cf743bc916be0eec9e60c5ce815")
addappid(359422, 1, "b4bae12aed70f3905a46e123a78287245dc1042993fcc019eb72862a999da02d")
