-- Lua provided by SkyAPI 
-- Game: 8i - Make VR Human
addappid(462530)
addappid(462531, 1, "78c577bc8ef67e218be4c0e7a1461baf430554af21f6f684619ddf9d7d6d2b91")
