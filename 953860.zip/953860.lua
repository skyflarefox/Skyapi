-- Lua provided by SkyAPI 
-- Game: AppID 953860
addappid(953860)
addappid(953861, 1, "c8fde9ad3f8a1fc27b8f113aa310c3f7f107eb7ccfd9b7d3178f817a0f87f15b")
addappid(953862, 1, "30ad3fd233c3a75326b5d8886b308569398577c371eb67b71579dbedd7624091")
