-- Lua provided by SkyAPI 
-- Game: Lake of Shadows
addappid(1719790)
addappid(1719791, 1, "479fedfcfac901b0b38c691983a74f46e2a9b3c201741190e00d9d9964e7309d")
