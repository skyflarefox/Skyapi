-- Lua provided by SkyAPI 
-- Game: AppID 836450
addappid(836450)
addappid(836451, 1, "6ecfc9428a5a833677870d53af40fcbbf83e8d0d03dd52b756807d5cc3a9d48f")
addappid(837450, 0, "1f49eea1805ba23896a61dfbb8308c0931a9d93eb52dead48fee97b731b3e2de")
