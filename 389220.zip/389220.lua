-- Lua provided by SkyAPI 
-- Game: Maximum Override
addappid(389220)
addappid(389221, 1, "6c2c9b3fefe256ae8a6d24709cd7f89440ab6ac31b5bdd8fb36f6815f0518d60")
