-- Lua provided by SkyAPI 
-- Game: Hidden Kitten
addappid(2402200)
addappid(2402201, 1, "50ba32485dc44c7ea78e25218284a403c922ef314d276f2970abba6ec9d928f6")
