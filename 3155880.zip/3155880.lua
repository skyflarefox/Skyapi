-- Lua provided by SkyAPI 
-- Game: AppID 3155880
addappid(3155880)
addappid(3155881, 1, "6532d5964534ae762a852425fceae48fff12a8584a302de3079ca6cf7aee868a")
