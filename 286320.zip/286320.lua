-- Lua provided by SkyAPI 
-- Game: Oknytt
addappid(286320)
addappid(286321, 1, "7fc36aa9772bdf71b9fb199477b4ca39cd3cef0949f846ae653fa6d00d599b90")
