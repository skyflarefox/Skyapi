-- Lua provided by SkyAPI 
-- Game: Pushover
addappid(814650)
addappid(814651, 1, "23c48a46bb7b4a10c21a162c87381ad858b0ed630d8de679de23b888286b1793")
