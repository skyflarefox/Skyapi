-- Lua provided by SkyAPI 
-- Game: Life is Strange: Before the Storm Remastered
addappid(1265930)
addappid(1265931, 1, "f03554a039cea967647878f3e6215ee9fe74c906f4a8d5d088201c36534cb435")
addappid(1537870)
