-- Lua provided by SkyAPI 
-- Game: Scratch Girl
addappid(1814490)
addappid(1814491, 1, "090f02da0d97a277694eb66782074a24bbc7cc43da8c189397aa00d77c8957e4")
addappid(1830550, 0, "c644973d058360276bcbbb1ec6c97f8b05f447dec6ba08ab275f2444b0693f97")
