-- Lua provided by SkyAPI 
-- Game: AppID 851080
addappid(851080)
addappid(851081, 1, "5b2cc5e418f16dc656beeffc8f24e5c3f64c587c5c38a16d579617b0dcfa6665")
