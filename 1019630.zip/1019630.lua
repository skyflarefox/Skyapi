-- Lua provided by SkyAPI 
-- Game: AppID 1019630
addappid(1019630)
addappid(1019631, 1, "3781dd109f8cf977fe96a8136bde6a7d5d09426ba22044c5b7033b0febc470ed")
