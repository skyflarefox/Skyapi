-- Lua provided by SkyAPI 
-- Game: Epic Food Fight
addappid(991510)
addappid(991511, 1, "827424167231461402e3bafc042fc38d6ca91651febd49bc40940182ffc62484")
