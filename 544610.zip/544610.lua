-- Lua provided by SkyAPI 
-- Game: AppID 544610
addappid(544610)
addappid(544611, 1, "8218309c22098c48817733fcb6cd6ce958cb65bd67963da1e84ccf1c5ab41f3d")
