-- Lua provided by SkyAPI 
-- Game: AppID 404460
addappid(404460)
addappid(404461, 1, "7b572dd748a1c225aaebe85dab44f665d07e695f48c5ddbadaf2fa0f4d549ad5")
