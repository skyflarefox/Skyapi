-- Lua provided by SkyAPI 
-- Game: Hotel Giant
addappid(502460)
addappid(502461, 1, "909400c31c2b1acf883ee6736bf7e668257d695d5a8029dee4530cee3948a9e3")
addappid(502462, 1, "a89a5ad756b6cbc736491f831432f66a8ce46cb9198908dcadcf8b7e24b6753f")
addappid(502463, 1, "cce7e94c00e38bc3ff178bec4b68dcb07951c7f89340572c012da459dc6e0509")
addappid(502464, 1, "503c2bbcf259e1a7cf803533e6913c4faf66f0a57dde6c72dbb1b1263300e7cb")
