-- Lua provided by SkyAPI 
-- Game: AppID 1975440
addappid(1975440)
addappid(1975441, 1, "a5841fd8a2ef1290667c7e49fec8d2d795f65642368ad9a52e5836ed13c2bd28")
