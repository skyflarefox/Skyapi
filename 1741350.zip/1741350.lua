-- Lua provided by SkyAPI 
-- Game: Lamentum Artbook
addappid(1741350)
addappid(1741351, 1, "58dfb6504ab7982f26895fff5cb700f137b5e797cf1fe965cd839e0c7052b260")
