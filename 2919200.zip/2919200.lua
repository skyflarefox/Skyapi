-- Lua provided by SkyAPI 
-- Game: Death Sword Spirit
addappid(2919200)
addappid(2919201, 1, "926e994e222b06753b643a3beb7e460a7a967952942bf23a56beba2485f4340e")
