-- Lua provided by SkyAPI 
-- Game: Lost Wish: In the desperate world
addappid(1891740)
addappid(1891741, 1, "783044b353bbd32d14b2c44e2114f4f83cd69173599d5e13bdf95eda8db06e0f")
