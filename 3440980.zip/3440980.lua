-- Lua provided by SkyAPI 
-- Game: It's Raining Acorn!
addappid(3440980)
addappid(3440981, 1, "84d4f374c5eb85454b1f07d1b0673d8e460c059cfd56a04ac3f0cc2c0bde02e9")
