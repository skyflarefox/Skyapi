-- Lua provided by SkyAPI 
-- Game: AppID 3545430
addappid(3545430)
addappid(3545431, 1, "476806cd603b59bba50be6f9bf7ef7c09093cf4fa228231d0d34038230816367")
