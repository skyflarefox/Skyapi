-- Lua provided by SkyAPI 
-- Game: AppID 1181140
addappid(1181140)
addappid(1181141, 1, "ec987ee5dfd51b9fcc2ac64d51ad4de16b43d25530ac3a49ed5f02225ba92a45")
