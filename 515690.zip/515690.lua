-- Lua provided by SkyAPI 
-- Game: Warriors of Vilvatikta
addappid(515690)
addappid(515691, 1, "f586ffddd5961676e9bd04c4931c0940067129916d63736cb65b30abf7c2ef74")
