-- Lua provided by SkyAPI 
-- Game: AppID 1543100
addappid(1543100)
addappid(1543101, 1, "8698d8a4f8e2ef707ca0e452cc781b1a3cf5e7762071f5902b776523a23b1d06")
