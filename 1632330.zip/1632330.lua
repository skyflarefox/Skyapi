-- Lua provided by SkyAPI 
-- Game: AppID 1632330
addappid(1632330)
addappid(1632331, 1, "121cb7616699cd277f9015033696f1dda6b7d98e85fef150a2649c329a9e32f0")
