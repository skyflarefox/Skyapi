-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1119980)
addappid(1119981,0,"732d08165eb2d508fe8b3082419c091f9bcc1d837a162337009d686b73fc80eb")
setManifestid(1119981,"8668371056398683870")