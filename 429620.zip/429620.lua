-- Lua provided by SkyAPI 
-- Game: Dungeon Rushers
addappid(429620)
addappid(429621, 1, "35d8e8fe56ef15284d32543fe6d810c0dd2188bccfd596d606a90ffd2218a1d9")
addappid(429622, 1, "567d8ae99541b775b7bb5baf878753648ac15e729d13d5e8a1e2dc884ad7b416")
addappid(429623, 1, "75f2e840304cc06c333540b6e1eb3909a773a08a722c2f3a727ebbfa5d4f6674")
