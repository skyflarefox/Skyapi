-- Lua provided by SkyAPI 
-- Game: Operation Flashpoint: Dragon Rising
addappid(12830)
addappid(12831, 1, "8a80c75a84879a9149e769959b2bad5b6718796a6246d6370f47d9cd401d0b89")
addappid(12832, 1, "f73cbbe3dc4bfbece21c8fcec9cccca6735ee9b228bb0e9a4783416edef6ff7c")
addappid(12833, 1, "61af6a1900e6e59d1357ecb22878569bd6916e922bf1674eeb3896430761adb5")
addappid(12834, 1, "3649a36cec4dc214b6a8fa7083ac6e354bf0f115a4d44146f183c971a87e8cb5")
addappid(12835, 1, "f69a8e390cb0c769cad0b68671a66cebff6c345c92675d876c490e2a3e209b92")
