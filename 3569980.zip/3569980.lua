-- Lua provided by SkyAPI 
-- Game: Trash Horror Collection 5
addappid(3569980)
addappid(3569981, 1, "02ad7595c306b0af5fdc6d4e48c1b5693e2c9d2ed4ab8342433739d6424ebb08")
