-- Lua provided by SkyAPI 
-- Game: AppID 776320
addappid(776320)
addappid(776321, 1, "35753b1477ba802af2567ffcefa228f4ccef74f5c06e57cfeaa8ae8ada95415d")
