-- Lua provided by SkyAPI 
-- Game: AppID 1015730
addappid(1015730)
addappid(1015731, 1, "eb38fc6679586ec2a747cea00a702131be17e2a1668be81aaa3c21ba3a140e61")
addappid(1015732, 1, "027091c42cda7e0ba30f5c0c93fbb7fd0be37121fb164ef38f76bc331845256e")
addappid(1015733, 1, "e1aec716c3ee122b04cde0fe589c8b2f8fb00d5ec7d724dda6c026b4462de433")
