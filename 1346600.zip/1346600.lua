-- Lua provided by SkyAPI 
-- Game: Elli
addappid(1346600)
addappid(1346601, 1, "9eab405a9566ee5bceea2997134b8b669dba7cdfa5b08bd03d1dc8214155048e")
