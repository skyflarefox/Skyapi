-- Lua provided by SkyAPI 
-- Game: Logistics Simulator
addappid(1617420)
addappid(1617421, 1, "b85126bb785516154da36faf11cfb4dc862e65c2bf05eac0d3abf17db9990782")
