-- Lua provided by SkyAPI 
-- Game: AppID 1292240
addappid(1292240)
addappid(1292241, 1, "6f23dd06dbb3e90faee2295d60f5ff3094482e67fa0841b5de8fd07d75f840ee")
addappid(1292242, 1, "05452cea69e0f15395898463466d5b7d1e08a01996a372046fe69ff85acd3207")
