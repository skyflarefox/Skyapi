-- Lua provided by SkyAPI 
-- Game: AppID 1292240
addappid(1292240)
addappid(1292241, 1, "6f23dd06dbb3e90faee2295d60f5ff3094482e67fa0841b5de8fd07d75f840ee")
