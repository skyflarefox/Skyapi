-- Lua provided by SkyAPI 
-- Game: Demons Infernalize
addappid(2324380)
addappid(2324381, 1, "4074452c0b5996188da4d2221ac704c99693072dc741d6e57ea5052c35b8d19a")
