-- Lua provided by SkyAPI 
-- Game: Fluffy Milo
addappid(1935490)
addappid(1935491, 1, "7f2d00cefa276eed56381f1ab13551bc8ba804c72b094966e4f42604c3a40b5e")
