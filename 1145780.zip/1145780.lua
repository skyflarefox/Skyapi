-- Lua provided by SkyAPI 
-- Game: AppID 1145780
addappid(1145780)
addappid(1145781, 1, "c37cb8979a050caea29c940fd13239f7cc0262ed371f7743e497f5fcb21c7e6d")
