-- Lua provided by SkyAPI 
-- Game: AppID 497020
addappid(497020)
addappid(497021, 1, "3c540b07cf7834d0cc42d6b38338de4d9f87c07d5551e477499c67c4d0f2a182")
