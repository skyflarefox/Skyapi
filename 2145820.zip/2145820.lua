-- Lua provided by SkyAPI 
-- Game: AppID 2145820
addappid(2145820)
addappid(2145821, 1, "814429c727d73a630317c198068e015dd95f16fa64b5f4b6799203679cd2582e")
