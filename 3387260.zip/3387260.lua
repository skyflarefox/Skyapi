-- Lua provided by SkyAPI 
-- Game: Luma Island Soundtrack
addappid(3387260)
addappid(3387261, 1, "b4c9cd24fd4ef1dabbaf1c67459c7cd2315605547c61edcda2bd0f9d558aae1c")
