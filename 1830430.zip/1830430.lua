-- Lua provided by SkyAPI 
-- Game: Grimoire Groves
addappid(1830430)
addappid(1830431, 1, "323e9cdda818b3cdd55e784fd31bd0adaf092f0aabcbaa7b2a0f6e4d46cce635")
