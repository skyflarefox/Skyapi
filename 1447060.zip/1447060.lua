-- Lua provided by SkyAPI 
-- Game: Jad
addappid(1447060)
addappid(1447061, 1, "1a46a8857dbf361f83ad54106b028d8ec828df5b502869893bcd0df59379c264")
