-- Lua provided by SkyAPI 
-- Game: Glamour Riot
addappid(3557370)
addappid(3557371, 1, "3594ed5f9065f294c8b05201147626f87fd81c07d438b70567beafdf496252c8")
