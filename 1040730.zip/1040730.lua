-- Lua provided by SkyAPI 
-- Game: ZUSI 3 - Aerosoft Edition
addappid(1040730)
addappid(1040731, 1, "c5b3b28e4505b43631d0f7d2f350534de914ecf27c9b27517622c56b767dc1d1")
