-- Lua provided by SkyAPI 
-- Game: AppID 977650
addappid(977650)
addappid(977651, 1, "1a32159d9020b5e8786a0b51f1595246831ce00c17d7d527c39f07f0d121a1da")
