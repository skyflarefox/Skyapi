-- Lua provided by SkyAPI 
-- Game: Tales of Morrow
addappid(1783620)
addappid(1783621, 1, "4e9cd6be83a65b4a15a1c5e80db75e87d8a34ce10bff37d24f52ee804625db97")
