-- Lua provided by SkyAPI 
-- Game: Gamer Shop Simulator
addappid(1228570)
addappid(1228571, 1, "c119144d38eab91a27855decdd1f225c45f747c423b278b9c066d9471346a2e1")
