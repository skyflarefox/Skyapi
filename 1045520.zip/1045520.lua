-- Lua provided by SkyAPI 
-- Game: Acting Lessons
addappid(1045520)
addappid(1045521, 1, "b6a955f1d728cf529a0de7fe6e219eebf725e4b19a8c6359b587f8367d4e812b")
