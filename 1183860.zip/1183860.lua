-- Lua provided by SkyAPI 
-- Game: AppID 1183860
addappid(1183860)
addappid(1183861, 1, "783e2bcf9d724722f44b71f6a3c7f6ca638b8e1fb97741a6f14f2c315aa6d1f3")
