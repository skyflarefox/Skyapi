-- Lua provided by SkyAPI 
-- Game: Under Pressure
addappid(2524980)
addappid(2524981, 1, "9cabc3d9b86272a986e368d2a483ea50fd7279ca8d7e853dfd47bf3f8d0567a5")
addappid(2604790)
