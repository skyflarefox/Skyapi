-- Lua provided by SkyAPI 
-- Game: AppID 2758350
addappid(2758350)
addappid(2758351, 1, "ec5fd942f41ad57271210048932f358da7d6b54312d56e477df86d530d1c4b2d")
