-- Lua provided by SkyAPI 
-- Game: AppID 467310
addappid(467310)
addappid(467311, 1, "9a0677fbb67128eca1e06e0979dd2f9e502834cb006d9cfea7b5c3ac57ad9213")
