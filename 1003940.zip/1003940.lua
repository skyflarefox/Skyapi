-- Lua provided by SkyAPI 
-- Game: Invasion Zero
addappid(1003940)
addappid(1003941, 1, "5376a356aded8853f5611f55590a846d27adc65b71e09b54b12a4e68cdab3051")
