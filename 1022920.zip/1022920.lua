-- Lua provided by SkyAPI 
-- Game: AppID 1022920
addappid(1022920)
addappid(1022921, 1, "bf3f54e01faf5c5cd8269b3f30355f2981bb665fe6fa4075d53d7883d1fa2859")
