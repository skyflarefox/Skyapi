-- Lua provided by SkyAPI 
-- Game: Links E6
addappid(1620750)
addappid(1620751, 1, "b3647764bec9aa953067926fece1702072d9469159c1e3e121298930aa28f0da")
