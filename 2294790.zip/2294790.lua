-- Lua provided by SkyAPI 
-- Game: Vivat Sloboda (2019)
addappid(2294790)
addappid(2294791, 1, "f0534544e78ede51060c3ccb0295de84d7eb7de98543678c09a9ade107649bf2")
