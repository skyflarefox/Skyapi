-- Lua provided by SkyAPI 
-- Game: AppID 1271310
addappid(1271310)
addappid(1271311, 1, "5a078762ceb4c4a0fd09f77fd2122bafa1e2b0ee42b00dd88a85637d57b81e3f")
