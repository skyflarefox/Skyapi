-- Lua provided by SkyAPI 
-- Game: QIMEN Tower Defense
addappid(3428120)
addappid(3428121, 1, "68574c2be9ebe8ffc2d39fb96947f0e13a8549c33f73f97ba5f65424e9208c9e")
