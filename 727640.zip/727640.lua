-- Lua provided by SkyAPI 
-- Game: ШП - ShP
addappid(727640)
addappid(727641, 1, "3ea9d521c78ec13b1ca1d054d189d5d6389eb9800129d4372888147ce8c131b4")
addappid(748140, 0, "11b142b38d213cdf5c1a46e2125d024d432811b4c80faa6ce6ab0cadb6c82229")
addappid(749590, 0, "8f22cab78170f8fdac333fa25eebf1864a86b755af7895d791ff5d08fd547a0b")
addappid(749660, 0, "6936e3dc9accab04476aebe0a6eac69be4cc37e9ce3c533444cdf28e5ed461a4")
