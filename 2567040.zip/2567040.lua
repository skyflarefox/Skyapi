-- Lua provided by SkyAPI 
-- Game: Only UP
addappid(2567040)
addappid(2567041, 1, "f7756cc0c7d88ad26285b70f22e0a201028d2303864645703e8ff6432495887d")
