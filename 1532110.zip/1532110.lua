-- Lua provided by SkyAPI 
-- Game: Curatours
addappid(1532110)
addappid(1532111, 1, "7a8493fe2d664174b707b1a151a5b6443acdb1d64d6f698da8fb8943a01b81ec")
