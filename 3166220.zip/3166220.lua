-- Lua provided by SkyAPI 
-- Game: Harukuru HD. - Spring has come true? -
addappid(3166220)
addappid(3166221, 1, "87e1456180671ce3d138f8d2a69c0cd620506faed1e13778ca2016bc3c6004b6")
