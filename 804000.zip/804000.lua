-- Lua provided by SkyAPI 
-- Game: Expendable
addappid(804000)
addappid(804001, 1, "3912a5e6cdb73fc27a6c8c46b0a5372185ef48b4919e1ca4ad6d955b76906eaf")
