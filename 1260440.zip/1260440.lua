-- Lua provided by SkyAPI 
-- Game: AppID 1260440
addappid(1260440)
addappid(1260441, 1, "5fd27d5e70823be698b9ae57fdd53025bbb00b4f0ee78b6c626021b71bf4a8f5")
