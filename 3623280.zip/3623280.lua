-- Lua provided by SkyAPI 
-- Game: Vampirates
addappid(3623280)
addappid(3623281, 1, "dc7d91568d8c2fb564969c25f137e890fdf1cdf6fcd2d7b8f1b42d6167ddc4bb")
