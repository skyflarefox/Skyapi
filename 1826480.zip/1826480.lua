-- Lua provided by SkyAPI 
-- Game: AppID 1826480
addappid(1826480)
addappid(1826481, 1, "9a0d343f582904e7c1b1912ecafc52d609aea332f9a83de461460936043bcae5")
