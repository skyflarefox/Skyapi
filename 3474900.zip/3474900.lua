-- Lua provided by SkyAPI 
-- Game: Anima Engine
addappid(3474900)
addappid(3474901, 1, "fbc9891a1c20a2a57931cc7ac38cec562cf9fb996f284e99863b13fb98f140d8")
