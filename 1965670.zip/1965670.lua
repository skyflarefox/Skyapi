-- Lua provided by SkyAPI 
-- Game: It's high noon
addappid(1965670)
addappid(1965671, 1, "fc68e34909dc63529f573306a737642b867926a012dce080eccf3b24fb53fd2d")
