-- Lua provided by SkyAPI 
-- Game: Bleeding Blocks
addappid(400710)
addappid(400711, 1, "a43f4f39192f9384c0c6cd5f6c12f9b423e6d24114a77026ee0c678c923ea6ed")
