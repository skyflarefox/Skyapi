-- Lua provided by SkyAPI 
-- Game: Valkyrie Squad: Siege Breakers
addappid(2692030)
addappid(2692031, 1, "c2f9d73d28310191f8fc91dea63b4b7e20f12acc6ced690a7fe88d0d74a3b679")
addappid(3218670, 0, "3374323e24d2b984834dd7b3080571261dc6f41f5e7791ad7b16e3c2629f0949")
