-- Lua provided by SkyAPI 
-- Game: Hotel Overloop
addappid(2955200)
addappid(2955201, 1, "9252d0ddf3e7bd5f6ba0c30c8de63c476dcf25837465dbefe093a04e3b3d881f")
