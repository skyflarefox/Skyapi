-- Lua provided by SkyAPI 
-- Game: Careening Demo
addappid(3393250)
addappid(3393251, 1, "2c3198112e8fce61253d1dc33e0ac4f7fd4dcb3ceb0d7ac3f382d294ed9f8dd5")
