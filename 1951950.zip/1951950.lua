-- Lua provided by SkyAPI 
-- Game: 3D Controller Overlay
addappid(1951950)
addappid(1951951, 1, "0de9f1d7703dece32e06f930e2a162d5f5c6b6f25958b873db33f5c6d45ee782")
