-- Lua provided by SkyAPI 
-- Game: SNUSE 221
addappid(948070)
addappid(948071, 1, "d575dd1c8935185017e21580c7a13bbeb2ac888677686f67eca0de3553571d1b")
