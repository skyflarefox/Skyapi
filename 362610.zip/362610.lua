-- Lua provided by SkyAPI 
-- Game: High On Racing
addappid(362610)
addappid(362611, 1, "442617f555c47e5c71c873752cb58687dc9ca507a5ee5513090ed9e78a569887")
