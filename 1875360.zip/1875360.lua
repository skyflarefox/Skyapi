-- Lua provided by SkyAPI 
-- Game: Off-Road Farming
addappid(1875360)
addappid(1875361, 1, "db2d305832342d15853620c213b6250ba82059baac3499c082746df45f8a998e")
