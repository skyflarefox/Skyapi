-- Lua provided by SkyAPI 
-- Game: Cult Of Babel
addappid(2078970)
addappid(2078971, 1, "80e6752621a9d7ba04b7c3a371b2108a29f09a792ebf4f5edac0edd324f00d14")
