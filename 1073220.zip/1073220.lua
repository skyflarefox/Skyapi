-- Lua provided by SkyAPI 
-- Game: AppID 1073220
addappid(1073220)
addappid(1073221, 1, "102b63e470d800e809bbbf737d77ffe19fba4152b4c935e7abad51120e18e71f")
