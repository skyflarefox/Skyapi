-- Lua provided by SkyAPI 
-- Game: AppID 2242890
addappid(2242890)
addappid(2242891, 1, "662819b06675dee4690d3d5ada8aa96ba8b95228b87f5d40b903c9636fc12c0c")
