-- Lua provided by SkyAPI 
-- Game: Cannon Fodder 3
addappid(209750)
addappid(209751, 1, "27d217756896c02c43c9d212befea2762371553e0e9e5ab6755c06c5f98a6b34")
