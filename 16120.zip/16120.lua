-- Lua provided by SkyAPI 
-- Game: Plant Tycoon
addappid(16120)
addappid(16121, 1, "4a5e384e9b573e5746553cc0204224ab9adbb5a95f2f6d2bdf6e7b046d1c1b7a")
