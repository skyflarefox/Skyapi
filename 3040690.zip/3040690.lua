-- Lua provided by SkyAPI 
-- Game: Lost boat: VR Underwater Discovery
addappid(3040690)
addappid(3040691, 1, "65f2550d9895e5625837ef45404f53b6150616b6410826a905664d8d9408cd2c")
