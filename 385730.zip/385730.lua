-- Lua provided by SkyAPI 
-- Game: WWE 2K16
addappid(385730)
addappid(385731, 1, "80bebb1d9dae5ea48e85969d1d44bb5f207037bb1a0737b785ff9f845c78dde1")
