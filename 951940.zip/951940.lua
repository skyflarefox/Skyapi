-- Lua provided by SkyAPI 
-- Game: Almost There: The Platformer
addappid(951940)
addappid(951941, 1, "33bdb8a3fcd7b0d4fc80cb1ba01877f151dbc3c3cf19aa1f511587c228ac0146")
