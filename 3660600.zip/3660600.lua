-- Lua provided by SkyAPI 
-- Game: ЗУМЕРЫ
addappid(3660600)
addappid(3660601, 1, "2df9561ec7c15a5a2d4b8e1549c015c3c85b98bcc7ebd5b19fca9ed6e4daff1c")
