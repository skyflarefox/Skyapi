-- Lua provided by SkyAPI 
-- Game: Magical Monster Land
addappid(949990)
addappid(949991, 1, "49ad7a297f7b70388340cb88374270fe5e3d06b6df2d867e1208e66a6eafdda4")
