-- Lua provided by SkyAPI 
-- Game: Hausmeister
addappid(2064580)
addappid(2064581, 1, "0f9e0b0441014c5dd03500137d27a4410962764abd80511abc62d5f6ad1741dc")
