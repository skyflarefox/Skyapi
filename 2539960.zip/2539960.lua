-- Lua provided by SkyAPI 
-- Game: Orbo's Odyssey
addappid(2539960)
addappid(2539961, 1, "dac10501442541a4ba27221d67e05dc9ae3a71803939ba45c6b91f93ccb77110")
