-- Lua provided by SkyAPI 
-- Game: AppID 485950
addappid(485950)
addappid(485951, 1, "e6a7c7c8c1fe4f938f6de4d1c39370b86f22fb893e6a0c90546e85d3959df0d9")
