-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(218740)
addappid(218741,0,"d8e121186f060f6f6e629bb2c5010e2366d37dbb214ed02ed526a49c3a1dfe3b")
setManifestid(218741,"824761431797179780")
addappid(218742,0,"5c6e723b5fae1efdd37aca720e39a642e912e3763ba796f51b75f46187c90f64")
setManifestid(218742,"7552422296834538964")