-- Lua provided by SkyAPI 
-- Game: AppID 806850
addappid(806850)
addappid(806851, 1, "fcdce36ffd9a8f4d9e194c4e74002418ac1927b72a47ee6d3b2b4d56ef934f39")
