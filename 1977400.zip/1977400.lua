-- Lua provided by SkyAPI 
-- Game: AppID 1977400
addappid(1977400)
addappid(1977401, 1, "79d73000f4d68d4a60640f62de1af493feeabec5c4be2841a78eded9acf04476")
