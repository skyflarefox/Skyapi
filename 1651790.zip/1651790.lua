-- Lua provided by SkyAPI 
-- Game: Peripeteia Demo
addappid(1651790)
addappid(1651791, 1, "459746ca66c0d336c430fd00fe74a8c674c5eb089cbf36aa62c6f082f001a57e")
