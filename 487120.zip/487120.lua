-- Lua provided by SkyAPI 
-- Game: AppID 487120
addappid(487120)
addappid(487121, 1, "4c501a8893cb40344da30e292f34450808cb2863d4b616b21b1261811cede857")
