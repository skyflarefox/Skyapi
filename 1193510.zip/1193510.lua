-- Lua provided by SkyAPI 
-- Game: Antarctic Heritage Trust
addappid(1193510)
addappid(1193511, 1, "78c57d4e84e370161dad782ec3eaee449798039ccc85c045285a6b6b1e26ec1a")
