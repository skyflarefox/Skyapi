-- Lua provided by SkyAPI 
-- Game: Sengoku:Battle Royal
addappid(2867440)
addappid(2867441, 1, "6273b8e1e0f6a58f0f8cd92f53920f26d677cbb9f2f60d68b47a2445790b482f")
