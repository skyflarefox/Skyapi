-- Lua provided by SkyAPI 
-- Game: Kick The Puppet
addappid(977900)
addappid(977901, 1, "f11f4e635ad2b8d8868b6b49e812f7bd4acf6b5e40466f9dc2a37e138feda20e")
