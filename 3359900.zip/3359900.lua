-- Lua provided by SkyAPI 
-- Game: REAL BOUT FATAL FURY 2: THE NEWCOMERS
addappid(3359900)
addappid(3359901, 1, "939a4aa533fd1eade4a02356eb95e41e1026753c56a85d974d6cce1e4b25ca82")
