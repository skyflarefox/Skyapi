-- Lua provided by SkyAPI 
-- Game: GourMelee
addappid(1081410)
addappid(1081411, 1, "5b6e19565b16440609b96f33eda3fbdcc05d74d4686e4b029b503f5f4243aa19")
