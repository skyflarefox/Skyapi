-- Lua provided by SkyAPI 
-- Game: Sliding Blocks
addappid(701970)
addappid(701971, 1, "d4d020070020484553cd4edc8d1d8166bb94dac9330208f407d0d89a8de5ce08")
