-- Lua provided by SkyAPI 
-- Game: UberSoldier
addappid(2905090)
addappid(2905091, 1, "3f2217f3705dc0d8727902039b450870241887d3269e44e722581c98ce6cf611")
