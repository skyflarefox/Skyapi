-- Lua provided by SkyAPI 
-- Game: AppID 3230110
addappid(3230110)
addappid(3230111, 1, "48ed21448d67a6c56657cf964110d62a9df4838d01f481045a34ee01c80f66d4")
