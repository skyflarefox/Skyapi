-- Lua provided by SkyAPI 
-- Game: Magic wand
addappid(3109480)
addappid(3109481, 1, "d70c20a50c3535ad43e3c3ed58c46ad2f88d4f45a08eb43861ad948deb91a1dc")
