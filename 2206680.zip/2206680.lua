-- Lua provided by SkyAPI 
-- Game: Halt
addappid(2206680)
addappid(2206681, 1, "cfd21df714a1a2674ecfd9f991b4efd4dc27e16962c7f67d3c3bccf309539dde")
