-- Lua provided by SkyAPI 
-- Game: ModBots
addappid(1818960)
addappid(1818961, 1, "9630475e1251418d56f3abc6abdcc33157b9aa0813c1420fe03a5f9ab387027e")
