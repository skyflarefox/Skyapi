-- Lua provided by SkyAPI 
-- Game: Clutch
addappid(35310)
addappid(35311, 1, "4e87f34dbd4e16bf608195f5bc7b67d2204f007a42daac8747ef1a4ca00ce374")
