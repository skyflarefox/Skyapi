-- Lua provided by SkyAPI 
-- Game: Souls of White Star
addappid(1772050)
addappid(1772051, 1, "e2bcfd8c9279a9384ec0b7e5867826afa026bbc41b00e0c4230bebd79de029c5")
