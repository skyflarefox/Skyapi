-- Lua provided by SkyAPI 
-- Game: Luxor HD
addappid(361020)
addappid(361021, 1, "00e8bd2255fde2a6710c289b35eeaf056d3cc1eab869ecc1d0e63737a6d7fba7")
