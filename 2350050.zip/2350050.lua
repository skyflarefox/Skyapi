-- Lua provided by SkyAPI 
-- Game: Cosmic Survivor
addappid(2350050)
addappid(2350051, 1, "d37a0eeb052ba21bce21ce2201a8f18b67f1009f69ed80a8c00c3608087309b9")
