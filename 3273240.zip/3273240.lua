-- Lua provided by SkyAPI 
-- Game: DYNASTY WARRIORS: ORIGINS Demo
addappid(3273240)
addappid(3273241, 1, "fe9f86ccf4158ce692f1d0a3e0bc277d689640e5edc7eb3ee53a62541d6ab8c9")
