-- Lua provided by SkyAPI 
-- Game: Everdream Valley
addappid(1403650)
addappid(1403651, 1, "05a2c84ec7278d6ab3d89d68bd1078d2def724ffd621fe4e9143d9cec8329bd3")
