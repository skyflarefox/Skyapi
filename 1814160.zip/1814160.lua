-- Lua provided by SkyAPI 
-- Game: Crazy Santa
addappid(1814160)
addappid(1814161, 1, "4ec74e7c7546a7b03d8b4695785b08445379b0738823fbad044f2173dbb11125")
