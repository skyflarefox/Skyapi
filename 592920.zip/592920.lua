-- Lua provided by SkyAPI 
-- Game: Inception VR
addappid(592920)
addappid(592921, 1, "33e6df063ebb0b5fd72b5554d4e539c772ffbe894fb25263e4145e908c6b9640")
