-- Lua provided by SkyAPI 
-- Game: High Octane Drift
addappid(457330)
addappid(457331, 1, "47663e7eed935d83a5b9a7e5908d14e50cc5f33499cb7cf24041e40dd5b5969d")
addappid(457332, 1, "a82ec9c729c6aa80687e055642c44baf4fe4a963d81c4a585fae97c5ca87630e")
