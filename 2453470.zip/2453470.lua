-- Lua provided by SkyAPI 
-- Game: Plunder Masters Demo
addappid(2453470)
addappid(2453471, 1, "86a4c09206fa18ad87a6734add51697888abd47c54c0d74dd719fef09c8ed32b")
