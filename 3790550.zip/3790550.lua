-- Lua provided by SkyAPI 
-- Game: Rogue Paper Scissors
addappid(3790550)
addappid(3790551, 1, "a32a5de75ec63802a08003f263efbcd37a2e94e042f962612a5748440d353e10")
