-- Lua provided by SkyAPI 
-- Game: DX-Ball 2: 20th Anniversary Edition
addappid(922400)
addappid(922401, 1, "3ef89d51937eaf9113afc97e88e907ae39491c0a1e85698c9df931c1575f479f")
addappid(1001780, 0, "35c1425619baae48575250716fce413bc102647528def2a146b2315a43794562")
addappid(1001781)
addappid(1001782)
addappid(1001783, 0, "9ad99d6262d4b4f8d87f1fed57adcba61c872860ba4ebbad95ee7d3828c887f7")
addappid(1001784, 0, "ee9128d3999e5c2dc8d32fd1feef921e593d99cd5b2307d8a3b25b4157212e52")
