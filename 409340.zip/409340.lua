-- Lua provided by SkyAPI 
-- Game: AppID 409340
addappid(409340)
addappid(409341, 1, "2fa6b5f66bb6b81ec1648af7ea6ef675ab5617c98501b20cee1a4e6fe8baf9b5")
addappid(470080)
