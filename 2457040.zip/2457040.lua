-- Lua provided by SkyAPI 
-- Game: Thyria: Step Into Dreams
addappid(2457040)
addappid(2457041, 1, "4e7cd9c008a2eb634e0d18519f755e46a4626bdb0f9e74a2dc6c75cb542fa1ae")
