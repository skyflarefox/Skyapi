-- Lua provided by SkyAPI 
-- Game: AppID 2523620
addappid(2523620)
addappid(2523621, 1, "74acabc54820d1d1b070c7d1085bdfa1eaa76e24ac4ab77d22f47ac40e79bc55")
