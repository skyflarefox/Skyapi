-- Lua provided by SkyAPI 
-- Game: DEEP IN THE DREAD
addappid(3323770)
addappid(3323771, 1, "6208919b7e1c7f0d0071dc326bea51e22ee06f4667e6ad24ab9b52ae144018f7")
