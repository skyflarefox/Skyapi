-- Lua provided by SkyAPI 
-- Game: AppID 527270
addappid(527270)
addappid(527271, 1, "0b5da2cfbeae1d80d580f66b2d50625231e42d45589aa7e21a56fc2c86a3c74a")
