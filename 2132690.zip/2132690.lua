-- Lua provided by SkyAPI 
-- Game: Vivat Slovakia
addappid(2132690)
addappid(2132691, 1, "65089430108460a99f1873b6dd45308d6f6363e72b61179582cb7562e11af745")
