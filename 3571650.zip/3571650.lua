-- Lua provided by SkyAPI 
-- Game: ROOM FOOTBALL - Hangar
addappid(3571650)
addappid(3571651, 1, "86f269526aba61447362293744d145ec4a2e61bc3f6fb3857ee6f8a2b034f97c")
