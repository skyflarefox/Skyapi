-- Lua provided by SkyAPI 
-- Game: AppID 3013520
addappid(3013520)
addappid(3013521, 1, "036c15a030f8b2ae8461eed547c978e33952eb34374fb67158df36849594a616")
