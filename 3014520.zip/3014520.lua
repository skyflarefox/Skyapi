-- Lua provided by SkyAPI 
-- Game: BrokenLore: LOW
addappid(3014520)
addappid(3014521, 1, "9ebdfdd344e8831199145bd672e2c82a848e9f03b3e1bb68b32b81ff733ccaa7")
