-- Lua provided by SkyAPI 
-- Game: AppID 2923370
addappid(2923370)
addappid(2923371, 1, "2f811f89a8842339d55af6b469213db7fc510f63bd150aff663c5daef88d7cb1")
