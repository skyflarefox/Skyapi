-- Lua provided by SkyAPI 
-- Game: AppID 1051950
addappid(1051950)
addappid(1051951, 1, "4b5560557352fedef56f33773a4a588edf481b6c25247e608e8fed4696988b5b")
