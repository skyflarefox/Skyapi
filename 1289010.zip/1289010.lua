-- Lua provided by SkyAPI 
-- Game: Haypi Monster 3
addappid(1289010)
addappid(1289011, 1, "2645da63a7228b49049f37c09393186c062d93943cd5aa8a7dd5f8dca5a0c363")
