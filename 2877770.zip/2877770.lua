-- Lua provided by SkyAPI 
-- Game: Into the Restless Ruins
addappid(2877770)
addappid(2877771, 1, "c32c1ceb29c1499590334c45e2c8e8108d118244bee3dcce9c7ee1029aa4385e")
