-- Lua provided by SkyAPI 
-- Game: AppID 1387200
addappid(1387200)
addappid(1387201, 1, "e38a02dd30c809c92fbd4af9bf314b75f05cb0ebb603c6b72be5bd07b0f364de")
addappid(1387202, 1, "346ecc3fd03957e9a29b28e115715693b8c1e897e3886beeca54e783ba22fb3e")
