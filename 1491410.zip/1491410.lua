-- Lua provided by SkyAPI 
-- Game: Eternal Strands
addappid(1491410)
addappid(1491411, 1, "e4195a57e3f14ccbdf4be2fa5c576bb10366f40df6a80f47b31f6d71e918cdc4")
