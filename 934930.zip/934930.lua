-- Lua provided by SkyAPI 
-- Game: RDS - The Official Drift Videogame
addappid(934930)
addappid(934931, 1, "f54bafe2333dceab35812d3990e57d83d9c16ba31490a765ad6b43ba9090f325")
