-- Lua provided by SkyAPI 
-- Game: The One Penny Adventure
addappid(2082990)
addappid(2082991, 1, "820d1b9836ccd8d515150995a591eb3d7603c95ce70a595e14c7b51724839fd5")
