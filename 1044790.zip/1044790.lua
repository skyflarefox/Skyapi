-- Lua provided by SkyAPI 
-- Game: Gado Fight
addappid(1044790)
addappid(1044791, 1, "d81d8d50a876a35bbfd7927770b72a0c46ce3217cf24df385fd45bdd7f326127")
