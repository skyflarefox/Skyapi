-- Lua provided by SkyAPI 
-- Game: True Puzzle
addappid(780020)
addappid(780021, 1, "9cd33db232a21fd6f0f8eeab0192a458bda6312124e4f41890a4d9c8e05419df")
addappid(1006280, 0, "4d74d73922b87499f2118e438326ef8765b5f28804aad48755d8e1d74c65b3ec")
addappid(1006281)
addappid(1006282)
