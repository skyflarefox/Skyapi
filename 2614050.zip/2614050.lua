-- Lua provided by SkyAPI 
-- Game: Magnet Block Demo
addappid(2614050)
addappid(2614051, 1, "19abffc2a1232ebbe9ee9219bdb668b47e635aeddb907b343153f17bf741adb5")
