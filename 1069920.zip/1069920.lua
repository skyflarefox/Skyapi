-- Lua provided by SkyAPI 
-- Game: To the Stars and Beyond!
addappid(1069920)
addappid(1069921, 1, "14d693508df2a1ae05e355e42edbcbc5cb29d47949e8079b2b43def89050632a")
