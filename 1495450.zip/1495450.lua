-- Lua provided by SkyAPI 
-- Game: AppID 1495450
addappid(1495450)
addappid(1495451, 1, "27f7a1d0d831f51c19b6c52771f4446b3638432daee05d3e1defee57c00a9c7e")
