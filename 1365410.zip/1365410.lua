-- Lua provided by SkyAPI 
-- Game: My Universe - Fashion Boutique
addappid(1365410)
addappid(1365411, 1, "2a2f8f83b7a31ee378e56e2e5360c15250398e0efd584c171848b25b8228060d")
