-- Lua provided by SkyAPI 
-- Game: Hoop Gawds
addappid(1298220)
addappid(1298221, 1, "c6e5056ac6b49e22d25e4f085640db69ee700668a5c30b99d10f468fd8ac4151")
