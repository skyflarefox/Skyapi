-- Lua provided by SkyAPI 
-- Game: Jewel Match Twilight
addappid(2177540)
addappid(2177541, 1, "5b53ec225d8370f2c68e26329191958d48529e98330d464c28a0df038dc063df")
