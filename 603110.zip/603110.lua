-- Lua provided by SkyAPI 
-- Game: Grizzland
addappid(603110)
addappid(603111, 1, "452c341301e7fa0a66f50bf8bb428c034857e357ec3c5fccc74860da9075c203")
