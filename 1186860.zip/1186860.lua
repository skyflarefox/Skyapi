-- Lua provided by SkyAPI 
-- Game: AppID 1186860
addappid(1186860)
addappid(1186861, 1, "3ccb28e304edd0ead286d31b829521df83e00deb2c1c3aa5a69f85ebe458ba1e")
