-- Lua provided by SkyAPI 
-- Game: Myths Of Orion: Books of Power
addappid(288670)
addappid(288671, 1, "c04d45912576fe68a6e0dd18f7da6c16251243205f03115d5d69ac09ef63c6be")
addappid(288672, 1, "3ba0431f7368afcf5ec0bb4ed6f5ad0094234bc0b7b8bcfd730420ed7c0cb5f5")
addappid(288673, 1, "5c989664ae15aa98d7a8fd1632bccf2739a77f633abc4fa599cb4fec9f6b024e")
