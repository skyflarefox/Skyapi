-- Lua provided by SkyAPI 
-- Game: Rush Heroes
addappid(2813330)
addappid(2813331, 1, "d217a2d5da0cdd66115d700905058ccc50cfcbd36041c1e2527715dfabdb8035")
