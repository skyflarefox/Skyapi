-- Lua provided by SkyAPI 
-- Game: Sex Adventures - Mile High Club
addappid(1925230)
addappid(1925231, 1, "7cbe6c2ff75799e634165ff2786ec65949fc42a4ab433c207b30ed3f742d3b65")
