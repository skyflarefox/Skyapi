-- Lua provided by SkyAPI 
-- Game: Switchcars
addappid(442210)
addappid(442211, 1, "99904e33291b1add2c471adb1de24c2efcc994d36a56f09c66247e3d1d20efc6")
addappid(442212, 1, "94a0ec16a0e5fc0767dfda8f778d6f65713c8a6e6805c4d94ef4287523bb79fd")
