-- Lua provided by SkyAPI 
-- Game: Summer Islands
addappid(731650)
addappid(731651, 1, "312cd8c606cd3a9e79659d4d40ae26625d253ba338aa6acd18b15d2c688d45a5")
addappid(731652, 1, "c93f54961e2f32b34dc6e1e88a4a4bb076e6e38922b717210c3a696bd6ef19cf")
