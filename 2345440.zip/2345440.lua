-- Lua provided by SkyAPI 
-- Game: Piscirazzi: Fish Photo Shooter
addappid(2345440)
addappid(2345441, 1, "59294fb5c869f855e939cd86f0e991061cae9ea3db46d8a60f7a59578e97988a")
