-- Lua provided by SkyAPI 
-- Game: AppID 769220
addappid(769220)
addappid(769221, 1, "24a60bc3fe5d19316e502a5a16f8fbc1c18e7feb5138c6d1f19e54f0383253b5")
addappid(779350, 0, "712a33196a6c07a6d1c5e71f122029f79bb3ecd00b18cbf6901ed26b82a607f8")
