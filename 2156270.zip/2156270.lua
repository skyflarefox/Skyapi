-- Lua provided by SkyAPI 
-- Game: AppID 2156270
addappid(2156270)
addappid(2156271, 1, "91292afe057fd73900b2e42803779e7f6441127e379d1ebf8d919cafebbdfb6a")
