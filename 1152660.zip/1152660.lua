-- Lua provided by SkyAPI 
-- Game: AppID 1152660
addappid(1152660)
addappid(1152661, 1, "c31cdabce139a700340c49f2ae61151ce8890a684629eea2ced653facaf82213")
