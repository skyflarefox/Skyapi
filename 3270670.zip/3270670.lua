-- Lua provided by SkyAPI 
-- Game: AppID 3270670
addappid(3270670)
addappid(3270671, 1, "2d62b12fc79666cc6926fe1237bf8798c46c1468893ea7f52a52aefca48ce88f")
