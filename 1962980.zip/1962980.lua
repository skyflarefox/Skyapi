-- Lua provided by SkyAPI 
-- Game: Aierlon
addappid(1962980)
addappid(1962981, 1, "23d0bb11e1f5c273e92fb006770cdeaa345d9b16ac8c8d034529e6da7b53b68b")
