-- Lua provided by SkyAPI 
-- Game: AppID 1113850
addappid(1113850)
addappid(1113851, 1, "974dbea0ea11f79ef8d6a78afcbe374549d5fd88aee5aecb45539d3ce84752e7")
