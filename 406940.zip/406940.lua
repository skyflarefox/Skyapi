-- Lua provided by SkyAPI 
-- Game: Dub Dash
addappid(406940)
addappid(406941, 1, "641f7fdb9b95b51d702b54583e73cf48770b1da18c272dd8362fe13f69a30a47")
