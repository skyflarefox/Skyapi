-- Lua provided by SkyAPI 
-- Game: trip=true
addappid(1757880)
addappid(1757881, 1, "d25131f460e3e830928eefa54a37bd156c2e5a2cb66be54edd18c254c4d85e88")
addappid(1759300)
