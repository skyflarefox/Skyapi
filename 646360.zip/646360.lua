-- Lua provided by SkyAPI 
-- Game: AppID 646360
addappid(646360)
addappid(646361, 1, "06bb76e12dcea1c4b5ebb48662b13c1df65ccaded92946a17d0db9ac9115dc9f")
