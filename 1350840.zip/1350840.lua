-- Lua provided by SkyAPI 
-- Game: Song Of The Prairie
addappid(1350840)
addappid(1350841, 1, "e9d078024c3e02c79b8a6f7548eff51b462cbd1d3dd55d5a7aabf59e46989a7b")
addappid(2522580, 0, "e89ce503476a4295297ed741f812d06ad0075cb0af1986a60ebf050064cbf0fb")
addappid(3068290, 0, "71c4bb8b08a74d59951749e728eae8214b036cd81872ddb52e4049101752a946")
