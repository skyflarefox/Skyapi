-- Lua provided by SkyAPI 
-- Game: Cube Island
addappid(1587910)
addappid(1587911, 1, "2a1a6f6842c42a169368ce81751e0d26b1c5386ce205631fb84d215fb7d98ac9")
