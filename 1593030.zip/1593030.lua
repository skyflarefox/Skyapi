-- Lua provided by SkyAPI 
-- Game: Terra Nil
addappid(1593030)
addappid(1593031, 1, "fb819bd41659158d7eaf863588d03381b5065204e716c1f1630ed65a185aa897")
addappid(2321930, 0, "02757f56a474735a503289ae2b52ffb6aeda1c41eb2eec9b5e04bd596eca88d3")
