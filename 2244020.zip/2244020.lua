-- Lua provided by SkyAPI 
-- Game: Riley In The Abyss
addappid(2244020)
addappid(2244021, 1, "9da21f4f5b7d59b6b58a9d0ab56d22daa2995cc6d5fcae7aa53596118f2f0375")
