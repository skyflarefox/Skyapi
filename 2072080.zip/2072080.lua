-- Lua provided by SkyAPI 
-- Game: Super Demon Survivors
addappid(2072080)
addappid(2072081, 1, "a4f4b8e5c1cb8597e8cecd34a147de3fad18da5010bc7b37f4db6ac16b578f02")
