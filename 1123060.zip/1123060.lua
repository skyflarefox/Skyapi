-- Lua provided by SkyAPI 
-- Game: AppID 1123060
addappid(1123060)
addappid(1123061, 1, "84352a658fd3de02bea6328ad903527e9690f7fd83835bb04a6ace117097118c")
