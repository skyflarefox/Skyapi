-- Lua provided by SkyAPI 
-- Game: RollerCoaster Tycoon® 3: Platinum
addappid(2700)
addappid(2701, 1, "0eb3ce09e083b32754f751a54bf35789af844c680114bc6ac9997f944b1e3dbb")
addappid(2702, 1, "16cb9e4d64b0809a1ffe696faa7286ffb0af5dff7887d903ad3d8eb72737c96f")
