-- Lua provided by SkyAPI 
-- Game: Spiderbro
addappid(2059060)
addappid(2059061, 1, "8431a7d57a9356af919a686e3aaf6ffb2a3762856efd5907a3d0c810df5482d1")
