-- Lua provided by SkyAPI 
-- Game: AppID 779330
addappid(779330)
addappid(779331, 1, "ea8af4211e9364a2babf43efa7caa3dcbde51dbbe8aa78739f04770bcee45d07")
addappid(779332, 1, "3285c7a4605f2e2ba0196061de7c54491a7efbd17cc4a59f6b3a6dfa1a39e0d9")
addappid(779333, 1, "62f37b86523db1b241740fd660106d1790c5cadc57b4f776383e7727a1852a56")
