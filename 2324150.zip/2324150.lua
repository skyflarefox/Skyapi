-- Lua provided by SkyAPI 
-- Game: Neuroshima Hex
addappid(2324150)
addappid(2324151, 1, "3cf60845882cfe04c21b3cb40e17d2351f1cca6a6eff0127531fc9db73c69d30")
