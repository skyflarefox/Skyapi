-- Lua provided by SkyAPI 
-- Game: FreshWomen - Season 2
addappid(3478650)
addappid(3478651, 1, "ac18510eeb2d0b975c7fb8019572de8c568179c25d765f22223bce123eff775b")
addappid(3930100, 0, "4cfc083bd45f19ea36197cdeafdf100cb186c1e56d447b80f94517f1fa9c60bd")
