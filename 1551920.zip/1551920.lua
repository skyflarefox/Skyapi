-- Lua provided by SkyAPI 
-- Game: Whisper Trip
addappid(1551920)
addappid(1551921, 1, "f4a8533443c697a6e38d4b06d03f6188c9b98e0b4f03859d6fb1f09e85fc821c")
