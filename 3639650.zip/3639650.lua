-- Lua provided by SkyAPI 
-- Game: Kotama and Academy Citadel
addappid(3639650)
addappid(3639651, 1, "1d8e7052572c205bad0554d9198e38b66c9e5c7e9633df56ec3fe95b9636f264")
