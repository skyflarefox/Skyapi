-- Lua provided by SkyAPI 
-- Game: Within the Range
addappid(1693000)
addappid(1693001, 1, "e8b69b79baadb67ab60c84690d7df384b20ff2054edc31a31b5e7c41a3c2485c")
