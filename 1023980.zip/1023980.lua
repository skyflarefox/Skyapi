-- Lua provided by SkyAPI 
-- Game: V.L.A.D.i.K
addappid(1023980)
addappid(1023981, 1, "aa6b71fc5824f192ecd792ca941622453d7ea4efb36c819c571b415d0d7cdec9")
