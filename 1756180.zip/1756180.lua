-- Lua provided by SkyAPI 
-- Game: CARNAGE OFFERING
addappid(1756180)
addappid(1756181, 1, "f674ed4ec4df45a1601705d18a4c93fab7239a649223b82ad3853064e19c7189")
