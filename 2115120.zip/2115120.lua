-- Lua provided by SkyAPI 
-- Game: Pedal to the Metal
addappid(2115120)
addappid(2115121, 1, "c4a45ad447a7b3dfb46d801f3d6387949ec0e355217b317df73865a8d8acc2e1")
