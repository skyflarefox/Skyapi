-- Lua provided by SkyAPI 
-- Game: Eventide: Slavic Fable
addappid(406870)
addappid(406871, 1, "a570623bf46fc61a6450a8b5263c61723fdfa2f395f9a2467894a3b8cf4eaa1a")
