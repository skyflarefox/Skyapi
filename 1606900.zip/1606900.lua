-- Lua provided by SkyAPI 
-- Game: AppID 1606900
addappid(1606900)
addappid(1606901, 1, "b095b79f809c6a2e7c4e88cbde3975314aa73f7033dbb065d9363f6887198604")
