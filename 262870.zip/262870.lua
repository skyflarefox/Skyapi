-- Lua provided by SkyAPI 
-- Game: Recovery Search & Rescue Simulation
addappid(262870)
addappid(262871, 1, "9d0d3590ab0ca4ed1da08c945cb72725fbee7e2f3d55f01cccbd3f32e73d9be5")
