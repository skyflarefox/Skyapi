-- Lua provided by SkyAPI 
-- Game: Jack Keane
addappid(12340)
addappid(12341, 1, "a50f7f5229785c30f8fee6ee98e984425e39d54bcab630b7999cce14f6077f2a")
