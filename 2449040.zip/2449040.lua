-- Lua provided by SkyAPI 
-- Game: Cursorblade
addappid(2449040)
addappid(2449041, 1, "e4c5d1c33d93e150c74486b84b0bc6a4d91d790a2b8dd0de7b2b1c9d70829a1e")
