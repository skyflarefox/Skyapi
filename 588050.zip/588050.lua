-- Lua provided by SkyAPI 
-- Game: AppID 588050
addappid(588050)
addappid(588051, 1, "922681e7c1855e42b72f8c73980f16537fa09d83227f7206935530eaeabc0a70")
addappid(588052, 1, "d8332b43f9e2e1257ee4e63944f4d875b9cb0d2a52dcfb5fc01e6bb04aaa85b5")
addappid(588053, 1, "8a83d7cead5953c1644d64ea849f4012ee8e6dc2a73c642a3ccbd112d1bd5da3")
