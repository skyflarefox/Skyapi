-- Lua provided by SkyAPI 
-- Game: Finding Anastasia
addappid(2538330)
addappid(2538331, 1, "3f052ec7d74b2a80dce8657adb0be38916e7a3588506e78b2873d6ed467b8aa9")
