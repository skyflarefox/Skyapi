-- Lua provided by SkyAPI 
-- Game: AppID 1170940
addappid(1170940)
addappid(1170941, 1, "62440cb9c7e3e97a3e1e5fb018175b4b8f4e88c21ea5ec37e42f27f7a97ffcd5")
