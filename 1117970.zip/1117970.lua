-- Lua provided by SkyAPI 
-- Game: AppID 1117970
addappid(1117970)
addappid(1117971, 1, "faf0e4fedfe50d2a44c9fc9033b875b55375ddd5bd0fe50919c046ce3b380047")
