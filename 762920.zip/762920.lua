-- Lua provided by SkyAPI 
-- Game: AppID 762920
addappid(762920)
addappid(762921, 1, "757e7884b8da2e208f89cb25a398c16878b62d4bc7e6d73f5a7c367a561f00d6")
