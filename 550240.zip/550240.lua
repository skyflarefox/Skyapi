-- Lua provided by SkyAPI 
-- Game: After Life - Story of a Father
addappid(550240)
addappid(550241, 1, "622a8fed5c5b234a841b72562488909c6e4bfc786105b9d3793665ce47840770")
addappid(561720, 0, "88a46f96495f527abe4154eb58ba035e4d0ebe8a9affa01d2b878e5d4edfa6a4")
