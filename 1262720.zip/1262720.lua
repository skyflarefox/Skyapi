-- Lua provided by SkyAPI 
-- Game: Ruin Raiders
addappid(1262720)
addappid(1262721, 1, "bd5e351a2d83912a74429afd8658a7e2bc9cf4d99e7b0f746080b7be8612f71e")
