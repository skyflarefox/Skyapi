-- Lua provided by SkyAPI 
-- Game: Thymesia Original Soundtrack
addappid(2117330)
addappid(2117331, 1, "ad99d0552579af595eaf8e780b12c0a0f33ac2eaa64472069f4991b1e00b7007")
