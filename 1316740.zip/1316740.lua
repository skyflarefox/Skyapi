-- Lua provided by SkyAPI 
-- Game: Extreme Escape
addappid(1316740)
addappid(1316741, 1, "217fd2fad6c55e8d8e799a73e3d2d988bffb070d8f117226bd26a5502234b82a")
