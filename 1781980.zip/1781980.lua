-- Lua provided by SkyAPI 
-- Game: Mini Island: Winter
addappid(1781980)
addappid(1781981, 1, "4d221ac0a91f76c2d0f699ebe48ab34255a4fa599caed48043d00e63149d9e1a")
