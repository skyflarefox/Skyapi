-- Lua provided by SkyAPI 
-- Game: MadOut Ice Storm
addappid(400500)
addappid(400501, 1, "80ab91eafbb04fe8404fa958b26209b176874e00cab1f0d3ed22c1e6c221afa0")
