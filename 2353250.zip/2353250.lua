-- Lua provided by SkyAPI 
-- Game: AppID 2353250
addappid(2353250)
addappid(2353251, 1, "6eb33634aeb57c51ab14b8099974d93148de8b54d7a4104cf3b7d6e2aac1b425")
