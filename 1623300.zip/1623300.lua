-- Lua provided by SkyAPI 
-- Game: Model Building Restoration
addappid(1623300)
addappid(1623301, 1, "cec862ef2d5bc52d78d9ebfccd0662924db3dcc2e0b93880f2f66e093dc04a87")
