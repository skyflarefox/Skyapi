-- Lua provided by SkyAPI 
-- Game: FILTHY US
addappid(1788170)
addappid(1788171, 1, "49b1d1d33bdb486ca2fd0dc2f3f4505848867af098604f10ab406858240816d0")
