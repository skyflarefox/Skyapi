-- Lua provided by SkyAPI 
-- Game: AppID 2459310
addappid(2459310)
addappid(2459311, 1, "5e9f55ec3b2b02763db3d6314a4a186c9358cb38b12959fde8bb43a20e377ab6")
