-- Lua provided by SkyAPI 
-- Game: Chime
addappid(62100)
addappid(62101, 1, "4f4b5b383a504a4e640c3b86a2fe1cfe73f8da90e6f3ef1c0110b4281e2f5c8a")
