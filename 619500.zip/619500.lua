-- Lua provided by SkyAPI 
-- Game: cyubeVR
addappid(619500)
addappid(619501, 1, "04edff8314d48a82cfcca536be9da1d8a512b3c204b3044063ec08f5515f4030")
