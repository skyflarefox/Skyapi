-- Lua provided by SkyAPI 
-- Game: Cats in Heat - Summer Fling
addappid(2278780)
addappid(2278781, 1, "853ee3e53c1fb7349d0f7bd2d7f2a462eb3a59f74b13086739ca955655df73cb")
