-- Lua provided by SkyAPI 
-- Game: AppID 711550
addappid(711550)
addappid(711551, 1, "b7859b791751ae421edc0dd8d2a34deba470031f4b6c6e740673b0a363e4a876")
