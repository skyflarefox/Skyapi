-- Lua provided by SkyAPI 
-- Game: Black Skylands
addappid(1143810)
addappid(1143811, 1, "f1be9d8e6df2ff518fad12aaef496dd12e89500f6827193e9660bf84dbb53aee")
addappid(1799480, 0, "e81dffde37487dea48e17245e183fbc4687e9273a903391960be64b41f6204dc")
