-- Lua provided by SkyAPI 
-- Game: AppID 729300
addappid(729300)
addappid(729301, 1, "7c35a5e9a495882098014550f8356278a9856247871b18d01e86c8a99eee1cb5")
