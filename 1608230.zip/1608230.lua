-- Lua provided by SkyAPI 
-- Game: AppID 1608230
addappid(1608230)
addappid(1608231, 1, "111bd9a2a83debc63dae7c527c541ebaa1192ccce92e1ce0f44f41dea9bc75f7")
