-- Lua provided by SkyAPI 
-- Game: AppID 1236700
addappid(1236700)
addappid(1236701, 1, "b90a64fb8218554b2e51d93a715742d52432e249a9a7d2cd78c6ef8c3fb653e9")
