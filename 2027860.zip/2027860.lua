-- Lua provided by SkyAPI 
-- Game: Search 4 Bigfoot
addappid(2027860)
addappid(2027861, 1, "ec80b5bb5964b6aa5455df0046e64ce424e501bc36f0432b31ed526df4a48ccc")
