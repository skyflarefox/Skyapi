-- Lua provided by SkyAPI 
-- Game: Drop Doll
addappid(2459870)
addappid(2459871, 1, "d9eb75528572dba6f955fd1caf97619cb6f2daf92d28ba9a3ece8fdd4a86487f")
addappid(2498360, 0, "f5c1374e10b02662a58e62576faa8ee6fcf64c1dc18bc44bbbc25e2aed222f28")
