-- Lua provided by SkyAPI 
-- Game: AppID 500670
addappid(500670)
addappid(500671, 1, "ef138ba9830d8db90c66018e998a9d71e2d83b74ce657a4197e2f53906b4ab97")
addappid(500672, 1, "43000ac1c7f882bae9001f05f4254dfe7d41ae1aefc3b3703b43d1e862b29c66")
