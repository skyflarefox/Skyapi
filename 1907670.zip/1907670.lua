-- Lua provided by SkyAPI 
-- Game: GoBangTetris Demo
addappid(1907670)
addappid(1907671, 1, "68937fbc58238bf43edc3a2a296f5162dbc701c2b3c2992bc96caf7df4e8a3e9")
