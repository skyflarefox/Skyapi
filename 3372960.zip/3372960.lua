-- Lua provided by SkyAPI 
-- Game: Christmas Infinity
addappid(3372960)
addappid(3372961, 1, "115c38d21d9c7683fb2bcb2202c3f62d80e7cc8c6f2d9a859bc5ed1b9900835f")
