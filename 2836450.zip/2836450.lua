-- Lua provided by SkyAPI 
-- Game: Casino Simulator 2024
addappid(2836450)
addappid(2836451, 1, "cb049175a1a9522047c9a3480a75517e34dd03973560261d964c96f9ee0bba94")
