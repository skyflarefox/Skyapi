-- Lua provided by SkyAPI 
-- Game: Data mining 5
addappid(1012860)
addappid(1012861, 1, "c2cff0b3a989d08a22656e19cabb76cfaaac736c3767c99ce9f23210c37818cb")
