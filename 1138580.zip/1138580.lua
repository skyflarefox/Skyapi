-- Lua provided by SkyAPI 
-- Game: AppID 1138580
addappid(1138580)
addappid(1138581, 1, "1fb41d479ffd59d486ea7657cddb2b648826e5559dcf9e827810873623a3e65f")
