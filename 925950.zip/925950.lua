-- Lua provided by SkyAPI 
-- Game: Here Comes Niko!
addappid(925950)
addappid(925951, 1, "819016b49285cb53f7bbb5a28bc9394f2e729f12f610f58b86469f2d51706205")
