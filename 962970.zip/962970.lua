-- Lua provided by SkyAPI 
-- Game: AppID 962970
addappid(962970)
addappid(962971, 1, "dd631398c8faf0171823c20a2650ea02ccde48674676e2676bc72de1b089f609")
addappid(2226560)
