-- Lua provided by SkyAPI 
-- Game: NejicomiSimulator Vol.2 Demo
addappid(1661220)
addappid(1661221, 1, "7d56bab892b6d59435055683b819278de0a6cfe383fb160773f49a0cc50fd595")
