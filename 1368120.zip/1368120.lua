-- Lua provided by SkyAPI 
-- Game: Messy Room Simulator
addappid(1368120)
addappid(1368121, 1, "97590ea230272eb4a7de6970a54e59620f21d467ff9f72958d7a3e6c0a1d6277")
