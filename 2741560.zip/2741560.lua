-- Lua provided by SkyAPI 
-- Game: SimCity™ 3000 Unlimited
addappid(2741560)
addappid(2741561, 1, "9d6b7b9c4e8115c01918ecfd6e9708f4c0819c81cab26a6574f453a68aa8e0dd")
