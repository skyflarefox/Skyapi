-- Lua provided by SkyAPI 
-- Game: The Renovator: Origins
addappid(1917550)
addappid(1917551, 1, "bbd0aebf560a55d8360256a1d40fee1557f0716a7fb40311f16e6d7004e964d9")
