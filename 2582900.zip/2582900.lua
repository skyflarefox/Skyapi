-- Lua provided by SkyAPI 
-- Game: Scary Maze Game
addappid(2582900)
addappid(2582901, 1, "90d1e27676bd42809499e5f6d3609fab2070ee973fe3f6890578ab01314b75a4")
