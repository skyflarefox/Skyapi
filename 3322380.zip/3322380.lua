-- Lua provided by SkyAPI 
-- Game: Blend_IT
addappid(3322380)
addappid(3322381, 1, "3dc1ffa53f986ced2e3c0de16512b44aa811f01b3d184f820f8043a0e1f24a16")
