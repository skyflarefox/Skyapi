-- Lua provided by SkyAPI 
-- Game: AppID 720480
addappid(720480)
addappid(720481, 1, "7061406c45e7291bc5f7ffe34e5c1096b5b8a1d039347ab81a84fa91472189f8")
addappid(722310, 0, "f65ef3c687dedd1d2a3c7595d42389dd483b1f2eba44750734554d8338ebe8df")
