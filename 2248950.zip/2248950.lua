-- Lua provided by SkyAPI 
-- Game: Trans-Siberian Railway Simulator: Prologue
addappid(2248950)
addappid(2248951, 1, "c61e8fac795f5cb589da9ebd004f86efd410b2c7fda301ecfbe680ef85b383d0")
