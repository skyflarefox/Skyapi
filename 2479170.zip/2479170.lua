-- Lua provided by SkyAPI 
-- Game: Tonight, I Die in My Sleep
addappid(2479170)
addappid(2479171, 1, "f9eb869d58d890e80244a744216997b2745b0b0adcc673aeb969df6d5197fef6")
