-- Lua provided by SkyAPI 
-- Game: Morendo
addappid(2168870)
addappid(2168871, 1, "ba9ebe430f5c37b04e33f6ee1e1fe0fe84156b7313ffeb63d6937f4b3c722dd6")
