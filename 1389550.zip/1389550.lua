-- Lua provided by SkyAPI 
-- Game: Mind Scanners
addappid(1389550)
addappid(1389551, 1, "4e0c70fa54c378ae222263d616ea2dd8cbdc5b4d5630bf1e0e0e7684e66aea8d")
