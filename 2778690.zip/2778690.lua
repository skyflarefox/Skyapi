-- Lua provided by SkyAPI 
-- Game: Challenger's Odyssey
addappid(2778690)
addappid(2778691, 1, "70ae544882f2610bae50dad50f0ff5850e0d77e6525c62f59ef35b140bf21bfd")
