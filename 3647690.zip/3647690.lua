-- Lua provided by SkyAPI 
-- Game: Cuddle Corner
addappid(3647690)
addappid(3647691, 1, "7af601ac1162312b1d37d4cd4e5e82a3627bd7cd2137194208ec9e949b7bc2a3")
