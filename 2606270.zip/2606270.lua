-- Lua provided by SkyAPI 
-- Game: Cyber Avenger
addappid(2606270)
addappid(2606271, 1, "26a9f0b56280cf0c526f5181d426911fa592cecc2b0e646e52047d2d1451812c")
