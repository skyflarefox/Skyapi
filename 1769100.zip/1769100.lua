-- Lua provided by SkyAPI 
-- Game: Cosmic: A Journey Among Shadows
addappid(1769100)
addappid(1769101, 1, "07c3c074f024e19355be017b09180963c177be1c7c94dfef286776386e44dae9")
