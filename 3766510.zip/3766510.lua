-- Lua provided by SkyAPI 
-- Game: FART DROP DX
addappid(3766510)
addappid(3766511, 1, "f916186d767549b1c8289b51b1334de1683f828995088eaf408b69827b2c5698")
