-- Lua provided by SkyAPI 
-- Game: AppID 603250
addappid(603250)
addappid(603251, 1, "461601b49582833cd795f52918146ae6fae81f16cc4cccc26c3abebf89467e1d")
