-- Lua provided by SkyAPI 
-- Game: AppID 1191870
addappid(1191870)
addappid(1191871, 1, "41987c6c5c584387d2042bec360a245aec94056fc7d82e3e9b37fd72a1a2e18a")
