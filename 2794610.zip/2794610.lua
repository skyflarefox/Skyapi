-- Lua provided by SkyAPI 
-- Game: Massacre At The Mirage
addappid(2794610)
addappid(2794611, 1, "1120adfc90aa4e57c0416d48ba2ee87859c6760a82bce5bc393f742d808e3c04")
