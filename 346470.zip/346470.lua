-- Lua provided by SkyAPI 
-- Game: Tennis Elbow 2013
addappid(346470)
addappid(346471, 1, "434fbfc437670313405bd744eb11d5907961d2e7f3b7f425177401d584d94587")
