-- Lua provided by SkyAPI 
-- Game: Conan Chop Chop
addappid(1061880)
addappid(1061881, 1, "f16a0c04ecc844a861ff2fcd95ff97ae4d8de59daeb9e44d79148fb9b0a855a8")
addappid(1061883, 1, "1d561c642c2f3f570bb7ea1fcea699c0f789bc9c942ee9c30425479ef8a07629")
