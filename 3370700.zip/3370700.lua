-- Lua provided by SkyAPI 
-- Game: AppID 3370700
addappid(3370700)
addappid(3370701, 1, "ab3fcc68db9acf1f4f7a69b131fd2d6e78dbbead88d943cd1720fd3f9e92f717")
