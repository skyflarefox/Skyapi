-- Lua provided by SkyAPI 
-- Game: AppID 373750
addappid(373750)
addappid(373751, 1, "da220cc1aae8b1db4bef88e5fde09c555b9b9fd11a4e9f16c3509f4f1300cb7b")
