-- Lua provided by SkyAPI 
-- Game: War Tortoise
addappid(2120250)
addappid(2120251, 1, "a395c64e34d78ab6882baf18e6116b7a0260357ed026e053d5ae87e4387ca6cc")
