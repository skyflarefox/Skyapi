-- Lua provided by SkyAPI 
-- Game: AppID 1051570
addappid(1051570)
addappid(1051571, 1, "32e80864ab27691e39ab9e4370c463e3644efa0e8a7b9192915c64c57cb03d37")
