-- Lua provided by SkyAPI 
-- Game: Race
addappid(768800)
addappid(768801, 1, "6d264b2b6354ca14404b44e8f0b9a6398230235cc206c253d7fb6508ab6f615c")
