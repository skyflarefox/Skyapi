-- Lua provided by SkyAPI 
-- Game: AppID 1005050
addappid(1005050)
addappid(1005051, 1, "31019ef36be1ab093ac61147a6b34795fedab10fe5b3b6276e8739b197d4b053")
