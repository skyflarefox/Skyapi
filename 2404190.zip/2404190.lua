-- Lua provided by SkyAPI 
-- Game: Borefest
addappid(2404190)
addappid(2404191, 1, "73f1471d90f2ab8bf1fadbae798231073c380224b76d0793fbca483f57707094")
