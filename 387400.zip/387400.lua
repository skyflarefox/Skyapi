-- Lua provided by SkyAPI 
-- Game: AppID 387400
addappid(387400)
addappid(387401, 1, "c952b9a59eb7f54acce0a51c1c9b1cebc86a04f42fd9bf2a66ac7bcc543baa28")
