-- Lua provided by SkyAPI 
-- Game: Valor Mortis
addappid(2828711, 1, "3aa7bf74ac09da6be0b60fa92b918131bca6fa16306a8b4bd1a9084fd06a54e0")
setManifestid(2828711, "3604628958963660819", 45965871052)
addappid(5250300) -- Valor Mortis Deluxe Upgrade
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d")