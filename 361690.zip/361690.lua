-- Lua provided by SkyAPI 
-- Game: STAR WARS™ X-Wing vs TIE Fighter - Balance of Power Campaigns™
addappid(361690)
addappid(361691, 1, "3b2cf29dcdb3418b85c383877d933c8946d6617a53323725e9bbf5fe16b840e3")
