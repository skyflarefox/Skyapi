-- Lua provided by SkyAPI 
-- Game: AppID 907090
addappid(907090)
addappid(907091, 1, "aa44172f0180e1376e0362f3f4d1eea850b824c74e050113a90a4400a157f38f")
