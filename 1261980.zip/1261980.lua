-- Lua provided by SkyAPI 
-- Game: AppID 1261980
addappid(1261980)
addappid(1261981, 1, "28fb9bf1496b327c6ec5fca8afa3fb2683436c22e18d1037ce1b61110afc6f85")
