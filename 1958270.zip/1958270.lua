-- Lua provided by SkyAPI 
-- Game: Strip 'Em II: Facka's Game
addappid(1958270)
addappid(1958271, 1, "1e0fa4f435ac8add0843d3f69af029bd51a378ddf201bc0f5663e4781ea3bbda")
