-- Lua provided by SkyAPI 
-- Game: Pure Logic
addappid(1861500)
addappid(1861501, 1, "056a4a8d6364e01582289b50709f9ebec3385b242618cb6417423d655f33325d")
