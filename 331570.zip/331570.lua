-- Lua provided by SkyAPI 
-- Game: Wimp: Who Stole My Pants?
addappid(331570)
addappid(331571, 1, "149a04e7baf756545e329273f81f97953478a614b3fc1181c8c0e2e431ef991f")
