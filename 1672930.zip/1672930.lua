-- Lua provided by SkyAPI 
-- Game: 梅斯特姆
addappid(1672930)
addappid(1672931, 1, "34c22a337640b4fdcd240babeecf27792fd4e9fe1625b62f64d6a04ee8dc3ed5")
