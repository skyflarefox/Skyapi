-- Lua provided by SkyAPI 
-- Game: Glass Masquerade 2: Illusions
addappid(935880)
addappid(935881, 1, "38bcf8a07964d2e15f2e3207e14bcdc6c801315f050016d13565ab597a4f6d2a")
addappid(935882, 1, "4a7fc1f64780eb047121d3de7deaa5845d98514853a4be26f796bba3db3e97f9")
