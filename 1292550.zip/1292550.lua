-- Lua provided by SkyAPI 
-- Game: Lockdown
addappid(1292550)
addappid(1292551, 1, "56b9060e4867bd0b6ff9bda8167a8d931f2a4e9983ea2f9fb6cf2dac4ea3e095")
