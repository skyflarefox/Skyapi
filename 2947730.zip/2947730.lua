-- Lua provided by SkyAPI 
-- Game: 3D PUZZLE - Hospital 1
addappid(2947730)
addappid(2947731, 1, "7a6533bab1bb9c4fe4e1ad140a307140885414f5500f3c49f80669e90174fb9e")
