-- Main AppID
addappid(2936290)

-- Main Depots
addappid(2936291, 1, "d37e9bb5498f6c1def03fc192acb979995b0d76c9eacaeb410cc7fc6268a631a") -- (windows)
setManifestid(2936291, "8362624900479149727", 6322850631)

-- DLC's (with depot keys)
-- The Life and Suffering of Prince Jerian — Official Artbook & Wallpapers (AppID: 4892150)
addappid(4892150)
addappid(4892150, 1, "8bef97936e1e31c62285e827260a7a3a460a8933c8c5234a5886c44d2911ef3f")
setManifestid(4892150, "6384930306906564001", 355847588)
-- The Life and Suffering of Prince Jerian — Digital World Map (AppID: 4892160)
addappid(4892160)
addappid(4892160, 1, "7f3a1bf08247691dabd6e8140ffec1bb53983c37ed297b51b6208ea385a6eeba")
setManifestid(4892160, "9022251816851934585", 54020712)

-- Missing Depots (We don't have the keys yet lol): 4873871, 4873872, 4892151, 4892161
