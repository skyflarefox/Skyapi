-- Lua provided by SkyAPI 
-- Game: Nobody - The Turnaround
addappid(1810580)
addappid(1810581, 1, "0243ab0a120d40649c6fd221a81db41c79f57303cdcffdd17db18a783a72e39d")
