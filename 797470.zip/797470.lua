-- Lua provided by SkyAPI 
-- Game: AppID 797470
addappid(797470)
addappid(797471, 1, "cf70288ee39e7eb4328debdd6b7d850099aeac78763da97ba2a84a34aad6092f")
