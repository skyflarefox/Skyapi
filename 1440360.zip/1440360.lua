-- Lua provided by SkyAPI 
-- Game: Tanks in Labyrinth
addappid(1440360)
addappid(1440361, 1, "95f99e1cc67a65a09fe8b5bf12dea273474c7eaee1704835eb655a4bb431cdd9")
