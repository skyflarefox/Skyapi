-- Lua provided by SkyAPI 
-- Game: Aptly Rolling
addappid(1712730)
addappid(1712731, 1, "bfe44216583df61a24778ec56b333c5d9985b72b277131bfa53edc6d181c71e1")
