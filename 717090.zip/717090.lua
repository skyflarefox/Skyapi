-- Lua provided by SkyAPI 
-- Game: AppID 717090
addappid(717090)
addappid(717091, 1, "faa7fec07af4a0ef9fbf78fa7659e725991d4c548858418973aa32a6218d5d89")
addappid(717130)
addappid(718150)
addappid(718290, 0, "4cb97966f367fa7c3eebd2ebfafcc5b7c4c83fa32d31e757725706be9d615d19")
addappid(719920)
