-- Lua provided by SkyAPI 
-- Game: Realistic Ragdoll Sandbox
addappid(3048280)
addappid(3048281, 1, "4c6dfc73dd4bc4e4bea567490a70390e025d43a85b8b98c910ae5e2e3b8ca060")
