-- Lua provided by SkyAPI 
-- Game: 《Rail of Möbius》Demo
addappid(1642000)
addappid(1642001, 1, "5750d2830c1310b23464d1bbc832b243d95fa3583d2ae6f5df764c8e0345c670")
