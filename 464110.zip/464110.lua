-- Lua provided by SkyAPI 
-- Game: Factotum 90
addappid(464110)
addappid(464111, 1, "34f6aaafaff7dd30b4674481ce514d1dea8984e4d5483dd7267ede16e666b7c3")
