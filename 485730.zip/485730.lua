-- Lua provided by SkyAPI 
-- Game: Shift
addappid(485730)
addappid(485731, 1, "ef92c9c1b77385255e769f05fd03e4531a101a539a61f7cd64337fe140bef716")
