-- Lua provided by SkyAPI 
-- Game: Buff Knight Advanced
addappid(385440)
addappid(385441, 1, "a603a19bc9c08b362ebb2ddcc0992186c5f44291471a94985cf6ce5d1a704d82")
addappid(385442, 1, "306d8eb116e9a5d309a9f392a3e1fbba0e0d73477bd2d01f3a2a32645f4490b4")
