-- Lua provided by SkyAPI 
-- Game: ARENA 8
addappid(856730)
addappid(856731, 1, "ba9bcab7cae35ca9fbbff2c53e11bf29f86606699f7eceecdfdb89e6aa0fa33c")
