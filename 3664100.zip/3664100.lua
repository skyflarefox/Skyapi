-- Lua provided by SkyAPI 
-- Game: Hentai Mika
addappid(3664100)
addappid(3664101, 1, "d39883da6f62ffae7fe5e8b47c410645d62ddf7a1d80373e58ebf29f58fc9e3f")
