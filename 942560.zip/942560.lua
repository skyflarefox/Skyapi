-- Lua provided by SkyAPI 
-- Game: AppID 942560
addappid(942560)
addappid(942561, 1, "a1075a6b429595e6ca1c71175e2cd54500333b7b177830dc3c6515287962b1fb")
