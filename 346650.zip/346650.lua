-- Lua provided by SkyAPI 
-- Game: Break the Cube
addappid(346650)
addappid(346651, 1, "56a79457e55d1f36b340f211eb2ee92928a2e5182d6b4c4a9b8918583821e534")
