-- Lua provided by SkyAPI 
-- Game: AppID 541410
addappid(541410)
addappid(541411, 1, "648d9acb2f19f4dc7f0fb0439e285cca2b223bface2c66048a4f29ff5f271888")
