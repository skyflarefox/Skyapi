-- Lua provided by SkyAPI 
-- Game: AppID 2574070
addappid(2574070)
addappid(2574071, 1, "a6a366074fcf0b07de1bb47382102694f6174f8a713706045fac118e81bfc9e4")
