-- Lua provided by SkyAPI 
-- Game: Midnight Ghost Hunt Soundtrack
addappid(1951320)
addappid(1951321, 1, "aba343df1c9b9b9b2474aaf6ea2b3487732782e3e683889133b8c5e94555ce3f")
