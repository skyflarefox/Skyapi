-- Lua provided by SkyAPI 
-- Game: VEGAS 19 Edit Steam Edition
addappid(1698340)
addappid(1698341, 1, "0a15e02e1ec9d67ccb0f158024de173c618b6050d0b42dd684a2155bf713c084")
