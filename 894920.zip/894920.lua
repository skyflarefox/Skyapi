-- Lua provided by SkyAPI 
-- Game: AppID 894920
addappid(894920)
addappid(894921, 1, "b71e7bbe27ac4dbbe8ec0a1810cdff36978bb8f7c77c40bcfa7d3f180bdc5413")
