-- Lua provided by SkyAPI 
-- Game: Love n Life: Happy Student
addappid(3149980)
addappid(3149981, 1, "8b8665c3eda3a9e140b8834bc26ff913a203836181e758f0b5530d703c7990da")
