-- Lua provided by SkyAPI 
-- Game: AppID 2165260
addappid(2165260)
addappid(2165261, 1, "36b9f206e52c5f57ba4fd0763d61a0d2974f05b84bb4c89b35d87622ed715d67")
