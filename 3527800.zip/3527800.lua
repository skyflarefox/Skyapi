-- Lua provided by SkyAPI 
-- Game: Hentai Clicker: Reika is streaming
addappid(3527800)
addappid(3527801, 1, "408e0c99a4a088b8a49feefe5975b4c185a21b2c472e5b8d3d8f89b0e2bb5fd5")
