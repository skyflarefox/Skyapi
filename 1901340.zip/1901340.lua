-- Lua provided by SkyAPI 
-- Game: AppID 1901340
addappid(1901340)
addappid(1901341, 1, "eefb68d350df3a18025b0af91489d7ab9d3f167f1ee654450ae0ca9a566ef32b")
addappid(1912240, 0, "ee4080dc2dafc43790b5256cb152a03c88893cfb9d89314e600158477b80416a")
