-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(587620)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(587621,0,"dbef9c5a131af356bcee9780519c447ff2fcf3b38399004c4aa76bd0eb85adec")
setManifestid(587621,"239798342841480155")
addappid(587622)
addappid(587623,0,"959eb7d1aa7418826034feb7e0fe4081f67974c4d0121cf9a451742fe660c3d4")
setManifestid(587623,"71373641097201029")
addappid(587624)