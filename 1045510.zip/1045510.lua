-- Lua provided by SkyAPI 
-- Game: AppID 1045510
addappid(1045510)
addappid(1045511, 1, "4c442d522d6ad3fe5cddb51b3ccb670d9a1850dece47437b9e81a39e8b178611")
