-- Lua provided by SkyAPI 
-- Game: Neko Neko
addappid(1218520)
addappid(1218521, 1, "a1da58ddae6ac0c931d4e52af31ec3d624ea6a249d4f176ccb842b20da857955")
addappid(1218690, 0, "177793857696bef9ee6388ed8e15b1256ad8cbac08aa638b2482857e22f12958")
