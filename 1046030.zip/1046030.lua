-- Lua provided by SkyAPI 
-- Game: AppID 1046030
addappid(1046030)
addappid(1046031, 1, "33c4649d448f898a1faa5d0e7a66071e5346618ddb5a4e1b92f58ad6ed6dcd2a")
