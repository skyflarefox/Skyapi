-- Lua provided by SkyAPI 
-- Game: Lakeburg Legacies
addappid(1584940)
addappid(1584941, 1, "87fcec72a0409e959302d74e81c97fc4d8b6a9c9237754c1f47da4cea0c7df2a")
addappid(2470590)
