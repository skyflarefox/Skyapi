-- Lua provided by SkyAPI 
-- Game: Survival Girls
addappid(1827550)
addappid(1827551, 1, "e1e5a8b38967000dbfc1fee2bb1c313d5f8dff77b7181c1cf7463980cda37923")
