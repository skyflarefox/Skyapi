-- Lua provided by SkyAPI 
-- Game: My Cute Roommate
addappid(1276610)
addappid(1276611, 1, "e5e51bc88000aa99ba94977175e0bf4415e4738ffff76bf9fd14a632b79f7301")
