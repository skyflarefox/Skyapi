-- Lua provided by SkyAPI 
-- Game: Regenesis Arcade Lite
addappid(642000)
addappid(642001, 1, "1fd0456d3f86781d665c613de1e16d25ae68cd746ba563d7e6af4ca2399d47b7")
