-- Lua provided by SkyAPI 
-- Game: AppID 493370
addappid(493370)
addappid(493371, 1, "d52a405d3b34641c7616719a16cddc71ee0064026790f16cee35475ba12dfcc9")
addappid(493372, 1, "663318edc09771e32b01ef4ae19169161090d73d6d75a7ca4056afa83ca41dbd")
