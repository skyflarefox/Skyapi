-- Lua provided by SkyAPI 
-- Game: My Yandere is a Futanari
addappid(1854800)
addappid(1854801, 1, "94d91ad65155663d088400a07ec67f19932df121c73c1490e99665f0eb933f79")
