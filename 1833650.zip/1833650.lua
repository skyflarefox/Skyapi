-- Lua provided by SkyAPI 
-- Game: Devil Should Die
addappid(1833650)
addappid(1833651, 1, "2e811b03efbadbe123ddb4cc3bb8d9fcab44ed1f0ffc695f1b5e12ba522b1afb")
