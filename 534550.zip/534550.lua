-- Lua provided by SkyAPI 
-- Game: Guacamelee! 2
addappid(534550)
addappid(534551, 1, "532dc45b5876ab2ab47aee412f56eb4a7bc4cfe3bfcb95bc2ca43ab352ee8462")
