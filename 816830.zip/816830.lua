-- Lua provided by SkyAPI 
-- Game: AppID 816830
addappid(816830)
addappid(816831, 1, "08611a6a53c6712af84b0a0d515e4c552ba9a5f3413ab57281a1ef731d9eb784")
