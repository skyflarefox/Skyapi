-- Lua provided by SkyAPI 
-- Game: 蘑菇的冒险 MoGu's Adventure
addappid(1487520)
addappid(1487521, 1, "3485e503737308f7970d469dea253da53d22099a5bb2d2db62daa0341f14be8b")
