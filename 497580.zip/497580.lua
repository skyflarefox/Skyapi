-- Lua provided by SkyAPI 
-- Game: Agent Walker: Secret Journey
addappid(497580)
addappid(497581, 1, "aba545bd091712b58482bde823a5dce3b01a1459e8f452a9b94c8439da1acc3f")
addappid(497582, 1, "e3745814efca73880e0031ac23dc35a82fcff72aaf6b87435936d956f9316a95")
addappid(497583, 1, "06e312f457f2ed1d1b39d99046c896207418efa97b3516e7e1133629e10a8b7f")
