-- Lua provided by SkyAPI 
-- Game: The Iron Oath
addappid(699330)
addappid(699331, 1, "9e4bfde164a398fbe9012226452ab1d79eccc1dc1625697a31144f3b39a3d7b2")
