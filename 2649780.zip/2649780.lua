-- Lua provided by SkyAPI 
-- Game: Nightmare Side: The Game
addappid(2649780)
addappid(2649781, 1, "561b8deae6eff546aeb3304cbfcd52c8f562304bafa25e680437efd635c82d9a")
