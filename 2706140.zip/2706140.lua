-- Lua provided by SkyAPI 
-- Game: Mirage: Beyond The Screen
addappid(2706140)
addappid(2706141, 1, "ea73f7474b75f16bd2c5ca8197e574afad3069e4eb25854a5655e65dfd410182")
