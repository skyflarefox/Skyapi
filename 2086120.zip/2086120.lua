-- Lua provided by SkyAPI 
-- Game: Royal Idiots
addappid(2086120)
addappid(2086121, 1, "487dc372d24e3a71bd5cb6372913fe999cebc14abd8f15ab7a07d806ee34f14f")
