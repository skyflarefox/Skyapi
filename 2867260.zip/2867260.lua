-- Lua provided by SkyAPI 
-- Game: AppID 2867260
addappid(2867260)
addappid(2867261, 1, "56b54c57cd7ab67af3f04fea0f875ceed8b034b1d244ff2558ad646cf627f739")
