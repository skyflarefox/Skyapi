-- Lua provided by SkyAPI 
-- Game: My Friend Stalin
addappid(1553910)
addappid(1553911, 1, "3efe59e5b875e3174e994c1ca02cd93a0f39d372b96479f203cbfa9a3ce7252e")
