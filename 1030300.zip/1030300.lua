-- Lua provided by SkyAPI 
-- Game: Hollow Knight: Silksong
addappid(1030300)
addappid(1030301, 1, "f4a253f96969f93b8a9392cddf6f1b779886ea10a160e7ca148b92bae09abd28")
