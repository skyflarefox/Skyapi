-- Lua provided by SkyAPI 
-- Game: romantic player
addappid(1209000)
addappid(1209001, 1, "6e54403fb9a697a08b7a6de410aa761252274f94a96a2b2c361f0ff517d6e35e")
addappid(1386740, 0, "5b3b0af76be6a747773cf13b48f382d2f4c1acd20ba2c0537499d3208104486b")
