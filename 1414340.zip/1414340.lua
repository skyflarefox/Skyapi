-- Lua provided by SkyAPI 
-- Game: Smash Ball Demo
addappid(1414340)
addappid(1414341, 1, "c28d4b1f2cabc34268190631a470264547898763f7e27f79ee1ed8a4b5948cb0")
