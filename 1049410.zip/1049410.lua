-- Lua provided by SkyAPI 
-- Game: AppID 1049410
addappid(1049410)
addappid(1049411, 1, "e31233e6b65f2a9bc367c15c7bb132f1d9f0d8812222f22f072d74b78ce4daf9")
