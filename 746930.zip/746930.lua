-- Lua provided by SkyAPI 
-- Game: OrbusVR: Reborn
addappid(746930)
addappid(746931, 1, "29e028b4b28a39737487f1e97e2c91ea8c74cdbaf8e8928b39a1b226fed7c6c3")
