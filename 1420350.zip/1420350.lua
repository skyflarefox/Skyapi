-- Lua provided by SkyAPI 
-- Game: Fraymakers
addappid(1420350)
addappid(1420351, 1, "0c2d0021a596f771ab6bbd2e32b93e69fdd6d1800facd004dd585661a6ca7fca")
addappid(1420356, 1, "84fd7fb85455d2f10d7a6ce1543c6d276d4e9dfa422987e2d0c5e672ae4dce1b")
