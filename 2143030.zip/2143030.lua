-- Lua provided by SkyAPI 
-- Game: Cave Crawlers
addappid(2143030)
addappid(2143031, 1, "db69eb8b304e751e12e70fd67b4905834176b3678ef6d2c66c29411c01153b7b")
