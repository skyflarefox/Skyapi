-- Lua provided by SkyAPI 
-- Game: The House of Big people
addappid(1879910)
addappid(1879911, 1, "ad55770742dddf8d7ea8cb560a096006f5058d5ca5f5dae08d84ecf712483bfa")
