-- Lua provided by SkyAPI 
-- Game: Bejeweled Twist
addappid(3560)
addappid(3561, 1, "9585d450f8a63b285dd63e337609b5a0799b126750cbc2d15aee27e5e48a4da6")
