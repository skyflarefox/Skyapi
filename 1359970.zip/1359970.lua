-- Lua provided by SkyAPI 
-- Game: AppID 1359970
addappid(1359970)
addappid(1359971, 1, "bc2199ea22f53e8c5d72924b277f1f26c81ca1e0607b7eb5abb8434b8e62c133")
