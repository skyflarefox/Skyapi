-- Lua provided by SkyAPI 
-- Game: Robots at Midnight
addappid(2623040)
addappid(2623041, 1, "ffb7b6ea3589f131a8597ef59c7c8c974ca0e3432a2828e4d74fcf11482a7c8a")
