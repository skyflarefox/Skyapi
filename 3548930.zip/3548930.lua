-- Lua provided by SkyAPI 
-- Game: The Unrested
addappid(3548930)
addappid(3548931, 1, "736b075e5f46f18c74db7beeb567d3e2017883b6feade649e03c228801129511")
