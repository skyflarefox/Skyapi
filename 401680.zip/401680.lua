-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(401680)
addappid(401681,0,"252c45db846d30301af4ffbe669aa2aa5e7023ee11d930f8018917553bbb2d27")
setManifestid(401681,"4007769963011890934")
addappid(401682,0,"0bee7626e249e556df5bd0ead0f93611ab4d6d1b7e13e1251feb27a7e2c6246e")
setManifestid(401682,"6222116235039793827")
addappid(401683,0,"3c4e6372aef78a9ddb5836f5a14f238dcc4ccf544163ae1e92b9826871fdb955")
setManifestid(401683,"2504145601774977058")
addappid(401684,0,"1e4a42b570df48c1bc4a44aa9115f391e19f49eb43337d73ad35cde3f5937df9")
setManifestid(401684,"9202629513538553961")
addappid(401685,0,"f3366b6a06377566d2547b6dea0104d2304d66e083ef9f586d56d25bc84d32b1")
setManifestid(401685,"2846684166415870920")
addappid(401686,0,"68154512b9c9e325b13a55e368f5c91635966e98c2713e0d1856c69b4c23fc9a")
setManifestid(401686,"7598919311012993660")