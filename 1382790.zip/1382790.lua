-- Lua provided by SkyAPI 
-- Game: Demons of Asteborg
addappid(1382790)
addappid(1382791, 1, "0d179f6cdd4e29a3540525056f8be063e3fc85aa6c5d2470d8ad020da8f84a02")
