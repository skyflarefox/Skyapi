-- Lua provided by SkyAPI 
-- Game: AppID 1015930
addappid(1015930)
addappid(1015931, 1, "72a196821c2913524553307029de3543c0262b7b49cd842801f736bbeb499c2f")
