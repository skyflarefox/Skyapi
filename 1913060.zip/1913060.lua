-- Lua provided by SkyAPI 
-- Game: Long and Hard... Summer! Demo
addappid(1913060)
addappid(1913061, 1, "223e024c692f229d8d624f6940492ffb2bdf758b955e909fb3ef2a1acf817aa1")
