-- Lua provided by SkyAPI 
-- Game: Sexual Sealing Dungeon: Eronest
addappid(3332860)
addappid(3332861, 1, "0de0253fe5191b8d81344add736cc696230499580761f70e2ce50a5672950d2d")
