-- Lua provided by SkyAPI 
-- Game: AppID 1280900
addappid(1280900)
addappid(1280901, 1, "79e203dbe62572745d74934cf2009671c2a84b68def228200f36e780956c8272")
