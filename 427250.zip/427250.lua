-- Lua provided by SkyAPI 
-- Game: 8-Bit Armies
addappid(427250)
addappid(427251, 1, "b81bfeb36ef17f5b364fa56dc1b76ebdd6a76465b4bbc53f8bc1bf6a60bb860d")
