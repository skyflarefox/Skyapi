-- Lua provided by SkyAPI 
-- Game: Trivia Vault: Food Trivia
addappid(861720)
addappid(861721, 1, "6ff12891b6f1c743f6752cf18fe3b35b0a5c3d87f4c49dbde3eab935939ac206")
