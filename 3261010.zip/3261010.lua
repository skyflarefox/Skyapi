-- Lua provided by SkyAPI 
-- Game: East Trade Tycoon: Inheritance
addappid(3261010)
addappid(3261011, 1, "8f8a5594624db1c37364fca6d784679c899df8c89df990fd4da88738234d6530")
