-- Lua provided by SkyAPI 
-- Game: AppID 241720
addappid(241720)
addappid(241721, 1, "117e504e4d82f8e86b226a8cc0080e5043147732abc225961716e03f075cde37")
