-- Lua provided by SkyAPI 
-- Game: Smackitball
addappid(461320)
addappid(461321, 1, "73af1b489672ce753a868b42cdcf4e068c99900ad0bec98e09824a81cc76cfc2")
