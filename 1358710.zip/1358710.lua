-- Lua provided by SkyAPI 
-- Game: AppID 1358710
addappid(1358710)
addappid(1358711, 1, "70d6f39a5f0c5b6b288ce013e15b6bc178de93e16d2160472502d4a9451f3a0f")
