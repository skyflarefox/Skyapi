-- Lua provided by SkyAPI 
-- Game: Sackboy™: A Big Adventure
addappid(1599660)
addappid(1599661, 1, "d759c1903ae656936c6564d2148c69c553fb408d0234a6604c01916699b2b482")
