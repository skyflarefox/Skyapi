-- Lua provided by SkyAPI 
-- Game: Apollo: A Co-Op Game Demo
addappid(1888850)
addappid(1888851, 1, "40ba21881ae8e6679ff83d3f5a4bc78c170136d9bd06043c18ead5c256d64f67")
