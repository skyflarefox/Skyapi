-- Lua provided by SkyAPI 
-- Game: AppID 2111860
addappid(2111860)
addappid(2111861, 1, "d9425d08b4f8b09fb375834547e4b4807378ab6ad73b613e9687a440588fe8d6")
