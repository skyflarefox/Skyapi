-- Lua provided by SkyAPI 
-- Game: YKMET: Strade Soundtrack
addappid(3873650)
addappid(3873651, 1, "4e9b41beb1ea13ae98511181ffcc19e88150fb6f26a527ee0e2ce2889aac761d")
