-- Lua provided by SkyAPI 
-- Game: Trials Rising Demo
addappid(1099490)
addappid(1099491, 1, "0c1ac5bc0719711084e5b47433e5e32ec80843ed44dd5ca4a6ee522bd96b6099")
