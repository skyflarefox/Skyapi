-- Lua provided by SkyAPI 
-- Game: yni^
addappid(2278390)
addappid(2278391, 1, "564ce0c95bb4912b49dd49c796168622084a141a95748ec96ae936358a15e40f")
