-- Lua provided by SkyAPI 
-- Game: Deep Cuts
addappid(3035010)
addappid(3035011, 1, "e9618436b7a2e03c36a556f6f857567569e2fc4166f061b9ca3f7ad94dfccc85")
