-- Lua provided by SkyAPI 
-- Game: Chariot
addappid(319450)
addappid(319451, 1, "7d63c0c73eb482fefaa06cd600fde01c1167671b2ec031d396bf0cc0756d6176")
