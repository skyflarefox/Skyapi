-- Lua provided by SkyAPI 
-- Game: AppID 524520
addappid(524520)
addappid(524521, 1, "70318c6cee4221e3257e717e8a2c8eb5eff273df3c3400104d11725353a95455")
