-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(572220)
addappid(572221,0,"d666b123427ef0dfbacdf6b3715a6bdc0cf4845b558f21b6d072ee6cc906ff0c")
setManifestid(572221,"4102102560877479437")
addappid(572222,0,"bf6abc2169f3910a776874fe55385fd3145c4e8513094efdc99d3b388a9a668f")
setManifestid(572222,"3980466674769507019")
addappid(572223,0,"2bcd1a93cb35d9622960ef9998ebb8a1592003f45de196aa925a0cbcf253057d")
setManifestid(572223,"4072921515945983935")