-- Lua provided by SkyAPI 
-- Game: A grande bagunça espacial - The big space mess
addappid(449220)
addappid(449221, 1, "0aaa0f2f74fa7a69cd8c04801841550c3d3c2a11261d2f3a792848e550a40932")
