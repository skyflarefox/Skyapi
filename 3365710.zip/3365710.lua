-- Lua provided by SkyAPI 
-- Game: FINAL FANTASY IX Original Soundtrack
addappid(3365710)
addappid(3365711, 1, "c67081096b66ce35a2f6fd8f4fa18281a6d942eba6140ec174c98a816f4bd0f3")
