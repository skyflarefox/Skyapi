-- Lua provided by SkyAPI 
-- Game: Soccer in a Box
addappid(3231990)
addappid(3231991, 1, "80afbdb4a975734a5e1585013b89e1e421f7429e63b9b103fb5c0a93e7bdd217")
