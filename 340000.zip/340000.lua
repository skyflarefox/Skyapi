-- Lua provided by SkyAPI 
-- Game: Headlander
addappid(340000)
addappid(340001, 1, "2133fbec1526b19d8371840e55a6f28f3718a020d361a3f78d141dfdac7394cb")
addappid(340002, 1, "5c0a3371f161fa9a87c588a9df3f366db9f9787d8805e1e2ba6462ddbe442e5a")
addappid(501260)
