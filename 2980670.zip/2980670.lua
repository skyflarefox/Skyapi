-- Lua provided by SkyAPI 
-- Game: AppID 2980670
addappid(2980670)
addappid(2980671, 1, "7a1cc8fe30882c51f64467d3b7ed25b98b311e92e4dde0c89170754230fa81d5")
