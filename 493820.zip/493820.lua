-- Lua provided by SkyAPI 
-- Game: Rivais Em Batalha
addappid(493820)
addappid(493821, 1, "eef32b778dc687b22efd6d5a1a095ce71635bc997655531bab1902311057e44f")
