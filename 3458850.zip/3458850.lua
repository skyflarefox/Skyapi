-- Lua provided by SkyAPI 
-- Game: Puppycraft: Maze
addappid(3458850)
addappid(3458851, 1, "da2a94394d603697383486df7e6258e5c141165b5e4bca78b17acda2807bc7d7")
