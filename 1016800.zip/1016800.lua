-- Lua provided by SkyAPI 
-- Game: AppID 1016800
addappid(1016800)
addappid(1016801, 1, "d5922db497812c1e9e7de0a1242522c0a4f38964b632aafe2f466105a69429bb")
