-- Lua provided by SkyAPI 
-- Game: Searching For Rest Demo
addappid(2426700)
addappid(2426701, 1, "8a10e782b7ef1822e6b8b0f5c5b5970040ff868d2615b3dea9d233889335ce95")
