-- Lua provided by SkyAPI 
-- Game: AppID 2314180
addappid(2314180)
addappid(2314181, 1, "da21ad931a2c28e3aad3a35854e17d122c4fa0f9764abfba40cf200e031ef300")
