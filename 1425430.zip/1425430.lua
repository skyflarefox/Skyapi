-- Lua provided by SkyAPI 
-- Game: The Outer Worlds Original Soundtrack
addappid(1425430)
addappid(1425431, 1, "16f7345094a515179560047721d15bb7530648a30cf9fc5095a49814474b9de3")
