-- Lua provided by SkyAPI 
-- Game: HYPERBLADE
addappid(1834740)
addappid(1834741, 1, "ab30f4645e9c8a5c397d1837c1c4502077d2f780483116694d70e6d8a7a76cc7")
