-- Lua provided by SkyAPI 
-- Game: Master of Love
addappid(2911280)
addappid(2911281, 1, "738f0e6092b07c2f05214713b999954338847c3f1c5c5fdbf64ce737a13b0420")
