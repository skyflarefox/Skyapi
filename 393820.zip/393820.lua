-- Lua provided by SkyAPI 
-- Game: AppID 393820
addappid(393820)
addappid(393821, 1, "436a12064f36b6563189420948f2345c49290a8f685b4c4300df7f8543a10396")
