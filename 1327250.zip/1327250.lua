-- Lua provided by SkyAPI 
-- Game: AppID 1327250
addappid(1327250)
addappid(1327251, 1, "8eb052610b3c35510e74f61e2cda24c2648decd6621945f15940f2ac112be43e")
