-- Lua provided by SkyAPI 
-- Game: The Richmond Rut (In Search of Fenton)
addappid(2462150)
addappid(2462151, 1, "2379bef342fbaa50063609c65b6fa8d6f855ee1719203dda5080d24bea58bb1b")
