-- Lua provided by SkyAPI 
-- Game: Fantasy Jigsaw Puzzle 2
addappid(1729770)
addappid(1729771, 1, "29477bf50b7571671b1261e5334c316888cdd664d77c924d8de40f6b5e35916a")
addappid(1729890, 0, "ac3abfd58a93c49bc2ab51990c8b9248cb4467589778d10a5393e7d57a709075")
