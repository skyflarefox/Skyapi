-- Lua provided by SkyAPI 
-- Game: AppID 202570
addappid(202570)
addappid(202571, 1, "5c97e0f178a064b081a5c639f663b9c9d9878e4837219d865a4f3869b0c35249")
