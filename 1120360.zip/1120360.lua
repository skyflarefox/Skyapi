-- Lua provided by SkyAPI 
-- Game: AppID 1120360
addappid(1120360)
addappid(1120361, 1, "396f7849cca6b2065a6f74260493e6b079fee3150e9c17865d652232a5132a9e")
