-- Lua provided by SkyAPI 
-- Game: The Pilgrim
addappid(1132880)
addappid(1132881, 1, "d96a37f2e964f560c053f892a9e94aa60a08055a3b96aa1119e89fd7d4da51fd")
