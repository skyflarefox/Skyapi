-- Lua provided by SkyAPI 
-- Game: AppID 1198850
addappid(1198850)
addappid(1198851, 1, "9fe940eb285d2d57383c4a5ed0fce947ecd10f6bc43af44abede4ecb78637930")
addappid(1198852, 1, "0a220e518335047c74c9be74833fd3d6221e0923d7d4e2aeebec5322269367fc")
