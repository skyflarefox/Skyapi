-- Lua provided by SkyAPI 
-- Game: Kingsway
addappid(588950)
addappid(588951, 1, "b5cc60718097a56ab52462d040f511e5948933c74353e44173a6e64b056ee036")
