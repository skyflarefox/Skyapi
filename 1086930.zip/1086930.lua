-- Lua provided by SkyAPI 
-- Game: 名城BGM合辑
addappid(1086930)
addappid(1086931, 1, "22c376472344edda762fa56eb33e4637eb5c9181537c245148b9cd93129aa04f")
