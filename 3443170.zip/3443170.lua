-- Lua provided by SkyAPI 
-- Game: Daughters of the Dragon Demo
addappid(3443170)
addappid(3443171, 1, "c0683035bb85d4c3b2fd976dc996ebc7bcdd4a2cd643975cb85b3cc58b7fb019")
