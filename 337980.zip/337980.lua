-- Lua provided by SkyAPI 
-- Game: Vagrant Hearts
addappid(337980)
addappid(337981, 1, "362b4456a04c55648f45537fa2880984998ebcc0322e42a566dd4b8b3340822d")
addappid(392440)
