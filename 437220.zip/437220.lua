-- Lua provided by SkyAPI 
-- Game: The Culling
addappid(437220)
addappid(437221, 1, "37a09f126830fbe2d491594d7d538361e6144661dd3618ad53d5e32cb53591e6")
addappid(437222, 1, "975f70c778d9266c5289df68b4dec07b236236a2000a5c32d37f1b23481bcb3c")
