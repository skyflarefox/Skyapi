-- Lua provided by SkyAPI 
-- Game: Poly Fire
addappid(3255600)
addappid(3255601, 1, "e921bce89f70456a6cfedd6559e1aee6639d4ab9537f6beedd44338e168403aa")
