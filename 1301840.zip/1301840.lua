-- Lua provided by SkyAPI 
-- Game: Maggie the Magnet
addappid(1301840)
addappid(1301841, 1, "3ae1c40d6cfd58242442aa4434081ef4f6d359f8dfbb7889060806813453edf4")
