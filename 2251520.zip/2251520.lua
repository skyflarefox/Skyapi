-- Lua provided by SkyAPI 
-- Game: Battlerace Demo
addappid(2251520)
addappid(2251521, 1, "248a6856fb80cd87c0dab43d3d96c7e24ca3ddb71b9f67412a530169ec941f60")
