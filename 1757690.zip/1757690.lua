-- Lua provided by SkyAPI 
-- Game: Haunted Hell House
addappid(1757690)
addappid(1757691, 1, "9202c8fc8e9ed705b2be1b895d5458c227a0658d6933ae2607d6bbad080f64fe")
