-- Lua provided by SkyAPI 
-- Game: Happenlance
addappid(1663410)
addappid(1663411, 1, "2b623623ecda3c9989a9e3be40c1a5a421866c1631ef346126abaf0606ad424a")
