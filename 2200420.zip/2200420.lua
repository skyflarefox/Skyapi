-- Lua provided by SkyAPI 
-- Game: 13 Candles
addappid(2200420)
addappid(2200421, 1, "16d3ee403bb6944ac9644642274de1414dc8df62002a8f3a615e147a4eaf85e4")
