-- Lua provided by SkyAPI 
-- Game: Speedball 2 HD
addappid(251690)
addappid(251691, 1, "3dade2edb9f510c018445ad9ae1e4e21d752de5ca2210c39bfe05ae06350c3ae")
