-- Lua provided by SkyAPI 
-- Game: Countryballs: Modern Ballfare
addappid(1147130)
addappid(1147131, 1, "d4f8947456038a2985c756b31858c915d2ab826ca8c6533d401e6bda227921ae")
