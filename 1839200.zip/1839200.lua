-- Lua provided by SkyAPI 
-- Game: AppID 1839200
addappid(1839200)
addappid(1839201, 1, "78d5dd9570f7ed9a40ecf7b9a067b831d46e4ad4b31b320f9be51464667ba902")
