-- Lua provided by SkyAPI 
-- Game: AppID 1612380
addappid(1612380)
addappid(1612381, 1, "4f65c52b8b295af5894a683b5e703adcb590b379349ea6c03b2d28cb2c5b42e7")
