-- Lua provided by SkyAPI 
-- Game: Space Prison
addappid(1865930)
addappid(1865931, 1, "95e2682359f609f627932fb5081916f5949c69cb5b73bee0be34aa4f9eb8363f")
addappid(3078930, 0, "5b278043514d3dd326e567505f6ec182ac75420b5740bc8c4ffaba321e06950e")
