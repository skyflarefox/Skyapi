-- Lua provided by SkyAPI 
-- Game: Residue: Final Cut
addappid(265790)
addappid(265791, 1, "4c1e3282f16129d8f48200af5cfabc270beba887877efd775963c7ec892e5243")
