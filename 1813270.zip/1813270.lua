-- Lua provided by SkyAPI 
-- Game: Poptropica
addappid(1813270)
addappid(1813271, 1, "7b20b8875fe0f1b60ef44abbbf85b5b5c3beca55be22715351b99edac6c3152c")
