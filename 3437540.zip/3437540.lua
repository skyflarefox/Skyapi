-- Lua provided by SkyAPI 
-- Game: Mysteries Of FangClaw
addappid(3437540)
addappid(3437541, 1, "523383890e14d2b23d3b89d1bf103a8a4903c7c1bfe95efaf1cdf5feb0bce178")
