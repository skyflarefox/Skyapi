-- Lua provided by SkyAPI 
-- Game: Beloved Rapture Soundtrack
addappid(3278470)
addappid(3278471, 1, "73dc5d8ea5373db3bd390ecc6b21a362503f0eab88a0753a7e94c75f7b480305")
