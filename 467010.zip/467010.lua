-- Lua provided by SkyAPI 
-- Game: Fall of Civilization
addappid(467010)
addappid(467011, 1, "fe15018e7c64bed3282fb4254ae65a58b12716cea264b14c64924e541a600971")
