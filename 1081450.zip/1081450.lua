-- Lua provided by SkyAPI 
-- Game: AppID 1081450
addappid(1081450)
addappid(1081451, 1, "9a926de7c5ce32c942698beecf0e5a0b8536cc887227d048e8ea70fb93839bc2")
