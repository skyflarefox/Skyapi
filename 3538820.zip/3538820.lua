-- Lua provided by SkyAPI 
-- Game: Galactic Simulator2: Stargate
addappid(3538820)
addappid(3538821, 1, "8d7b7aec10b106b3f6c26881c29ee2297db00ee0e2dcd0df7c519c5b1a8a4ae6")
