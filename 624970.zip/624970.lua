-- Lua provided by SkyAPI 
-- Game: AppID 624970
addappid(624970)
addappid(624971, 1, "8336cd937fbd3f08a9a9eabf7951b60ee81abebc93f3452805523d8afa1f91f6")
