-- Lua provided by SkyAPI 
-- Game: Expand & Exterminate: Terrytorial Disputes - Endless Base Defense
addappid(2232650)
addappid(2232651, 1, "8732692bd47d02842a8bf7632f84121ae2bed68bd56635e39b2e7d5677230483")
