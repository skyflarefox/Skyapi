-- Lua provided by SkyAPI 
-- Game: AppID 913690
addappid(913690)
addappid(913691, 1, "a13496b274b240a6cdb7e6d950a9f2652e3e9bba33f6e26892d55b97eeb817b2")
