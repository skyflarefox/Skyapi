-- Lua provided by SkyAPI 
-- Game: Hentai energy II
addappid(1085560)
addappid(1085561, 1, "eea6ec9d7dd5aa31738d722111b8f83663e093ad1506cb8afa8140a8fa3c96cc")
