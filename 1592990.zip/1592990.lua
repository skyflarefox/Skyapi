-- Lua provided by SkyAPI 
-- Game: Raccoon Arrival
addappid(1592990)
addappid(1592991, 1, "30e1948f4150dab28e800a75542deccc09602d54e2010b7c25eef30c6a032f86")
