-- Lua provided by SkyAPI 
-- Game: AppID 2400790
addappid(2400790)
addappid(2400791, 1, "4fe3b2b84d601520c61cb3d56e00d86bc27daae0b7a70da1fbcd798478610c6a")
