-- Lua provided by SkyAPI 
-- Game: TITANIC Shipwreck Exploration
addappid(924800)
addappid(924801, 1, "0ef929f4946006b1311a9774cdd8133e53e599baf914a724b4ace607e9d16e96")
