-- Lua provided by SkyAPI 
-- Game: Chroma Blast
addappid(653220)
addappid(653221, 1, "ca45c8df602d850682daf1dd6d777094707733be0ef5882b169f045ce0b0ed28")
addappid(653222, 1, "eb96d9f73b8b5c83bf782cf80a0294ecb57705fe3d26c6c23374e0a6fe2c288c")
addappid(653223, 1, "c2419535c73011fbc807910e310ace92a04c670712bc220a0b2f461c77b32d70")
