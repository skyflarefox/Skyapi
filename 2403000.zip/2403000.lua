-- Lua provided by SkyAPI 
-- Game: Fantasy Amusement Park
addappid(2403000)
addappid(2403001, 1, "2c153e82bf9bc38368e7923fb1c00700baf0ae5d712608a56bbe9391613c1cd4")
