-- Lua provided by SkyAPI 
-- Game: 2Dark
addappid(435100)
addappid(435101, 1, "3f4b20b3c80b9322722f6d5edf4d8d6a871be2ced833bdcfe1c06cc486c52825")
addappid(579740)
