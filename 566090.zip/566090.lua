-- Lua provided by SkyAPI 
-- Game: The Bard's Tale IV: Barrows Deep
addappid(566090)
addappid(566091, 1, "fe0557c9ba3ba5c0cabd9d01e7f924c34f5232a103ce380106cfa045d80783bc")
addappid(566092, 1, "2f365ec001f9033ac3174a60637807de98a145f6b5b226dccbf10601b98fe527")
addappid(566093, 1, "67e76d413e36461db77a21a9507e415f934d8657844e21f40c985e1497ee1fe0")
addappid(566102, 1, "282ebcb06b1b8f1456bc6fb28a091282dac5e2f0a92787de8acff2628c272188")
