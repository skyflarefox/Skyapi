-- Lua provided by SkyAPI 
-- Game: Crystarise
addappid(1748750)
addappid(1748751, 1, "0dd8d1d2c2ce470c3b4a85848cf3041303b123c178c8c25b2a8be85dcf3b6a6c")
