-- Lua provided by SkyAPI 
-- Game: AppID 868920
addappid(868920)
addappid(868921, 1, "78da0650c04841c08df2175d5d2a58b2888f2fcfe92ad31aec4e3603d02fa545")
