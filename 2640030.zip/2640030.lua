-- Lua provided by SkyAPI 
-- Game: Wonder Ball
addappid(2640030)
addappid(2640031, 1, "0d4d84e8de9ffde0f6cf5ba432051ece266603477d39b1c154da2ad562870aeb")
addappid(4446890)
