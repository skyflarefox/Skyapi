-- Lua provided by SkyAPI 
-- Game: Derail Valley Soundtrack
addappid(1308910)
addappid(1308911, 1, "1ece8b01c750e3f7d0ab48f65ba77eec1718c899c381122e57dad43273cf616b")
addappid(1308912, 1, "8a9aa26f86210fd05c92b7f4edfdb4e000712316e58107c2de65bcdadb1e12bc")
addappid(1308913, 1, "959971611e70ed06f0d57c7296f158b6983f3a7bc0bd8b6ee068539744e1d28a")
