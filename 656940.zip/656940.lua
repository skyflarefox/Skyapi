-- Lua provided by SkyAPI 
-- Game: AppID 656940
addappid(656940)
addappid(656941, 1, "c55144e785380d364b5bf3edc5876526e9317fde756d53988daa8098def29121")
