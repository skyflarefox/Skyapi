-- Lua provided by SkyAPI 
-- Game: The Watchmaker
addappid(504430)
addappid(504431, 1, "17064d22aeecec1dd392732ccace3672b2cf90b3139f29d7a09ba154eb7e3e9d")
