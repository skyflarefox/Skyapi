-- Lua provided by SkyAPI 
-- Game: AppID 1277970
addappid(1277970)
addappid(1277971, 1, "1230129d89ad38b0f1540be71dfe646a3fe266a43c40cae8ba7b356df3c567a0")
