-- Lua provided by SkyAPI 
-- Game: Kitsune Tails
addappid(1325260)
addappid(1325261, 1, "021be79561b9d0e1a45d3435aef31268abf0d0199446f1e86f13f292dbaca4a7")
