-- Lua provided by SkyAPI 
-- Game: Uneasy Memories
addappid(2907280)
addappid(2907281, 1, "15d366c71035bc12e24091b7ac2e64622e6f7a72d9e9453d92a33d5b3431185e")
