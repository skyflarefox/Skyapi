-- Lua provided by SkyAPI 
-- Game: AppID 3013720
addappid(3013720)
addappid(3013721, 1, "8ad22c3ec1f8ad1fd6f71f6cfcabdb36e27e84a5c21b3cb1030cf90d99320474")
