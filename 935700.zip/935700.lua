-- Lua provided by SkyAPI 
-- Game: AppID 935700
addappid(935700)
addappid(935701, 1, "f568eac204097394f6921ba94d41a2d6f0e51d691434826775efed3c78b4ab60")
