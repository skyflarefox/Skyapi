-- Lua provided by SkyAPI 
-- Game: ANNO: Mutationem
addappid(1368030)
addappid(1368031, 1, "3332efc299cec15a93d1602555631c48f6272e69159b6cdd85a42aae0c5c5c22")
addappid(1909960, 0, "07a45b03b0c6f5bf92fb6f84ed9877e0908f29f89663a644d6cb3438188281d8")
