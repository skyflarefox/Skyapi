-- Lua provided by SkyAPI 
-- Game: Princess Maira: Initiation
addappid(1761530)
addappid(1761531, 1, "71044c4b82603f9b6c280c98b9bfd7eb29da9bbfc1ee0a2ccb2f65c8f8e071e6")
