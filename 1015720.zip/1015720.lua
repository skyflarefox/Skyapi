-- Lua provided by SkyAPI 
-- Game: Alternate DiMansion Diary
addappid(1015720)
addappid(1015721, 1, "6f007a59e61e962dd07241d2d5241e3546493edde54d6e24355a4340e1a1b29b")
addappid(1015722, 1, "96eeeac42091d6b3b1d0c03fab56c0a3186a2a1eb247a9e250b50cd9404d38f1")
