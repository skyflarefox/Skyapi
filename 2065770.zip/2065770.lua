-- Lua provided by SkyAPI 
-- Game: Guns and Rush
addappid(2065770)
addappid(2065771, 1, "9b6da76a989d8f4e62ba6f4e741a07df15ce9decfd094fba94d2468fde44a61c")
