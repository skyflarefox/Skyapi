-- Lua provided by SkyAPI 
-- Game: TRAILCAM
addappid(3242230)
addappid(3242231, 1, "30e1e62ad0ece1aa5d1eeb5465d40d604d393724581c9a43a9c4b1a341cd1691")
