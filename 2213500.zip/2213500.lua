-- Lua provided by SkyAPI 
-- Game: Sven - Completely Screwed
addappid(2213500)
addappid(2213501, 1, "9d3f6855cf4315a0dfdc66d69610d6b873e0965039fd86d6339b054f4d0f8784")
