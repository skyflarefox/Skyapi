-- Lua provided by SkyAPI 
-- Game: WAyE
addappid(893060)
addappid(893061, 1, "4a2b296c2c47b792b0f841c31d1c0d720167e7b84e88210f494f7d01558e3f66")
