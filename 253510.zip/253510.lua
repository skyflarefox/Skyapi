-- Lua provided by SkyAPI 
-- Game: WARMACHINE: Tactics
addappid(253510)
addappid(253511, 1, "4e05c91011ff9456e594de3694cda21560a62a9c6c49f3702691b08a1b5443e9")
addappid(253512, 1, "ea0576a89c2a00420728c85fb517b649e06f1960b33224a89503858dafac0383")
addappid(253513, 1, "7f25ce92082a4b64a14b2526983fab3b3e1b5ce4eb2c940c3aaeee1e53273e31")
addappid(418566)
