-- Lua provided by SkyAPI 
-- Game: AppID 2621340
addappid(2621340)
addappid(2621341, 1, "1f7a99ba884bde6ab4f7e05f2970af7688b6a19cc251b9a28cf0e6a5bf5bc56b")
