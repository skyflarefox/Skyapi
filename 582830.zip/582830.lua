-- Lua provided by SkyAPI 
-- Game: AppID 582830
addappid(582830)
addappid(582831, 1, "5f0fa13bea9b3ff9e6b46f50c1d81f7ef255d3a59d54fa76c2a258ab1cc8554a")
