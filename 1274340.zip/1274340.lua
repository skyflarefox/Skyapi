-- Lua provided by SkyAPI 
-- Game: ColorsInvasion
addappid(1274340)
addappid(1274341, 1, "56e7b0a322f3b022b5344e637b04d8601fc6be320c50c1faf03743bab119c513")
