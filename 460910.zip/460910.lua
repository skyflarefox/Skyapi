-- Lua provided by SkyAPI 
-- Game: A-Gents
addappid(460910)
addappid(460911, 1, "96ba6a25b71361d47d620d2390915c51ec5d034dc457fe75fe719943dfc7a342")
addappid(460912, 1, "f7459594ef5bb506dad6ed267d9c6404fc9943d887874ad3e3686688bb55c4d7")
addappid(460913, 1, "e47673bf2f6f583dafb0ccd7a43a2fdfa7ff8f9fc7607ccb6f95c77070e4bf3f")
