-- Lua provided by SkyAPI 
-- Game: AppID 463760
addappid(463760)
addappid(463761, 1, "69056bf959bf524df77c7bf69cef9936eb740a585eaa60acb524948357c61b2c")
addappid(463762, 1, "0fd0d1cbc3da9b634af1d6ce16bfd22b11a2d9696fb068e5f91351ee454650be")
addappid(463763, 1, "e6d63bb133bd40532a1d444303c13c22202ca308a32d3e8ff3d3ab05fc15cf93")
