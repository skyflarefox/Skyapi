-- Lua provided by SkyAPI 
-- Game: Arcade Spirits: The New Challengers
addappid(1484620)
addappid(1484621, 1, "4ca5e252866cf75012d6e8db44638aa2b55e88b8a69745a07df37a42db6629b7")
