-- Lua provided by SkyAPI 
-- Game: 2236 A.D.
addappid(800820)
addappid(800821, 1, "444579d8d253405319bf4f6e1e3b82d750c1108ac04311c455dcc1b5b0bf90ec")
