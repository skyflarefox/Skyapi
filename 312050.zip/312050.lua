-- Lua provided by SkyAPI 
-- Game: Red Johnson's Chronicles - 1+2 - Steam Special Edition
addappid(312050)
addappid(312051, 1, "9adad7f5c2c49006fa89ab4f284f9bc6065935b57b14bd25a748c62cd4cfdc61")
