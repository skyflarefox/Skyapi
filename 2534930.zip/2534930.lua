-- Lua provided by SkyAPI 
-- Game: Super Mayor
addappid(2534930)
addappid(2534931, 1, "1ece2a88341776cabcdd73c30c1f013cc0df02c12c52bcd21def512fa186a4f7")
