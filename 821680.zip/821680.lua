-- Lua provided by SkyAPI 
-- Game: Military Operations: Benchmark
addappid(821680)
addappid(821681, 1, "09356945c2618c747246b294fb2dd8c43a1165b59bd8cf280e930493d92bc8a0")
addappid(821682, 1, "577175b04ec971fa6c8f14de3144a3a195c25bf1c6203309cfd4edee52c63d00")
