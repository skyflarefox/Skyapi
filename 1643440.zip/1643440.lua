-- Lua provided by SkyAPI 
-- Game: Les aventures de Fierot
addappid(1643440)
addappid(1643441, 1, "a97c23e85b8d38e0a3c8603141e52213fba3785ec34c4764943e7ee63ce49f60")
addappid(3438390)
