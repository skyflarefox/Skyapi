-- Lua provided by SkyAPI 
-- Game: AppID 1841900
addappid(1841900)
addappid(1841901, 1, "789eff5ecca968bad048d0161dcd30c391cc32287f2393403e0d59e874b10f52")
