-- Lua provided by SkyAPI 
-- Game: Mega Man Legacy Collection 2
addappid(495050)
addappid(495051, 1, "9d0486a0c0f575c083cc3e416de7a0074cafa01889208f14118ede19b7d22ff7")
