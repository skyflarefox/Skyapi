-- Lua provided by SkyAPI 
-- Game: Pirate Pop™
addappid(487350)
addappid(487351, 1, "07a30fb6face4a2f9aea58e32a213dd4c946b2d99575bad70236788de1bd0b60")
addappid(487352, 1, "b3d66db626fa914bf9353af6617e8861c4b56a150d7f1e34c6a21f2d74a141c5")
addappid(534030)
