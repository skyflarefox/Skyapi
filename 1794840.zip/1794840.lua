-- Lua provided by SkyAPI 
-- Game: Perceptio
addappid(1794840)
addappid(1794841, 1, "816350e0df03b1c7cd3c262496c732d20fdb8999d14903654c592a4270e59f8e")
