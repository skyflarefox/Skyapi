-- Lua provided by SkyAPI 
-- Game: Tech Store Simulator
addappid(3076400)
addappid(3076401, 1, "a5bf77c64570c7fa895e9a95d02f36b442360e1741d18ad6a89488d318e1fe5a")
