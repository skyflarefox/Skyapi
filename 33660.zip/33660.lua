-- Lua provided by SkyAPI 
-- Game: AppID 33660
addappid(33660)
addappid(33661, 1, "f8b538ab6203cdaaf2920210219f9d75e0db166930a22757bd749ab7dde8a35f")
