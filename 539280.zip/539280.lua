-- Lua provided by SkyAPI 
-- Game: AppID 539280
addappid(539280)
addappid(539281, 1, "7fac1775a4a023999b0607887ce2ccbf729650d103055c7f1bf5d1e5ba7aa4c1")
