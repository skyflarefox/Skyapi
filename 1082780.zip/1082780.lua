-- Lua provided by SkyAPI 
-- Game: AppID 1082780
addappid(1082780)
addappid(1082781, 1, "0f9bd69fafdc1765c2029d0a68ab4b0b45a9a7150798163ce0085cf9c52afd8e")
