-- Lua provided by SkyAPI 
-- Game: New York Mysteries: The Outbreak Demo
addappid(1193860)
addappid(1193861, 1, "ec9fc79a400d5b1061a83bd263a993217956b7bdc53699fba2df31a4e269ccca")
