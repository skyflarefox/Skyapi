-- Lua provided by SkyAPI 
-- Game: Car Manufacture Demo
addappid(1760610)
addappid(1760611, 1, "281b0f939d6b4e9e1b4e9c520900be123b814401e982afdf0710cd613bd099dd")
