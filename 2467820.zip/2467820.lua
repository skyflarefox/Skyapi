-- Lua provided by SkyAPI 
-- Game: AppID 2467820
addappid(2467820)
addappid(2467821, 1, "d9d31a9fa9275d914a897b074ed98f57f375cdac635665545e5aa425cc75940e")
