-- Lua provided by SkyAPI 
-- Game: AppID 2779430
addappid(2779430)
addappid(2779431, 1, "44ff240c8e40c30c8ad783a4c20a31fbbc2459999b74f786751226561775af35")
