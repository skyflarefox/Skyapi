-- Lua provided by SkyAPI 
-- Game: AppID 2977140
addappid(2977140)
addappid(2977141, 1, "a86b442ea9fbe4d5761f4be6ed082c60af64a04202839741f9ae4027e0bf9c30")
