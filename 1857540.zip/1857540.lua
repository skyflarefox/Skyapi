-- Lua provided by SkyAPI 
-- Game: Kurukshetra: Ascension
addappid(1857540)
addappid(1857541, 1, "2903d96e5897db86886a2e223105800d47f8eb5df5f5c3d79dd319450a4dbae4")
