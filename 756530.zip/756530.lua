-- Lua provided by SkyAPI 
-- Game: AppID 756530
addappid(756530)
addappid(756531, 1, "802ade737f719929dc331cdd738dbae2fde8d894e218605cc06d07e1a5fa703f")
