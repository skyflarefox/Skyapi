-- Lua provided by SkyAPI 
-- Game: Mega Mall Story
addappid(1923680)
addappid(1923681, 1, "75778c23874b24a7347903b7e70cf6f1ccf0e94b78c9ff6d8465536180486ec9")
