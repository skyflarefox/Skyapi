-- Lua provided by SkyAPI 
-- Game: Darkstone
addappid(320320)
addappid(320321, 1, "7b3420951a4705240fc0124075c85592a295ab0b52a995d211a9d2d5e0eb9512")
