-- Lua provided by SkyAPI 
-- Game: Lustful Roommates
addappid(3556500)
addappid(3556501, 1, "b84cd2cac9aeb8ae940259583cbf467e35e674f7a311e256a2654f2e5628e0b4")
