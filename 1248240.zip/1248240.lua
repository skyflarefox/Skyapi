-- Lua provided by SkyAPI 
-- Game: AppID 1248240
addappid(1248240)
addappid(1248241, 1, "223215cbce8f42df222f8668407d1c96e8021601dd82c0cc047ab94ae296a6cb")
