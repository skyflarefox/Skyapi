-- Lua provided by SkyAPI 
-- Game: Tainted Pools
addappid(3568550)
addappid(3568551, 1, "61937951ac6a7acf20beced2ad21109b0c66738667a779f97029abf86d5143aa")
