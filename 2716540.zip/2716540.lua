-- Lua provided by SkyAPI 
-- Game: No Strings Attached
addappid(2716540)
addappid(2716541, 1, "870084e5dbf39ff1f333a1a356f55678498d40f57dfaf1a5c57af2f5557d924d")
