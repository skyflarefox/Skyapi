-- Lua provided by SkyAPI 
-- Game: Word2
addappid(2764720)
addappid(2764721, 1, "683a82a9b504be5c49be8ce3782df0944753332c8b7b8594752a9093485321aa")
