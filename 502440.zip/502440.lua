-- Lua provided by SkyAPI 
-- Game: Plant Fire Department - The Simulation
addappid(502440)
addappid(502441, 1, "2b2f9ffc0f713a42ccbfdfcbc6c03f8c15fc860798791ca54cc04e5fad87c564")
