-- Lua provided by SkyAPI 
-- Game: THROUGH
addappid(3091660)
addappid(3091661, 1, "bfa162c1aab35d608135e1ce4ce24ef3738d8ad85ac5cb0b20391e25f75cfe00")
