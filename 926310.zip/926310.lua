-- Lua provided by SkyAPI 
-- Game: 咕啾！文鸟恋爱物语 Love Story of Sparrow
addappid(926310)
addappid(926311, 1, "9e09ed4cb9fb84be2536ee89a8e8acc8de3fdc592d8a16252874790a951a4b77")
