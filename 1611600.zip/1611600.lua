-- Lua provided by SkyAPI 
-- Game: WARNO
addappid(1611600)
addappid(1611601, 1, "4f4f2eafce1c568afab8d453340193eeec38f656303f6aca28a1ba4e806204ea")
