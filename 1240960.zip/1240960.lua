-- Lua provided by SkyAPI 
-- Game: AppID 1240960
addappid(1240960)
addappid(1240961, 1, "06d457193c2e57f193df2aa3c395a393345869f2720d14a0f80168263c7a09f7")
