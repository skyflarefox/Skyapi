-- Lua provided by SkyAPI 
-- Game: Handyman Corporation
addappid(1703180)
addappid(1703181, 1, "96986e91e2d5b285a66e2ede44534ce7469bb7972a50e565746df73276dfd3e4")
