-- Lua provided by SkyAPI 
-- Game: AppID 338530
addappid(338530)
addappid(338531, 1, "9c40797b656f7cb7df8c6d1b9957d31118080e2e974288a97ab9b2fe8ff0e0d4")
