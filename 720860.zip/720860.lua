-- Lua provided by SkyAPI 
-- Game: RAID: World War II Soundtrack
addappid(720860)
addappid(720861, 1, "c36fe6f1ff1de1c920d44086427094c57e4b569881cf06ab4e9dd5acde452548")
