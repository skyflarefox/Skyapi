-- Lua provided by SkyAPI 
-- Game: Gemini Strategy Origin
addappid(1361180)
addappid(1361181, 1, "3c657393aae38f87cb1008e151bc32ac6cd72f6f4e78d3ad3129b5067754e321")
addappid(1485130, 0, "e2a500e14229eb25ea0777e3034f4ad31af6d9b821c5215a85b6b1872621dec3")
addappid(1519740)
