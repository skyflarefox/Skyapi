-- Lua provided by SkyAPI 
-- Game: Sullen: Light is Your Friend
addappid(525460)
addappid(525461, 1, "ef45be98f97b4bf753900f34dd1359766231e6c0c925d2b29fcd27e887d2abac")
