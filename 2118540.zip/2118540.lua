-- Lua provided by SkyAPI 
-- Game: My Big Sister: Remastered
addappid(2118540)
addappid(2118541, 1, "baa6c26c3a875d8b8cc4ce5950fc574f4c2a8d2a8b168971dadac0e14f5a8957")
