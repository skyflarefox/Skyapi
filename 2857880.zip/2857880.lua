-- Lua provided by SkyAPI 
-- Game: Yakuza Rogue: Yokohama massage parlor chapter
addappid(2857880)
addappid(2857881, 1, "0e3aed59a84f0f573d8dde17640d405192be412ff8acd5121f9d435260394e04")
addappid(3021070, 0, "c15898f5cb9817204c1ced116d37a58b054feca4371bd675c4cc81a832ab1ec2")
