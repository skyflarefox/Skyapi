-- Lua provided by SkyAPI 
-- Game: AppID 914800
addappid(914800)
addappid(914801, 1, "f44c7c8d89df72bdd72122a3271719e26eb0f559c9ced165b22be5bb4d4f07c9")
addappid(1231690, 0, "484366106eceb9ee1e09ff7e6294729cbfaa9f5acc58f9face07a8659b2bc4cc")
