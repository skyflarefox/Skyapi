-- Lua provided by SkyAPI 
-- Game: Lord Goblin
addappid(2483850)
addappid(2483851, 1, "0a60cbbe629a18e2bb9f893067cbcb33bc004e1a4996d2d1002d9b522e4d4cb4")
