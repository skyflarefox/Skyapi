-- Lua provided by SkyAPI 
-- Game: Monkey Business
addappid(2381690)
addappid(2381691, 1, "93f447fc79f2f06e62c4be56c9c2b448361d6acabe200d2346a88efc3d7eb3bb")
addappid(2746660)
