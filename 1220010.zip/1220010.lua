-- Lua provided by SkyAPI 
-- Game: AppID 1220010
addappid(1220010)
addappid(1220011, 1, "c282e5aea5508168d72b73189b916ba008b9c13e82fad2a3e0cc00ab1dac1b7e")
