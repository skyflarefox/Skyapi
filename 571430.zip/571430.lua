-- Lua provided by SkyAPI 
-- Game: Drone Hero
addappid(571430)
addappid(571431, 1, "55779aad3c21f44f0eafda085813504fb67cef51abace05e934fee1e6079c063")
