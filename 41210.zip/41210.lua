-- Lua provided by SkyAPI 
-- Game: Eufloria
addappid(41210)
addappid(41211, 1, "75d546287a157d4b33dbcaa2409880bb178988342ac208076452aeb5365b594c")
