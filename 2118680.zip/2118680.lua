-- Lua provided by SkyAPI 
-- Game: Kingdom of Lust
addappid(2118680)
addappid(2118681, 1, "50720a2eecd17627680d712039dff7b97852e8442319725c727137012c1c4151")
