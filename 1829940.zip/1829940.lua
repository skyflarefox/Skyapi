-- Lua provided by SkyAPI 
-- Game: Downfall of Krynto
addappid(1829940)
addappid(1829941, 1, "fd07c21220f03b346dc979863bfa7bcc7e1de9dcacc9f024fa44c762aa2106ca")
