-- Lua provided by SkyAPI 
-- Game: Girls and Blocks
addappid(2852950)
addappid(2852951, 1, "39f67331da14800b41b2fe8b2354899d4769f2a59dabe707c8df64de544fc267")
