-- Lua provided by SkyAPI 
-- Game: Fujiwara Phoenix Demo
addappid(2419560)
addappid(2419561, 1, "cae1464e8776c171907e36b481683726a45f73a0fd71fe9b9d5c6528aa1201d9")
