-- Lua provided by SkyAPI 
-- Game: Music Racer
addappid(893030)
addappid(893031, 1, "3e905f2c4fe37332d819d661afbef85cc1c280493e06d6ef8bbab19d0ac47b7c")
