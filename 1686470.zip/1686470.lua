-- Lua provided by SkyAPI 
-- Game: X-Force Genesis
addappid(1686470)
addappid(1686471, 1, "0885266d9e14058e1505866ac1778fb351680568d55b33af33636f8fc5ba3166")
