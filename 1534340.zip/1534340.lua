-- Lua provided by SkyAPI 
-- Game: Fida Puti Samurai
addappid(1534340)
addappid(1534341, 1, "1a3b2d3914505a32f0ade9b93f0bde095532a7999cf12ac80066cab8406fc4c8")
