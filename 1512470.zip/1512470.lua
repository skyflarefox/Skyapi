-- Lua provided by SkyAPI 
-- Game: Incel Syndrome
addappid(1512470)
addappid(1512471, 1, "9bd669264cdc37e6e3800bad281c59282f490d61ed3eb64a1ccc4b223a373443")
addappid(1512472, 1, "f50db80902ff614e25446ce896f7276c1418ea01e75dd0afa02cf645bb741217")
