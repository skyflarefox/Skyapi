-- Lua provided by SkyAPI 
-- Game: There Is No Game: Wrong Dimension
addappid(1240210)
addappid(1240211, 1, "3de7ca82e6f5ed632137a40a3633050d7391e2cb5a159413c08d6c651d5a53d4")
