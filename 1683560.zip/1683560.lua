-- Lua provided by SkyAPI 
-- Game: Ravager
addappid(1683560)
addappid(1683561, 1, "e4dfb83b7827c5851b83586e05311dc5f700ae4ac4ceb62641898671bb6f90da")
