-- Lua provided by SkyAPI 
-- Game: AppID 576810
addappid(576810)
addappid(576811, 1, "80ff014996de730f71f7e73520bf6ea93222fac01f59ea2a6f6d58e3f4ff16d2")
addappid(576812, 1, "aa405a4c6ce547e3d9966417c0bf422c64312233e5d77d3cc38782a6ed74aa9a")
