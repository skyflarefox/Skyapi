-- Lua provided by SkyAPI 
-- Game: America's Next Top Pornstar
addappid(2793310)
addappid(2793311, 1, "37da9a14882ecf7f8481e8fecbeb97a4ca93ef12135962378d6b7c8b6d0e6548")
