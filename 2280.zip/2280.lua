-- Lua provided by SkyAPI 
-- Game: DOOM + DOOM II
addappid(2280)
addappid(2281, 1, "59d59862ea40c92ef01e270e60c349de893eee7a55a089cb6ef63b68e8935075")
