-- Lua provided by SkyAPI 
-- Game: AppID 2994530
addappid(2994530)
addappid(2994531, 1, "1c367875cdbdcc082d9be6e84d0cd697c04418349881e1b554ec062177a9752d")
