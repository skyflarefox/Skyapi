-- Lua provided by SkyAPI 
-- Game: Mushroom Quest
addappid(868230)
addappid(868231, 1, "ec2d71e4ea3319a12b2e468837dec0212e8cacf4a34d80e6415f9de502bd9eca")
