-- Lua provided by SkyAPI 
-- Game: Path of the Midnight Sun
addappid(1969060)
addappid(1969061, 1, "a4ce751221b376120ed86d9d9ceea01aab38793cd516052c48d334d1b7d6d537")
