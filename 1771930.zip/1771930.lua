-- Lua provided by SkyAPI 
-- Game: Weird Cinema
addappid(1771930)
addappid(1771931, 1, "03ad07522b2198dcd5024a9cfd7f923522f2884d3182a2772e9f384842360057")
