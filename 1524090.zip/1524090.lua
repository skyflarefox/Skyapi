-- Lua provided by SkyAPI 
-- Game: GRIME - Demo
addappid(1524090)
addappid(1524091, 1, "d9d9b9328eec27e58d17e8a78c3f50cbc3338c57d4e06c67eb8937389e09a821")
