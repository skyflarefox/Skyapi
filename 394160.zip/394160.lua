-- Lua provided by SkyAPI 
-- Game: AppID 394160
addappid(394160)
addappid(394161, 1, "ea0003096fe445305ea99b789d968df2fe1bdb1702443ed7e0fd58cfb525f948")
