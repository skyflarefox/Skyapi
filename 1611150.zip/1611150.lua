-- Lua provided by SkyAPI 
-- Game: The Cube Factory
addappid(1611150)
addappid(1611151, 1, "63ceaa728df8ce79f71fb843bfd5b97a48eaf4f703981d03c9612dc9e2333f3d")
