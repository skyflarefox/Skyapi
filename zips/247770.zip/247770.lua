-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(247770)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(247771,0,"1db360a99679e85c85830d330be250f9545bc10e2d04adf8bcbe7717ebf618b2")
setManifestid(247771,"7122248614402239406")
addappid(247772,0,"80d000e8de670f48341e9d94fa7f11ff1f893de14a9ab0ce6924d5ced4a9eb59")
setManifestid(247772,"5253528043419007865")