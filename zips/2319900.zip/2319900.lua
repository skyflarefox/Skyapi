-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2319900)
addappid(2319901,0,"420b840bae5b4fc39fa08d4b141a90bffb44e5e9f5e65a802e980534db1dfa76")
setManifestid(2319901,"3052473962679518754")
addappid(2319902,0,"8d96c5c7f726d465cc3742fdd449113d944f69abcf922cc72b569cffd5adecc3")
setManifestid(2319902,"5673210690810000622")