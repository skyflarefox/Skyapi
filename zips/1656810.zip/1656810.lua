-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1656810)
addappid(1656810,0,"d25abf4bc94a6e29d619b2cab31d80356e90bdccd7d76c2d1ae66e7dc21cd05d")
setManifestid(1656810,"8953733160857412340")
addappid(1656811,0,"6129f427bf739a143db9f89599be2ec3268fd41e3c758d57bd860cda90fe1f15")
setManifestid(1656811,"196440362220956543")
addappid(1656812,0,"a633554f82c4743ad225d132206109d5033c6618982c382507153c1a5f87f608")
setManifestid(1656812,"2771525721837571052")
addappid(1656813,0,"894f6434497af164c7e08a2bf272cbdbff92a69807a756686dbaa45fe4133332")
setManifestid(1656813,"185327280035340810")