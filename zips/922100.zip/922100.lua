-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(922100)
addappid(922101,0,"bb73ebf9d40923e295c3705e2ad54408b170b9048b595952c6ac1d8484be76e6")
setManifestid(922101,"8332009948034642769")
addappid(922102,0,"1673f03a5e477553c375f2501ddd8aa52cc3591409297a397d8bd623d0996ed5")
setManifestid(922102,"1539577171704178340")