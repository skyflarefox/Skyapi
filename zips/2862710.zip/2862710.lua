-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2862710)
addappid(2862711,0,"18a7d8d5778635e905c2807b23555ca50bd0950d5ed67ef9a9c2fd14abcc0fe2")
setManifestid(2862711,"2528227757348231668")
addappid(2862712,0,"b517e1314723ba1073c13cf99e125caa7bad5a75418131ec7062f8f2fd8e940a")
setManifestid(2862712,"8412254861602484451")
addappid(2862713,0,"03e10ab1df52fbe39fb8417d5e2e143f6901ac39b484b9803d147bc11fcb2f6f")
setManifestid(2862713,"1900831108241748121")