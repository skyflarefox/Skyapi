-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(696400)
addtoken(696400,13719886409915882436)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(696401,0,"9fb6bef9dd57af8be96d1cd94c86ebc4f67fb09429fae1233b33590d468c95c1")
setManifestid(696401,"1199655590426712383")
addappid(696402)