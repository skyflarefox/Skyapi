-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(823710)
addappid(823711,0,"692eceb9b2f1388bdba1fcedb9f78f02c03e2be79d7134795f3405d24367d69c")
setManifestid(823711,"620859698889610465")
addappid(823712,0,"deff6d2585fcb9e012ce2e8ad09344e1a1bbb04b794c911c4c14ab35920401ac")
setManifestid(823712,"2177988128663538389")