-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2686860)
addappid(2686861,0,"44bc0a7a0b99060cccb20de62b0dc06be2a3e179bcfec88c20c840e440ad63d9")
setManifestid(2686861,"6680255257538428094")