-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2951290)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(2951292,0,"b18213a32a06c699e18719f92a7dbad4bcb30b2173bcf9ac669683fedef30b9d")
addappid(2951291,0,"aa4f04142e2bfbb93471aa2dfde711dcfaf3c8e031b2a695beb2b46b6c0daf24")