-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2118400)
addappid(2118401,0,"2f585689f79f5636f8027636024d246211bb0e68def6d81c36ab5fb1936cd6cb")
setManifestid(2118401,"2523587326234531157")