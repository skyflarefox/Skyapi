-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(546490)
addappid(546491,0,"05077fdf882e9a7ff95a367ad6fddbdcce8db4a5bdd1efd0bdc04f86e550ac38")
setManifestid(546491,"3499429602050234010")
addappid(546492,0,"4c6681e36f276958d5826ba262ceeeea4334286ace0f2283021d5b819b228bdb")
setManifestid(546492,"1636926344944634880")
addappid(546493,0,"fc8841794fad0e2121b52c42d719a429101011e8cdb1f2e792c146b1fcf12c56")
setManifestid(546493,"6141711513194773659")
addappid(553010)
addappid(552820,0,"73a793fd5da22d7a4b346e584b604b6eefb79fab1ae0226c73b42e0832c221df")
setManifestid(552820,"5640608183233397558")
addappid(546494,0,"d4c4ea640ca3883ecad84986ad57c0d3301e92eaf91343f90e85ff81c55b0f9b")
setManifestid(546494,"4905310401459775610")
addappid(546495,0,"52a6b9995f5505e8eb30f220df51fc4ac9c5d148c28162853f661924c891e917")
setManifestid(546495,"3278816934576665671")