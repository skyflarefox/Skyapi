-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2465470)
addappid(2465471,0,"c58d5a418d732cde33286e8450b6d003ec9ff997ea9b44b0a3da6a5e797caddb")
setManifestid(2465471,"531211737386579146")