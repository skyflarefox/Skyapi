-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(890730)
addtoken(890730,13563184663983582137)
addappid(890731,0,"f26122e0c18bf9260b94174359169b41aeecac1bb5a3d1398f78c9ee1e4172d6")
setManifestid(890731,"3915278656014914229")