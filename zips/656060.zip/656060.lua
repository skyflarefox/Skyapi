-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(656060)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(656061,0,"d489587899fb7960822ee7c12c82bdd45c7f3a3ad401d472871c1b753e863949")
setManifestid(656061,"1638030292306666219")