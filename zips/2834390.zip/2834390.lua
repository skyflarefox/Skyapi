-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2834390)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(2834391,0,"42e479481f458de70834e6fcce9f08102d64b8078623578ba7759e6eb9a546ce")
addappid(2834392,0,"8fdd9fd82669f8d894bd28bcf8de900bf9bb1bd88b4c5bd6cf216c9bb4ee2c21")
addappid(2834393)