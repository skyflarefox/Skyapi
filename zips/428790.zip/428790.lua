-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(428790)
addtoken(428790,13400128242778518428)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(428791,0,"8b05e66d0012147144fff88761ad471ab73e7f594d20426edcf9af6b579d5b36")
setManifestid(428791,"3095167427658641544")