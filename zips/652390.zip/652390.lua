-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(652390)
addappid(652391,0,"9b51f9f00c6cc937bcd70d0e4d24eb91842dace6cd274c1b7800afa9c340e1d8")
setManifestid(652391,"9016985366871282863")
addappid(652392)
addappid(652393,0,"f1edbc72a49392c90af315fbf248667f1670125734b520a62fe523ad1b198ac4")
setManifestid(652393,"6054785941328339331")