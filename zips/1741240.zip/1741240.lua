-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1741240)
addappid(1741241,0,"d0c46184813765018c3673e7df96df323690776c084cb921a72f141429750129")
setManifestid(1741241,"7397428717577397892")
addappid(1741242,0,"1674c3d97f093b66246a074f1611811a01eccff652fdba50f349f2bb831dbccd")
setManifestid(1741242,"3988357156147961655")