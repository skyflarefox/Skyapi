-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2624910)
addappid(2624911,0,"5ea0effdd59991dea3acdd21722757d0143414228cde452e91d54a2ae3c5b676")
setManifestid(2624911,"567399531359759186")