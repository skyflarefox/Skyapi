-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1514800)
addappid(1514801,0,"488cdda6a11e894c68d39666957478e7409e4b0bb8c1d1c92b13ee48c5c1f58e")
setManifestid(1514801,"7014609771796603661")