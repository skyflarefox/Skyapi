-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1635360)
addappid(1635361,0,"924d03db7174320d18c12b4a4958c08b6275ea5da08a219e7dc31acf83544d44")
setManifestid(1635361,"3391053104968925145")
addappid(1635362,0,"d0860824aa0c13b7e66cfd8c3bbc5cb5038f23c1a50362abbbe4cb63f309f784")
setManifestid(1635362,"4136102433678879925")