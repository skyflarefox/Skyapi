-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2949800)
addappid(2949801,0,"398122efefd28825d94142d5927ba9e73429a27b3c39512b3053c872ce82bbca")
setManifestid(2949801,"6236039666892347197")