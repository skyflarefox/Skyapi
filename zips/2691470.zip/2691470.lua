-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2691470)
addappid(2691471)
addappid(2691472,0,"131d982b46f8756bbe8a0cfb8f6724fa817d5ea664397ec79dc2af58461886fd")
setManifestid(2691472,"6433619720456651197")
addappid(2691473)