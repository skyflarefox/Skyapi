-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1861780)
addtoken(1861780,262588390737303137)
addappid(1861781,0,"ecc0428370cee04858d0be15cd249a7d8e553ef86cca30c9b774d38128ab77b5")
setManifestid(1861781,"7671760931379392118")
addappid(1861782)