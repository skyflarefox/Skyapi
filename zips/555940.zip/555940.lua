-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(555940)
addtoken(555940,1206217906180160830)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(555941,0,"6aa9d6f055317426f77ba5d1c4e119637959b4060416344e7eaf2c4e1b948a3c")
setManifestid(555941,"957371298419931191")
addappid(555942,0,"1ea50f19fe335b9562c8178a7d8b73cbfab9a60f4b6816374b7133d3e597cd01")
setManifestid(555942,"9169202735654670617")
addappid(555943,0,"4e55316a56e824501a667fdaec7c06aabb20fd6f0948e6ed22c4551a9b9c77be")
setManifestid(555943,"6305427199764268362")
addappid(555944,0,"236a73537c32592df7ae55db4fd374a4abaf57b2ded884a2b6235f17d4d0a21e")
setManifestid(555944,"2201313773752201528")