-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2010030)
addappid(2010031,0,"ad79833ee6091179507f4008cbbba4cc167bc833221fe09c2d6fa512dd106a0b")
setManifestid(2010031,"963907628653641320")