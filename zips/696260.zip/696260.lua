-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(696260)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(696261,0,"67a0270fd098a22c84ff0a09f80f67c2011fee49edc7011faeaac50f05213f33")
setManifestid(696261,"1345350015068019400")
addappid(696262,0,"ea8f7d5cb21f9bbff9ba29da1f87e61bee0f93822acad275669199903f7b8298")
setManifestid(696262,"1431817530079395411")