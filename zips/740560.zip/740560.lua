-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(740560)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(740561,0,"1da0a8b2a4704edb4c8ab34d873d8eccf38ac038a90a9591e29386a8d0617927")
setManifestid(740561,"2126656203442131306")