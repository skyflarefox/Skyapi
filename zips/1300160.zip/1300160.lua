-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1300160)
addappid(1300161,0,"478e977e482eac7731ca72f82f4afa71327261f151cefb3ec44f0d9f063965ae")
setManifestid(1300161,"6967257190397809858")
addappid(1302060,0,"0dbc7a6aa71424a08833db7b0ff2bdaead0a5e2c30b470b65a7b7a5e2bed256e")
setManifestid(1302060,"1967565530201561430")