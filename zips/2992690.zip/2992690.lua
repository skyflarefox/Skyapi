-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2992690)
addappid(2992691,0,"dcba2a06ce1cce09435f7ef576e2a59a04215da85a8c3f695798191d717651ba")
setManifestid(2992691,"1937408552929553506")
addappid(2992692,0,"a461368f95433fd2798a809923ca731f7b90e52977c3a54c11452f4f6164dda7")
setManifestid(2992692,"5587202602357188300")