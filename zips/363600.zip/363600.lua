-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(363600)
addappid(363601,0,"ddc01b4bfd2e71f3b9d42917e02ab2b873dc5fe1b9d50361b1746f4fab692b52")
setManifestid(363601,"7387767993653648079")
addappid(363602,0,"a3a0f6cecdbf665739602d5135d79272717442cd7b7cc3d7f9fbeb97b6898b33")
setManifestid(363602,"378556502422087475")
addappid(363603,0,"bc4ddcc3c0e569145b7c3dd079990f38b754b6617c2c48f54bd963c1b2801b53")
setManifestid(363603,"1424806365044070048")
addappid(391860,0,"1f1bb61de7cff153d8bedab0a72211c5d2e105c05d8f34173a467e7825caa51c")
setManifestid(391860,"6950478326005789511")