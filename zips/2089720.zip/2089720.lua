-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2089720)
addappid(2089721,0,"30e51511be12def3ca304ff195b219df37382b2fbdf9586c46383af035e8deb1")
setManifestid(2089721,"545367256517487085")
addappid(2089722,0,"a4f630af1a8957458102c52b7693568d0754c2fb615770c2f1721b941cf3bf09")
setManifestid(2089722,"6031879932362613470")
addappid(2089723,0,"c0775b45a29b037e2e1a504d83cb180707d95a84caba4a961fc7dd0d5986c3cd")
setManifestid(2089723,"7711937096479476590")