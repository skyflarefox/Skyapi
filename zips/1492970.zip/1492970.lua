-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1492970)
addappid(1492971,0,"fece933a7ee67d2fc16dee71caa84f3b9e7871f87a057977c9900c546cf9d413")
setManifestid(1492971,"8526504535185701540")
addappid(1492973,0,"27ec43fff9a5f1c78f5dd79dfb8f5d6dc6b19ace6b7df3713ecc1bc0c6dce9a5")
setManifestid(1492973,"8977536763259191905")