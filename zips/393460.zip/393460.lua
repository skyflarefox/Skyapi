-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(393460)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(393461,0,"833d652455d0c4e40a499a0de444a1d3bfc660dd10f146f988d326b6ae9d673c")
setManifestid(393461,"4887064419910719507")
addappid(393462,0,"ad4563a11a758246e14491798b9d59717621269f9bd09113a42fb3aed02b6a7e")
setManifestid(393462,"8963081318079795594")
addappid(393463,0,"ec4ccf62adee52d75666bd554adabb87496c8039b2ce4281aed8cbfa814099f5")
setManifestid(393463,"4204945824763309142")
addappid(492620)