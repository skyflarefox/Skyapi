-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(829230)
addappid(829231,0,"fe138018c6e42de719538a3a1f007575561747c1d0e8a3bdc8beee72db4c85f9")
setManifestid(829231,"8823760024866566881")
addappid(829233,0,"fb482e8660ffc3357f2c19a2b9f55f4cb95d273b34ed6bf64473b1e9392b33db")
setManifestid(829233,"433401327991273859")