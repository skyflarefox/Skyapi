-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(362090)
addappid(362091,0,"3c47fff8819eeb83ef20e448f751d639a1aca6497ad00e8aa57fc10514f83a4f")
setManifestid(362091,"2904880714820961345")
addappid(362092,0,"4ad138b7a717c454253882ca556370ff0c4d098b4bb52880c984856f56e17651")
setManifestid(362092,"138372918911503115")
addappid(362093,0,"a4e31e1e1da2df27225c11eeb3d567dee2bdbaddb877f060f6561cd00137d9c6")
setManifestid(362093,"7601699171446725658")
addappid(372550)