-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(732110)
addtoken(732110,12600569950390936922)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229001)
setManifestid(229001,"4049573910112143457")
addappid(732111,0,"7c78863b337d4a7d1acd08d9b7cb40a3306da31f62a57723381c4d47f699eabd")
setManifestid(732111,"1853162512700448899")
addappid(732112)