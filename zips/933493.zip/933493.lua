-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(933493)
addtoken(933493,13896167761093581552)
addappid(933493,0,"a4eb8ebdeb7fd3f33fbd229f9da8230a6be4cd7561a65e271106c9ef71deea95")
setManifestid(933493,"8996713594365027854")