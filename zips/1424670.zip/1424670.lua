-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1424670)
addappid(1424671,0,"2dc40d3b1110457d9ac2169018eaee8ebc193d25c4ce9d2069e8e5b54af8fd2d")
setManifestid(1424671,"6595448993601423679")