-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1416790)
addappid(1416791,0,"8f197ce49f4b3c5e6ec5fec56704934345b4b79a82be0010e513b45916b8ff5d")
setManifestid(1416791,"3538604224365069261")
addappid(1416792,0,"b2c96664435b9440b61cf5618c7235b2da4abb7b9b6457538befb6c2bb21fe7c")
setManifestid(1416792,"8916667336135511303")