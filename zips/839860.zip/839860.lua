-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(839860)
addappid(839861,0,"5ac402a2f2334d05381a6e9812036b0056375f135992ffe1a98b3b05d75e0d16")
setManifestid(839861,"8595601174929290438")