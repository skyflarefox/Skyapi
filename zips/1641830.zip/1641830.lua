-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1641830)
addappid(1641831,0,"49c699e0c480ae02a210faf27fecfb984b0f2a41d9b92a694f9628a5b85b3e00")
setManifestid(1641831,"6474602932152513069")
addappid(1641832,0,"327af1f515387374592438be68937b7e43f86597d0fbba8da269655f5baf4899")
setManifestid(1641832,"8512554140825062379")
addappid(1641833,0,"da397803d6c97551c22d966bcb4965afc0900dcf7dc8e752b4d8c338938b5500")
setManifestid(1641833,"5661213398476871908")