-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2902830)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2902831,0,"725c59a08499b377f26b8789b9d30e17bfd0d543717c4d51a4afab2ce53390fe")
setManifestid(2902831,"152754283985013394")