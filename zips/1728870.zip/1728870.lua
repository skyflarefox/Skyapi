-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1728870)
addappid(1728871,0,"ec6c46e80ff86b77e19ca969c10d8d73e2cd483ffc2a03ba548d4bac9ba79617")
setManifestid(1728871,"6806353789108883710")
addappid(1728872,0,"86a16e79f10138c7c511956cd2e3b383aa033b5b1f3e1de824d64c340e335666")
setManifestid(1728872,"4912754452131982987")