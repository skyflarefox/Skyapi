-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(646570)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(646572,0,"d46524b47e7a9384e6b575394a6e96940634c8db3f58e829182eb486ca60e425")
setManifestid(646572,"2910015420030023273")
addappid(646573,0,"7b0997618ad03031136f9caa6811f5d2c08ee7e0ac4b9c745675f12fd0354ee4")
setManifestid(646573,"5221386008033040636")
addappid(646574,0,"85867004baa33349870d65ae84baac02f1a0e0280462a7b6f41912a30e008955")
setManifestid(646574,"6089130681980710352")
addappid(646571,0,"af36e1914da16f3e4556bedf7e46a76646b670c91bb6e1d3cca380e16ceb2df6")
setManifestid(646571,"9072802409324604124")
addappid(877621,0,"9aebfbce314584af6e967104be1d5060284feca4baef886010adc9c4a983b4fc")
setManifestid(877621,"1616206291221819177")