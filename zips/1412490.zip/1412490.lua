-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1412490)
addappid(1412491,0,"065413db420d565d529a6fc45db38b19868ceb5219ae841fd0cb89754f0ec896")
setManifestid(1412491,"7292431247434305857")
addappid(1412492,0,"9ad50d97418596ff1467e7c2d6e87e0768f84a995944aed2bb5ecb5d580e7f15")
setManifestid(1412492,"6050469822624457919")