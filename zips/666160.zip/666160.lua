-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(666160)
addtoken(666160,14654076966855399985)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(666161,0,"543a32ffcfb0463f9fb01db40a9c710cde0e56471a1ba53b06cf664af5545c3d")
setManifestid(666161,"8803426328610424671")
addappid(666162,0,"4f57db0d51fa047ecd9b28b5baf5b5ee91da8fe094fd223814ed17043f953bb6")
setManifestid(666162,"6144846046584997179")
addappid(666163,0,"22d384fe3f91c37af674a7a9534fc3ceeda87a5db4f3cc6b4b8e3b2c9881c171")
setManifestid(666163,"8566219599148243938")
addappid(666164,0,"cae13d9386b1abb2f1f1d0613eb2ae124d81e82902564316e3fafd37438c9fec")
setManifestid(666164,"5466630343533452833")