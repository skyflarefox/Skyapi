-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2660620)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2660621,0,"5d5925a6e95efb9f35f04cc6d09b977fc5b2c642062e145bdb86fd21c374c3b2")
setManifestid(2660621,"4782819728768791714")