-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1649010)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1649011,0,"37e12969216f3718cbc3da5252107bb96e8ea10bea2e65c6edc91b5d632345ec")
setManifestid(1649011,"375685221609601139")
addappid(2586980)