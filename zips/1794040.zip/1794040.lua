-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1794040)
addappid(1794041,0,"a9fc67585ec8ec56e03e03d1887c0e461704132b34411038ca14af5d57b32283")
setManifestid(1794041,"9084066288834936327")