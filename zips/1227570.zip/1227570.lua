-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1227570)
addappid(1227571,0,"9581f9a4bc8e847cc78e7cd6d0f1cd82d839484adc763ada7044a8dfa23c8f1c")
setManifestid(1227571,"3287169545950174799")
addappid(1227572)
addappid(1227573)
addappid(1227574)
addappid(1227575)