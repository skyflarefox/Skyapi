-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2423840)
addappid(2423841)
addappid(2388461,0,"df5b531131bdde59e44e07763828b889d3808d09fd0e2b0daf678841ccde5f88")
setManifestid(2388461,"5923601375060561707")