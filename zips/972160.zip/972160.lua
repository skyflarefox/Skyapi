-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(972160)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(972161,0,"a77ed090ae1a637858712641d654312c589bf467e445ba4472309dcfd2b7c17e")
setManifestid(972161,"7849324634488426558")