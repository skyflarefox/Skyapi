-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1467920)
addappid(1467921,0,"ff504cd58d996b283902cb0d0285dc9ea8067285e5fcdc00ad552f8d4e449af1")
setManifestid(1467921,"7009112324665659945")
addappid(1467922)
addappid(1467923,0,"47150a7680248c190d97431bc7eb3d903421d66b2ec767e47b5870e703a06af7")
setManifestid(1467923,"4904164302046725195")
addappid(2264860,0,"2929ae1f551a87e05df2a2bd9f35132fd8e8734061b131e8767d2d0beb6a380b")
setManifestid(2264860,"3271636736313260155")
addappid(1467924,0,"d68892c2094fae4c61b3262f8555d041daa69e6bf5e2827b438a164c537af381")
setManifestid(1467924,"3953399411971057561")
addappid(1467925,0,"3fc876f779d5ef97ade70e5cf0a0113e4b4dc96f9bc33160a32822cbf701138e")
setManifestid(1467925,"1267376502228860939")
addappid(2264861)
addappid(2264862,0,"77eb93037daa438629f5288107c42721c9e312ca5a68424c6e28f0d17be29265")
setManifestid(2264862,"2052681382690727815")