-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(677300)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(677301,0,"ab20343c15fce2dc8fdbc3b719e1a75920c0bb299b4fc7cd01b2828cdaf2b294")
setManifestid(677301,"6593659221710263505")
addappid(677302,0,"f6839199eb33d353e4f4f4d09664427937e1372aadc3f4953bf59ad6a2840c8d")
setManifestid(677302,"7421829048030202323")
addappid(677303)
addappid(677304)