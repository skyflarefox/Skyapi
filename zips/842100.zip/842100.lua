-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(842100)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(842101,0,"f8914dc18d4332a8ef96e4238cb7c74fc4501861408680f3cc2c3e2ca622fac8")
setManifestid(842101,"1123923986562136782")