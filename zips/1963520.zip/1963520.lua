-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1963520)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(1963521,0,"9715e37af2e7eacb456eebef6924ee23e34a48a1456559e68f8d101bff3c68b9")
setManifestid(1963521,"134509047228128258")