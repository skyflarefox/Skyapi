-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(656710)
addtoken(656710,1258987500687321423)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(656711,0,"a2a29a6ddf665fcad3d9947ea6e2694ba7a8e2784f54078e6b29a40b5b61cde6")
setManifestid(656711,"1020083231725050031")