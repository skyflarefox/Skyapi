-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3007500)
addappid(3007501,0,"83ba0ae52365aa9e1a1395ad55f1353a153d6dd85960d24c2b59d78a7fde6080")
setManifestid(3007501,"8973460725013913922")