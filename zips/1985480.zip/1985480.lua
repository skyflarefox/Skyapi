-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1985480)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(1985481,0,"872c3c830afb87f77a615ddd0c119967be7686245f2dd3b529611fe15a1c092f")