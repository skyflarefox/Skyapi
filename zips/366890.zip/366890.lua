-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(366890)
addtoken(366890,13663964182212555110)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(366891,0,"201ff3e02f89aa5899feb3c77e2b321e66d6fe4ec370ac1ed10686c4e132c48c")
setManifestid(366891,"351793160272849366")