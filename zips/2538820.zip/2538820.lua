-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2538820)
addappid(2538821,0,"fdff66e4d7fec5cf208a441f83c2e9c997da45dda6d1ce389101f2b6beda3473")
setManifestid(2538821,"5393320185824282818")
addappid(2538822,0,"599916638926373493a8eeb416d0c6af1d9b0075004d13ee594f7548a21af7c0")
setManifestid(2538822,"4746123267454428744")