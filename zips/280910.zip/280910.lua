-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(280910)
addappid(280912,0,"e5e87ac99f9ca3e62275e3fef3c565291d789c777db9c84b9580de5cfd82a0ad")
setManifestid(280912,"2043198764307958694")
addappid(280913,0,"0f163b10eff05e29313fca44e81d7c59fd636ba64be5ce6ca97717634e203d19")
setManifestid(280913,"3581640117395045186")
addappid(280914,0,"179cba5c5fafd3673ff04c9ee6a07681e311a9f668960c62e09d8113627cbcaa")
setManifestid(280914,"2618483484997245479")