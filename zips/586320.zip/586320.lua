-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(586320)
addappid(586321,0,"393b4a87201e0a30b9b8625cf25f902f5a65e96edfdcb2b530416056a757a0dc")
setManifestid(586321,"3639886307156278726")
addappid(586322,0,"14c8cc0f95cc387a9a35ba1b217c5bb82b0e018d70aaeddd7b3b613cb2c80210")
setManifestid(586322,"3107170335987539816")
addappid(586323,0,"aafb94b94a96a6250087e295d8429a78cf24f63db5312ae332e2ea73d489bb88")
setManifestid(586323,"4896029042283978934")