-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2222910)
addappid(2222911,0,"f7ec4227af258c431cedc3250cf74a0b408ff671edded29b1e7e148e22f95fb2")
setManifestid(2222911,"7443816902566821441")
addappid(2222912)
addappid(2222913)