-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2164310)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2164311,0,"b8e2d93043198b095f32ee6a60fcac8d6ac1e2a01de48a927adc36ea279cd7ac")
setManifestid(2164311,"4004992443643896260")
addappid(2164312,0,"78913506cd63f080ce97b84e26a5b325885df177870d9f43d48deaecafa0b6f8")
setManifestid(2164312,"932785357790941921")
addappid(2164313,0,"2f7865eede4dd2b638294358db4a0989b75f3c16b1bd6492a083ace8d377f0a5")
setManifestid(2164313,"7046186301072319877")