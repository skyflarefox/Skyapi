-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1912072)
addappid(1912072,0,"48a4fc26cf1e899e5817f72cb9df0b3199c93d6f9ce010aeb7f6c356934d8974")
setManifestid(1912072,"262113667127504677")