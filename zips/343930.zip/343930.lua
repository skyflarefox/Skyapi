-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(343930)
addappid(343931,0,"e1a238361cd6824704096943c6f87dd3d190a9954a06453756339d9cf3e782d7")
setManifestid(343931,"1058804986781983753")
addappid(343932,0,"16a1d2adc3648357bf031c770f140695d58085d0130911beb266c63388957e14")
setManifestid(343932,"4741219777275871804")
addappid(363350)
addappid(363351)