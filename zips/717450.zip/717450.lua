-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(717450)
addtoken(717450,11008058209880317903)
addappid(717451,0,"f6ed7ea53a335e5fb205a8f861a2c88b793b7e430cf056a9143a5f4437cb139f")
setManifestid(717451,"4994530550990766612")
addappid(717452,0,"fc7b4f1008a6e6a0497c74757fc337a46d88d9dce44c519e42b4ab5fc9d5cd17")
setManifestid(717452,"8110293523272905187")
addappid(717453)
addappid(990680)
addappid(990681,0,"2ed1439a077023a1403614e3e90a2f239a73c9135af3a89655c0fd79e3799a6c")
setManifestid(990681,"7599022835714583385")
addappid(990682)