-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1488020)
addtoken(1488020,11094269554514648807)
addappid(1488021,0,"57e8a0003b99a1947612f5b36a607bcc082cc6a16557579cfc4c4f43367fcf7c")
setManifestid(1488021,"3586147143372339887")