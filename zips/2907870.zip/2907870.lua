-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2907870)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2907871,0,"9144a62f859eeba20e54fb2cf3c5e0c9d3f52476a21eb9862fe06088fe237d82")
setManifestid(2907871,"687246648171210203")