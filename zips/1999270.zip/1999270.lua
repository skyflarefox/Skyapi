-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1999270)
addappid(1999271,0,"018b653b9b20cb999529b75c5893c842325de70b50a9d294e1425f2461089604")
setManifestid(1999271,"873845939608994832")
addappid(1999272,0,"bc8a0725a46c16535d2b0ea0ca3671bc100e16c5feb496ba92fa7bbfacc89061")
setManifestid(1999272,"5505416664520345647")