-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2153870)
addappid(2153872,0,"8d457689bea1359a61b8bc676238db49b96aec8e56ad39efd92741e9d2db04a6")
setManifestid(2153872,"425545223924338255")
addappid(2153871)