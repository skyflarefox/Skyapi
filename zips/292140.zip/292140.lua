-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(292140)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(292141,0,"549a471e372538d6e666807a2c77be950ad2fe1c6f2023fa8351a8a16942e913")
setManifestid(292141,"76473417885808439")
addappid(292142,0,"9dc2e5803adb867ad7ab36d54856c4746af9d8f61a6ddfe1fffe1441e50380d7")
setManifestid(292142,"4999560722177730503")