-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(324260)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(324261,0,"e146ebc692091c9d8a5db3aafc37001dd134b734fcf20d7a168480dfdaed9d58")
setManifestid(324261,"7745741345257069259")
addappid(324262,0,"8cb285c97a25a4b4f3031d0c22349e0f88f08c69e21e12736abc8955a5696d23")
setManifestid(324262,"5296181899840631194")
addappid(324263,0,"6235169779f0459dc4194873ba3c66b8b7c4eb844ed28c5805759c235717eee2")
setManifestid(324263,"622653836519506497")
addappid(499412)
addappid(499411)
addappid(499410)
addappid(602740)