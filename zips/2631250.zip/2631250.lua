-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2631250)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2631251,0,"35b65353c889458eccf51a3307b040e48e83aff12bddd5bfeb96a787392be005")
setManifestid(2631251,"150359154658006113")
addappid(2631252,0,"bb6e2fdcea1188e89b4fbbc62a18fad23a4580ab83074a3bee8bb5fee9c8eadf")
setManifestid(2631252,"431009321496640377")