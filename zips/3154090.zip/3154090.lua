-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3154090)
addappid(3154091,0,"53c778d79fd92445d1905ee5a9dd0cb59daa0a864834f9642246462a85c6bde2")
setManifestid(3154091,"6270943639327688332")
addappid(3154092,0,"e584c4afb43e58a84342bb65134beee58af1b65b965c58b5fa08579b5bc37488")
setManifestid(3154092,"1082350897927998127")