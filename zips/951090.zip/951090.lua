-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(951090)
addtoken(951090,8912088500900636751)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(951091,0,"594b8504df9f2e7fe94f7fa6d0b5ae3afdb11645bfa056ae7e07944e6366db3a")
setManifestid(951091,"6090401542749733382")
addappid(951092)