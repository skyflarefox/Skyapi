-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1498890)
addtoken(1498890,11407017420324248060)
addappid(1498891,0,"435b9aff214145fe1a3e24be1c84dead0c24e3fd21c1e2bce354c6d4b1359064")
setManifestid(1498891,"3269962712375838202")