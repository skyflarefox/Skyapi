-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(828960)
addappid(828961,0,"d961d606bc18bcee73b35288ea930ac6b53851d14ae3e3a4f12577c8743c597e")
setManifestid(828961,"7424313245267107732")