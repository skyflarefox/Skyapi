-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2321580)
addappid(2321581,0,"a69fd7eeac36c2ebb36a11777b2558b949e28a58473bad48194cf782e4520a6a")
setManifestid(2321581,"5760545202101801799")