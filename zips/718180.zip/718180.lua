-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(718180)
addappid(718181,0,"60d3667189e7f7b52c2c87c1754ac29bf3423b9ff9d39197bda98c7391494004")
setManifestid(718181,"1014007415288772844")
addappid(718182,0,"ba2fe3a6ade847a50d00d350ede0c32c8880d2b849f011b1bc57c789128733c9")
setManifestid(718182,"5913485897393606398")
addappid(718183,0,"6971f9a312420b0df2239df4bb4eeb72fb057712e30240ef74bcebd65dfa2c44")
setManifestid(718183,"4539069653839157948")
addappid(718184,0,"265ab5c4ca8f23dd7446d5c273d8026914d2fb35da283049c22542cc3792af8f")
setManifestid(718184,"1448513492220326627")
addappid(718185,0,"bc38ae41f54df64ff5217872a1d69ba5bd6aaca4a4f4144b292d82c299b98838")
setManifestid(718185,"2209220352935013467")