-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1174640)
addappid(1174641,0,"697d5ee432d2e06fb644d3c9536176de82e71ffe4b333f635c904dfa6ed96280")
setManifestid(1174641,"921862008048873447")
addappid(1174642,0,"90e9d0a9c55e0aa2363ec6afdbe541ac47297b20c10e90c30dcb48d8b604f46d")
setManifestid(1174642,"2611186443389457036")
addappid(1174643,0,"0b3b7f9a033dcacd6543281bc3e97fa061f4fe8b13a566dfe654e5b592bbdc38")
setManifestid(1174643,"5535936049530799725")
addappid(1573040)