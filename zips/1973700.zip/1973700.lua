-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1973700)
addappid(1973701,0,"0f5ba8e244309840a2746d3aad34a9fb9ca12a517cbbc32ae8d8375d6541db43")
setManifestid(1973701,"6390305438362535858")