-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1418070)
addappid(1418071,0,"0fc14254748cf52a5ffb674a38106b62956b421a187233f66381af16c9e4236c")
setManifestid(1418071,"4860458539731430065")
addappid(1418072,0,"55320f667cab00d7690be42717a64ce334d2f001959066648aa28b6f048e547c")
setManifestid(1418072,"5792448759614853447")