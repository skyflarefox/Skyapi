-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(547410)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(547411,0,"48236fac534677eb32cf3fff2ab5dfd750cd131efdc61deae29ac5b1868f978c")
setManifestid(547411,"3166586821488209185")
addappid(547412)