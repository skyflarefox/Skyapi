-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1366750)
addtoken(1366750,2769747181124058806)
addappid(1366751,0,"98fa0d912cec6d8869ac0b028f1981cf809eb4274f57ce2f3b3cd462975aafe4")
setManifestid(1366751,"3402689538557699801")