-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3354500)
addappid(3354500,0,"6f73df8bbc26936f5f9ee9d3bf031b9cb96617d8f8004038c2d04c9f8b01b808")
setManifestid(3354500,"2927728479501190777")