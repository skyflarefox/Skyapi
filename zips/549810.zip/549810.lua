-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(549810)
addtoken(549810,12434802298647877050)
addappid(549811,0,"6824ce770b5a9b331a4ff0e6bd4a2c2115080d5923429309e9540d65a442ae93")
setManifestid(549811,"4565715742509352981")
addappid(549812,0,"43543f4b60b45c029e1204ca78f7edfb41a13d26de20d971ce9794ad3da3bd88")
setManifestid(549812,"8487383247440439934")
addappid(576350)
addappid(576351)