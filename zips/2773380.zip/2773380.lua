-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2773380)
addappid(2773381,0,"8a01e99931792044ef4b87d3830a2c02c67fabf3c3d1f8d5c3f685bc5abca678")
setManifestid(2773381,"8290939850242578428")