-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3129540)
addtoken(3129540,9059495116188881920)
addappid(3129541,0,"53018f92153d7f2af370aa5f7a096c630696dfe9e2feb6d1052a505a5de32d32")
setManifestid(3129541,"1848737527836492973")
addappid(3129542,0,"c0cc048169e0837a77301df6e1860d89281eac075b89d61358bbeebcdc42880e")
setManifestid(3129542,"6769613233641080639")