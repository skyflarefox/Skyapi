-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(921500)
addappid(921501,0,"ee5548f41edd87177c05ea5bba1572ee376d36f33a83c43c4a759bd386853cac")
setManifestid(921501,"3327801444146852314")
addappid(921502,0,"93bf1b8c1a86a5e2d68b5515e16a86fef5053fa0dc650c4312a08bbcdf84462a")
setManifestid(921502,"6337692028512832889")
addappid(921503,0,"728cb62fb9b67177b4fd9d9a770b8b4796402e1c656edfdaef174fdb5430eaa0")
setManifestid(921503,"2667569220334376004")