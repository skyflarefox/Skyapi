-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1958460)
addappid(1958461,0,"35eea8114dfbc39feafcedd6db9207eb332aaaaca15fe946e11ba10b3db2c084")
setManifestid(1958461,"5851145081217078522")
addappid(1958462)
addappid(1958463)