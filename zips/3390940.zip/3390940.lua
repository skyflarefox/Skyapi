-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3390940)
addappid(3390941,0,"7ddf685675ecf7dc61525e3762cca2b1dc57e67a6d74f4d7fb6a49e4949a37f2")
setManifestid(3390941,"6915651803402844757")
addappid(3390942,0,"6e83912877e570fc0a442712b9b1292feb23b0ce7ada5d9fc2f0d35b1b1ee31d")
setManifestid(3390942,"1678431403077886208")
addappid(3390943,0,"c8cc8adf60f6285e6aeff4c6bd5083409993c07ad86a65fcd3257fb017eaae88")
setManifestid(3390943,"603267302959713316")
addappid(3390944,0,"3fb0f3e1a0401bb39b13bd2d3fbec566b666b1bb3aca1f80df4f359aa04d2215")
setManifestid(3390944,"6502896548354016274")