-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(860860)
addappid(860861,0,"089b8c64ff170fb43924fb130111de950f5479fcfa21d17b672cac8d570e56fa")
setManifestid(860861,"2089324670378740198")
addappid(860862,0,"10d5c1710c834a7534f0ffdc5026fec354a9c2dc9cd2f7e5e07ff40d864ef6af")
setManifestid(860862,"4615436899342964667")
addappid(860863,0,"eb1ab805aef27581575b4c19c48ed0ced7297a6b8d4a241c1c8472e1aec84306")
setManifestid(860863,"1700957437661275217")