-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(774441)
addappid(774442,0,"2579fef3df9285a7d8160539ad23291088f97aedcd2bd7422a11626c9536b3a1")
setManifestid(774442,"5553699209809650313")