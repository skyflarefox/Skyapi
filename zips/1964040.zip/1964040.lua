-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1964040)
addappid(1964041,0,"ad5778a8902bb322ef67069868979cff5e4b97f00025fa24cd2db4e25fece9a8")
setManifestid(1964041,"1768815437547772713")
addappid(1964042,0,"eeed68130fb27afd56fe33b7b093052ab0bf14a30da8fa4f40b40a9b695cb891")
setManifestid(1964042,"7826560517419546290")