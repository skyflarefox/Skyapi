-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2346530)
addappid(2346531,0,"2ace4b16b6f77551d885c86657e3e5b74e09df76af8eefeeda1a81ca9c0df911")
setManifestid(2346531,"6386006400929215354")
addappid(2346532,0,"50099bd4872580e6aaa1bc63a800d666c05db5168c6baf70f13f3629c2f3be9c")
setManifestid(2346532,"5261326487205691496")
addappid(2346533,0,"fd2eee9d9534cb470605bc504049edc7dee0ccca45fd137f4baebe638dfd4c10")
setManifestid(2346533,"8155439024796305072")