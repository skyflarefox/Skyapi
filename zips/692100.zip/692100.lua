-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(692100)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(692101,0,"e0d89cd6fd582d5767416c537d131b7feea4d585643a366529575288af254137")
setManifestid(692101,"8025719015542581073")
addappid(692102)