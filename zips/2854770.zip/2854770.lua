-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2854770)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2854771,0,"af311e20e2cf52139a55ac51ea04af50ed3d366933a85607897f7aa9e4a1447f")
setManifestid(2854771,"2333706814363569458")