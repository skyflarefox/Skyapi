-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2063500)
addtoken(2063500,16881665783219656599)
addappid(2063501,0,"b07e56a22cf5434968e6e38b88910771fc5a9890ee2b97791445b5da3f4622a6")
setManifestid(2063501,"6324261636239806150")
addappid(2063502)