-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1995140)
addappid(1995141,0,"b94f8fb052ebd7d150e7dfda288eb9502e4bc3fd02bbf4e3294fff2904e3461f")
setManifestid(1995141,"7519174125580562307")
addappid(1995143,0,"55b14dd10eeb4b78dfe796bffa4ac317371a1fdebac0a62237cd3fb536c6bbd9")
setManifestid(1995143,"1817167589794762385")