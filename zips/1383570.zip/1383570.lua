-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1383570)
addappid(1383571,0,"a4233c4ce9ac53eb8564875b3e377326a5433cdf13e17a41b714ef182e3f0037")
setManifestid(1383571,"8994973841186981602")
addappid(1809190,0,"3a02d2b2b621b12bbcc4745c3bcd3a5e07a05a978c0d80cab308f32d9b53fab4")
setManifestid(1809190,"1468105164789908887")