-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1914840)
addappid(1914841,0,"e424b2a86edc9c013e746f53b7e621c1b0c109a09831b8b3d9a76519c42e7afb")
setManifestid(1914841,"1879875613279242946")
addappid(1914842,0,"206b1cdc31300279ffce380bbdc75b19672da5a0f71ec97ed6689a041d7684a6")
setManifestid(1914842,"4446972635578408377")