-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1061010)
addappid(1061011,0,"2e2ac884cb9346291979da225bed68234191c90c0a4f038ab396641c0ba9e400")
setManifestid(1061011,"698526262375585609")
addappid(1061012,0,"f0040663f33af72a1836f1c07aa006a90eab90c43bb7d0f10df6edde52b68adb")
setManifestid(1061012,"6275904398616017762")
addappid(1061013,0,"0277c6558329ed3163511a875b67160144c5fc86b8ea121eb12fcd6b9556c91c")
setManifestid(1061013,"1375972951394436842")