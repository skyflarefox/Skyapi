-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(824360)
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
setManifestid(1004,"7747775778018907449")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
setManifestid(1005,"2135359612286175146")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
setManifestid(1006,"7138471031118904166")
addappid(824361,0,"4a07063f5021a72df1b577dc36a46314222e3a8ff8b6c5df9d9eff3fda91423b")
setManifestid(824361,"4979571331082771496")