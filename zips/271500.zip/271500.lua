-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(271500)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(271501,0,"328ade4d6b9325ca6b95ba6588f4b1c202603c391f73d010ffc84c68661c16c2")
setManifestid(271501,"1274431612034355530")
addappid(271502,0,"1d0a9ffaaced72e35c709cddb30d5193a0e353d777a79bcf6fcce93878623288")
setManifestid(271502,"8916510098130899912")
addappid(271503,0,"febf108e53d0e7d578818c317657ac65e7d0a4dc0717afb562eec9d71f4614d3")
setManifestid(271503,"3675947824537962582")
addappid(271504,0,"efa64fe3574f6cba1ca51648613e7d9b9ca7998e17dc0868e0a7615dff35f3c9")
setManifestid(271504,"5911692963477002617")
addappid(271505,0,"1506a5b36c313d6e0cca53f8071a38605aa6a03b85a1d29348c9236860e28a72")
setManifestid(271505,"9145736325738430997")
addappid(271506,0,"c130d71187a900fc39b6e87147b2de6ec93f6ecb99f49a8df18667f82f992c2a")
setManifestid(271506,"292698739261679221")
addappid(271507,0,"aadb8243368ac8dfe7845052df0f12fdf65607daf6c376c8eb4f48806e743536")
setManifestid(271507,"6476766775614614987")