-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3228750)
addappid(3228751,0,"1ce75bd4ec604ed2c5df384bcdc404884c1137cda40f8193de696bc2d8c064b6")
setManifestid(3228751,"7521323224473043392")
addappid(3228752,0,"e4aa0cc5b5bf2263966950a3d93e1b78f9622f69a106dcfe55f7652ff08d9dcc")
setManifestid(3228752,"3579112180188329689")