-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1272580)
addappid(1272581,0,"5e0d2036f987255f719b63626ab004f7e7084acf91bbc82ab1de754299bf6de3")
setManifestid(1272581,"2338469150601403779")
addappid(1272582)