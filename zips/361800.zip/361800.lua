-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(361800)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(361801,0,"f2f416813ff3ff5808d8bbcf56d018e52628de0d9f1162e8c57b8bbd2a266a63")
setManifestid(361801,"5682670468741841617")
addappid(361802,0,"55a45897e8ffba930802f83d92dd4c8462677b30c429df4e1098bc2152913d09")
setManifestid(361802,"3323122046234330441")