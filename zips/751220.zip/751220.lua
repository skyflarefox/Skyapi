-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(751220)
addappid(751221,0,"a2554af4f40bf0ef0fccf7fa2a1749366360956a0dbde109e3eb85a6dc5a4315")
setManifestid(751221,"3258073002377923193")
addappid(751222,0,"3fdd7a00e0aed9416bbe4e9c9b861bcf6b2ba5cbd4025129ba6a952ca1fa0626")
setManifestid(751222,"5806940890744239399")
addappid(751223,0,"1270ed50b99c6d77a8bfaa52a9290042531f90fd9f88417ef398cd89249b113d")
setManifestid(751223,"5047645382558260247")