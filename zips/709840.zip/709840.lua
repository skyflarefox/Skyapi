-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(709840)
addappid(709841,0,"8ffa4b0a7ce10e53f19239bf6d6e87399551e85ac3943c28e9b20fac5c59c783")
setManifestid(709841,"4434280338249002159")
addappid(709842,0,"371818e09ffaa454e7b78f2677526637edb1ab1d4a84e436b9fd9884d387fe71")
setManifestid(709842,"2490616250928958684")
addappid(709843,0,"080f50b36eaea177ebb47be10c20668854bf3595ffd6e3d8f7207286d3b28c79")
setManifestid(709843,"714405701537921233")
addappid(709844,0,"3e0807b6399b5bfc3896e276e59c6544f0d89cf62ef3f7c4d6e1207654d881bc")
setManifestid(709844,"7202085453037685412")