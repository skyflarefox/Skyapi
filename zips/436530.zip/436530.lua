-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(436530)
addappid(436532)
addappid(436533)
addappid(436531,0,"e51ed31950e6846ea8dd0e9f9f96da1b3f1614007abfef5e44f7cb09dc41a06f")
setManifestid(436531,"2668570624496966306")