-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2209550)
addappid(2209551,0,"a0b0d785dfc869da273c6b4a402609da1d3aaf1f2f7c6a85624a7f166a1771d1")
setManifestid(2209551,"3171385272542575449")