-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(218820)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(218821,0,"43840656b6bed47fb05e092d959666c2209be91903dfd98e760769d9bc914429")
setManifestid(218821,"621698610113857201")
addappid(218822,0,"74b26f8272ebb259e4a1475bc43c89e7ffb7f1a1e92892cac243e8030871e505")
setManifestid(218822,"9040633698820373098")
addappid(218823,0,"c594420253c1736950189f0808bb41e2ca1014f90ab199da0f1c52f11d08f59d")
setManifestid(218823,"5041255923054087555")