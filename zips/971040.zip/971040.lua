-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(971040)
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(971041,0,"8468e99b8b75cbf6ce4ed450850da14c08fd974268b94991e7b6e018c9505b1a")
setManifestid(971041,"963435099455465282")