-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(308580)
addappid(308581,0,"891e0c0c0acfcacdf62c700e8fa551b357c1b02a17e2dd17927b2b731ca2ed3a")
setManifestid(308581,"7422807130483284637")
addappid(308582,0,"6ff543b90ee37540fb1bf586f9e9c7e90c930f398617aed79eb65dfec419f19d")
setManifestid(308582,"8081799649510971414")
addappid(308583,0,"d0066fd4f6ce19567bde1d711754436f3fbeca993a17f086547f46cbcedadc94")
setManifestid(308583,"2760768605559582004")
addappid(308584,0,"906093a03d9f1c0a7859bdfe7a85279f1fffed2a6d6f3144f7f321fbe1a68f92")
setManifestid(308584,"4649709121263567642")