-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2684320)
addappid(2684321,0,"a615177f684a7ff36af8e9b238785dd3d4e19a5334f2471a9fb3c262e729919c")
setManifestid(2684321,"7368493678989856929")