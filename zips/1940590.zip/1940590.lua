-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1940590)
addappid(1940591,0,"a821a44919c51178d4cc60a7eaa906a41ca4d096038f73b2ba0f97aa5e72ae7d")
setManifestid(1940591,"4177053660855518844")
addappid(1940592,0,"dc5c313b416e8bab8f17cc4b07d1d13cfdbc0497ee84613ce1a92496098dcd1f")
setManifestid(1940592,"1524031636103197983")