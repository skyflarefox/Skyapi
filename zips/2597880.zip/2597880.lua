-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2597880)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2597881,0,"c6ef5819757efe256522c5c3d9981687a645b3344739949ad09d05070ba1282c")
setManifestid(2597881,"4731355691680424699")