-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2168750)
addappid(2168751,0,"ddd2b7dd170798760a4cbc59bbceee79be3b4c21f5fb67235b0f2a346891d0c3")
setManifestid(2168751,"6062623157426076449")
addappid(2168752,0,"7ad93598f4c746f2bb7d5878984f8f5f39c42ec97fa017983854a68ffe1eb3e1")
setManifestid(2168752,"8994846772830435356")