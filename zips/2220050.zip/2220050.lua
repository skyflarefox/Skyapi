-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2220050)
addappid(2220051,0,"f91ec35af04a87567c3c2a80b076631adf68800830d616cb6030d22d8ae2901e")
setManifestid(2220051,"5059516963757807395")