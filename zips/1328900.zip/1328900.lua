-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1328900)
addappid(1328901,0,"a3250aa5798c7131ea858cc429d3c20dbc09f097d43aa30053895aa1ff8d3dee")
setManifestid(1328901,"4945612642063891326")
addappid(1328902,0,"c887e68c72f9f55e45545275cfb7cccba82756427797d6176874b01403eb5c58")
setManifestid(1328902,"3547625577058982001")
addappid(1328903,0,"6c25a477e11d88c19dbe2aa893c687f1d6db25d3d9115b507e9b299a6c00bef9")
setManifestid(1328903,"8760727041645861923")