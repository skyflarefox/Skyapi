-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1692000)
addappid(1692001,0,"86714b01b626cbaac47488a2a7ffe20223195f9e8d36486ee37922c5567ec4cd")
setManifestid(1692001,"6781328880595017691")