-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1398070)
addappid(1398071,0,"d107d7b9a11670a339d2600e66607132f67ef8db5a3c09ab2640e5fcd809b4d3")
setManifestid(1398071,"3689011184860058238")
addappid(1398072,0,"d5a1b149449858f63acac131a25788e26842bd978e8a1615e6fd87e5d12b0e27")
setManifestid(1398072,"177970671170152577")
addappid(1398073,0,"fcc5fc8f56f215df0fbfdf727f2ce31a8e947f519d58b7113ff9f6e051910820")
setManifestid(1398073,"4705797256021008515")