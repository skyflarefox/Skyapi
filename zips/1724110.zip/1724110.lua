-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1724110)
addappid(1724111,0,"d7596ab7ec3ea53fd41602d6fce180db5611dcfc95097a0b82ffb48039b5c438")
setManifestid(1724111,"2437443947495298125")
addappid(1724112,0,"ced4195af016893eb6c33c44f9c5afd0cbe7dfa1a4026ddcb6e069a1d6f8ce9d")
setManifestid(1724112,"678878947895912041")