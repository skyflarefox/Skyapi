-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(555710)
addappid(555711,0,"7eaa33653310c0607cc636500d56e2139437b71fe70ca7d6be52b3514eb20f78")
setManifestid(555711,"3310432613610581184")
addappid(555712,0,"46db2f61dad4dd50d463c45e3897c5812e9af80ff6784a0ca7d7f482eb265cec")
setManifestid(555712,"4792331367831087999")