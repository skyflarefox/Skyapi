-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1638950)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1638951,0,"54cf9bf6ba257da6d6b09f9bdcdb21a4f90523ff944e016484d088b5af0bd8b4")
setManifestid(1638951,"2671044094438741922")