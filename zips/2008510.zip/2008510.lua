-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2008510)
addappid(2008511,0,"7604be3f1fa927ce9d29de68bb03a30149e5a6f96b512f49e2ca3bfe889c9b21")
setManifestid(2008511,"2020100639572129057")