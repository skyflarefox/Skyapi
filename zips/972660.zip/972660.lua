-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(972660)
addappid(972661,0,"187ac179ffc1b8c1f070554d4e13861b9bdbef7ecd1c2e5b53a1413e48e54883")
setManifestid(972661,"6269447316531223781")
addappid(972662,0,"7ca518a09e4deb74c6dc6fc2e9de6d80bf74af17db13d5319b9467603aa25d88")
setManifestid(972662,"8058226904025998493")
addappid(972663,0,"299c32fb774806b7671917661d5f3f5eb761c728ea22b717a6395d1f2b759543")
setManifestid(972663,"4029588228379842087")
addappid(1398770,0,"05e8f50eb4a5b8466f8ea94e8f7c97cb9edd1431b29f8d87012ae9161c1710e9")
setManifestid(1398770,"4330632686706330779")