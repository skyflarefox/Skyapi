-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(555430)
addtoken(555430,3731361680026431056)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(555431,0,"6f7283d3c6e207cfeb83226e676feea1454d149f74210364492740cde19c8e56")
setManifestid(555431,"5116174285061871739")
addappid(555432,0,"9a4692d0439dc5ca064b2dea7257d3ed432e614c6ef5a2ed14e73fd73ef7ffcf")
setManifestid(555432,"9050399945567092315")
addappid(564870)
addappid(565400)
addappid(566300)