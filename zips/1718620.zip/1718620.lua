-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1718620)
addappid(1718621,0,"d7195d3f0b9c2054d1e8407f4288c66659436bbdd7a381c40a5b5c901908adf3")
setManifestid(1718621,"163076928303022599")