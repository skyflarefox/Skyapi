-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(224763)
addtoken(224763,18133981425943676207)
addappid(224763,0,"19c6e089f2d743d986b9af1efcd18596af578cb85dd38da5d2b273003f830371")
setManifestid(224763,"1210287337979426083")
addappid(1403120,0,"62e1924f8ad95119b633075fd6cc5ccdfce3781b4bc89baa1baa4ead5f28b99d")
setManifestid(1403120,"7084584673061738649")