-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(340440)
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(340441,0,"7908e2dd9c973d23264fa0e45f2e2bc02f4d5d3cbb5617690bf478f842151cb4")
setManifestid(340441,"4584488198105504615")
addappid(340442)
addappid(340444)
addappid(340445)