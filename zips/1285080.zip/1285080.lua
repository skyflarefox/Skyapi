-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1285080)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1285081,0,"5c9389a1152ddb6f611cdc51f31dc0b181eeeda32ec4f9a5863db1e02c41c2d9")
setManifestid(1285081,"3540385869208219272")