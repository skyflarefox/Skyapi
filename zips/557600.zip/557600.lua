-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(557600)
addappid(557601,0,"3dbed8d99e716a2c4481b39e1b841b09d8984a126afa6acb9f67ca8471289d62")
setManifestid(557601,"227936140866282624")
addappid(557602,0,"8da70b135344ce4c582063dd71a2dfb857a4df67d9a086e94f7e09496d9d56b1")
setManifestid(557602,"416859192670904825")