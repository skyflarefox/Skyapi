-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2538470)
addappid(2538471,0,"db3ec9a96d5fc08b638d257e11e5a847b3b45e981f5f910ed2aeff8e3c3ee2b1")
setManifestid(2538471,"2294563992424014791")