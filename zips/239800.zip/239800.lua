-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(239800)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(239801,0,"ed30703ba9e1d8d2991de0897581d7c321b4342a4fd7b1dbe777b9ca1f446f75")
setManifestid(239801,"1243561928853160754")
addappid(239802,0,"12b17dd792ce8d7c3b5ccd9b9e25e43c9962b3cb9049a8845ff57b61f083e19a")
setManifestid(239802,"1338660493300423366")
addappid(239803,0,"25447a4f4e1de6ae47c5bf9f2437121833417443d416a696984937df0aa47ce6")
setManifestid(239803,"7586064337957146762")