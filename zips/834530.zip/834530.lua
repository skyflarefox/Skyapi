-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(834530)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(834531,0,"64ebec3e0178f27e5d27d7cc4c91382ce5653dca2966989a8ee26574a83383d5")
setManifestid(834531,"6343115858572417905")
addappid(834532,0,"00ac0f337bbd03f1d6b4e25cbe12b68f9567b85b234bd69822a7cb22cfecb100")
setManifestid(834532,"8056939067145069014")
addappid(834533,0,"84c25831d0a0900169b6bd7540ec8ecb569e08ec283a37391d404c60a798d0c9")
setManifestid(834533,"5566686960884841902")
addappid(834534)
addappid(834535,0,"f9e85ff7b9d2d862bc853c14bc4e7e6773efdcdfd9028d7a196296a4926a63e0")
setManifestid(834535,"8036566944547967721")