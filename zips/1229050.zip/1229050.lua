-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1229050)
addappid(1229051,0,"679da5c3c9d6d8b83d9c4374dc2c58ace00b0cc4ca7627f97cfd5c85b4d624f3")
setManifestid(1229051,"3415019302504253425")
addappid(1229052,0,"a800e5ab1ae02b714de97f7ca5746afd3f81f546f77a6ae454b13825b0f521d7")
setManifestid(1229052,"9045821659330311136")