-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1928920)
addappid(1928921,0,"75635ffac72a87dfb2d674f3b282401529b9481248d481f47cf19c4ddbe6c2b9")
setManifestid(1928921,"2898589162469243940")
addappid(1928922,0,"bfbeaf5ac0b888d9580cb2ba7044827b665678ad87df57506a2133ba395283b2")
setManifestid(1928922,"7380207456135817669")