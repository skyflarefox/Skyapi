-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(884190)
addtoken(884190,7053610143002885949)
addappid(884191,0,"16f0d43e0523cf7c88af6d533d839d1204cac387f96553ef2ba1c859a7c681e6")
setManifestid(884191,"2608624680719844207")