-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1373270)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(1373271,0,"1ced4c3a23559a59e4b14ef8307496004e46f0024b33ad8bfc7acbe9016c64bc")
setManifestid(1373271,"771126069392354829")
addappid(1373272)