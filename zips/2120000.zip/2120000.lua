-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2120000)
addappid(2120001,0,"06aeebf1a725ce0c55d64865d36eafc2647c519197324c3c8338801697a9d3bd")
setManifestid(2120001,"6050948609389058868")