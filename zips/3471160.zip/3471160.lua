-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3471160)
addappid(3471161,0,"22ed64aceed43dbc017dee7524337d9ace2620edc407fe74108cd6650c6b5916")
setManifestid(3471161,"2361130057196895126")
addappid(3471162,0,"9a491e0c2c210909eec6780e04f6049e1005184c05ade4513bdf329904e26ea5")
setManifestid(3471162,"2452926130454564707")