-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2715350)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229001)
setManifestid(229001,"4049573910112143457")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(2715351,0,"6db4084e80324fbf5ba6e31c586f44b7df2f0dcf1d33749429e96ba5d5e447ef")