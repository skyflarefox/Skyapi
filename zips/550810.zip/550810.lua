-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(550810)
addappid(550811,0,"0d21c57e59ae161a466db81522f2c8d9359599db4a5f6300e588d6e57c07dcda")
setManifestid(550811,"9102973294386577065")