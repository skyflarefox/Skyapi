-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(929310)
addappid(929311,0,"4f9ef4ed195f0c564eee109cadb7742de04b6cc085c707cc8fabc8fb8481b375")
setManifestid(929311,"6688947639258765710")
addappid(929312,0,"cf040daf99b39e749c8cbd830f76faed4b93e29e9c401340159e82a1304937ed")
setManifestid(929312,"205091717800144686")