-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1731641)
addappid(1731641,0,"eb53b280baa5cd37a63429a6d4cb3fe9466fd0aef4805e608490d75b7ffc4160")
setManifestid(1731641,"4177785255783165312")