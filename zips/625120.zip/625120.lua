-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(625120)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(625121,0,"ff5b958b30bdf3afbe3e8b8617f68d6bddbffd4d05342025ce714a74e86a4aca")
setManifestid(625121,"7959890611398142802")