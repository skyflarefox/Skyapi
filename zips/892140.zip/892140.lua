-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(892140)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(892141,0,"f7bf9da811830c4ca0f3d2e98cd7c696a71863631a8cd6b3ec4ca4b5890756f5")
addappid(892142)