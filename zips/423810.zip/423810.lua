-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(423810)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(423811,0,"fabcf56208646a3f0f4b80e6c6f0d4da53ea431f81a0bb6471f2f7f6cdb82276")
setManifestid(423811,"1266364906596785467")
addappid(423812,0,"073fc6212672d2fd3aeb8e50fd19ba946a213a87974c3dfaf1f580a75ce15f8f")
setManifestid(423812,"3651593770978077539")
addappid(423813,0,"e3d57b88f167e2f7763476717189767c7e7823bcc6369c48fdc0338a2b3af604")
setManifestid(423813,"2169066844599651468")
addappid(423814,0,"394845a90d95c330fb4be6bbaa8ba4480612e20ff82357e93af4bcbf7a544e8a")
setManifestid(423814,"630817622110740387")