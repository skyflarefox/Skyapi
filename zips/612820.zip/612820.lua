-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(612820)
addappid(612821,0,"c484c39c7d0bb62734884ee4bcd8edb19e8b860efea8ee8f6d775f408c89b683")
setManifestid(612821,"1883891875840237690")
addappid(612822)
addappid(612823)