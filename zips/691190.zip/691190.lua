-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(691190)
addappid(691191,0,"075ffc79c19b7c25b0a910fd426fcf39faa4a53aa27c9693cd46897dcb00ba8e")
setManifestid(691191,"4143875513848873583")