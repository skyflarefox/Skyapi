-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(298000)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(298001,0,"63cf9d65ebb00630f32f23d611c8b8c2aa175586eed36fd0d640b8b3641e66b2")