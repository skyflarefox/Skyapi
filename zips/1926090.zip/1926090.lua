-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1926090)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1926091,0,"6158cfa58205db6b7892ff6e1af2cd2eebffdf034bbbcf1835ea5a3d54347aea")
setManifestid(1926091,"7307281027573075497")
addappid(2504080)