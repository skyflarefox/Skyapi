-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1848421)
addappid(1848421,0,"ea8392143cf3fe4567df9aa415cb555b827e6dc4947ec4a7a00d999c631c5250")
setManifestid(1848421,"7338703804728340958")