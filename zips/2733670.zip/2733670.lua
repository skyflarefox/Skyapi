-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2733670)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(2733671,0,"f9ff0b7cb1f67f6a1584c8f74171990954eb39f139da69c236391554d720a766")
setManifestid(2733671,"1674114427612244932")