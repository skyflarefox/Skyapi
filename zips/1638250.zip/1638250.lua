-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1638250)
addappid(1638251,0,"e6bd7c4e02855b4e7fd6f2ef9a27d3cb03f908d378add93124079315666efb0f")
setManifestid(1638251,"7331893540917098665")
addappid(1638252,0,"979c2b95dc57ebe8a7761a47190c08d7eb960f1fd496e49e96a46143ae779a4b")
setManifestid(1638252,"6797228624236040180")