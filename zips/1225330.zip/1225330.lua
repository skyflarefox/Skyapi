-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1225330)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1225331,0,"bf4623b9dc059a63ddc9c7c1a4d830617cd9e31375ffe3e2af78aff8515b048b")
setManifestid(1225331,"1705881122111512160")