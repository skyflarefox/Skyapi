-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2989880)
addappid(2989880)
addappid(2989881,0,"9c51f44bcb1031e78d04a8e4b95f0bf0bb4644df69cfb6150227ea84bd30cba6")
setManifestid(2989881,"3088659831864937215")
addappid(2989882,0,"ce505763a9f22e8e422c473800ad7b9711661fcd3b3f73704ede3d2d48d7380e")
setManifestid(2989882,"5137236595835115354")
addappid(2989883,0,"7d2895eb1feb64c7fd77106911c01459c8ba5adacd44f21cffe38b9fe163c812")
setManifestid(2989883,"5515543213888018498")