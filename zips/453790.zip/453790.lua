-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(453790)
addappid(453791,0,"3e43e32218032e02242ab1b626429926a5a145638973b0992ae016426a62ad29")
setManifestid(453791,"3336589732497698102")
addappid(453792,0,"0ec4b2bfad20dd0bdb1a8e908b85422e6c4d0d7ff5e854f07e2a5f688dc1b14a")
setManifestid(453792,"268648456967715849")
addappid(453793,0,"a55b67d4651763318f5643918f5704196fd8027f128db4cca1a340fd7a5b1b6d")
setManifestid(453793,"2859541029284918250")
addappid(453794,0,"8059de0604daf7e075f62b32afc248c9ad7c48e3e9403375125ad8103b067710")
setManifestid(453794,"2700506670881145084")