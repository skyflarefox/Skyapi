addappid(1382370)
addappid(1382371,0,"886c08fbb6e9eaad33d8ca4984a68adfabd7cddb3fcf6b0ba65b9f689dd9cf22")
-- setManifestid(1382371,"478067080372141705")