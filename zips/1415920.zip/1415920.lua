-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1415920)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1415921,0,"55c1f46d4745d02cdc6466e57157dbbb88f2a266f8f4e58f1e5294d6cffb22cf")
setManifestid(1415921,"4317608319863647590")