-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1836500)
addappid(1836501,0,"26ba9be4cd03eb5f5324d50467c0aa304e6fbf1ffa50855fcb875814c27f7d8b")
setManifestid(1836501,"6462245936491927411")
addappid(1837360,0,"958b01f5ce413173f14fde2cb0e0ed69ade9e9695a24c801ac0c845bcba17dbd")
setManifestid(1837360,"7640922905612055592")