-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(273070)
addappid(273071,0,"d57fd9f230eba971a66dda485863466700d2524cdf12cdf00d55bbf10bb591f1")
setManifestid(273071,"2351974863739839148")
addappid(273072,0,"cf17021afd6d99447352a806c9a726ac5502a4411e872409f7b6d5cab77da923")
setManifestid(273072,"8558042103703524313")
addappid(273073,0,"f1c830b75305bd4621d15127d784801a61f137252d52323e85667388186a7759")
setManifestid(273073,"9069974396724994621")
addappid(273074,0,"b0f5e0518d16bfdc0e94f995337a6b35482be12663ed3d9b3026a116534c8a1a")
setManifestid(273074,"8217201616247452073")
addappid(304480)
addappid(414310)