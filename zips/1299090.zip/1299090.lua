-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1299090)
addappid(1299091,0,"8770bcbd1a726ee1214b675723010b0de4de0208cc217de705967ee3bae2f091")
setManifestid(1299091,"5482189630123454173")
addappid(1299092,0,"434616267002059d021073d8e7ddbc9ac51be14ee99be754fdb22392ff39ed93")
setManifestid(1299092,"3629005302153416630")