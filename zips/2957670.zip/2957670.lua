-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2957670)
addappid(2957671,0,"2c5597cc4b0bade562f5d787619619927917c00871635ac779e20196708997cd")
setManifestid(2957671,"8732832280822080305")
addappid(3285250,0,"67018ce868158b09230c09c27e426293272e429e55503a6f6d7f64913e2596a5")
setManifestid(3285250,"4707045616295780015")