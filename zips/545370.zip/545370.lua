-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(545370)
addtoken(545370,8718872487952821721)
addappid(545371,0,"bc9c41118f242c2aada8574e25689e22646a4c78cabedb685d90c33753551236")
setManifestid(545371,"1280610296582713559")