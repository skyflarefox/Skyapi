-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2591120)
addappid(2591121,0,"ccd55c570778cd23c6299b6d05a236e100dd14f1b5f34d43c595cf7f0bc4b193")
setManifestid(2591121,"82673025661500025")