-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(575130)
addtoken(575130,10680550888574125567)
addappid(575131,0,"b3089e79ef562063bdd19635d8d755ff3a936631b5f9a94fb9061c39efb79344")
setManifestid(575131,"7809885957788852726")