-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1624830)
addappid(1624833,0,"e8af25921ebeb24d72737f3cb39e8979f93222028d05b1e98267d3daf1f82013")
setManifestid(1624833,"1527838045592416170")
addappid(1624834,0,"be776895417cefb2513ce1835f5aace141b112366afef95fcb0727c80d06fc81")
setManifestid(1624834,"5703961661889284980")