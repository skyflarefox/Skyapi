-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2287920)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2287921,0,"7c796ea7a75557a2a2263bfb52825c2f2707917a8c49163f82dd58e75270ad12")
setManifestid(2287921,"4289068706414964776")