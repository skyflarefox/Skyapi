-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3255830)
addappid(3255831,0,"03cefda2182dea4a98c95c90c56bcec2c2aaf373feb8030ef9a4b46147a587be")
setManifestid(3255831,"7321360450992293861")
addappid(3255832)