-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2161580)
addtoken(2161580,8138395948114799644)
addappid(2161581,0,"aba94665387bfd097d5ccde4c338f2e9f2ae6329365287ee204db3b023e0b194")
setManifestid(2161581,"1006552907641361180")