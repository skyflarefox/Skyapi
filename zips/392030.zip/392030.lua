-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(392030)
addappid(392031,0,"5a0c1d9f8c8cd75eba3fa5fcbf4b8b98e0d64ab742540844c8d71375e2ed03ff")
setManifestid(392031,"138002260948216673")
addappid(392032,0,"2044790a05933cc6a0b40f204f0fdee3a8bdc1aeb674470f826f764828ee8e54")
setManifestid(392032,"5524081988596810481")
addappid(392033)
addappid(392034)
addappid(461050)