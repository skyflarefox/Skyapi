-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(257870)
addappid(257871,0,"2af66a7a3e5b0f3d5a0e6e6e95df71e1c1cbbb47878b7125e6b55e7619f40a5a")
setManifestid(257871,"5168594245858466177")
addappid(257872,0,"2c32f54a7610a44b12a06618b7f2f3dd33893bfe7ddf55627d0d4797cb5f91e1")
setManifestid(257872,"5647190177942877167")
addappid(257873,0,"abb9a6970143dc07492b7716281f744b89d98e09b047118c0328b85121038a51")
setManifestid(257873,"4500445725089227315")