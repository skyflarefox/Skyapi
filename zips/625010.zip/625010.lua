-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(625010)
addappid(625011,0,"b27dd970cdd7a776364712bfa30bf8d3394bb9cadabf5e2a67caccb644662bc1")
setManifestid(625011,"6974457473957499449")
addappid(625012,0,"351e99bfd65bba8a8bcafda7410b5398cc9345b60ce4e2f66a1fa7ba459ccb3f")
setManifestid(625012,"6945450726612516360")