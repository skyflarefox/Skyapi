-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2424240)
addappid(2424241,0,"8f477735defc67eaac9089afbb2fc09dc24325caf092df06e8bca0a0b42a2834")
setManifestid(2424241,"5321597364333994912")
addappid(2424242,0,"210ea52c602677ae8b14596b5f48c6dd9ed600700a3927b41bfeb999c897cd68")
setManifestid(2424242,"6493983059592222364")