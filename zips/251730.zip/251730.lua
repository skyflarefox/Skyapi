-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(251730)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(251731,0,"9eb6976ef8121eb22a66cf7637f46bf150604d67f3b00c507a57396e4df473b8")
setManifestid(251731,"7590261144661331237")
addappid(251732,0,"5c874825fa53d3804870cfcfd2c68930e4c97d983477116985948af69263b897")
setManifestid(251732,"439241199539704180")