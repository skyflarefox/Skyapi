-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1720400)
addappid(1720401,0,"364495165d936ac2da68067973c99e913edf26ee8e8ef51e220ce33e95fab33d")
setManifestid(1720401,"4650324154701246762")
addappid(1720402,0,"6af6a4d4adfddd5e7d518de22f243dbd4187f1c6bea5aad0deddde0e8d15b387")
setManifestid(1720402,"7182821150993537114")