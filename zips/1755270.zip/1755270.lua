-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1755270)
addappid(1755271,0,"d93196f5fa2515dd91953b63169aa3c9e836969db95a21639d3cd46788b39cd7")
setManifestid(1755271,"6073381027756498974")
addappid(1756400,0,"2f8957f29afb4fc73c8d3dcef602f451d883f3f7e5e27b70dd491980798837e5")
setManifestid(1756400,"7253409990347503615")