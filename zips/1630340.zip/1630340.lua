-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1630340)
addtoken(1630340,325269880567375590)
addappid(1630341,0,"6fbfe01ffcd654f301ec48e5a7de2225577df6210fd134f89f27a492b9185d47")
setManifestid(1630341,"2047553346642127417")