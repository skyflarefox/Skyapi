-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(624220)
addtoken(624220,18342357792299328513)
addappid(624221,0,"d4ef417a68b7868488410ab986c1eb9c391deb92f763e39f8372ec0fa3d169a2")
setManifestid(624221,"1327672289595335221")
addappid(624222,0,"aa456ae50105883010bcfe5ac84760fac5e9fcc8d0053b0652fc03b52773f5b3")
setManifestid(624222,"9028904581591999340")
addappid(624223,0,"60e0d56a55f84e6011fc2d4d1e578816623fb81046787a1222f0f7fd7c92f950")
setManifestid(624223,"6154199940893278675")
addappid(624224,0,"f76e7c79af48f0e420c4e5ae941eae487513a85d8323c00d9eb1b6a1ca6a30d3")
setManifestid(624224,"3319954976092464159")
addappid(624225,0,"370f3c4fc316f95e109b16331450531eed7125ac88976a60d9ad7e97b6ffeac6")
setManifestid(624225,"6428685917347624608")