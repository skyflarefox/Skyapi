-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(403460)
addappid(403461,0,"39727f286f4a8676df8de186ff2fedba6bc90973dfe0424ec6c04751e13e3ecc")
setManifestid(403461,"7790954306453211542")
addappid(403462)
addappid(403463)