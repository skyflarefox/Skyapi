-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1938850)
addappid(1938851,0,"3a0f19d61954c54cce7b59b4ea20e17fa429f5dae41be1c9fd63d90c93a00f69")
setManifestid(1938851,"9118670289367044010")