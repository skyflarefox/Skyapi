-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2109370)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2109371,0,"10ef091d30c140edf4aaae9d81771407eb4c6053d7ed10c256f173c2661d5b6b")
setManifestid(2109371,"3743418449602043001")