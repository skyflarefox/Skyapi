-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(402850)
addappid(402851,0,"c96b275449b5c335d3f67c61782286c8c44306b1d45508b1f4f72761ff97796f")
setManifestid(402851,"1091191818870862992")
addappid(402852,0,"86ab206c3bc23f9cdd8b831b467fa16689038d13d6b0201081311a24e61e7a07")
setManifestid(402852,"6110738519133881630")
addappid(402853,0,"c3e37cb0a8aed0a1c29e3c9b46b0306f2bf5a2566d91afec9e0eadeb4a2e0464")
setManifestid(402853,"6114176600233045964")