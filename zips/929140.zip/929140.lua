-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(929140)
addappid(929141,0,"03382c049f763e2ff86193c8dca468b0f5a380661737f9a2ed65fdbb923e7ee2")
setManifestid(929141,"8272080158641604730")
addappid(929142,0,"a3114f7cd12e41649f7850f1be5b13a4cae96a9fe8c23f7d893077f0622f91c6")
setManifestid(929142,"2673400158942609724")