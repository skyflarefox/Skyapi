-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(852110)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(852111,0,"4785f83fba98f9cc1a653bf22b392921f3493967f96cbfc77617bee05dab5012")
setManifestid(852111,"7913179310077406573")