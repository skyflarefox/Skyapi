-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(795890)
addtoken(795890,8028617269747803771)
addappid(795891,0,"62d5b2e10af4a2405cbd277171787efa118d2a6fac71aa4bfa76f74ae740762f")
setManifestid(795891,"6255955246847327423")
addappid(795892,0,"da51191adf531fb53346c1583e603ac3f70fa2a89c8958982f5d07dfe82b9d70")
setManifestid(795892,"6544447531763591778")
addappid(795893,0,"04622bfe9ea21844b65b9ce425f8cf229a5f297374447623cf2f9862c7e10d5b")
setManifestid(795893,"8369043621289309750")