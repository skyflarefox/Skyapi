-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2429860)
addappid(2429861,0,"591782e366a2be7556b05c52c3ebab70bf328172f2277b1fea48b311ac3c8423")
setManifestid(2429861,"2563026805166856843")
addappid(2429862,0,"ca36c8d20f6726a752664b377430a930b5579b93916c6a88a475a62391f53425")
setManifestid(2429862,"2208207033562509711")
addappid(2429863,0,"90981bee3efdee85d4251d950a4becc37d8433d2e1f0228a8022ae3f4416dc23")
setManifestid(2429863,"7504000890197777094")
addappid(3155140,0,"f3c0f43ae4dded6a1c15adbb6cb81d456e280cb4a13c34cf33281784c91f7792")
setManifestid(3155140,"7490278290563903666")