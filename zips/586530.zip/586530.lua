-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(586530)
addtoken(586530,15009113847931355184)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(586531,0,"e5d1ea650c7ff5be3aa56acabf9de1392b70473fdae5412dbe1c435ffc8a357a")
setManifestid(586531,"2619102839511576641")