-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(345690)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(345691,0,"64dd0208b994308cb69369ea4f1082c7c6f79fb3960fc1e63fcae63079f68977")
setManifestid(345691,"6878655178096129872")
addappid(345692,0,"3628ecadc50f930d5bf4c505fd2b1b2e84f02394a48ef2bf86893af8f6ff0372")
setManifestid(345692,"3726135127775958984")
addappid(345693,0,"19bbd0646cef2919fc1da372bc925680a535cd47cbf2393650756bda4e742234")
setManifestid(345693,"1555319158762955807")