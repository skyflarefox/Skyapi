-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(822930)
addappid(822931,0,"64e4b8c57c4cdac75d01965c2737718ad8e4e3965c9fc096fb61a3c8cd10c5fa")
setManifestid(822931,"6808270240413980430")
addappid(943850,0,"3520061771aea987b335ccf11b2afadf9862d50a9156c9dbc69ef4547bd0ccf3")
setManifestid(943850,"4554391290252589121")