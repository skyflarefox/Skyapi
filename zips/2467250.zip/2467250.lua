-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2467250)
addappid(2467251,0,"4d60757e542d9916fe1f0d6da4cd36f7cba154c5ef03f563a587efaeb92a941e")
setManifestid(2467251,"7040116540182002622")