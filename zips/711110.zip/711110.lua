-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(711110)
addtoken(711110,12767631670443186620)
addappid(711111,0,"7584efa4b911072e557fc85cb83cfe72137054779bc251fb87e5cf28f637d7f9")
setManifestid(711111,"4882457559020020213")
addappid(711112,0,"9ee28b4f49d7c53cacb04ce0a189d3e251bb79825ce2b2afce366d6052602889")
setManifestid(711112,"4372171910254439510")
addappid(711113,0,"caeadf438edcb6e3f144839606dcd0bcbd4bf08192eab7a7c4738ae9c614684d")
setManifestid(711113,"2297569616100661403")