-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1850550)
addappid(1850551,0,"f1500874439fe839ef88213e995a26676f3e3a1101598ea605aaae95432c7582")
setManifestid(1850551,"2975643707354817729")
addappid(1850552,0,"d2065b8dcb4edf64caf597170309532412ae8bd25f689172c765777dd12fcb3c")
setManifestid(1850552,"8000159155576842015")
addappid(1850553,0,"b5e5243e926cca28d8ba014056793d5321ddd763ac81e18e5c948f53f2575f0d")
setManifestid(1850553,"7621673310005421755")