-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2003680)
addappid(2003680,0,"491d189a245a85c406ee71ff46b421542688d34fa12c680da2d0613b8652d8f2")
setManifestid(2003680,"3871038288551810366")