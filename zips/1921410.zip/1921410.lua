-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1921410)
addappid(1921411,0,"00810a02509948a2061c31270abedf817d95ccd772f17af73934668a35461de5")
setManifestid(1921411,"2226176597517389790")