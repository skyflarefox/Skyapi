-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3439760)
addappid(3439761,0,"85e53bd743c604720a49b296774e1d86b20dec07be4f8f75edd5c693eec04b65")
setManifestid(3439761,"8357005492645426813")
addappid(3439762,0,"3d8ff3cdda63cb444e76eae624bfb61c8e92cb81364222deeae131e571e5f478")
setManifestid(3439762,"1943388040517855814")