-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1717020)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1717021,0,"ea8785ccea32fe78b225286a0d6ce9cb1b4325ecada578edd70c417724aa75cb")
setManifestid(1717021,"8969246539329993794")