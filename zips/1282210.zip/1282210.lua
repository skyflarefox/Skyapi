-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1282210)
addappid(1282212,0,"846bdee8e19907273928653d7d236e876b0cc55cf3a6e4833e5b3e30a8bcafd2")
setManifestid(1282212,"7190674072837493504")
addappid(1282211,0,"87b70e59bb345b1a37c8e83083cf172190b287e0e03c1e8da21ffba9d11514d1")
setManifestid(1282211,"8631664385588301650")