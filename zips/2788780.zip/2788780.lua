-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2788780)
addappid(2788781,0,"4262165e1a12d8a626843a0f60ed12b292278d56e806364c41e36ffd678ea987")
setManifestid(2788781,"2824733118001773387")
addappid(2788782,0,"2262279722aa69bc36b435851eeb02d2c2ca074b5a2ae16987be5b3bdbb9ba9a")
setManifestid(2788782,"5558993961383088647")