-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2782980)
addappid(2782981,0,"54d357d5f32be496aaa4a3dbc79568db5d1d5c3ab742f984ae9a96a3fe39c51d")
setManifestid(2782981,"1245909822820819756")