-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2010180)
addappid(2010180,0,"3df8e8380d595f3bbf86a070ac58db0888ed1bf10bd7f12795bf301c3777cd39")
setManifestid(2010180,"7094133042059372790")
addappid(2010181,0,"c63aaf7d1b4b8548556757efea2496d1166335621cfc036d29896c6746a80f73")
setManifestid(2010181,"1323876442982350439")