-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(574080)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(574081,0,"296d570cbd983d05b0eec5673a457cb2a5cecac935591b0a73e511dc6951e41a")
setManifestid(574081,"6385172361872187603")
addappid(628970,0,"5e1c55e25461ed962eee2d8a4f21b0f31b3ce706c52ad4467bf72edd421ab28d")
setManifestid(628970,"2110742151971912897")