-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2991290)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2991291,0,"95959f1bd12312bdbdfee41e2596af2e69dd88cdbc966c81c1144e642ed04baa")
setManifestid(2991291,"1083686238613080935")