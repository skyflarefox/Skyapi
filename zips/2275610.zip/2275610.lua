-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2275610)
addappid(2275611,0,"79157a3bbfd746a3fee7763efb8b1651d5f1e8620be71686bfbcbd0f8a9d948d")
setManifestid(2275611,"8070825614097449258")