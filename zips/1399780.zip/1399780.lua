-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1399780)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1399781,0,"3865bdcfb996789447a5e30e98af2ec7e3bd6b878bac0921bb58f4457e9624e1")
setManifestid(1399781,"8774066863880232627")