-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3360970)
addappid(3360971,0,"1b463d29c65cd83bffba630d71a8bf7286e2256c7946aa71c4a72537c844b8da")
setManifestid(3360971,"8354440226850545620")
addappid(3360972,0,"65219c28e71df447cee902cb6317bac270f15a5c1f5aa7da1bca71e61f9252a7")
setManifestid(3360972,"1808164749071087006")