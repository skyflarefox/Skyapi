-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1296890)
addappid(1296893,0,"ed870f79c7433f6a238a0e8b56262683f9be58a672607832c30c6ebe08975d94")
setManifestid(1296893,"6887454529693311368")
addappid(1296892,0,"3101484424c4a6d5e416d263d9e33bdf6d607d35190c63cd5cadd1f29d5f08c9")
setManifestid(1296892,"948185257329853133")