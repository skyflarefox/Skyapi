-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(258240)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(258241,0,"74bc71daa0eaaaef66e3f8e13a89a17fe193d5cc4dc9260846b2ceaaecb85d68")
setManifestid(258241,"7526270802902935749")