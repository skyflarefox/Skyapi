-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1638754)
addappid(1638754,0,"3ea0ddc7b189e8d62a98adfc717f2b3e10dc418b8e2a49e0c6dc65936e562db7")
setManifestid(1638754,"6952131697325270935")