-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1749010)
addappid(1749011)
addappid(1749012,0,"d5fae04fcf591663475153cc15137c81a4c2d2ff1f39dc14ef4e076768b2f3fc")
setManifestid(1749012,"5147791262597333807")
addappid(1749013,0,"37bfdb350a84a1af624ea5a3f810def24c6ee4d0b12d678f53b41690647b0913")
setManifestid(1749013,"955604895544148473")
addappid(1749014,0,"bb1c90eb9181b0eaa9a3fcbabe34b3ce332dccc2004c777cba75912ced67c387")
setManifestid(1749014,"5162562048576084206")