-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2965270)
addappid(2965271,0,"306e209d4615c383750b3f9697af74fddecfa8f9ee88532317cb8e0bef48d16e")
setManifestid(2965271,"4621326836777639407")