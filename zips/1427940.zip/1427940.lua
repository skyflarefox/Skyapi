-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1427940)
addappid(1427941,0,"8bca65a782d9e999cae09fc5a1204c83a9f9f6e4a841459a0fe34e4396d297e4")
setManifestid(1427941,"5999954568448423865")
addappid(1427942,0,"e85d3afd7117544f2d0bf494604e067a25abda4c4b514726bdc2367c96033881")
setManifestid(1427942,"2401843917986895831")
addappid(1427943,0,"72f5a9f42c69dce959fdb5f985ed6e97c142c72d4b155b524e509282a9f03bcc")
setManifestid(1427943,"2882628105063364017")
addappid(1427944,0,"a12aa0d3959eddcf85256e5cf2c3d98feceeed30388964bbe0dd02d0b509d29f")
setManifestid(1427944,"4799875918011805629")