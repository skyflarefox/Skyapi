-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3105370)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(3105371,0,"31d0281eb4d7984c7b88025a70255e72d76728f8320e58826b8f9cf64dbe5a89")