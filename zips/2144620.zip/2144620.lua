-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2144620)
addappid(2144621,0,"25afae4235dc7738113ea977a817ca977bdce649703fbcea3e72414ab3dc5ef7")
setManifestid(2144621,"6267906061816176223")
addappid(2144622,0,"2c40530ef51e260e0ea474c1e6a408ca448e447f7c3a7f5f6785bd91e019b949")
setManifestid(2144622,"526678466774536383")