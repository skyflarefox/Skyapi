-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(213850)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(213851,0,"87ace129bfad8c8ab8c82aced01bb4c47ab8bc881d8460abd1865b2ebad51748")
setManifestid(213851,"517572328011574659")
addappid(213860,0,"c8ce8f3275cf26accd317dabbc147e32b5b11fa3fad742c78bb32b6f2d93a079")
setManifestid(213860,"440574345329346402")