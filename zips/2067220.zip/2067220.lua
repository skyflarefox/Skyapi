-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2067220)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(2067221)
addappid(2067222)
addappid(2067223)
addappid(1942051,0,"fe1ff730b91012f303847522af7b0ec3cd8b46944de3cd3a5967c18e483403ec")
setManifestid(1942051,"8772130629607178472")
addappid(1942052,0,"e17bc02e0eaeec284ac41fc3fad55b920dfe2cd9418911100e0b745dec995547")
setManifestid(1942052,"4371739647487958503")
addappid(1942053,0,"84db2633f90e0c317bb92b12524bc2b4bc7ad1d757b50122d2b209a6b11b4c5f")
setManifestid(1942053,"3323729397932562790")