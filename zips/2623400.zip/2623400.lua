-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2623400)
addappid(2623401,0,"cfc3c05bf71d4d622d819b29c7baeb5e8c296e152fccb24baa7451f22544d492")
setManifestid(2623401,"6440092785848778885")