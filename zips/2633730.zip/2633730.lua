-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2633730)
addappid(2633731,0,"9bd402b65c7a3a6864da96d710b5bf48febb8829b5d83bf47ef1071482593588")
setManifestid(2633731,"2434976427918523979")