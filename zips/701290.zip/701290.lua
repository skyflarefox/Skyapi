-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(701290)
addappid(701291,0,"56e734609fe2ec5e8bcc6860a11701ac2ce447a6d680d85600592fd699d76f03")
setManifestid(701291,"2234639818846959120")