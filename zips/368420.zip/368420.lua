-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(368420)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(368421,0,"3dfee627b2eab92c6f885340f6982f8df2392526e0f66614399351fc240f248c")
setManifestid(368421,"1468268255518728710")
addappid(536820)
addappid(548660,0,"989a5b819f55f4efeabf379cca72e1f6e084a2cd79f0d30b3fa387fbf07c99ad")
setManifestid(548660,"5986226876968242506")