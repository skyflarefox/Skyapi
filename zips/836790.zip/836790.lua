-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(836790)
addtoken(836790,3623624426241416347)
addappid(836791,0,"b9383f93bddc7850208fb86a2d1a7882406fb239249a80958fb65abc967b68e1")
setManifestid(836791,"8752453840064391623")
addappid(836792,0,"1fd1fb6893e58fbbaf20cc3fe0bffe0943b20bc5e18558bc60c16692beaa3dfc")
setManifestid(836792,"4483598859283978863")
addappid(836793,0,"1c8fd9617171f508e14b0be9f996087bc6829ff5a07175c96e48d6ddbaa1f3a1")
setManifestid(836793,"1510289898926030290")