-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3122300)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3122301,0,"c5fd8e7ec2edf1a0d1460253e893132dbb5c3e2e0011d519b690f794a74cae3b")
setManifestid(3122301,"7582255883305507451")