-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(925570)
addappid(925571,0,"4d118f2a9064b3e3a4be789aa2a59e10d7b30cb1b25346632fa3d69c6c3dc5a4")
setManifestid(925571,"5740094523654639013")