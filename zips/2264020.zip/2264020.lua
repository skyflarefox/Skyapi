-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2264020)
addappid(2264021,0,"7ac425d371333df5cd807387eb3049aa6b6760f34fcff241addbe96c8c05d653")
setManifestid(2264021,"999994816141065024")