-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2092120)
addappid(2092122,0,"2ad54e57d1cec22abd51c9cb474c99b4eeb52043c2e2900ff3395d22c9efa7f0")
setManifestid(2092122,"5132952258896970564")
addappid(2092121,0,"30a459496e4ea8b9a77a7d5f4535b5ea830be719a341bb39afcdb7b8dae814a5")
setManifestid(2092121,"1457779992844106619")