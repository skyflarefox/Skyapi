-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(485890)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(485892)
addappid(485891,0,"ed56c96dc1b420cbdcfdfec2bd33eb65ced587fa3fd6713f8d4c16599cb97d28")
setManifestid(485891,"6792004602440880087")