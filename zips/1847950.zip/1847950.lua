-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1847950)
addtoken(1847950,14573456470856139926)
addappid(1847951,0,"9fe02858ff0f310c6c397f28b32b4d017ba8f8c99a49d1f67d75d97b581ef209")
setManifestid(1847951,"5980563665182396025")