-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2395740)
addappid(2395741,0,"dc1c529de2e123ec71aff98fb0e3d6e963efa928c2e1b80bd01478f2157cd88f")
setManifestid(2395741,"303457403950487349")
addappid(2395742,0,"076a8863135f3d3ac7df4a1c2605013bb24833c14f9ee8a7aae94a1282f6372d")
setManifestid(2395742,"1222919521763214971")