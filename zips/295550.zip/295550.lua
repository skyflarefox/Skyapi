-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(295550)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(295551,0,"7eb1a222e6678c549fc2f4cb75bd93f0b08bfab98785ef66d43610daa75b894e")
setManifestid(295551,"2660490470463896239")
addappid(295552,0,"d44104399f95cf5ed2265d04309d98924dfc67e61222b94760bc53b8a8811f74")
setManifestid(295552,"3720456375719686867")