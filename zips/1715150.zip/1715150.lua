-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1715150)
addappid(1715151,0,"1ca0afe96809881d3701422e057171e687bbf6fa459247d78d90de8c64931c83")
setManifestid(1715151,"6864993975387138873")
addappid(1715152,0,"88ceb451a2f3dd80ac4d2ec6dacc574655ec1e6d9a3b289f086dcd680f6945af")
setManifestid(1715152,"8691451094999957940")