-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1057770)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1057771,0,"8f6f9ecd61c3e22dd9c94df1485fb3393b857847e51c9db81621e936a4e67020")
setManifestid(1057771,"554249699407343144")