-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(562480)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(562481,0,"4fd0d39d8bcc146d888d7a27bb749df7dc4b27bb12a3d1ec3147884762a269a0")
setManifestid(562481,"2129180127506470189")
addappid(562482,0,"410b38871f0b8e346454e0a4f5af42a403d96dd7c7df28b61059bcfebb6e882c")
setManifestid(562482,"647382059797074871")