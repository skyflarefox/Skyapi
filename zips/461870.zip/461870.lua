-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(461870)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(461871,0,"33cf536ac085a67f87e59eea8e15c68ce14c3db7c25a07ac85bccf97e2fe3c8e")
setManifestid(461871,"8257850844176613783")