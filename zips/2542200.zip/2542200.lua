-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2542200)
addappid(2542201,0,"23f25a38acc90c642af331910b9778aa109078c91c7757a76c5089b954963da9")
setManifestid(2542201,"101912467947241804")
addappid(2542202,0,"989946fe7d1bf770319a8771f0bedaed5cb7a50ef587ab8f527fe197cc39a161")
setManifestid(2542202,"6959678778904877552")