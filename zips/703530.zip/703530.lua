-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(703530)
addappid(703531,0,"070dd4968f8253a676da19289c01d41a4153b12f29aef6e6c79b4f61f506ccd7")
setManifestid(703531,"6374810280648821684")