-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2248430)
addappid(2248431,0,"d2896332e1231d545e5fcc8b6301e4f1143a0113bee66061d9acd890d52932e8")
setManifestid(2248431,"6075090501125119660")
addappid(2248432,0,"a490ac4ef8a5f449a88df1c4a37bebbd549deb3ecf0fff6dc849da900ab95b72")
setManifestid(2248432,"3203134912372312587")