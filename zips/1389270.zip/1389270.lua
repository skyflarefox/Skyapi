-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1389270)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1389271,0,"5d361db4ad4a4ac8892b9aba5ab2fd138935674e176de4938f29190f260a54f3")
setManifestid(1389271,"962243189866324696")
addappid(1389272,0,"24b538e235c5deb1f45ebd56d75d0460ccabbc322b885dedf2c720918b8c5caf")
setManifestid(1389272,"9200515099843380754")
addappid(1389273)
addappid(1389274,0,"606d12a40d23cacc308e43247ef061b167e9fce213978d99c2cd9d0e0a4b6781")
setManifestid(1389274,"5905649198825696288")