-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3464460)
addappid(3464461,0,"b4aaa84692964c41eb1eab33b14d418c74abfde18e60e6537815c6729ae09cd3")
setManifestid(3464461,"9091275092660261564")