-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2824900)
addappid(2824901,0,"44d54348a8a83097329bef8454ca872f0fec20a3deb3bf1b89ca42fad7eb2622")
setManifestid(2824901,"2407189898565622338")