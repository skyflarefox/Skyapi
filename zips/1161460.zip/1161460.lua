-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1161460)
addappid(1161462,0,"40c42cbafe606f34b017c05d90838fa0dadc99a5efc4ba405ee6962f1561a987")
setManifestid(1161462,"3074209859897361969")
addappid(1161461,0,"714e36ee849bc54db5cc3f15043316f398d767b2229256494c8702a2de40b363")
setManifestid(1161461,"2161147480364516394")
addappid(1161460)