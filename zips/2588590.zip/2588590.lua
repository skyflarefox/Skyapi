-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2588590)
addappid(2588591,0,"688a14b0674389b108952cd133dbd8f22a9829558004028bea232e900d3bdf55")
setManifestid(2588591,"5484208147034427037")
addappid(2588592)
addappid(2588593,0,"af463defa0f7966b93a6786925ebc49fbd246ca2198384e44be388a46c82b21e")
setManifestid(2588593,"8339746744179123045")
addappid(2588594)
addappid(2588595,0,"793458638c9263fef7cdf0b3a96aa3483836a5fcdc63e7a3f4502c89d53315cc")
setManifestid(2588595,"5351598856546938554")
addappid(2588596)
addappid(2588597,0,"bd97343d8ca3a83ea6a53bf2eb84e71f406ffa61129dd2e6cb14b062a15ccf78")
setManifestid(2588597,"1414924411443663697")
addappid(2588598)