-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(347380)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(347381,0,"89fc96c195528d54533c4417beb5c791970bd2344b3599f79e3f5d272a94178d")
setManifestid(347381,"5946091293115369622")