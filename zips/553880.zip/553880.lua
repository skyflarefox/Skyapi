-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(553880)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(553881,0,"1efc6b2fdf601afcbbe071e3101b7a198eb01aa9451b74a1839cea2dac0bf5df")
setManifestid(553881,"7743207340481479884")