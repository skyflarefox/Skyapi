-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2170240)
addappid(2170241,0,"64f91f7cdd7062137ea0e349084a14e8150f35a1d66cb748305dfc39adac13ea")
setManifestid(2170241,"590532986080562630")