-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1812887)
addappid(1812887,0,"e5ec952b042417731b9e34ec1fe1ae73e3603b2f751875757f596af6d85a3b2a")
setManifestid(1812887,"229050784816300231")