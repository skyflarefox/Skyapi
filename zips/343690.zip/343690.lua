-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(343690)
addappid(343695,0,"2ccd5715bb169fec76d90763bed696f756e0e9f82cb9ce5cd140706032a59ed6")
setManifestid(343695,"5705323243587032188")
addappid(343691,0,"d86f544f76c1af51b285bfa45ccdc0892d9154a81a2524f4fe0fa3a0815fabe8")
setManifestid(343691,"1328860436950669594")
addappid(343692,0,"ae2df48c6ad4047db17f812e6d9e4b6b58b3f7b8429c2cf514069908c779d111")
setManifestid(343692,"4945008208676182974")
addappid(343693,0,"1fa81f78dec732345070cfb1a0ab57e7173e667ee3db5246d3839761e1e73f8a")
setManifestid(343693,"6904657019764462601")
addappid(343694,0,"454e40cd4ad83dbdcda897b885887ac0c0d0a0bfdec484408f29a091d009d52a")
setManifestid(343694,"6632667033720702783")