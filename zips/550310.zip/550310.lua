-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(550310)
addappid(550311,0,"7749fb825c1e4cfe4e7429fce483bfa6e2993ef95d3253eb60b31f15df23eb38")
setManifestid(550311,"1751220941950637931")
addappid(550312,0,"d40ffab45089b309e822d7da6302b561a26a8daa567a6512aa21dba55493f043")
setManifestid(550312,"277281190728185110")