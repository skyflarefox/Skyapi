-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1388720)
addappid(1388721,0,"a2a199513d8deea5ebd78279ba525e61814921d799f247ec2ca568864ae05eaa")
setManifestid(1388721,"5428807273638536121")
addappid(1388723,0,"5c7d8456add7355568fbfd9fb5d51469af1a14b356ce03d4b003c5ac58e319c5")
setManifestid(1388723,"5830880848644666402")
addappid(1388724,0,"d0fb2959e08a937ca6963a9b0e95f697fe12c9db42b29980c2bbf746c1ebe664")
setManifestid(1388724,"603958391803281790")