-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(629260)
addappid(629262,0,"f8932261b89b06c1c3a3d25f7cb1e41f376c23d7b299fd3c454c465586c38198")
setManifestid(629262,"7318210884359385459")