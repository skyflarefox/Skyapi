-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2895420)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(229030)
setManifestid(229030,"1043465440436835055")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(2895421,0,"127f30b81fd3ae4d1edf8b3abd66d2b22838fb7962fe9011fbdba89da8c74c5e")