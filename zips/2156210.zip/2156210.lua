-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2156210)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(2156211,0,"163f1273eab0fc43b7c803c283116b4685a5592ff656a5de8dc18ebc9c37f92a")
addappid(2156212,0,"305881bf97852d992c8370266caa7fdf774f9f60e914515596cbae31fa9c37e4")
addappid(2156213,0,"f80c6bc3304f963f59f29aa88ae39ecde7de3987cb203b3046737e9375985bdb")
addappid(2156214)