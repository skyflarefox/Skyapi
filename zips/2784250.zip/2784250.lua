-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2784250)
addappid(2784251,0,"bba21d95ca70da7c8d222a30338a8ca00b0320d82c18e112028e6bb5fd8367df")
setManifestid(2784251,"5347623676740914751")