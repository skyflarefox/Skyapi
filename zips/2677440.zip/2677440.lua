-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2677440)
addappid(2677441,0,"d45ea88779b20a6309c4a69514853da62e9865297eb4ead7ca258d4f6b1df771")
setManifestid(2677441,"7268786071366250427")
addappid(2677442,0,"f42068ed6b4c832855a6b1e4c7184058f6b4c332f221fc7c9960a6b01444b11b")
setManifestid(2677442,"749879609808693166")