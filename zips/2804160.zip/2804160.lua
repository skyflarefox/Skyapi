-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2804160)
addappid(2804161,0,"caddb04adf771ebe45cf99138fb9f39fbe18b9547efe6b6d0f080a9a6d4b9000")
setManifestid(2804161,"2475918933368785846")