-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(224480)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(224484,0,"57a0ab06475197f953f5fbec310f366741442aadbb562181b2cb89e85b2dd8c7")
setManifestid(224484,"4253549932522289047")
addappid(224482,0,"63e1888aaccd1bd13a2d01fd28b08d3a8c0e9e80968521dbe4ef45fdae3632a0")
setManifestid(224482,"2782582796488406357")
addappid(224481,0,"0c445f92664319a109907a326398699a92ae30a44c196554a7667f54088b463b")
setManifestid(224481,"8491811867326479954")
addappid(224483,0,"7d5fa7d187fa069a17bc3b7759270c4f1e6b8c1409a0bc26f47089d49f02df63")
setManifestid(224483,"542502232443733342")
addappid(296170,0,"28354c9b84b75dfd88b68705a69e7f3c4aad351080e1b068747996b253e77159")
setManifestid(296170,"1366459023872831277")