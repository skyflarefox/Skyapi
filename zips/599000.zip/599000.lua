-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(599000)
addappid(599001,0,"8dd5b4ba1f3e4e56f971e5c3f245ab578a003acc8cb5c2d6f07ebcbf3808f11c")
setManifestid(599001,"8636786688150812672")
addappid(599002,0,"d68c0df41011a5bd6c68c707a5cc1b1d0165825aa8f2fed7183d07b783e5b26d")
setManifestid(599002,"5337849419800943572")