-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2082270)
addappid(2082271,0,"bd6cf37cad5ec2f580323ed01bc2e352f1670445ed1d8d2c12d145fc94735f3d")
setManifestid(2082271,"5196500550481939154")