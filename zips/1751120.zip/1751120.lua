-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1751120)
addappid(1751121,0,"52f7aa0b29d0b82aad6d18ed7ff0845e0f9be297f117ddf2f873389c270d6e1e")
setManifestid(1751121,"2792273258624563840")