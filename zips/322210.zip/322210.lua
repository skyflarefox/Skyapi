-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(322210)
addappid(322211)
addappid(322212,0,"6cc2551f8d640dcef22e3b8e42ef73ecc99eab7746cef840452c81402a803885")
setManifestid(322212,"5203239241664335591")
addappid(322213,0,"6ae067adc26cb651c142b5d607c4133a8421286b4a97bb1924d0d6549087b34c")
setManifestid(322213,"7183844994724458647")