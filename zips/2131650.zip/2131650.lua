-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2131650)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2131652,0,"65ab5efe73d2ad271b6038a0632621f95755aa433619ed4223eb115634d035ff")
setManifestid(2131652,"7077042967756280050")
addappid(2131651,0,"0073fe0583da7d2329aee1439801c51c48ee664444fa0f669155c1e51d331fe8")
setManifestid(2131651,"3332246131242867228")
addappid(2314280,0,"1741d8bab672cba92e86f4f476a811e7e9e39685a9269a7040437c907492d334")
setManifestid(2314280,"271318178683467101")
addappid(2314281,0,"5267831e9c74001101fdcd5e5987108b01c2c9fc3a3ad44c53f9bce2a3468e77")
setManifestid(2314281,"5944477904700342265")
addappid(2131653)
addappid(2131654,0,"5a546c87b8553c36c0b7c7ad9ea7aed11c225ff288a3077f0ce9236dababfa09")
setManifestid(2131654,"653085675608124350")