-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2893510)
addappid(2893510,0,"b2115366009e3e8ec360cd2827f5af458ed9c53cf856c8d8c71943c59df490e4")
setManifestid(2893510,"2560097644477768097")