-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2133670)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2133671,0,"c80277409f3d813f4db741e66fb47cd4c31fa1ee39f1992f1c39e33c4c68d7c1")
setManifestid(2133671,"8142256767224536294")