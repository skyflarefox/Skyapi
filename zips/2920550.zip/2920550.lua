-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2920550)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(2920551,0,"6c1c5b7e5a0d79a8d62f7aa51e627acef12a8da05dd45a94dc63348d8c59a272")