-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(284000)
addappid(284001,0,"c051b4ca4d82e7466a61d77d61f5d88cf0cd4107683c7513028cd10973774cc4")
setManifestid(284001,"6963340161941106196")
addappid(284002)
addappid(284003)
addappid(284004,0,"33f79c5cf3bfc88cdbf321e0260b83003000e59c91faaae991513621b981461d")
setManifestid(284004,"1504617382901877346")
addappid(284005,0,"5e17a44d73e1b673bbbad91cbe237d201bf62668d3154d17c3364828344313be")
setManifestid(284005,"1074643505505038239")
addappid(284006)
addappid(284007)
addappid(284008)
addappid(284009)
addappid(284010)
addappid(284011)
addappid(284012)
addappid(284013)
addappid(284014)
addappid(284015)