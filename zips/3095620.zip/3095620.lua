-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3095620)
addappid(3095621,0,"1b5d2ba9680b49da5e3920be07dae16ff4421e986c8129332f4d19982f4ca7db")
setManifestid(3095621,"805878552202338508")