-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1982881)
addappid(1982881,0,"cf724007ade8601c55a7e2982f95ff79d806fcab351682167f58f5236f92999c")
setManifestid(1982881,"5078265086111898136")