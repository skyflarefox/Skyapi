-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1665140)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1665141,0,"d5fdb43b9a2a1c76dc30a2f7bd974cb195e94ee79e76d61614a6baa35048316e")
addappid(1665142)