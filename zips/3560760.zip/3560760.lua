-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3560760)
addappid(3560761,0,"fd45688c1cb976437d9e8ac47938f076b017149b416f5d4998e0bdcc8ab9eb31")
setManifestid(3560761,"779833258704945706")
addappid(3560762,0,"5ecbc14a94c7cc2742b9fb59ae84e432f4d0bb293b118ec11bb982b3302643c9")
setManifestid(3560762,"5140239274200816094")