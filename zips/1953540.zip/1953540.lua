-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1953540)
addappid(1953541,0,"ef31b1e72044b74697cbaef9e815f5ea7097f86c051b7271c2c7d97ae66df3af")
setManifestid(1953541,"3965728142889081942")
addappid(2573080,0,"326b2c34adec870789a2e0a5e51d16ff3b4cf790548657a59c0f1410d53717dc")
setManifestid(2573080,"3471205971274529007")
addappid(2573090,0,"2ef434264d01e0e13ca4663dd15b0f6820dacebab95d0a40012317a1547f250b")
setManifestid(2573090,"814789414431572608")