addappid(1175360)
addappid(2685580)
addappid(1175361,0,"474762a0b0e44e77480374cdb172c736b3b987742cdf39a80149dc65ad9b6696")
--setManifestid(1175361,"4552339095540373731")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]