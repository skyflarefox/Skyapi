-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1223960)
addappid(1223961,0,"cab5c169e58df6e5543df580a52b34a77b27faaa9c1c8ec854134daa4566ad9a")
setManifestid(1223961,"948690318679310461")
addappid(1223962,0,"9bcb897a473ea0a05395051a61b144ade90456f50fff6c2a59db22f2e9bc3dec")
setManifestid(1223962,"3004662310631814781")