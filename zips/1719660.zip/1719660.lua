-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1719660)
addappid(1719661,0,"eb1b1c7659359b22638c6c2be314f1129d485164490700d7dd0a98e532410846")
setManifestid(1719661,"9181631295102447385")
addappid(1779580,0,"ea6c2bcb7300a79fc7c384375d955b30d1de6b359cd82fb14760062dc684bfe7")
setManifestid(1779580,"4229155319320389425")
addappid(1795050,0,"14c9b9a6cc61ed32c26c8dc7388f5f1a00ec8454b55059915552e6d7a5d627ef")
setManifestid(1795050,"444527002045293259")