-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(399640)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(399641,0,"dac7a26e82731e22ae75a6c3163f0a3f8779a21b66e7c08d6eb7c3b7a12fc756")
setManifestid(399641,"482999711748877435")
addappid(399642,0,"b7cd155b7d7e526bc3657a6514700cc72df7261e93724358e2759628967ba143")
setManifestid(399642,"1108905756810838851")
addappid(399643)
addappid(399644)