-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1274300)
addappid(1274301,0,"15ca4016e83f695eb2b729348bbabe7491f1e6e8e8297b607ecd4f5724f173fa")
setManifestid(1274301,"6869697459117137751")
addappid(1333370,0,"0bfda0b1d5d9b05ae27494490d28a4418c746d09d1ebb1e4fd983e24c6d81985")
setManifestid(1333370,"7880083163248479744")