-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(342450)
addappid(342451,0,"e1894ec1d744c6533bfe6f7dcecda6aecd6230ae3fda255fcb9835df6187bc39")
setManifestid(342451,"7791166972187336754")
addappid(342452,0,"39a4bc15575d463c306c4ef16549d413e6a85d72fb6c369ffd9718a88bc02cea")
setManifestid(342452,"2717255318760842043")
addappid(342453,0,"0faab0d46bd6ab5b90b7327bd055f72289a4de9e3ecc4f016409803cec81e1c6")
setManifestid(342453,"7673458692104506558")
addappid(342454,0,"1214fc84d7f8cac5a8b3df9bc7c95bca65dc7d76ecc54b2f803657844eec4fa6")
setManifestid(342454,"7900258620384027997")
addappid(342455,0,"3408925820287931d0ebd5b22b9ed9d20029bef519581928dd530aa27d039fe1")
setManifestid(342455,"5483801872624155534")
addappid(342456,0,"28dfbad3e763dcdf19ca32f151fe83a5cb0b8784e724f04eaa8ea399a821a875")
setManifestid(342456,"6969989656656017795")