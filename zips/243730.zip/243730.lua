-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(243730)
addappid(243731,0,"a1a138d88a3d376f22fe197c2898c6542ca1b9c6646895871118c7fe0f4c79b3")
setManifestid(243731,"6975081868961707037")
addappid(243732,0,"036634f476385224c0b9dba37f50e3258b688c7642b36302a715bb5b38ebb037")
setManifestid(243732,"244602438114119945")
addappid(243733,0,"626b7c28389afdc9d78b634377957b5e402592d2300e7d4338583eb573f172b1")
setManifestid(243733,"673035703819169847")
addappid(243734,0,"80c2b63a4d01ad4fdef585b1b8aca6013754325376e8a84a4d54d111399e097e")
setManifestid(243734,"808383876744671946")