-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1973580)
addappid(1973581,0,"faf6ab913e2bd0adbb4376a03542bd6b3f35654478d7c92744f04801c4634188")
setManifestid(1973581,"4956798727354747789")