-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(578350)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(578351,0,"0be5e4d0e2515886c60fc9127d394605d300b69ade561afe71b6fea258cf478b")
setManifestid(578351,"3871623938139814672")