-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(749570)
addtoken(749570,12171588904325010343)
addappid(749571)
addappid(749572,0,"61b31746054a1dd0148d8f73263826f484fc3079035a1705578f7d6fea4eea10")
setManifestid(749572,"9144101299505642648")
addappid(749573)