-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1442650)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1442651,0,"d36e1fe8363fe1bbadb034770b8002ca6c7c008cbb956b9b7b43c2de2ccf58c8")
setManifestid(1442651,"8405851460164211571")