-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(460960)
addappid(460962,0,"ed974515857c7f61fe8854df4299715a3e83794e1d4ff7ef207e439f30669b0f")
setManifestid(460962,"36901673830089059")
addappid(460961,0,"4d9dd8c90c7fe750a19bfda5b96142314274cbcad3f5dfd832921192199582e5")
setManifestid(460961,"4518943117400794641")