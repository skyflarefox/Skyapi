-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3380720)
addtoken(3380720,17014698030686997416)
addappid(3380721,0,"7a7505feb70dfb6b45e675987c1160441a69603298332c8dc73c108205b7ee47")
setManifestid(3380721,"818426663785132735")
addappid(3380722,0,"dd40ef28f51949c7c484ad2c4e7d9ec8353cc83ff2e08923d449de9b0d27e100")
setManifestid(3380722,"332214231934312645")