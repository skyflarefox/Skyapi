-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1683430)
addappid(1683431,0,"511db6311273fd3605655da5a5c79ab89744866c0773405adaa7da5f71a97c8f")
setManifestid(1683431,"8470011539720562727")
addappid(1683432,0,"6b6352e8ba7fd502030b643ca09bac2fac1367ff713ed6d22ee83ea07770e8f9")
setManifestid(1683432,"8641607938586864095")