-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2734290)
addappid(2734291,0,"7256a65c1fd956801cb488c65dbfecb5e42299cee41bc2943df40b08d69d533b")
setManifestid(2734291,"2936245664314633639")