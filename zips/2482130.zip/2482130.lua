-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2482130)
addappid(2482131,0,"11bbf528388ef97757177d072d3e6bc12ca6131c603dff7f475c5cfb73298c60")
setManifestid(2482131,"1015118035263547562")
addappid(2482132)
addappid(2482133,0,"0208ecaf6cdb0bd2340ccaa8a74038a201fb21e840f433b334185f87761ddc6e")
setManifestid(2482133,"6280878405387786129")
addappid(2482134)
addappid(2482135)
addappid(2482136)
addappid(2482137)
addappid(2482138)