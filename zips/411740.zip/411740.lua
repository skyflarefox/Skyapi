-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(411740)
addappid(411741,0,"48e957d6de630bd58bff2df57eab5dfdd3719e4907fb2897a10867c690183246")
setManifestid(411741,"310194535344826779")
addappid(411742,0,"4700960a9e5c66798453506fdbb9329e26a326a000840546bc091f05d89b6c07")
setManifestid(411742,"7704677424332412793")
addappid(411743,0,"1b7ff7ca98fc4fa1bcfb0b4a53bbf209649fcf3508aff1cf867c0a6f835defdd")
setManifestid(411743,"696589986295805172")
addappid(411744,0,"4f422100dc8fd979590f3f45ed26d8f61b3545f4ed9e8b33159e6b059726931f")
setManifestid(411744,"523392121473101803")
addappid(411745,0,"bb6a95e0a4251f127ab4c4569b03901dd2872cb91feffccb0ff7e2a07fe7e0c7")
setManifestid(411745,"8229309881460513729")