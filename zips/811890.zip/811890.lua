-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(811890)
addappid(811891,0,"b32799c3bc1861da431df49a5c9da8ffb36eb3a8a4bf5cafd375744a4826da85")
setManifestid(811891,"3561818061006674591")
addappid(811892)
addappid(811893)
addappid(1224371,0,"158bfb1946e34dc0fa99b2e7512f0fd4a47e3c657b084dcec7f2a7bfe0897ade")
setManifestid(1224371,"3675514871465954807")