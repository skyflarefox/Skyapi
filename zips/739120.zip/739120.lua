-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(739120)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(739121,0,"e5d76ea543b51796935bc7a56dcd30d02310efcac06b1139f0f260ea92652f87")
setManifestid(739121,"4799816964070848189")
addappid(739122,0,"31dcc2f00c1ee1277887541f8554a5302f644ebeb9589ecf521ca21c34724d23")
setManifestid(739122,"1257568331986116298")