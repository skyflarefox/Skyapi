-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1284140)
addappid(1284141,0,"5425517ef420903a8d1eb6009d42b862be4a20c217e91c61329adc6811cb7f22")
setManifestid(1284141,"1609069877494766342")