-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3332860)
addappid(3332861,0,"0de0253fe5191b8d81344add736cc696230499580761f70e2ce50a5672950d2d")
setManifestid(3332861,"8020777748674782292")