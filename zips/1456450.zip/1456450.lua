-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1456450)
addappid(1456451,0,"1597fcede42fcc8397a808c22adf950d1a2afe186488c7e0c0d560b6e2965db3")
setManifestid(1456451,"8983618565075105516")
addappid(1456452,0,"a899525daac6f4038ee70113d21a4e128ca802e239211e4d144585037d99fe35")
setManifestid(1456452,"7245791608680787330")