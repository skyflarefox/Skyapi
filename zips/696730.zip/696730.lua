-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(696730)
addtoken(696730,15408159780543391286)
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(696731,0,"824808064f05201cc8fa6eaa840c7b3bd698773c261a38a519bb2e9394e9fc99")
setManifestid(696731,"1643269441832460402")
addappid(701320)