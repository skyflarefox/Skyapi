-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(838940)
addappid(838941,0,"a1e42c3b4cf5cd1add3eebdd0ba362150c416038b336042062c42f25735211ee")
setManifestid(838941,"6774761324129652904")
addappid(838942)
addappid(838943)
addappid(838944)