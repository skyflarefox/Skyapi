-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(432290)
addappid(432291,0,"c9122c594fb18061ab1939cd3d19908734ec2750026df5caa691d81c16c0d679")
setManifestid(432291,"6385994411990312202")
addappid(432292,0,"b78998ca529dbb1f8a2e7386fe9edb2d5be2b22d25ccff005a46ab9f4b25716a")
setManifestid(432292,"5262015134800128641")
addappid(432293,0,"38066a576741ca738fee517fec69da6fef692e03fcbf956924687d5a0cff166d")
setManifestid(432293,"5908787853294030206")