-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3469030)
addappid(3469031,0,"e1f9f4cc8e6bed72f300aedb0edcdbb786832b76afc8c0787dbdfe5c239a1b9e")
setManifestid(3469031,"707015932766196718")