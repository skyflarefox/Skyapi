-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2137190)
addappid(2137191,0,"d699b3c796a17f2bde7d9b7bdf1f290d4d5ec681ac1f7610c2073cd98a1c072e")
setManifestid(2137191,"5037578425082041848")
addappid(2137192,0,"18af96be5b888204a15794f7746ab388181a083b1e1b00c83ccb947a4cc3b81c")
setManifestid(2137192,"8146867162891049791")