-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3177970)
addappid(3177971,0,"559e6e3450ca7058329648e9292f360d400970bf869e4a68440e07912d3ac476")
setManifestid(3177971,"1644171749143895542")
addappid(3177972,0,"cac467301f8871e1599a50e2c350b2b16b9ef3adf04cbbd932dd4a6d22fc479c")
setManifestid(3177972,"5841674226436188243")
addappid(3177973,0,"c0227822f255bb0836dc6ea94d39abc7a62fb9ba541ea8d3162b11962a12fb92")
setManifestid(3177973,"7011161532992163351")
addappid(3177974)