-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(643600)
addtoken(643600,4540790854930559713)
addappid(643601,0,"c5511e7b9ca74746ba506c0ab3a2bccee8edaabd51454d75c91ea3696a5806de")
setManifestid(643601,"335335416312299446")