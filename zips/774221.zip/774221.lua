-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(774221)
addappid(774222,0,"51eb680a58a978e84919a7641f0845214214d1595c5b5b2f5559f05038cc9fb9")
setManifestid(774222,"4184306917762002538")
addappid(923251)
addappid(774223)