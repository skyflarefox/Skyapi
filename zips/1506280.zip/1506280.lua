-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1506280)
addappid(1506281,0,"68ea5ca95dee740307df15b7f1848adb3be96d4391021e9e30d094ad53b4ca9b")
setManifestid(1506281,"8736055902058025394")
addappid(1594550,0,"8fa3a6fcbca0601d848bdb5e859fd10b8795d6bdb87dff46bd8e18fa7b78e071")
setManifestid(1594550,"3258153482705383576")