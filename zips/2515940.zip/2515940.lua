-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2515940)
addappid(2515941,0,"798374fafbc52d116f2495cf14a6a2ed506d0f53a7b8e5edfceb4a9cbad306ce")
setManifestid(2515941,"1903854195626440207")