-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2928560)
addappid(2928560,0,"bbf115b23fcadf411100fd4eaaa9a3a0a4d56c7a8f68a207d36330120954e0a3")
setManifestid(2928560,"3680108875939940893")