-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(699550)
addtoken(699550,18148431099055890429)
addappid(699551,0,"8507e72188a49316a4e622fe08a4d60f8a6d20d13f8b9d58fe955a26b9c1a2dd")
setManifestid(699551,"1979982604783661655")