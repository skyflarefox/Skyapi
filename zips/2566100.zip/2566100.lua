-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2566100)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(2566101,0,"e5b975c371adc082eebb530cc7e7ca3675342ce77630c3fbf910a2e44796f8e6")
addappid(2566102)
addappid(2566103)