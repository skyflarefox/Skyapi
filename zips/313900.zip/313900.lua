-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(313900)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229032)
setManifestid(229032,"3616495131483866412")
addappid(313902,0,"e15c527b97933a7c4322af1765e1ab3820d4309fdf942cc57f8b52ce8e64eb20")
setManifestid(313902,"131337985844360728")
addappid(313901,0,"4edfb6c18168304e1b25f6ad96eec0e2b6cee2b4631b64335cbe52043bee736b")
setManifestid(313901,"7967996421633057889")
addappid(313903,0,"a7f90010f52a3af6e95bd68a1178e47abc99e51f2170c89a2f6bbbdeff4d8047")
setManifestid(313903,"465516024796531105")