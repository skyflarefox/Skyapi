-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3248770)
addappid(3248771,0,"427f04b50d26ef7ebc22050c5152cbb82430525a2187736ee2b36d11b6754c7d")
setManifestid(3248771,"918150459154628975")