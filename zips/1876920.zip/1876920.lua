-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1876920)
addappid(1876921,0,"03c21c200c2b243d2288fcfb17af80aa67a5daba39f4279c2b24b20912698f59")
setManifestid(1876921,"296035969379534017")