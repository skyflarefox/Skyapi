-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(583660)
addtoken(583660,7993876567924949007)
addappid(583661,0,"9161c2edc861ad7e74181a13a8beff3b6be930c2d6256932f60fd4631c9c418d")
setManifestid(583661,"7727168576848333577")