-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(324090)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(324091,0,"cf5dfa6969d733763d96236beca790a481d4ade46fcb8398f96fc8cf310c5bc6")
setManifestid(324091,"4715122613004039857")
addappid(324092,0,"e37a45ff8cc62f3889cb04329c279d6b84a86a304f62a15885cb975bde7f813a")
setManifestid(324092,"6996922022060772769")
addappid(324093,0,"7055731ed6f22589f1e6542722f24320e50ff721f3988d52b20125279475f191")
setManifestid(324093,"4231279074432627926")
addappid(324094,0,"470989495cf393652a99bc7b1a31404b9982bfbd244bd30041d3821561542490")
setManifestid(324094,"772303430803884452")
addappid(324095,0,"f57b940f76a9f0aeb245ea4ccc06b655f6951a0ed96719e8abb871e1cb702642")
setManifestid(324095,"7493638206977332949")