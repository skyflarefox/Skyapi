-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(416800)
addappid(416804,0,"20402bf982f66680dcb4b05b102ce2d32c9700eb1b6245c095976ecd9f3c0e00")
setManifestid(416804,"8648207569973447079")
addappid(416801,0,"36c3d29f6d7201a4f576db1728366ac63589d3e715f1b4d8a043ca5b8cd31a4f")
setManifestid(416801,"2051104170522655335")
addappid(416802,0,"461386e57b5c7d9c29e3bd0807c796be5654396490fed50e083429c5b2e6d8af")
setManifestid(416802,"7980523189669394157")
addappid(416803,0,"3e1870aa2f6dab0709460ae1281f91a71660a6c19d3da35724e08314821f7081")
setManifestid(416803,"2926188775028395038")