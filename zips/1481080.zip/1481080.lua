-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1481080)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1481081,0,"310529d2d801d10414fb757f4c3aeb49c9f9e39cffe02c19acffb6e4bdb7020e")
setManifestid(1481081,"4643713096940209872")
addappid(1481082,0,"e60d209e43c1923044e0593947a69821a4f2a4c4c505d2b4ca414dd802b9cabd")
setManifestid(1481082,"4745204026474026929")
addappid(1481083,0,"53673c4926d749f24e04d69fcd91569b04e5545418f1d2806784cd8d21e65941")
setManifestid(1481083,"5894820743675621512")