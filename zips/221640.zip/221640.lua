-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(221640)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(221641,0,"8ffc476f2f7d1d5261a3b12125ffb217d76090278a1fed5945344816ab4d7bb1")
setManifestid(221641,"3466647956312300491")
addappid(221642,0,"73c567c342c35e5ae5151e0ca0e978d5a078c2095a16994bfceb6e0b3d100486")
setManifestid(221642,"1709752638055709001")
addappid(221643,0,"890f03b2a76e12192828bcffe118d5f1487791cc86f5a59a89ec7d6ce76f8b44")
setManifestid(221643,"7186315654381968499")