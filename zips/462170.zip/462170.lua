-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(462170)
addappid(462170,0,"d72941f7d386c87a7ee6df782d15480d0d6b9c2110fca4bc52d627ac49347c5c")
setManifestid(462170,"8355479874918237721")
addappid(462171,0,"c1b5d3e4679fc74a482d3858f33ec47041955714034b0078f19ed3e8b264eae5")
setManifestid(462171,"2355389519374069905")