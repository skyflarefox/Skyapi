-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2527460)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2527461,0,"496bbe368c7728a91cc3cd45e78f711a1389b4bc48be030f8d8795869776618f")
setManifestid(2527461,"734900192845514881")