-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2932950)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2932952,0,"3d817928d78f5f07145a32a68d1bb00c4ab0c162ec6d53c627b1cfac55757fe0")
setManifestid(2932952,"692694132685452073")