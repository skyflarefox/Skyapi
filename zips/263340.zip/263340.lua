-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(263340)
addappid(263342,0,"7940cc6a88c767d362e7cdd828c7e9cdffe5a98eff50140e0386d86a977fc1a3")
setManifestid(263342,"5098990294333662395")
addappid(263341,0,"9dd599993b22fdd786cd3658147b22fcc988ca9ba64bd428a843003b5bf83cf0")
setManifestid(263341,"1870889380212866237")
addappid(263343,0,"607cc6d8147494dc7a82816be8dc712e9a829058e361c296e8da136507c9baa0")
setManifestid(263343,"4203785904180338066")