-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2594250)
addappid(2594251,0,"0cd2ed767362e21fcd1efc1835e2adf39075223a4c4461c4eeff5dd43bd0ca8c")
setManifestid(2594251,"5337971465841178251")
addappid(2594252,0,"904bc5b60e3c3008b667ba7fddfbcf9bff0abd503b4b54ee9bfab5a24981087c")
setManifestid(2594252,"9051611012477840950")