-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2254920)
addappid(2254921,0,"46c87f8081f8ce42378aeb4511eeba8559ca4cdd58e5d0507b5d9ee9d45e2b7e")
setManifestid(2254921,"678531556016010046")