-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(263720)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(263721,0,"cd6c18d816198aa5b63768ffea9306f9b1c2f2b0a391a40b3dab5225cb7e67ed")
setManifestid(263721,"5628190440206131666")