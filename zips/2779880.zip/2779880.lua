-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2779880)
addappid(2779881,0,"193934f9759e3dc53e32cd2677fb076c3cc889e268f6270ab8305ec6dd1b75c5")
setManifestid(2779881,"3123167790265715286")