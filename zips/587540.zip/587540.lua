-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(587540)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(587541,0,"1d4949e76d49b45f6d11336abe55136700d4befd08729d2d72097ee2360ae77e")
setManifestid(587541,"3082145127868421685")
addappid(587542)
addappid(587543)