-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2543370)
addappid(2543371,0,"9d0c70ba9f59cdeabcdcf85ce0bdf753641d5bf4ba8facb1c7dd157526595349")
setManifestid(2543371,"5419042228107748594")
addappid(2689900)