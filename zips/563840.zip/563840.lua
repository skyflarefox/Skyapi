-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(563840)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(563841,0,"3c7bb7f230e7645f1e381b2935c94615d4eb106d240de048230a576554918945")
setManifestid(563841,"6116416378256840996")
addappid(563842)