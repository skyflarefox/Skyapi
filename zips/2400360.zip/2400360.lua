-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2400360)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2400361,0,"b3038ca8d1cd9010abcd32055c6060b5e2f299f72ee4eb6c20c0582309d38754")