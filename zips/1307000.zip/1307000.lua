-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1307000)
addappid(1307001,0,"f3f86395f2d7ecde7d6c139a92ad01c7d62f054fe79aab138a23a64dbe15833d")
setManifestid(1307001,"2840165785726898242")
addappid(1307002,0,"7940104b777ec04da03a56b2d597765ee65c09b2c19b20bcbf7ed4757a3088f1")
setManifestid(1307002,"7311295518975205863")