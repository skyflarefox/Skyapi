-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(796970)
addappid(228984,0,"df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068")
setManifestid(228984,"2547553897526095397")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990,"1829726630299308803")
addappid(229005,0,"aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a")
setManifestid(229005,"7992454656023763365")
addappid(229033,0,"9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3")
setManifestid(229033,"2059065101492814639")
addappid(796971,0,"2978149919d8a41969f973d556f7ec2feddfd523e459c92f3847dff3bfeec0bc")