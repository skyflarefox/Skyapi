-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2002810)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(229033)
setManifestid(229033,"2059065101492814639")
addappid(2002811,0,"80c03e7d29610153d6cd68e1cd1f08d8ecd5a97df8ac490088218cc91a8ce270")