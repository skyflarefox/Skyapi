-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1170760)
addappid(1170761,0,"108131f745bf7b02473d31e4fbc5e99dda0d22e989c5ad7fa12f6abfa1250613")
setManifestid(1170761,"3894521066892923626")
addappid(1170764,0,"ea50db4c508b91100ec9f14a753dc7d2e75a8d07d5e5068002a964fed73a3b56")
setManifestid(1170764,"3079861715303216840")
addappid(1170763,0,"ffdf90d9d55ad36291776ab92ec27f9d1e07e5bdf656bd72f615ed78f61d6788")
setManifestid(1170763,"167250175449787602")
addappid(1170765,0,"2fa88aee41281e5e819c62038e6d67a7cee5dca04dddace863c3cbc3d7ef93cd")
setManifestid(1170765,"8519329365403677318")
addappid(1170766,0,"d14fe8c5c876585dcf21af244acf27f92ebff5fbe3f0dfdc9271ce821046b487")
setManifestid(1170766,"214717485014716877")