-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(286140)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229032)
setManifestid(229032,"3616495131483866412")
addappid(286141,0,"d5367a73ba6b61257acf6cef913d9bc6003ffa33648258b17225bd5f3ddac73e")
setManifestid(286141,"3762731534886579029")
addappid(286142,0,"d7c9fc6be187cec732de386c761d58b761a17c49c297f8af06c671e39467eb0f")
setManifestid(286142,"2430501946914181321")