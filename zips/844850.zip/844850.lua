-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(844850)
addappid(844851,0,"5c5c04ea58636e5a5d58daf4e989c197fd085a71373a1f9863d5e3ca29ef1021")
setManifestid(844851,"189432212381992648")
addappid(961630,0,"5a03343c44e226c340b33a8020a27cbe42d3269fbee928d7cf16a6f71ab4351c")
setManifestid(961630,"8748341852433451845")
addappid(1202080,0,"007826f7d8390f0ba17a2d3399fcaffab700cd09e70c333a2a528edb0981209c")
setManifestid(1202080,"2519948823462935184")