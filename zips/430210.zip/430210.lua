-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(430210)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(430211,0,"3d473c67c4219a3740902def77ac1d1577a0a2340f4dbfee811f8751a9936910")
setManifestid(430211,"4136930411624443371")