-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(545560)
addtoken(545560,13350105374049874993)
addappid(545561,0,"10d7511190ba5f358aba4e9627f6a0941c8aeabe1de05ae14d31940d1e640896")
setManifestid(545561,"5692759525958804598")
addappid(545567,0,"d2a274be496484a33f757a341fbbab3c233e6123f8053034aa1b4c6f8341ea75")
setManifestid(545567,"7843276657814774132")
addappid(545569,0,"19d991db7dd01e221b4d54f464cfa84ef84054adbd57a4ffd0bc51c389c6f838")
setManifestid(545569,"7980928942791342203")
addappid(545562,0,"6b7448d44b410e25822339c97aedf53099ee60c23a53202e6fb88a815d8bf7bd")
setManifestid(545562,"6492697136184872987")
addappid(545563,0,"e93d485038049d5f46c866937e5bbfc08ff43b3c7e605a3318a9e271cf1364af")
setManifestid(545563,"1956072854387245456")