-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1993350)
addappid(1993351,0,"72bb8694afac0787072d9b1f8367dd4627f29890218d27e878666d3d4662baf1")
setManifestid(1993351,"1039685027114356859")
addappid(1993352,0,"12437d178e4a43a71efdbefd889aede912e0dcdab5400c680a33d18561c5e9c6")
setManifestid(1993352,"6809759928997919527")