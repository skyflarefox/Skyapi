-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(676490)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(676491,0,"641484949e73c7edae07b66233135b2311a1ef05e7c793fdc96c773e65b70f42")
setManifestid(676491,"2965757812648973337")
addappid(1251730)