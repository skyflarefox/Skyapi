-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2165330)
addappid(2165331,0,"d9e154f826ea7fb33f1480e75ec4a823f653094c50192b7d5a147297cb8801b7")
setManifestid(2165331,"855342090601836314")
addappid(2165332,0,"409f239ba48b82cb16f9ba27e2af2177d489c2590cbe0e9be32e681d21f653eb")
setManifestid(2165332,"7923259847669708075")