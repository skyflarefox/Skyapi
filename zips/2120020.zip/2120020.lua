-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2120020)
addappid(2120021,0,"7085f2afd305ef8d820f755e8a86e818ad369a9e284cf398946ef356ca0a86aa")
setManifestid(2120021,"7397735515718235705")
addappid(2120022,0,"0d7340536140b64629466f465ccc1126462d30942f711c070b7bee1c004f9feb")
setManifestid(2120022,"3116909905152192699")