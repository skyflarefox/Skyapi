-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1240980)
addappid(1240981,0,"a337d8f4ecca1f0b7c77d281106bdb8d73adf7122b1b65bab6aec9aece53dfd1")
setManifestid(1240981,"7077456466661229684")
addappid(1240982,0,"e965d20bf2437a6900431823975de9b2d9fc946b2203ada51a26efe99ffc5c5f")
setManifestid(1240982,"6863070686875677783")
addappid(1240983,0,"3e2a14821b74fad334a63d8d31023adf528059115dc688ec550799cdedcfa33c")
setManifestid(1240983,"868718932988287453")