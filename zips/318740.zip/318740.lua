-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(318740)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(318741,0,"016106317bb3f036de7edc473518ef842c5be27183204d3074ad1983ab355c8f")
setManifestid(318741,"8338524217523554494")
addappid(318742,0,"3a075c10dd97ee2b0d91d5be9d8a1a1f0af19e91eaae0af00e823e3457bd77ed")
setManifestid(318742,"1848681174185375834")
addappid(318743)
addappid(318744)
addappid(318745)
addappid(318746)
addappid(318747)
addappid(318748)
addappid(318749)
addappid(318930)
addappid(318931)
addappid(318932)
addappid(318933)