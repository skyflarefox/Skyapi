-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(555850)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(555851,0,"8de15a66558b3afdf4712ab9be64d17d5b9e9599ced109be9489a45f7a66c44f")
setManifestid(555851,"6070050622117892915")
addappid(555852,0,"4c766f69ee6d3ac0804157210e4ca491856a68c2198c2896e28a923e42e7065c")
setManifestid(555852,"206476555807616536")
addappid(555853,0,"62be66471b27aeabe5c2d4253b3674be71c89934ed090f070a5c2a4772863ce9")
setManifestid(555853,"7059625610791696851")
addappid(555854,0,"0197a2d3f07d31ac6ef0a39d01e0a04fddb1d8edc9aab2a56f97ddcc3e837a5f")
setManifestid(555854,"4639773806357011115")