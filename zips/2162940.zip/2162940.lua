-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2162940)
addappid(2162941,0,"9b37e84e54065939501c6bd6578142ed0ed99ad67faa6b74f4ba4b527c7a4c06")
setManifestid(2162941,"8872573729334723111")