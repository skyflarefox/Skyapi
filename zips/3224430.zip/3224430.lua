-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3224430)
addappid(3224431,0,"2c73bd864ed75a50734971990f961e2cab102da008c6817cf65e245ded2c5880")
setManifestid(3224431,"3296994465182692529")