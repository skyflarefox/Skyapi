-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(481180)
addappid(481181,0,"5d1f69639af5817361bd1b2097bacca3e9fbd0683dcf78259625ec4ba1f58638")
setManifestid(481181,"6817483454152376909")
addappid(491340,0,"a161866e468209218a30f4cea311c6da16ef28f69f3f3b72c79df011434ec938")
setManifestid(491340,"480729411799914302")
addappid(962540,0,"2aff071b35b9faea0649154731beec0e0dfe554763aeaa3e8e73ca97c9cde4f1")
setManifestid(962540,"4493127775585462592")