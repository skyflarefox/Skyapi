-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(707680)
addappid(707681,0,"7793a65cc6f5c086f8e81dc7ba6047727a9823e80e8cf0aaafdc84c0f09a0124")
setManifestid(707681,"8760395519515495446")
addappid(1025590)
addappid(707682,0,"a5261fe181405ea26358da35f9676d4ee0a0232a372aa6b2d73f2504d71a39fd")
setManifestid(707682,"549632825081488979")
addappid(707683,0,"f40588fb448d899ae2163afbea2a120f9ed97ee73563341f9d2a91943cb42c2c")
setManifestid(707683,"4280494977974971676")