-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2085130)
addappid(2085131,0,"c67a82f8f03c3a16959f55c798dc140173b83855208103f905dbba017db85e82")
setManifestid(2085131,"8163508101325865142")
addappid(2092780,0,"e06bea39adcb233ada672c12ff7208e46c71cab9724b7e53bc9d97b362008f3a")
setManifestid(2092780,"3131150338538802743")