-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1223730)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(1223731,0,"aa984e9987697f2dae05f17ae1aff514cb3c24400ad0578b2b245e99d4ba48a5")
addappid(1223732,0,"3a8390951861fdb0a52d91bcc000e85c82bd5ebd05c951708eca54b8a149452c")