-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3263300)
addappid(3263301,0,"19a893b4fa4f1ca240fdd6255bf03d694e3dad61127550f5bd3c20e494287227")
setManifestid(3263301,"6468258309628442230")
addappid(3263302,0,"b771576199a0a1743841af096321ca7bd1660f9050dd4484b22cc4fddd78d79b")
setManifestid(3263302,"1164769324008558783")