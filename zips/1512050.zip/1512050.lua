-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1512050)
addappid(1512051,0,"0a4301ca7c3cda8ffcbd7c02f7739f54bc30680b0b623c5db7d340abcad82ece")
setManifestid(1512051,"1270414053518523240")
addappid(1512052,0,"b1cdaee6f114f1add4126f0a932f4b8f3288c5941991af8cdc09c12f30f1a9f7")
setManifestid(1512052,"8089283213114110329")
addappid(1512053,0,"6eaffbbe0f288a30f998d3df164fae78dd65373ac21f50dc4b6a527fe2de0391")
setManifestid(1512053,"2721401841715369366")