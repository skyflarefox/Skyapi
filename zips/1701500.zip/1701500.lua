-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1701500)
addappid(1701501,0,"2da0113a7c7651484ee8780a53913082b067de8c45aa22455034491e7111f422")
setManifestid(1701501,"494131424390119178")