-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(918820)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(918821,0,"fef43ad025c22f4f077f6609347b0865ff8ffd50d65987490f2e3718d48aea1c")
setManifestid(918821,"8557229673408221772")
addappid(918822)
addappid(918823)