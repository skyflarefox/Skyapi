-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(874050)
addtoken(874050,1645934222331052539)
addappid(874050,0,"3b18a91271a6a6a125194fd0f64214f1ca96ebe311f0e1b882a4b749b26d6f07")
setManifestid(874050,"3074375498092021699")
addappid(874051,0,"8179c5974e6b4bee1944733525366f2e7b1d0abd61f34b22c06e58c35537b5a3")
setManifestid(874051,"6577630523648114151")
addappid(874052,0,"4b3b6d8fd59c75fc092d60e5ffd1634173cb3dc5e0537c606fcfbd07531251d0")
setManifestid(874052,"2261487866599815440")