-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2615620)
addappid(2615621,0,"765fcfcf65d42b96132e3f8228baa35a5b22915067b21fe51113fe947acd0549")
setManifestid(2615621,"8863943940257018932")