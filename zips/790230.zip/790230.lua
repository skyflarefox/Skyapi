-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(790230)
addappid(790231,0,"0f74f8d51f62bd0889b07024924d05dfb6b3a143c66e2e89987ad1343f311f5b")
setManifestid(790231,"5827157655955977408")