-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(578440)
addappid(578441,0,"f296b94100d1ff36cefc5219c0b0b38dc6e0aa6d2cc44d9de78cc46bd1082df2")
setManifestid(578441,"4671610580763106616")
addappid(578442,0,"dfc07870c16254d7dbae2bd3e234c13ff69073bf5a9b36a92ed00d72142185e1")
setManifestid(578442,"2346173252962886800")
addappid(578443,0,"9048107c67789b22a26b568948313e20a3987df2491d843dbb15809a156882b6")
setManifestid(578443,"3052929382013237355")