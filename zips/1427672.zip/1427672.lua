-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1427672)
addtoken(1427672,5168607812412684674)
addappid(1427672,0,"e24b6e17f64410ae15f2dd208ca32772efdece2b28e375c0b2d4d4bfb33f2692")
setManifestid(1427672,"2138890295048944577")