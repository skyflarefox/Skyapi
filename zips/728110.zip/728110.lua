-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(728110)
addappid(728111,0,"7ad40c5d10581461a124598082168885a04590763ea3721366b4cd92a922aa9e")
setManifestid(728111,"3064020319497590093")
addappid(973930)
addappid(1010960)