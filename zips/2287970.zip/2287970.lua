-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2287970)
addappid(2287971,0,"5c5d19f9efaf3f393662950597074efb54dd9630d704591d19e5fe5a8bbba103")
setManifestid(2287971,"275030738367907994")
addappid(2287972,0,"bcfe132956b177f0054436c34917af6971e55badd8a633a023dd63a825ae8a75")
setManifestid(2287972,"6865445779371825905")
addappid(2287973,0,"c3764840a5516a138c41c7cc9453e2835a7b71211874b1990c1d266d57459c39")
setManifestid(2287973,"6905847559837305186")