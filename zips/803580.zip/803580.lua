-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(803580)
addappid(803580,0,"cbc7c1fc41b5109b4a33824237c7ed6d53e78d6c2541ecba6db9993e9980b26d")
setManifestid(803580,"3749430238299177503")