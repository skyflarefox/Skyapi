-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2229880)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2229881,0,"dfc5c85c7364067d2212d5acc81bf086099f528afe1e117a27cc1d08392679e8")
setManifestid(2229881,"1937422335606860416")
addappid(2229882,0,"bef10d4e11921cb3fe06929ee4230398407ebb12c95cadda3c6a861ab63549ac")
setManifestid(2229882,"240611967032717951")
addappid(2229883,0,"62223571e4df5555398c6ea1e074270fc48cd5408b81a4762caf2e7d7e24b9a0")
setManifestid(2229883,"8597166659789824921")
addappid(2229884,0,"a7086d4091c08171a87e1e97c9634afa98bd66b218b7e18a7b0e87c9fd4b7a13")
setManifestid(2229884,"1522432102023798179")
addappid(2229885,0,"1cc7d508a2f9ce1cdbaa42565d5f4ac35b12587ae36eebd492edac35d590f56e")
setManifestid(2229885,"914918869490219229")