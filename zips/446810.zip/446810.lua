-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(446810)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(446811,0,"5ac945ee4fe8717b56368fbed5b9a93c45df9438447e908bf5e3eaa579fefe0a")
setManifestid(446811,"9196764387141784760")
addappid(601190,0,"5d77b3862ea33b0a5e9cc39ea36dae7ab49f766a56c533b4c3a3182d8a0b98ca")
setManifestid(601190,"2282043195278519617")