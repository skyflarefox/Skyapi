-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(215220)
addappid(215221,0,"85b4425a4bef7522c2e11da92cef44ad8ecdf97f3d878275929060ec25a620e8")
setManifestid(215221,"3892426169802505170")
addappid(215222,0,"7773fd9ae5f083c52615b641d7e2eec4a740ef0c1a379b608aa657aa699f2b43")
setManifestid(215222,"8092798337265431806")
addappid(215223,0,"a45aff7f3348abbd662d2648bc910758c15ee676cd9a92ca688120aa01a5f6a4")
setManifestid(215223,"784137634754681783")