-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1101760)
addappid(1101761,0,"0032fcd60ba0df86641d30a022d85596a5b4a111f0a3b6c7fc5199ae59a4b473")
setManifestid(1101761,"4813516701488376355")
addappid(1101762,0,"4d6cf25232f9a2c68904381de1a9cec7e3db1f7100bfe1d144528f6083bcbba1")
setManifestid(1101762,"2038854575669999980")
addappid(1101763,0,"bb1af7f4fd47fe952e7258eddb7747683af942ddcd8ad9e9847b872f7644a15c")
setManifestid(1101763,"2261270282357162858")