-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(443080)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(443082,0,"8c95a8419fddb587502de970706ff74233fcbda7371da73e75606b1ef6861e6f")
setManifestid(443082,"1465910422734556424")
addappid(443081,0,"21def7d5441e74a52de6cbb5967ce5b619315da87ab597471d262e25da353f23")
setManifestid(443081,"252867699049518182")