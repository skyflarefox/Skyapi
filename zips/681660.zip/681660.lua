-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(681660)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(681661,0,"026b0a053772482cfccbbfee93ff71db88a97cb895732376cb4268e38461867f")
setManifestid(681661,"6574716740680072875")
addappid(838460)
addappid(839150)
addappid(839650)