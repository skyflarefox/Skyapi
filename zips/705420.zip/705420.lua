-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(705420)
addtoken(705420,4051135319703883195)
addappid(705421,0,"ecd0799bbbd6e2ae601d9a24ebf97ca38749e136e4e582fc29a3f82afe70deb2")
setManifestid(705421,"550897295732229143")