-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1973610)
addtoken(1973610,13339604863168335643)
addappid(1973611,0,"2ef6377a8f99b3a885967bf81f8465589f2921c79020a39447aabfbff43f042a")
setManifestid(1973611,"3222082552105119593")
addappid(1973613,0,"79722c2970515e31dbeba5d0d8a86e8af40c6c4320fe6f0f503880fad97835d9")
setManifestid(1973613,"8952299824396628190")