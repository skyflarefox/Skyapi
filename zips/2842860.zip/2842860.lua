-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2842860)
addappid(2842861,0,"ddb6583a278b9d6e026f30f3d1f7929a82ee2d32179c4b52576741706887080c")
setManifestid(2842861,"8843316446084875296")
addappid(2842862,0,"bea0935ecca43ec225f0825fe7e6b90494f2401385355afff3195fae2953e603")
setManifestid(2842862,"2430812909240680356")