-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(857940)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(857941,0,"f4c6b9ecc44e1542a8ca82b896aafa4792591c2c7473456efaabdfb32fb0c31f")
setManifestid(857941,"62780623506977815")
addappid(857942)