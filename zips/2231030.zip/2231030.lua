-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2231030)
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(2231031,0,"9af0e7669d422cfe6ad69bc09b76f71177c2e676a48b85241d0c198be323b1a9")
addappid(2231032,0,"59852f830ce59ce63225f03c4b282677313922adaba265235b0fc2766023f6b9")