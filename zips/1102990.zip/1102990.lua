-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1102990)
addtoken(1102990,17590904141185136203)
addappid(1102991,0,"521bfaf555e5405c5a73cf4f7361a3e8f83fb336edffc9fa2204f2af81acba97")
setManifestid(1102991,"1624659254379887786")
addappid(1102992,0,"1542c11b04fc835379172c3aac98db649b17db55abedf41dc49cb908bce4700a")
setManifestid(1102992,"3728106033123613985")
addappid(1124920)