-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(332380)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(332381,0,"6e7b5e51b185e32c7f4aa99dc7b567a3adf7e7073b45d42a6c7c5754fdac7026")
setManifestid(332381,"4493628143251045366")
addappid(362950,0,"150a6123dd49c29f4c46b12cd3f96caa6b23f48c159002ea41986469d9f4476a")
setManifestid(362950,"8110161184075240845")
addappid(372280,0,"3e2669cba25860f403c445764b5ac0b140b68c966a71b9b7609a72b6acc7e31a")
setManifestid(372280,"485036585600988875")
addappid(485940)