-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(331810)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(331811,0,"9a2dabb15be3b857f2e66a1ebe8ed08f8977f938d5b391f0e81092b64f1070b9")
setManifestid(331811,"4841650749262768644")
addappid(331812)
addappid(331813)