-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2690200)
addappid(2690201,0,"bb67949991b5cf437d114dc74a148a55b3a546ad61e9f643d29f39f6709246f9")
setManifestid(2690201,"8371436847533982335")