-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(586240)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(586241,0,"05a4058569c314e5dfa7b1bb4000c4d495d1f56da23d85cf5fe8c5ebf148a3c0")
setManifestid(586241,"1433560812032019958")
addappid(586242,0,"ebf44c2d3e9fc9c65c03c5a9c2e9a094eef220e0b71690c48eef80194aa6ddbc")
setManifestid(586242,"5920520683985227734")
addappid(586243,0,"8f871c8038094fda5011afa59314755a6a63de864f19c1f834ae63098b4eaf19")
setManifestid(586243,"5107848500473883627")