-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2129160)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(2129161,0,"f1a64d60857c881fab53f59b145ebb961f0283d1decf599bd3efffe5efe8d2f3")
setManifestid(2129161,"5527754199604219632")
addappid(2129162)
addappid(2129163)
addappid(2129164)