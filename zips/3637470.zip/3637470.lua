-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3637470)
addappid(3637471,0,"263c8802f36928dec41a97d9928d32e02d03586113185704040f3b41f14d13d6")
setManifestid(3637471,"8659772693087272583")
addappid(3637472,0,"e2eb8af830733a56f38d33af3efd1a36f12b294b39f727830471099458bcfd43")
setManifestid(3637472,"7005123597752440638")