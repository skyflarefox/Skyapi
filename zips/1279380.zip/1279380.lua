-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1279380)
addappid(1279381,0,"c6788c745ef58dc8ab8cdcd744c44310b9c7ff3c44f4945fee1a8022f92e8267")
setManifestid(1279381,"64587901799124340")