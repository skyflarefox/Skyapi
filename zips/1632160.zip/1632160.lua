-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1632160)
addappid(1632161,0,"cf7924417fbb5223106093efadb4d0338e31dca57c13566824cf6371c3bfd87c")
setManifestid(1632161,"6743075962131600349")
addappid(1673930,0,"352778f0c50e0afd2bb41df0c9e1f3b4ebb9c3902218848de6946ac54a12980c")
setManifestid(1673930,"3174706464928412557")
addappid(1697480,0,"0bb2fa732a5882c0becada6cd55a32eeda4531e1f9d5e6fefc7897ca575d7b9f")
setManifestid(1697480,"6152110218182897196")