-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1610220)
addappid(1610221,0,"e97141bec1645aa289e31241959f706a3fc1e2f32d0de37bfe9ee63a150d9843")
setManifestid(1610221,"8777994516354658982")
addappid(1610222,0,"7e1326258b468e508ba95a907dbab19a82e66231aa8344aab788c432eb53ba25")
setManifestid(1610222,"4350797038943503529")
addappid(1610224,0,"e322b11d6a7562b82ece0b3128a2b02ffc930c24da7abb1c1c1297633adab1f1")
setManifestid(1610224,"9110208623926365796")
addappid(1610225,0,"8e0e02873bc9c86fc17e783cd5af840144fb88acfc3e371fa2a06f7ad8ac1b8e")
setManifestid(1610225,"5116331165543432400")
addappid(1610226,0,"09752b6730d84ab769b50b5917d7445b575553432eea6a5fba2d5a34ac452fd5")
setManifestid(1610226,"6805920401432061305")
addappid(1610227,0,"ffaafa4edab7ecfb51c14e99936edf9423ee31f98be8b2b54529e7fb34ef8e61")
setManifestid(1610227,"4708239561558374434")