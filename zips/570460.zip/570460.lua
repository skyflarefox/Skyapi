-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(570460)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(570461,0,"2811c0008214d58e6624621a3e32082da84be9cc52f3a47250d3974dae6eae22")
setManifestid(570461,"2449172043513666050")
addappid(770480)