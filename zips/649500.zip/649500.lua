-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(649500)
addappid(621304,0,"8f0178e85075bd065cca458087214ae13d03ffac442843e31cea96b1ffcd738c")
setManifestid(621304,"608831380618944875")
addappid(621301,0,"618d7c5275545e05c7ab7271ea2cff95a123a4694102fed060c5716b48c469fc")
setManifestid(621301,"6244871412279492939")
addappid(621303,0,"bb290d752454c3f23c0edbcf82180f1b68255dc9b7bc1ee8f751af96f7779496")
setManifestid(621303,"1036800391674798978")
addappid(621302,0,"61dad3074b32302bff26cb848fddf5e8f6552a03c122613260b717f5a5427aba")
setManifestid(621302,"8671744043206896199")