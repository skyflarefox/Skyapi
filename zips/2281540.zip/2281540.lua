-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2281540)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2281541,0,"9da978420320c4e0aabdbbda4dc04786ede196b4beca90f8c0d390e20a5d0d9b")
setManifestid(2281541,"1604704882703355540")
addappid(2281542)
addappid(3130250)
addappid(3130290)