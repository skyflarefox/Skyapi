-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1839930)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(1839931,0,"90e99f7e92b78e8bf291f6be1a6be1298c3a05504b89436cb4f543120987dd38")
setManifestid(1839931,"1653860733424777411")