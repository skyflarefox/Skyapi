-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(976680)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(976681,0,"5652ef05436b2a127fb45dc83ff5a698c0e0adefd3bb92b715feb3c63f91c637")
setManifestid(976681,"904969108503387655")