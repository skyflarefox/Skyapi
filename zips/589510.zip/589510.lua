-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(589510)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(589511,0,"8872a7d9a27f4aa318e79dfeb50ec4fdf2a846b40d6569662a9c4c89bd3a7b84")
setManifestid(589511,"1160291162496438391")
addappid(589513)
addappid(589514)