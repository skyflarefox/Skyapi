-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2848550)
addappid(2848551,0,"5cf9b7dc998049218bab8b87dbb8d6d00f62d1e708bd9512bb2a5daafd52e61e")
setManifestid(2848551,"2709531794836953372")