-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(227380)
addappid(227381,0,"c7ce105bc70843db66ce37e9b9f410288ad8cb54e485b37a182854a325b66e77")
setManifestid(227381,"1248395958283521394")
addappid(227382)
addappid(227383)