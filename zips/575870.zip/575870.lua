-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(575870)
addtoken(575870,4189051746740258616)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(575871,0,"ea055c0403db6828378bfc5b03bf17d79a040851b5aa964e306f271aaae79143")
setManifestid(575871,"8177359998691616402")
addappid(575872,0,"880b393761bad9b8ef3dc5d1843d3226f018dbf400de0365a4e888eba7afc9f1")
setManifestid(575872,"7168843013404709580")
addappid(575873)
addappid(575874,0,"8b1f264c569bcc6fe71d9e6047acce3557ef2c318c9f27cc7aa65458799d4ec9")
setManifestid(575874,"2935409234438011397")