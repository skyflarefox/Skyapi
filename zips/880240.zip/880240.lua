-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(880240)
addappid(880241,0,"f27d84af96cc42207e7460a343df9edf7b35c8ca405aab8872b29238b15e1d9c")
setManifestid(880241,"576523056145152371")
addappid(880242,0,"e1f65776de7bba903d8c6b679700ed64a7357479124162a0cf0225c0cf244673")
setManifestid(880242,"2677308401959018160")
addappid(880243,0,"a25b8d270ee111b2fa89cc6f585181dc5cda227c256c25c2a126f1d999c70239")
setManifestid(880243,"7607300007470496408")