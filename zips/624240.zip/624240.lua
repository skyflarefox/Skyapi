-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(624240)
addtoken(624240,9838035707299046481)
addappid(624241,0,"110dc63bda1480d423f13de095e8b615340a6c5d2e2f13b6d7b54388051227a5")
setManifestid(624241,"4851635656322144986")
addappid(624242,0,"a5afb54cda6a7634888bc6294e615109c4a94a06fda665567e705dd9e73a136b")
setManifestid(624242,"5517394431474036484")
addappid(624243,0,"a1d78d856cb35382da04f1cf33e968aa54730ea55b94657b530832391e805c81")
setManifestid(624243,"1807851727640239278")
addappid(624244,0,"4b64ae19d9ea5f9f75b833043cd3de8762f64af2e42fe562d88fa9da6d874eb3")
setManifestid(624244,"4803891676454563367")