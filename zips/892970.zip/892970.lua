-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(892970)
addappid(892971,0,"fb041c748eb3303b0bb18fbad3b813d19052060d14953e0d7d735943075833fd")
setManifestid(892971,"5647879931912746897")
addappid(892972,0,"10d286383a9248b6de0c8a160231b4d6332bce1da1fce424d4156329dda3ecf6")
setManifestid(892972,"3554916302746035764")
addappid(892973,0,"6c4d88d54997dcc4234f7ed792e946c0386a6c9a4f242a2bc8c89b49d50f3975")
setManifestid(892973,"7948263597522671446")