-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2051120)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2051121,0,"a3a1a2c67616cb63b8fe7830719af6ce7ff2ee70aeb15f6723f08c2a71d64d9e")
setManifestid(2051121,"8562777406195562958")