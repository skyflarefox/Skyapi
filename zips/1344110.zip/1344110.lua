-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1344110)
addappid(1344111,0,"9c17ab50d9735967f436ffe55992ccb850f6a465b9e07bf333ec15396c4bd15b")
setManifestid(1344111,"1352178462803716012")
addappid(1344112,0,"f9cf3a086e7a77b624e264f2f043eaf387f7f95b2f645ff310f196562e33557e")
setManifestid(1344112,"8532992118056580547")