-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2222870)
addappid(2222871,0,"e179edecaf6131e23ad0ef21f07d72a63bbd573cda6c25c64de45a278e5b7490")
setManifestid(2222871,"8942717776557408256")
addappid(2222872)