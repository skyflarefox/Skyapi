-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3097570)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3097571,0,"900852e193c445cd5c008eec7041abac89773dca0be86b746b83cdc1c2b5b98e")
setManifestid(3097571,"1427595725525068347")