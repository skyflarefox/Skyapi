-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1355140)
addappid(1355141,0,"8fadf91a0fb71d9c24b5cf4b8e723cc8210359e3513e824de4f35ebf6679e255")
setManifestid(1355141,"5656641436595544773")