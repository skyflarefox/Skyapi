-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3226500)
addappid(3226501,0,"68d2e432ef3d9ad69b19e670b9398d1effed15d09864c7b34e8829401072c8a1")
setManifestid(3226501,"6595766938864395320")