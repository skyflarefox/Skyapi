-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3306910)
addappid(3306911,0,"d189724b5ce9e1b7304158d9c619f0703774321fcd185988e2992a94982ada42")
setManifestid(3306911,"8332993920550717209")