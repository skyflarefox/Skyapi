-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(545040)
addappid(545041,0,"4dde7a91c0187c1676c399c1747b601ebf96006d5fff94482045e41819688a92")
setManifestid(545041,"502507429271609209")
addappid(545042,0,"1ce2661b91cbb8ec32833056ed6f146cd713c7cb851040db8f6f749aa01add9d")
setManifestid(545042,"6302899557684477359")