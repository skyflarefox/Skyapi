-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1372810)
addappid(1372811,0,"df6596100d8c79e5b47567902f61ab4351ac02aefa8fdccc6382ce0b44684423")
setManifestid(1372811,"2027851026347150373")
addappid(1372813,0,"8d10044d66eae146f1f587e09fd3969e350626d48c277a2f01cc44e6f5a460da")
setManifestid(1372813,"9027546050920686557")