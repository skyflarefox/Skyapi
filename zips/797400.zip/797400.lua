-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(797400)
addappid(797401,0,"8ceaa95b6b38e4c1e7bbd01fdaacd757e44d43b25f66af6f828ff510b2d6532b")
setManifestid(797401,"918399405092270728")
addappid(1192650,0,"b13819d702599c3b1ae4c59c4c2e13e36502f20436e352e24713e17043ce3cec")
setManifestid(1192650,"8223492557650072699")