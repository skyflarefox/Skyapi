-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1851280)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1851281,0,"dfdd2deac37ee7550afe483f6f82d959ef1e1e848742005b550a8255f4c3b510")
setManifestid(1851281,"9066886363091788447")