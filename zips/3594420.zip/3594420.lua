-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3594420)
addappid(3594421,0,"2d4945cfc45e9a87f2b95b5415d0dbcafca57d7cfc96c83e9c22dedfc1159e44")
setManifestid(3594421,"4271435556953725842")
addappid(3594422,0,"32babec84669f8415aef06baadfd7362bb58ad6f674588bd0a157f1f729e8775")
setManifestid(3594422,"8033335571404251054")