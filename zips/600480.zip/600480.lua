-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(600480)
addappid(600481,0,"cfec171ac99a86936c242a0fa19e37eace19a84cd5d2adff51dfed55d536c887")
setManifestid(600481,"6332609995632173844")
addappid(600482,0,"de6cd192497b107abc961735ad795d6ab801be336d49fbd8e850be38f3a37a68")
setManifestid(600482,"6850385675377483384")
addappid(600483,0,"2c10070b28746d958ef7f141176814d8e9724c158aab74bc23993894cfbdba2f")
setManifestid(600483,"3985718066241916266")
addappid(1315300,0,"c7101cdd4aa87fcffedfc82154c10b373197ce77ea253a1ede12aa95868afc1c")
setManifestid(1315300,"2419522766414517311")
addappid(1315301,0,"cde5c9af5cfc8204eeff3d0ba6f31d90ff0de5eab8420b017e9eea4f6ad287c3")
setManifestid(1315301,"6063619650681956326")
addappid(1339440,0,"5e2ed81c6f44576b240163391010fe5c238a7df570c264ce1ac6f010d58516a3")
setManifestid(1339440,"6069528085749270868")
addappid(1339441,0,"7b37506ab5cb37aa33b6acfa3692464608e692d8d4b4c16f62b6b2999dd842aa")
setManifestid(1339441,"345673800770966237")
addappid(2574770,0,"fd3ff0ea5de3d0bcddc083fd79c4c1868155712529c44cbc4a5908e297fc7ee9")
setManifestid(2574770,"2713715709974073370")
addappid(2574771)