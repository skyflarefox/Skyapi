-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2298590)
addappid(2298591,0,"e044b81a681cef3450961c1e7f3f715b7634b33b75b0894b08db6f8bd2976a61")
setManifestid(2298591,"7205593779244289961")