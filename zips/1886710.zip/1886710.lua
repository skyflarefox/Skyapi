-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1886710)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(1886711,0,"ccc4d71f3258634d98b3a0eba1b3360dfc21db37e753d36bb782ce50f0df3c05")
addappid(1991021,0,"db0f258cc17c498fe5b7fa60ac04d4c33c41638d01528802abb352e07e63e298")
setManifestid(1991021,"2550449853182125880")