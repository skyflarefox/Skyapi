-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(606480)
addappid(606481)
addappid(606482,0,"624d1587ab0fdc37274df3e54761c3d76ed828cb7e39ef4047e5d57c3e0afbdb")
setManifestid(606482,"7565551654430815051")
addappid(647400,0,"d3ac1a9dc13da25720b82591a300d6657b0db1315b9e1c422d2e9a2fadc44858")
setManifestid(647400,"4473157683911254749")