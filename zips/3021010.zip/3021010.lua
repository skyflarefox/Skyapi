-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3021010)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(3021011,0,"20545db64e3a034931e0fb2fae54bb5e2a52f29c9e6b94fd81133441debf75ad")