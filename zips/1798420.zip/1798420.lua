-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1798420)
addtoken(1798420,203285860905708894)
addappid(1798421,0,"b5bd8c351b5000c16773e43920bf9fbe416ce971cf30d09fb3f1be22485cdff4")
setManifestid(1798421,"2162095217613486075")