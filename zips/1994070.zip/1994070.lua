-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1994070)
addappid(1994071,0,"a6e0ac76c46d00deee652142e7760e17ab069de8d9b7d0f4b3992e6e0a03be57")
setManifestid(1994071,"1014289742908129465")
addappid(1994072,0,"e362f83e9fe255ebfbad70c2bf454f52dc7db41330a560009fe13b004182432f")
setManifestid(1994072,"1192682069549974411")
addappid(1994073,0,"bd2f06fafae1bc1fb3943b15f614c5a0700ab7e6abf081d344e3295e2e48342b")
setManifestid(1994073,"345090162076573166")