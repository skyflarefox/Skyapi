-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(369580)
addappid(369581,0,"5cd393482a240f847ac703fb3501befbc8cd5a99e20d5c97de749d00b8b39841")
setManifestid(369581,"7506665018178050017")
addappid(369582,0,"782384f244795aab91d87fda9c4b4e3188998378db1364c4dc21bc71668e1645")
setManifestid(369582,"1782052217449089329")
addappid(369583,0,"d1879f2fccff9e79039fde2d3fa326570e35e6f8f88be1c199b108d00a208617")
setManifestid(369583,"541798782387023683")
addappid(369584,0,"2450e4f37ec7833b035342ea75db1c4fa3a0c839b4b96463ca87c6f9bc47c674")
setManifestid(369584,"4259258926171556240")
addappid(385520)