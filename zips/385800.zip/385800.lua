-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(385800)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(385801,0,"5dd3b7827073de8f0ae56600bfc3c5bd21048b189bb2b7187df8f9e43d0f3d2e")
setManifestid(385801,"8640820770296307102")
addappid(1088330,0,"03026fc24573c714164577f75b1804481a04d8966f927be759f494d06141a8cc")
setManifestid(1088330,"5187404821721321190")