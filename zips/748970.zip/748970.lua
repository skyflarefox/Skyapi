-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(748970)
addappid(748971,0,"a835bfab1b3fdcb246fd30d4be9b8d05038324d4f9e573301a23af0587cc0dec")
setManifestid(748971,"5004854258845167778")
addappid(748972)