-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1614610)
addappid(1614611,0,"b9066e040fb19f1c66e8452f590176d21dac493fc0894e9a9ee7bf54913734f6")
setManifestid(1614611,"5546940022276058926")