-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2922040)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(2922041,0,"9293e3bc4bf2d11306667d6ffbe8bafa53d3b84569e013f5d090635973bdcde1")