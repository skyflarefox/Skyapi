-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1511180)
addtoken(1511180,11722284147853966053)
addappid(1511181,0,"78ffa3622fe25634ec02bb117b639f00f9be3e25a6c318afdaef88f54f1d8a87")
setManifestid(1511181,"64739632424966537")
addappid(1511182,0,"8bb321335cda99d1ace1866647a8ca9138e6537dae8ae657c161fc5b850ef147")
setManifestid(1511182,"6787287460883617561")