-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(735450)
addtoken(735450,11712792108312570579)
addappid(735451,0,"022378e07950eef35796b7865c3e4853297c40f9e86e15d86e19fdc04fe5eafb")
setManifestid(735451,"7857519370153468391")
addappid(735452,0,"a7d4c3c7fd19e1fa1c2f758a559296536f98f28cd29b8c5bc936096ec925cbb8")
setManifestid(735452,"574730925530257406")
addappid(735453,0,"4fc30169bd73121f2f430926548653dceb126a3cc2b8e6c1f81a1ca165448e45")
setManifestid(735453,"5816920377286829511")