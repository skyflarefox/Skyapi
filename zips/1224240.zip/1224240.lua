-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1224240)
addappid(1224241,0,"56517f782867db81ee07e144284edf02a83a9d4fa7e4c20ef05784dcc4fa5588")
setManifestid(1224241,"7556882035439429844")
addappid(1224242,0,"88a4b016b30efaa19c00b4036ac15a5b5748d47075d24a4afb254781ffcd40b9")
setManifestid(1224242,"1015130676517825067")