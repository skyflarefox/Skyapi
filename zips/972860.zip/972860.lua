-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(972860)
addappid(972860,0,"c580540adf1c5543b1c4391064c9df25687c8af499fb16ff9f92a1ee65660549")
setManifestid(972860,"3639094187959701576")