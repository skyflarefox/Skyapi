-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1266820)
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(1266821,0,"abf03c7018f0696ef305209934d49616203bf478375ff67cd63d82bd7f01c49d")
setManifestid(1266821,"693088027430637367")
addappid(1266822,0,"11393a87c330e22732f3a2e6c882acf68070db08025b62a40ea2fd8a9c765698")
setManifestid(1266822,"2836910218831262952")
addappid(1266823,0,"22d40991627b298d4228ada29a414cb02f864f606b467ea8fcd92974941ea092")
setManifestid(1266823,"2415024116189963336")