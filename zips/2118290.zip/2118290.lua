-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2118290)
addtoken(2118290,16611399629038374675)
addappid(2118291,0,"6e78c298e4a91dbb2df7fff9b533e2e00a5085bfa76e14095e1b8b28a8a5fde1")
setManifestid(2118291,"3492828558839434281")