-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(782180)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(782181,0,"50c55e6f2687b00278c8565765b8e4d9c30bd67f1c2669cbf885ae402fe9eda8")
setManifestid(782181,"3178945485299063139")
addappid(782182)
addappid(782183,0,"01c85dfdae528d4472311a1ca7bc7dbbed6471afff37897a43f58dcdfd8ae89e")
setManifestid(782183,"7251724271058922876")
addappid(782184)