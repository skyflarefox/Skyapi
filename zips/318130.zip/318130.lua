-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(318130)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(318131,0,"0ff6fbe8dd768d0ec0a555b41f6d0016bddb9b954c18143ef0a65cfa5831d736")
setManifestid(318131,"1157740199520421268")
addappid(318132,0,"7239efe62b39906339340680264b4906a09f962fae431752e74c719bfbe5d22f")
setManifestid(318132,"1862963911478811669")
addappid(318133,0,"8fe734517bef11c2fbfa8871193bef8cba872f05e15cc8582f9f8d2cb609943b")
setManifestid(318133,"6315591912415547905")