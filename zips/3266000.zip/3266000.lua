-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3266000)
addappid(3266001,0,"56800feca8e610e9f7f5f614786c10b477883c107f6b5319e714b71d27614710")
setManifestid(3266001,"7276102302225639961")