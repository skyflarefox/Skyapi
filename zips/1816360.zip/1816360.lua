-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1816360)
addappid(1816361,0,"4abb914a0704a882974fde6047b26a978e63a74a17cd0ffad61a7f57436ea38e")
setManifestid(1816361,"2735139370751677576")