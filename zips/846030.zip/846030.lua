-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(846030)
addappid(846031,0,"095ebd18370da2b2974902cfd88ddb05ebc4e930027d37328ebccce55ad1438b")
setManifestid(846031,"8734202624038852198")
addappid(846032,0,"03baf57252daf9dcb6fbace78b8dd15d37038fc3a783da62e92feb1725aa6047")
setManifestid(846032,"2545226615834059138")
addappid(846034,0,"ac7d97e1b252f73e2f53ab6f0cfe0aea40c898f31e505c648157077c86b07bda")
setManifestid(846034,"7580461832812801468")
addappid(846033)