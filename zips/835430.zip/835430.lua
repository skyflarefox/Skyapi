-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(835430)
addappid(835431,0,"125afe137ac010a2771e77e32474a163e6199440eb1dc07c5da6abb5ef798490")
setManifestid(835431,"2148099167347291519")
addappid(835432,0,"d6863d07390d03db7737df30ff46dbc6cea73f2e843559d80ee1d712cbbaffa0")
setManifestid(835432,"8982451473215827810")
addappid(1281910)
addappid(1279290)
addappid(1279291)
addappid(1591620,0,"b2baaefb9a2fd6e154445f4424c0109c6c3404869de3ce46c71844fbfb30fe35")
setManifestid(1591620,"225686493813117955")
addappid(1591621,0,"69c31aaf6adf1a7acde1d34f274206ddc533888e8ff3af203309162f6d8e313c")
setManifestid(1591621,"1159130807584567577")