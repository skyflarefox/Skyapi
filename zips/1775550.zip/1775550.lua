-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1775550)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(1775551,0,"5dca212ba73b5ab6560a7d29ab07675840aa54b7a45c4279442a07f80e6af358")
setManifestid(1775551,"8912110080787098267")
addappid(1775552,0,"2c021b7f66f2af238fc9f2e632555fe77fb057662f5fb463423e6b68791f1072")
setManifestid(1775552,"4021855980218400396")
addappid(1975590,0,"2963d8f3bdd942f4f89feaed945932876f3ae0a41812dfd0d398a1291de43a0f")
setManifestid(1975590,"7931476022311798105")