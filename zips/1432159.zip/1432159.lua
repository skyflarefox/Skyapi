-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1432159)
addappid(1432159,0,"64068a58c39057d3cfb6f5fed85ec29e3a46f6bc8b46db1a7b8888ae639d3c90")
setManifestid(1432159,"665996355738287623")