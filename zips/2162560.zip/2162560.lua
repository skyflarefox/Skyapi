-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2162560)
addappid(2162561,0,"b4b751db38e266de87267e7f4d3a71d3ce78dcbe6e8ee30c72d7fb416479135c")
setManifestid(2162561,"4367317902904568590")