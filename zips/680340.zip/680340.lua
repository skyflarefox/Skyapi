-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(680340)
addappid(680341,0,"8a2b6c29e5a21ee69c6536db9d55b3d83f1caa0a3a8ce6c88413334377173920")
setManifestid(680341,"5052750534136711265")
addappid(680342)