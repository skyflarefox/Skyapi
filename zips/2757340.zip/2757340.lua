-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2757340)
addtoken(2757340,14321832739132448828)
addappid(2757341,0,"a1b7ff3b607b1a46ced4333d88a31500cef3c6ff65b6f292105318254b46ba0c")
setManifestid(2757341,"33193709545096335")