-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1225660)
addappid(1225661,0,"bbf7ff1cc084c7cd5f4fc99577efb4c02635ceb8dbb4da6cb8f0f9da0822fe61")
setManifestid(1225661,"2056881151399385772")
addappid(1225662,0,"c8e7b5310d69f0651d6ff74330c08fc5d35ddd9450ebf5bea99ec959c9277e1f")
setManifestid(1225662,"5761003753885368666")
addappid(1225663,0,"240ec58a9e2af4227a4a6048f01ebbb0f4c4c6968d1347bd5ffe30b724121c67")
setManifestid(1225663,"8821874163380848962")
addappid(1650940,0,"e646045b1a139aeaf656c266efaec47a9a51880c9618cbb4c22a505e5b2e95f4")
setManifestid(1650940,"7886761709820475814")