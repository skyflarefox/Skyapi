-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(612850)
addappid(612851,0,"b9e937c7f9c84efa657656d1a3038e0a39f88cf45d6b245e0fbdadba1914e55c")
setManifestid(612851,"2355446580630456826")