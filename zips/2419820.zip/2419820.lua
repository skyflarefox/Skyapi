-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2419820)
addappid(2419821,0,"96fb5a95f359b9c4bc0c7a5fa42257222b9cce06feb3e5673e1e425efea8e9b9")
setManifestid(2419821,"5969446387603705284")