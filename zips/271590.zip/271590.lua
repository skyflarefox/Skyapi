-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(271590)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(271591,0,"baebeedec48b33c68a322fea0cbaa8d023d1dab4d2870aa909b82c33caa53941")
setManifestid(271591,"3078536858461817817")
addappid(271592,0,"e34313f0ec133a608e636cf04fd879d3ac1e8e10af38542436940be1b6834bee")
setManifestid(271592,"2329791907092268889")
addappid(271593,0,"71b57be5c50e5fbc819068a5bf31db42b653f1c75d88307da682ff0d5cae9457")
setManifestid(271593,"4296904213986058493")
addappid(271594,0,"ae7ed6931a136d41d3aae146563368eb3b3e4e60963344f3f426c0abc74bbdab")
setManifestid(271594,"6991706980502578342")
addappid(271595,0,"6dc0d2ce6b9dc96469ff792f6a607f759f0abd851d496cac73d71cd145c70b4d")
setManifestid(271595,"8334800630270461944")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
setManifestid(1899671,"4177720964978853031")