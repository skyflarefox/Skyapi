-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2502260)
addappid(2502261,0,"8e730b3155bdffa43eb6216bf37c63452595f22337f9f6ed912de9659cd9e156")
setManifestid(2502261,"5656702432843011231")
addappid(2502262,0,"6c0bc30e0f03d5da08398e4c9ade8db945e6e27e29fe9504a4f36c78a7e62151")
setManifestid(2502262,"7745291905639148961")