-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2319030)
addtoken(2319030,12906838892456633662)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2319031,0,"b1f7187090f08c793f4bd4e8c5a0a9676940f6c1facd511d5bc0e56f1fbe56ab")
setManifestid(2319031,"5742852475714267111")