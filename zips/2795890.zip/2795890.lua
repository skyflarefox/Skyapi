-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2795890)
addappid(2795891,0,"e5cdedb94cf9932a87b101163c03f8269b3607a6bbce74d72ad363cc7ce4e39a")
setManifestid(2795891,"2053940381072904272")