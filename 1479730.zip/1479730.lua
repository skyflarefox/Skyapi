-- Lua provided by SkyAPI 
-- Game: Commandos: Origins
addappid(1479730)
addappid(1479731, 1, "64205c91ebfac38afeb2011798b9270dc5d1eec20ef0d4b176a42fbf5570de84")
addappid(3565060, 0, "25969d0cfdf09a97590616156414c9996ebf94afe209ed4cb0eb957fa79a2c77")
