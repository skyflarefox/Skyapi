-- Lua provided by SkyAPI 
-- Game: Mini Taoism
addappid(2339220)
addappid(2339221, 1, "dc1b2c807e96619583366e44922de7dafb66e3a1e3bf86075fb215c394602162")
