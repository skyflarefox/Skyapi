-- Lua provided by SkyAPI 
-- Game: Call of Coronga
addappid(1307240)
addappid(1307241, 1, "e13ca4f5a679989a6d5d47837b6d13bf6e02fd377ff51b92725c8532db2fff6a")
