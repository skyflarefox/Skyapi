-- Lua provided by SkyAPI 
-- Game: AppID 2273150
addappid(2273150)
addappid(2273151, 1, "f4c7208e50f8da12af63231630396fecdfc5d506fa1bffb058e940e34a8e11b2")
