-- Lua provided by SkyAPI 
-- Game: Death's Door
addappid(894020)
addappid(894021, 1, "b153bef871903a4a0b114c4d530d47cc383f61d5933f78eafde707570cf42cfb")
addappid(1662730, 0, "274448960b2ae4dc02097e5075006d13ba7ce6428bce355c8b3c267fbbc0f300")
