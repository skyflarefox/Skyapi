-- Lua provided by SkyAPI 
-- Game: Summonsters
addappid(2827780)
addappid(2827781, 1, "7a37ac237bd89b04f7bfc18b2d74eb2b5e8e94323c2db675e94de5ef6c5c7895")
