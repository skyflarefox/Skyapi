-- Lua provided by SkyAPI 
-- Game: God Souls
addappid(1952440)
addappid(1952441, 1, "9b7868e81d656bdaf46ae7bad07e8f4286795bd11b39a02089c65d06aa22ba1e")
