-- Lua provided by SkyAPI 
-- Game: Gamer Girls (18+)
addappid(1565220)
addappid(1565221, 1, "1c861fc470355a7dc276f57dc36f1882aaee766729f91c82012593955c9269c3")
addappid(1588930, 0, "6aadd4a3cefb3663ac3772dff61d415294f5ff09f5a44128b0542a3181bd71f4")
