-- Lua provided by SkyAPI 
-- Game: Metal Gunner
addappid(1257250)
addappid(1257251, 1, "52bdfe58feb29cb86bd0071c797ef1f7277973fa8fbaa89108a31a05be74f19c")
