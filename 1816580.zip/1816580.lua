-- Lua provided by SkyAPI 
-- Game: Happy’s Humble Burger Farm: Rock the Warehouse (OST)
addappid(1816580)
addappid(1816581, 1, "0c143949a26cac9435028499589d1452e4c7644b30eb9f368284434e8a07e789")
