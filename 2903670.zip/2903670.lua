-- Lua provided by SkyAPI 
-- Game: GreenColdBody
addappid(2903670)
addappid(2903671, 1, "79ddb350e6d3f659203e9c70308dddce8b6adb7471dd3e7cd474e869555410ed")
