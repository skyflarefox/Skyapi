-- Lua provided by SkyAPI 
-- Game: boom faster
addappid(1563110)
addappid(1563111, 1, "da41e143a99474d192fa64f37085d115446bdab7a96a597209a25a4eabdff6ba")
