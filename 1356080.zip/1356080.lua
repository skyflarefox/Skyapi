-- Lua provided by SkyAPI 
-- Game: Hot-air VR Balloon trip over Russian Primorye
addappid(1356080)
addappid(1356081, 1, "a57f5bd76a359e69d1c5fabc527a1888358216c3f4412ad7dee52d27fabb5d11")
