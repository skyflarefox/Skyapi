-- Lua provided by SkyAPI 
-- Game: AppID 1355020
addappid(1355020)
addappid(1355021, 1, "27e21677d2b88915cb5fe12b7325ba1b6f022232cccdf9b3e949fad17029f415")
