-- Lua provided by SkyAPI 
-- Game: AppID 678890
addappid(678890)
addappid(678891, 1, "c89473d6af0d439287f7dfdb19e468b3835ddb3d8789224326641f7c6f052ed9")
