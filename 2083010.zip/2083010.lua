-- Lua provided by SkyAPI 
-- Game: Another World Quest
addappid(2083010)
addappid(2083011, 1, "fc93308a5e576cf5cad4bbdd315069504dfdaffa9282ac990a4b65d0828dac6e")
