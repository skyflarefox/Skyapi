-- Lua provided by SkyAPI 
-- Game: AppID 730220
addappid(730220)
addappid(730221, 1, "4d0096f19d9211161410d80b363fffec6437dd99b85f197e8e4ae0e970d028a6")
