-- Lua provided by SkyAPI 
-- Game: THE KING OF FIGHTERS '98 ULTIMATE MATCH FINAL EDITION
addappid(222420)
addappid(222421, 1, "05b790cfcf6ad87f7dd75e8efe61e3536174d02102780457187cc0c86ebf349a")
addappid(228982)
addappid(228990)
