-- Lua provided by SkyAPI 
-- Game: Lizard Slayer
addappid(2984230)
addappid(2984231, 1, "8e065451c1296e7e4f4ec0eb2f545b3633222b5261992603da8caa777ed92a28")
