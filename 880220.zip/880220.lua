-- Lua provided by SkyAPI 
-- Game: AppID 880220
addappid(880220)
addappid(880221, 1, "8d6d85f2bfd21f9bf9f4d58c6ec6fcd12191ad28d85fad8b5b64e100b6d3a999")
addappid(1325320, 0, "7371d0b8e9c7f527c60a299543e725be3e1fe54c3d4ffbaf33101d23591a981f")
