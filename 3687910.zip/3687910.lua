-- Lua provided by SkyAPI 
-- Game: In The Dark
addappid(3687910)
addappid(3687911, 1, "6cec68366524a4b30541b777115e1693689b09450b8eab494b3570d6b982375c")
