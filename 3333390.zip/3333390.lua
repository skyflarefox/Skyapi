-- Lua provided by SkyAPI 
-- Game: Roman Triumph: Survival City Builder Demo
addappid(3333390)
addappid(3333391, 1, "7ffb8556fd36e19bd83452668abb6df4a149a3fb15d85d3abf9d5440131ad521")
