-- Lua provided by SkyAPI 
-- Game: AppID 3045490
addappid(3045490)
addappid(3045491, 1, "958e4396704a99f6327fe628be323f3708b435ed0385d50b1be08c551492af50")
