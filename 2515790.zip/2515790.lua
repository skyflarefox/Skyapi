-- Lua provided by SkyAPI 
-- Game: G-Scramble
addappid(2515790)
addappid(2515791, 1, "0adb98d9068e757fa4e6c6386b5d60e0afb786be547a1336ca3d98995b521ec2")
