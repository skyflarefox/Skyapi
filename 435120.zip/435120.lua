-- Lua provided by SkyAPI 
-- Game: Rusty Lake Hotel
addappid(435120)
addappid(435121, 1, "32464ab82ee76a0861e7eeb437fa956f54751de335ae08b11a5ae2775a271d94")
addappid(435122, 1, "7ee769284f087a75c5effcd66c2793ef75b662a0cb2096f52a7eda890f9e9fa6")
