-- Lua provided by SkyAPI 
-- Game: AppID 1127610
addappid(1127610)
addappid(1127611, 1, "cf327b43d6b9d3c6d298a239e16463d41ee789e93192b8197dc36d59d4eb394a")
addappid(1254340, 0, "8f4bf6b05e02854f2e5b8f62a5cf91cd87e8a9f80d65244f51b8a8165e244dfd")
