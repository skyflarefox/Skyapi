-- Lua provided by SkyAPI 
-- Game: AppID 849090
addappid(849090)
addappid(849091, 1, "93f375f6a38a75faeb94acaa57caa7f90156e1333bd187f22bb153c7a2d6c4af")
