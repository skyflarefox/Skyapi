-- Lua provided by SkyAPI 
-- Game: Witch Ring Meister
addappid(1053160)
addappid(1053161, 1, "fa5f6fb72fb33621353d2b14648e33145684a68879e6a57e282e3d88adc0aea8")
addappid(1053162, 1, "d3aad15e845b6ec8396c255ba0077c3dfb5af6286de6b059a240fbb08bb398db")
addappid(1071430, 0, "a76de0c292f5cd71eaf45e53823651bdc25f522906c4dbda5e81bb790c3e5edd")
