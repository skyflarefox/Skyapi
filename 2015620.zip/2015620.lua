-- Lua provided by SkyAPI 
-- Game: Valkyrie of Phantasm
addappid(2015620)
addappid(2015621, 1, "363db614b65bb18d5e63b3fd853c1d2f7e139d4824d77ffd2142a57489e25781")
