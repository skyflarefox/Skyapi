-- Lua provided by SkyAPI 
-- Game: AppID 1823380
addappid(1823380)
addappid(1823381, 1, "034582980d4b8508f9a047133c88dd55282b85ba24ba99d8260121684a976a4c")
addappid(1868990)
