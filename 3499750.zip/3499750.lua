-- Lua provided by SkyAPI 
-- Game: Gassal Simulator
addappid(3499750)
addappid(3499751, 1, "408a4ad0951d7e95b8248681afb2c27e10911ccfcbe1cf2dfc07783f779dd765")
