-- Lua provided by SkyAPI 
-- Game: nothing & nowhere
addappid(1166730)
addappid(1166731, 1, "e25594dfc3a3b3532c6369aa5ac8e8c36e25abb4a343a2e09323cbaaa1e0239f")
