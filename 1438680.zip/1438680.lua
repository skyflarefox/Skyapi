-- Lua provided by SkyAPI 
-- Game: Techno Tower Defense
addappid(1438680)
addappid(1438681, 1, "9d611a3e996bf9fc14778c77bf0440518965a6829f800d766b0d20169d556998")
