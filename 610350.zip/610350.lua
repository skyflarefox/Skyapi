-- Lua provided by SkyAPI 
-- Game: AppID 610350
addappid(610350)
addappid(610351, 1, "20f7b57994b19fd77f748cffde9b5fabd910cf1629f88803e40ededcec5e0fdb")
