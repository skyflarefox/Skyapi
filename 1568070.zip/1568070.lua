-- Lua provided by SkyAPI 
-- Game: Burning Ball
addappid(1568070)
addappid(1568071, 1, "14b68e3fafb0aacc00d0d07eed9100aff2496dead30f735cee3a1ed25b37b2ab")
