-- Lua provided by SkyAPI 
-- Game: The Enjenir Demo
addappid(2084640)
addappid(2084641, 1, "923575e41391c99c8793ab08b4502f236f0ad2dc5d267e9d0326b0c2385a3618")
