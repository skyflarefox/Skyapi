-- Lua provided by SkyAPI 
-- Game: Strayed Lights
addappid(2162020)
addappid(2162021, 1, "c921eac6de027e25c420e2c68ede47fa16bf9d518bc5374551d7fc5b8ad9317d")
