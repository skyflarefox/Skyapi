-- Lua provided by SkyAPI 
-- Game: AppID 2791290
addappid(2791290)
addappid(2791291, 1, "b09312f0fd99d5b394c59a290e6504938c15ec726d355b95c28ce3e0b430fe22")
