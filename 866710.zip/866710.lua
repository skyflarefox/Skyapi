-- Lua provided by SkyAPI 
-- Game: AppID 866710
addappid(866710)
addappid(866711, 1, "2240c4c23b60ddf01743c041f64f9d260beacca89ba9431e539d287197056ff1")
