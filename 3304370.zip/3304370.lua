-- Lua provided by SkyAPI 
-- Game: Onslaught
addappid(3304370)
addappid(3304371, 1, "c58b5679d6d9ea7b11cfddbd81ab4d4a8e7ce70429d57f0e1a9f25d88349ed14")
