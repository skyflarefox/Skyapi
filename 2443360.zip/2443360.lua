-- Lua provided by SkyAPI 
-- Game: Zortch
addappid(2443360)
addappid(2443361, 1, "1d09f6d8665f0877db0f069f2017db184b924fc3e3a3925fef35dc3102906a21")
