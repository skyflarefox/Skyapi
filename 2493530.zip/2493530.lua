-- Lua provided by SkyAPI 
-- Game: AppID 2493530
addappid(2493530)
addappid(2493531, 1, "a525987fe04216491abadfd102fd1e1e2cc81dac57da11447df00058018b7aba")
