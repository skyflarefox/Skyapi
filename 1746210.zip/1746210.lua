-- Lua provided by SkyAPI 
-- Game: 日记簿
addappid(1746210)
addappid(1746211, 1, "1ae7561ddd23fc3637810940e18c9679fcf68bdc23ae1f7143168ad99551caa3")
