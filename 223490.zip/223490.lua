-- Lua provided by SkyAPI 
-- Game: Blockscape
addappid(223490)
addappid(223491, 1, "2146b765ea8b58887265c132a9f134e467669c2c958e02e40f13c331709580fb")
