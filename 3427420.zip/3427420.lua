-- Lua provided by SkyAPI 
-- Game: BDSM Clicker
addappid(3427420)
addappid(3427421, 1, "dea7d49312dd6c9655dde564f6c4cc02b6384e3acf15a2af8d1d05737bb80e3c")
