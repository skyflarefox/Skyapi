-- Lua provided by SkyAPI 
-- Game: AppID 949970
addappid(949970)
addappid(949971, 1, "789072c961fb1af15396f5b04538148fde393891adf76513bdc0fc6c5a117ca0")
