-- Lua provided by SkyAPI 
-- Game: AppID 618260
addappid(618260)
addappid(618261, 1, "05532eb9eaa45282a485697b6494710ab313a9d42f5fac7e28cdda81b9296941")
