-- Lua provided by SkyAPI 
-- Game: Sinister Entity
addappid(2164870)
addappid(2164871, 1, "ab135a5efa4bba3aba6143e287b5efbe4d778a1412da234078e9bdff495c68cd")
