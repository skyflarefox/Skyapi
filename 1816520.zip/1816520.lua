-- Lua provided by SkyAPI 
-- Game: AppID 1816520
addappid(1816520)
addappid(1816521, 1, "4b9d40e1f909559c1fc429d6418d36956c09ffdddec24b8b81f961cf6143f258")
