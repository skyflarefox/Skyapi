-- Lua provided by SkyAPI 
-- Game: Dinky Guardians
addappid(2349040)
addappid(2349041, 1, "d1a16751d2bab01f018d5e1bb272ddb75c738c71fc95476e7e0cb34aece690e6")
