-- Lua provided by SkyAPI 
-- Game: Noir Punk
addappid(1638860)
addappid(1638861, 1, "baaac787b133f8d9bca9ecd00e1828b3e0c24c6cf067020087d12e3e4bf26bfb")
