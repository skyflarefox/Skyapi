-- Lua provided by SkyAPI 
-- Game: Tactical Warfare
addappid(2599770)
addappid(2599771, 1, "d82fa44d507ef702920ae0fe0a7d8f15c82ce01563f67d2c2b7bd804d993c9d7")
