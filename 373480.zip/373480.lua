-- Lua provided by SkyAPI 
-- Game: AppID 373480
addappid(373480)
addappid(373481, 1, "8c60d67cd8e61fa3ed479ea316ddd2664192b57cd6fa08d7aebc02f4d1852e54")
addappid(373482, 1, "4752ff55c15235c289b72d49d28c869f1260fffaef26c3e53f0846ec03d1bdf1")
addappid(373483, 1, "a143e4226fd5ea48b5a16f1f26f2492b3d277ca609903f118bf86fdfeee21923")
