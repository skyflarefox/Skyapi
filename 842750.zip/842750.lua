-- Lua provided by SkyAPI 
-- Game: Galaxy Champions TV
addappid(842750)
addappid(842751, 1, "5fb2e234ee83f0bfadf49f4b37dff01419d772a88202fd33f42061dafb95d177")
addappid(842752, 1, "223b86e9f716c36eec1bdefb8268d7efa6fb9b92a0845dbf7893f392bc1c5bb6")
addappid(842753, 1, "694c4dfd35f9b6785e28fe5751ed1eccc8dd5e8b6aedc307fc122953f83812f0")
