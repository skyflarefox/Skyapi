-- Lua provided by SkyAPI 
-- Game: Finding Cats In Breeze Village
addappid(2845400)
addappid(2845401, 1, "4dac0797fc80fe697b5f950a184c1e0ceb56ad800741eb4b4bcdd113eb67b7c0")
