-- Lua provided by SkyAPI 
-- Game: Exodus from the Earth
addappid(12390)
addappid(12391, 1, "d944c1ef9e437df395814c39624751f916198ea204c1f9a88be40463dc689633")
addappid(12399, 1, "9f23b12bbaf7e4a62b185e82d19cb2d92716c5216a54a87de267926060308ba6")
