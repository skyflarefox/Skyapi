-- Lua provided by SkyAPI 
-- Game: AppID 860200
addappid(860200)
addappid(860201, 1, "12e12215b227ffb09a122ed743d6d3c2241139e7a640fd12b652a7205806263b")
