-- Lua provided by SkyAPI 
-- Game: Mega Mosaic
addappid(2915950)
addappid(2915951, 1, "164c5c25d6f44e3ebd4afaf8b52103ce47edcfc3f5ba4b8d0918081f19f66ada")
