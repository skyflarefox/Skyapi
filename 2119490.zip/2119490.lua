-- Lua provided by SkyAPI 
-- Game: TRAHA Global
addappid(2119490)
addappid(2119491, 1, "741ec350f58a390ba1a24d3530a541ff165cb183c8202326d14bc0c049f4797a")
