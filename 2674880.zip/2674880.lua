-- Lua provided by SkyAPI 
-- Game: Omurice Next Time Demo
addappid(2674880)
addappid(2674881, 1, "6728ec2e5942571e9ca3621585c64cecc75d21aa87436780562c94b79c55a53f")
