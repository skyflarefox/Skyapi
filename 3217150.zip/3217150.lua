-- Lua provided by SkyAPI 
-- Game: Japanese Psycho
addappid(3217150)
addappid(3217151, 1, "6085470cc525b3b40aaa9bf075dbf18e272194539d6a383785a24cca8cfdf3d0")
