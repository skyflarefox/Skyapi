-- Lua provided by SkyAPI 
-- Game: AppID 1175120
addappid(1175120)
addappid(1175121, 1, "a5d052e92864f2a1ccb05a2390c2cfed91008ec29e740609cca0763ae405c540")
