-- Lua provided by SkyAPI 
-- Game: Alien Destroyer
addappid(1697420)
addappid(1697421, 1, "8c0f9ce0fafabd173b601cdeb15e098ce78ab4f6b64dbc484a3b28620e6abd13")
