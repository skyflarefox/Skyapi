-- Lua provided by SkyAPI 
-- Game: Ells Tales: Egg
addappid(2989860)
addappid(2989861, 1, "ed37edecb3fe16e574b80a7ce84b07b2338e60c5c7d89786e632ee7006362bff")
