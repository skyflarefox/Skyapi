-- Lua provided by SkyAPI 
-- Game: Graces: Posthumous Wish
addappid(2899980)
addappid(2899981, 1, "cc43996014187e6ec7a6f50d5744e50b43d9696a756fc0b50268473b4571f0cf")
