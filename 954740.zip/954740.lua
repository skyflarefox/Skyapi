-- Lua provided by SkyAPI 
-- Game: Terminator: Resistance
addappid(954740)
addappid(954741, 1, "4159d3017619889a426e09a0c6691af103245053c33f26593c6e8e82c54a50d3")
