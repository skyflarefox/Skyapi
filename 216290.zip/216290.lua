-- Lua provided by SkyAPI 
-- Game: Gateways
addappid(216290)
addappid(216291, 1, "59c2e03041d95f6cf8fbb21478536ab0343e05f102f5932adb0a6fecea1edb6d")
addappid(216292, 1, "2b0b0a88a6d170279db85709b91df8599e2937860253aaabccf83266e4e0e6cb")
addappid(216293, 1, "99e7716b5c0798da3b8c7852ce67e3b780cd6bd67e9fc97ddd1a26c1327dfb93")
addappid(228983)
