-- Lua provided by SkyAPI 
-- Game: vROVpilot: TITANIC
addappid(3397800)
addappid(3397801, 1, "1d458eda842f24025de40e7ac58195dd6a50d3b96d5ead560b42a7610703234d")
