-- Lua provided by SkyAPI 
-- Game: Scramble: Battle of Britain
addappid(1530450)
addappid(1530451, 1, "af09b72bafff609f24613b4c8777f435de2b3a2ec390406f94d408b73b14c08d")
addappid(1530452, 1, "404aa3dc5eb6313e46ff99426ca926c49e089733e2dc3c3038291f68a6d4b9b3")
