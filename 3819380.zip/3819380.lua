-- Lua provided by SkyAPI 
-- Game: Hentai Shanti
addappid(3819380)
addappid(3819381, 1, "135960d1d48dc49c1c29939feaa5449a4b58ea1c14a7113e8e55a0560ada9397")
