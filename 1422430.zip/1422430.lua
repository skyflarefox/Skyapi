-- Lua provided by SkyAPI 
-- Game: Next Space Rebels
addappid(1422430)
addappid(1422431, 1, "c9634b772b843f6e499d8a7c89990dcbfa250128c5785d2a0a0333c225eb0a11")
