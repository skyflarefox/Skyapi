-- Lua provided by SkyAPI 
-- Game: Sex Diary - A Slutty Anniversary
addappid(1928100)
addappid(1928101, 1, "b1801b551807257cc6915919e34f5d49503750fc28771c5d9769fe3feb1fab70")
