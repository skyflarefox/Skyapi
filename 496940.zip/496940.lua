-- Lua provided by SkyAPI 
-- Game: Second Death
addappid(496940)
addappid(496941, 1, "317035e5e31ed1db9695968ca13c4feebf9dbf3916092464a608d915c082c1a1")
