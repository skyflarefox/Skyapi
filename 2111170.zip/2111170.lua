-- Lua provided by SkyAPI 
-- Game: STORY OF SEASONS: A Wonderful Life
addappid(2111170)
addappid(2111171, 1, "2d9d2b9615e3f11f5256bf67cffb29afba507e75ece6760e7f8e8d8c63f6b8c9")
