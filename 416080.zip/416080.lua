-- Lua provided by SkyAPI 
-- Game: The Odyssey: Winds of Athena
addappid(416080)
addappid(416081, 1, "84bc0a68b19eb469eedc2cc7775491d1371e6c52b1097972ee460eb815c75cee")
