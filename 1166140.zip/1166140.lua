-- Lua provided by SkyAPI 
-- Game: Forbidden Art
addappid(1166140)
addappid(1166141, 1, "ac93df928e571e2b35a96a3b8a6793750bf69715ed66a0f3feed37864a9ad067")
