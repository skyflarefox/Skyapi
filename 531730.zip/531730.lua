-- Lua provided by SkyAPI 
-- Game: AppID 531730
addappid(531730)
addappid(531731, 1, "3a5ecbf007c1a2163f82c88c7cdd9464ab2a6e25771cab3206d8c953b351dee7")
addappid(531732, 1, "f3b120745c5bf52eae5627341ab8e069de4f655dab102108c90a61f9c9a97e46")
