-- Lua provided by SkyAPI 
-- Game: Jisei
addappid(754460)
addappid(754461, 1, "ddfee12d8fb9bbe391eab50ba5bf9e1ebc1cbd54facdf5a7def26d5fabd25650")
