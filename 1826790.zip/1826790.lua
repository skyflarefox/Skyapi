-- Lua provided by SkyAPI 
-- Game: AppID 1826790
addappid(1826790)
addappid(1826791, 1, "04cec141f88e78c690006181caf680a65652c22b4d29908a98e456b1b635ee99")
