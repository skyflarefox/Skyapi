-- Lua provided by SkyAPI 
-- Game: Space Gladiators
addappid(1144910)
addappid(1144911, 1, "d5dcf8b64cab94f81b886bdd407aa4a5f414c567a5d697bb7d3d87be9ee088f4")
