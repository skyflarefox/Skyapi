-- Lua provided by SkyAPI 
-- Game: Captain vs Sky Pirates
addappid(722340)
addappid(722341, 1, "1ae6677cc14b4c7c03bc1b5c64e8909ed1f4e21125ce2ce15d05f23ec83abdf0")
addappid(750280)
addappid(751030)
addappid(754070)
addappid(754670)
addappid(755430)
