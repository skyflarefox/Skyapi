-- Lua provided by SkyAPI 
-- Game: King Dragon Saga
addappid(1517160)
addappid(1517161, 1, "27de55f2e60253bd896ca7525ceb4f1bdb6a2acaa63c828afee4ea0d347161c1")
