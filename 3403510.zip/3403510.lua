-- Lua provided by SkyAPI 
-- Game: Winter Clothing
addappid(3403510)
addappid(3403511, 1, "51562582a55930d23fe120742cc755a8f397d306bc83f521c5404d39c2fe3547")
