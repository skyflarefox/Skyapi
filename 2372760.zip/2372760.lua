-- Lua provided by SkyAPI 
-- Game: Eternal Roadster
addappid(2372760)
addappid(2372761, 1, "083bdad993f5dd5e3cce67c43a30d993bffbae71ca4ede592c9d4e186736eef4")
