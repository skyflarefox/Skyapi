-- Lua provided by SkyAPI 
-- Game: Survival Camp
addappid(1028800)
addappid(1028801, 1, "6a591bf319af17dae407359bfad7db9cb9961ae020e11b9c66d99157422f23df")
