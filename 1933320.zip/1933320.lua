-- Lua provided by SkyAPI 
-- Game: Black Hole Pool VR
addappid(1933320)
addappid(1933321, 1, "0bcadbcc3837f8a33206a39ca769bd59c29e99c8c973b6a15db88765686dc2eb")
