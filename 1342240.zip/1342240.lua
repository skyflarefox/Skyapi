-- Lua provided by SkyAPI 
-- Game: AppID 1342240
addappid(1342240)
addappid(1342241, 1, "82ee8dc42f570a99adb15c275d0f51ebdfc47b49298af93086e8a2f62aacaa92")
