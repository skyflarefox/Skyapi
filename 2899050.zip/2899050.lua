-- Lua provided by SkyAPI 
-- Game: Desert Stalker
addappid(2899050)
addappid(2899051, 1, "a6cff3e9d965f5096403263df0125bd18d78589c82e7642e33f2f3ab3c2be3e1")
