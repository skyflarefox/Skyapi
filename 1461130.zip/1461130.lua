-- Lua provided by SkyAPI 
-- Game: LAVALAMP
addappid(1461130)
addappid(1461131, 1, "733479bb214c23d94baae7829892879101ba9737df50c672fe1fd2daaab96ad6")
