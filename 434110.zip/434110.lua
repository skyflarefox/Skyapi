-- Lua provided by SkyAPI 
-- Game: AppID 434110
addappid(434110)
addappid(434111, 1, "572b38d940cc0e9ad6a7bd49e597ac11cc4cef27d7f5dc6feae180f7b15e5f8a")
addappid(434112, 1, "29f525ec89fcfd9e4cb3c2a6790f266638bd5bb6eebf96952951269cd5dced86")
addappid(434113, 1, "5e4599c99629926755801f44a055fbccaf136535279f1a0b52c36befaf6a2ebb")
