-- Lua provided by SkyAPI 
-- Game: A Quiet Place: The Road Ahead
addappid(2233120)
addappid(2233121, 1, "908cc3ca235e2d744c3f800596e90f596fe3b9acd68a130ec56985fbdf262212")
