-- Lua provided by SkyAPI 
-- Game: Sera Dion: Survivor
addappid(3243970)
addappid(3243971, 1, "acee49a89b9ce0d6c7dbc2cc714ce66895c0df30f818c66b25a8243422a9f12d")
