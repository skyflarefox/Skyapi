-- Lua provided by SkyAPI 
-- Game: AppID 1268810
addappid(1268810)
addappid(1268811, 1, "0b13858b507c54931e63cfb5fbe004450ac07e08f7e4279f7d05bee491d583b6")
