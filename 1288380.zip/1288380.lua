-- Lua provided by SkyAPI 
-- Game: Two Bit Hero
addappid(1288380)
addappid(1288381, 1, "3351012e179e94c02e9919cfdd24d26e6b2401a490b2f1ba7d146e6b75d097a2")
