-- Lua provided by SkyAPI 
-- Game: Pesticide Not Required: Prologue
addappid(2480450)
addappid(2480451, 1, "e6ba408b3d8aca676b61c6f4a1b668018fea0c323718cb1688eb6e92b383bdc4")
