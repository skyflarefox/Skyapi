-- Lua provided by SkyAPI 
-- Game: Forsaken Frontiers
addappid(2810780)
addappid(2810781, 1, "5c491e275fbeb58082e8e36b6f5b5dbb5e1195ad33b2eb9b09cdfebfa878055d")
