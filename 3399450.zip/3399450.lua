-- Lua provided by SkyAPI 
-- Game: AppID 3399450
addappid(3399450)
addappid(3399451, 1, "77fc07cf815274bb5488f717bef898b48d14d3144441905bdccdfd0b98c7642c")
