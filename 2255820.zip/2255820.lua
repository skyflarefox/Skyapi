-- Lua provided by SkyAPI 
-- Game: Dawn Of Hell
addappid(2255820)
addappid(2255821, 1, "fcabc32e0c4f8d079db59f5c7d296e784176d2aa24190af8a225a3310bca72a6")
