-- Lua provided by SkyAPI 
-- Game: I dont Fall
addappid(2966470)
addappid(2966471, 1, "310dae15931c36c16dc93b44dc6ddf6fe52d9c8bfe07078f610e00052375f467")
