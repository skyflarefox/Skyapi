-- Lua provided by SkyAPI 
-- Game: Descenders Next
addappid(2375530)
addappid(2375531, 1, "95ca2114d0a93ae20d7ebf2f46e6219130f1c3dabc5543fab754c7c0e56f9fb0")
