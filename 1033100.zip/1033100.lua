-- Lua provided by SkyAPI 
-- Game: Mobler
addappid(1033100)
addappid(1033101, 1, "271a2126f0d74e27e06f9c07507f0052139fed0b0815b66fb3bcb89b05694711")
