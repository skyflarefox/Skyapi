-- Lua provided by SkyAPI 
-- Game: A ARMY BASE
addappid(2673730)
addappid(2673731, 1, "c125a947cf528f4e0555dec603d19e8d749e53e969b2c3d79400129902ea491d")
addappid(2673740)
