-- Lua provided by SkyAPI 
-- Game: Apocalyptic cat
addappid(3015100)
addappid(3015101, 1, "b7322f739b1f72c1e23928d1e7d98493a58dd11ab3c93778598169ea609751f8")
