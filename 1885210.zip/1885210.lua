-- Lua provided by SkyAPI 
-- Game: AppID 1885210
addappid(1885210)
addappid(1885211, 1, "3706f3db1e617b0ba806fa966140848217240d3a60f9e2effd96a460aad5a67a")
