-- Lua provided by SkyAPI 
-- Game: AppID 2890010
addappid(2890010)
addappid(2890011, 1, "a39ebcd3e1a760d9200a5a148166809ccfa9b6f6f1321f36cd2d35ba79f8b0a0")
