-- Lua provided by SkyAPI 
-- Game: AppID 826230
addappid(826230)
addappid(826231, 1, "8b9e95626f5c8ad5da454380505231d1a368a25a88d46b4269b8a6a1d7462d6b")
addappid(872520, 0, "9d6ee9edd9a007f5c19dc6b5f214f7cf8479a98b05393d4039121bfbd31e6821")
