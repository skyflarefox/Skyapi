-- Lua provided by SkyAPI 
-- Game: How To Punish A Witch
addappid(1314290)
addappid(1314291, 1, "fe04cc60ccc9d89ce8b4e979ca848a4d59c583d13b6b983a718effb052240f07")
