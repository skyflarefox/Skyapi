-- Lua provided by SkyAPI 
-- Game: Dust Fleet
addappid(406160)
addappid(406161, 1, "4a6340235ac704c786b4cf89dd1aac3cd8467682380d00f4f110da731a1b9fe6")
