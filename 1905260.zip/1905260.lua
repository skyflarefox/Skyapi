-- Lua provided by SkyAPI 
-- Game: Mini Gardens - Logic Puzzle
addappid(1905260)
addappid(1905261, 1, "f1929d3fb79a6c9666993f31ed470e5076a67b2085d31d069526aa5060a6aaf0")
