-- Lua provided by SkyAPI 
-- Game: AppID 389980
addappid(389980)
addappid(389981, 1, "ee51d47071d3e1740fd1b5e07f55032b3891a6a00c5a36314f2922679fc818fb")
