-- Lua provided by SkyAPI 
-- Game: Legend of Mana
addappid(1175830)
addappid(1175831, 1, "70a76717998c7cb3429fa28331d0d5554dc18e441e503ca1f60b659608a8403e")
addappid(1542020, 0, "195b5ff3eafc17d81cf8278d44b876d75c6a5770f1d1d5e897e1d0b029b56251")
