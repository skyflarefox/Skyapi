-- Lua provided by SkyAPI 
-- Game: The Book Of Hiro
addappid(2533870)
addappid(2533871, 1, "e2098c5927aff6489e37ae3c6dfeace82dcbf589b2708b642e4295582dabe87c")
