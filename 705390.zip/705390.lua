-- Lua provided by SkyAPI 
-- Game: Aya's Journey
addappid(705390)
addappid(705391, 1, "3d36aaf292298c27cfb830393a14a07b32150e4f680aa26d0c4e7c57c6cec36a")
