-- Lua provided by SkyAPI 
-- Game: Hunting Unlimited™ 2008
addappid(12530)
addappid(12531, 1, "b16b4c1f2a46a251063d9104ddb10f3b83b0ae7a067dd87f4e49f579d071e5b0")
