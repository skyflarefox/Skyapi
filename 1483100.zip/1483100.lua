-- Lua provided by SkyAPI 
-- Game: One More Dungeon 2
addappid(1483100)
addappid(1483101, 1, "6c4cbbbf0c8518ed54a6bf9c77e3ccc70fa3bca0dfd1a0cc6c27036f581ebdd9")
