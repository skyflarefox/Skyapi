-- Lua provided by SkyAPI 
-- Game: Cannons-Defenders: Steam Edition
addappid(617710)
addappid(617711, 1, "4525f384b8c95d6f5d4c60f6709979bbf7f73a916e67f97d47255a4470a7f25f")
