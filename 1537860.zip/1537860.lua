-- Lua provided by SkyAPI 
-- Game: AppID 1537860
addappid(1537860)
addappid(1537861, 1, "91c72e347263406530ec603b27630e8d080ecc33e280e492bcfcd9f6de2d444f")
addappid(1537862, 1, "7a70f6011f8b18da5f3e75a29d07af6ae4dd146383fbcc2da19d76f4dc6b8238")
