-- Lua provided by SkyAPI 
-- Game: AppID 3252640
addappid(3252640)
addappid(3252641, 1, "f21c038b11571c1a072bc4d9a46f15ac59e382c092d13d844092d50700f415ad")
