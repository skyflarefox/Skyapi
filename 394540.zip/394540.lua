-- Lua provided by SkyAPI 
-- Game: AppID 394540
addappid(394540)
addappid(394541, 1, "dbe5e9c7f7fec5d9a4b8789fc953e09acc075acaf9264cae5b4e3dd865490102")
addappid(458400, 0, "ff0d7afc0a8a8ff6bb90e1b58fb7a0f3a825b932deca4bb7f4183e61fc23adbf")
