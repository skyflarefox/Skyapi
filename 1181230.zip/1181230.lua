-- Lua provided by SkyAPI 
-- Game: Zeliria Sanctuary - Isle's Memories
addappid(1181230)
addappid(1181231, 1, "fe5f6d9a67cbc8328ec6d2ad7ae1c6346c5490a46c68ff4457be1b03a9f26702")
