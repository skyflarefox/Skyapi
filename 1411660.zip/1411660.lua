-- Lua provided by SkyAPI 
-- Game: BITROOM
addappid(1411660)
addappid(1411661, 1, "cf7e946385bd561a908f286b2eb7ea6e57bd77af3091d305515cefd36589860b")
