-- Lua provided by SkyAPI 
-- Game: Armored War
addappid(1631530)
addappid(1631531, 1, "0bc438e5d8b452d319e1688a2b11d1cf204265e05dbe87e6e70f6ff13497bb6e")
