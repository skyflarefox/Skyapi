-- Lua provided by SkyAPI 
-- Game: Let's School
addappid(1937500)
addappid(1937501, 1, "88b023a604b78607ab4a19ae2c69a3067612b1293aa6b9411294c80b2adcde37")
