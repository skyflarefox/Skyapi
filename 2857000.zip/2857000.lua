-- Lua provided by SkyAPI 
-- Game: refarm
addappid(2857000)
addappid(2857001, 1, "9088d1335ec168c30d94727dcbf95152032da2bf9129301e16f709ea95d52702")
