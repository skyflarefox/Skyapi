-- Lua provided by SkyAPI 
-- Game: Road Stones
addappid(2069580)
addappid(2069581, 1, "0d0df32068a3e62fe63980c4134a4039f03b1351c18c92894f3194c5732578fe")
