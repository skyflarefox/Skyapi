-- Lua provided by SkyAPI 
-- Game: LIGHT: Black Cat & Amnesia Girl
addappid(1730140)
addappid(1730141, 1, "08e53c13f93293d1d47a89069e24e7e04dd8d1be8b9d6a985268e11ca3520fb6")
