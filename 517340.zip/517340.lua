-- Lua provided by SkyAPI 
-- Game: AppID 517340
addappid(517340)
addappid(517341, 1, "4cb2ba7ee5a6124fa5ab9b5ea16f3ecd143411b4d5015e9f3fedb9c0d12eeb2f")
