-- Lua provided by SkyAPI 
-- Game: AppID 2239530
addappid(2239530)
addappid(2239531, 1, "788443e3695462b61dd99f9331b8ce80cba9cbdee53ea337ecdb7bbce5c1364e")
