-- Lua provided by SkyAPI 
-- Game: BURIED STARS
addappid(1025960)
addappid(1025961, 1, "188cc0a09f75cb01aa9e9ccb70fb2efbea42f6940e9a86599270537222004106")
