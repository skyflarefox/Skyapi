-- Lua provided by SkyAPI 
-- Game: AppID 2497290
addappid(2497290)
addappid(2497291, 1, "f4fea57c5737f44a9249b0096a726d002670c9f5e01526b47fa6ab480a5f71da")
