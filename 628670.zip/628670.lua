-- Lua provided by SkyAPI 
-- Game: Hellpoint
addappid(628670)
addappid(628671, 1, "955fc7cba03bb9ac3216822e737749d4688231406d569ebf680cea22360a5f1d")
addappid(628672, 1, "60cc3f76354ea37430e1ea0c0495bdd87be6b24a6f9d7ccc656752feef50a64d")
addappid(628673, 1, "c762fc83e736d43983a4e99c26c37ac17f0f57c045bcdce7ac8aea0c021b3a61")
addappid(1380040, 0, "9ae1c8d6d4d8ecf5c84637f84f3f17d8dcc27b9fad706cc2574f3b93beb17f2a")
