-- Lua provided by SkyAPI 
-- Game: AppID 575750
addappid(575750)
addappid(575751, 1, "830d50e76d2b36b8271701a9ac1eb6fd9220302faef87e82b4acb792bb0c0598")
