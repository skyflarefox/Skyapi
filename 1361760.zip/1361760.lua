-- Lua provided by SkyAPI 
-- Game: Cartomante – Fortune Teller
addappid(1361760)
addappid(1361761, 1, "fc872705e87c1606c3fbd3bb4edbb2ac023f815e37656dd03d0cdfd2692f2147")
