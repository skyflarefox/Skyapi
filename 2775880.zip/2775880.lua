-- Lua provided by SkyAPI 
-- Game: Desert Witch
addappid(2775880)
addappid(2775881, 1, "5ca468ba89cf3b0091e726a4ee387f2250a30d721ff8465f85babb5025411d9c")
