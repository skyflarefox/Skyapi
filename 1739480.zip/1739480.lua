-- Lua provided by SkyAPI 
-- Game: Hordebreaker
addappid(1739480)
addappid(1739481, 1, "0b9533c03ada97a8813d34eedd00680e05d39bffebe8d83d4313f14821761217")
