-- Lua provided by SkyAPI 
-- Game: Neko Beach
addappid(1630650)
addappid(1630651, 1, "ab6fec0ec4b794ac5caacee9a98d1a91ad6756fb8825cd425af56135bf9874e6")
addappid(1646950)
