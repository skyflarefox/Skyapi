-- Lua provided by SkyAPI 
-- Game: AppID 581670
addappid(581670)
addappid(581671, 1, "1d81630525ac2cc0e89d9f17d4d277907c07bd5ed35d9a95a37dde8a4d0f6ca7")
