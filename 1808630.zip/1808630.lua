-- Lua provided by SkyAPI 
-- Game: NEDEN?
addappid(1808630)
addappid(1808631, 1, "93590404748500173d01478668621497ed3c0b1292dc9e7cb2b554d635dd3e87")
