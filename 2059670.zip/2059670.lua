-- Lua provided by SkyAPI 
-- Game: Moss II VR
addappid(2059670)
addappid(2059671, 1, "0a2c533e27e31b54193a233e8c1c5b3d8502134d795d09231ac1306aaafe9eb2")
