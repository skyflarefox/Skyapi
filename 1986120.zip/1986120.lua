-- Lua provided by SkyAPI 
-- Game: Chaste Tris
addappid(1986120)
addappid(1986121, 1, "da1d878b030b1a1a32161824caad3d4fd328246394d5288cce5bee0fdc9000c0")
