-- Lua provided by SkyAPI 
-- Game: AppID 1148560
addappid(1148560)
addappid(1148561, 1, "b44f6d9fdf339ec9bc1c67c585052989c4bf933324d72b20b5ed54499231c2fc")
