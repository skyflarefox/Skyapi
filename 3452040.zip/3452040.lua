-- Lua provided by SkyAPI 
-- Game: AFFRAID
addappid(3452040)
addappid(3452041, 1, "58311791b3fe938df460bbdd1edc21b0ed9fe4b1f7c5c36b7129216a7e8cc870")
