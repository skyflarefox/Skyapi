-- Lua provided by SkyAPI 
-- Game: Foodslingers
addappid(2145460)
addappid(2145461, 1, "38d598ec2602246aed9b527390019d4aa158c852621845f5a11d3c48ca2b8891")
