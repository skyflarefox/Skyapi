-- Lua provided by SkyAPI 
-- Game: AppID 3055520
addappid(3055520)
addappid(3055521, 1, "bd78919b8a6bf6d2c06a1c2ec4b2202f770400cc96374ae5a055bf1fd7dbfe8d")
