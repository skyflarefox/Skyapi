-- Lua provided by SkyAPI 
-- Game: Dokuro
addappid(317840)
addappid(317841, 1, "6512eb2e426e9cf23c2f6b93c07e48577850387a3df789701e1c795c08d08b04")
