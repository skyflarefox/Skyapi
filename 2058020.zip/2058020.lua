-- Lua provided by SkyAPI 
-- Game: AppID 2058020
addappid(2058020)
addappid(2058021, 1, "4526a4871c127f7b00b69ef927efa04357020a437ca137dc74a7c568789add7b")
