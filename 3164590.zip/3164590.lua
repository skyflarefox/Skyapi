-- Lua provided by SkyAPI 
-- Game: AppID 3164590
addappid(3164590)
addappid(3164591, 1, "88497296dbf59f5b65502475722b87668a169e1697856ee388fc4e28221c9d72")
