-- Lua provided by SkyAPI 
-- Game: Dawn vs Dusk
addappid(2071720)
addappid(2071721, 1, "e6de0092ab5e5cb160bbeb8b3157b4680b06db123b92cc94fe7e328b3a8858dd")
