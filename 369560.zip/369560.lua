-- Lua provided by SkyAPI 
-- Game: AppID 369560
addappid(369560)
addappid(369561, 1, "539128913dbfce081b56324887fd5f4cd259fe9eac5dfe5d39658fb07f23f607")
addappid(369562, 1, "dd77c84fbea3c00010f37cc932ebf793cd23c1fc03bb67888cd20cd6e9de4db6")
addappid(369563, 1, "b33422d7aaac9776ba1602069fd72abcc94069cd3345a24f0b3f90b59d9c77fd")
