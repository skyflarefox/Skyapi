-- Lua provided by SkyAPI 
-- Game: Slip 'n Dip
addappid(1360790)
addappid(1360791, 1, "0026cfd833ab8761aa9983f117f3faea224e5887059055e5699df89772478da2")
