-- Lua provided by SkyAPI 
-- Game: AppID 650860
addappid(650860)
addappid(650861, 1, "cb6e844d8c7139c70e39463c5cb15f1878ad7bc6e7c6f635854a84119568d6cb")
