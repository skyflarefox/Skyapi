-- Lua provided by SkyAPI 
-- Game: Dash Dash Run!
addappid(649570)
addappid(649571, 1, "74142dabf5751105e478482cc6c96b1582af097ac3dbd3714a9cb95e132c88d4")
