-- Lua provided by SkyAPI 
-- Game: Anomalous Coffee Machine
addappid(3173560)
addappid(3173561, 1, "9cf5d3ea5288b1451038e7e924d155b3dae10b231ef5a02b19828ea14f86c7b8")
