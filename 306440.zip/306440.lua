-- Lua provided by SkyAPI 
-- Game: Oblitus
addappid(306440)
addappid(306441, 1, "57c5b395b04d2ee859b1ae3aa280098238dc8d9fdda852ba9c4e943e75d3bb6f")
