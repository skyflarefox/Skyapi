-- Lua provided by SkyAPI 
-- Game: Marauders
addappid(1789480)
addappid(1789481, 1, "7ad240d388bfc7d00551db80ea1d7a33e2a9e6b2db81ff01c7e0e8b802adece5")
