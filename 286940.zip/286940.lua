-- Lua provided by SkyAPI 
-- Game: AppID 286940
addappid(286940)
addappid(286941, 1, "ab3d1eb2df1a3ac2547824660b3808aca9b9aa04ab4751ed587c242e3c72ce3b")
