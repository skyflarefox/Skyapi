-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(743090)
addappid(743091,0,"12cc86888528e7b8913583902237218a1b3350b93e88dadefd38512971cbfef7")
setManifestid(743091,"6764867375023598392")
addappid(845241,0,"9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")
setManifestid(845241,"7675389946101989167")
addappid(743092,0,"9fea801571fd542b9b813412fcc4cfa26b5f8828d6931a615e34680bf35fddea")
setManifestid(743092,"6837134493062996287")