-- Lua provided by SkyAPI 
-- Game: Die by the Blade Demo
addappid(1956060)
addappid(1956061, 1, "08465e336c0d340bad2cf9b02d2ade13527442abfa98df30735117d8c89ffc32")
