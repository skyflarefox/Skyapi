-- Lua provided by SkyAPI 
-- Game: Roody:2d
addappid(2345220)
addappid(2345221, 1, "6bb61c80b40b0371e298037edf33358ba93068a3939072ef839b0a5ca5089336")
