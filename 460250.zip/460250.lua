-- Lua provided by SkyAPI 
-- Game: 🔴 Circles
addappid(460250)
addappid(460251, 1, "de3e8e18d845c254d613a5e8467b01f760faba8e3d500160d0b046cd7194fd80")
addappid(460252, 1, "731423899dc2531b8f5c9f94a11b8fe887ca43ee4a387006315035f5ef1f46f9")
