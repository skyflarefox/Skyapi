-- Lua provided by SkyAPI 
-- Game: The Haunting Eyes
addappid(3075250)
addappid(3075251, 1, "69563a67975bbae970e6f8a0b6754e75e4da4f20a4b6295b3fd0c860af9ff565")
