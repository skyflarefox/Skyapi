-- Lua provided by SkyAPI 
-- Game: Azimech
addappid(1666030)
addappid(1666031, 1, "ce1f2204f0652c9443297007bbc515573ecc05a7f22930548f72e48507d2d630")
