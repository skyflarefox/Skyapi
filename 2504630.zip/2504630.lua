-- Lua provided by SkyAPI 
-- Game: Ur
addappid(2504630)
addappid(2504631, 1, "e49b4d520abea6ee00628b3b8ee2187be3bdf04a5f2bfee739e49ac3bc74168b")
