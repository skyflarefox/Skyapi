-- Lua provided by SkyAPI 
-- Game: ASTRALODE Freeminers
addappid(1273010)
addappid(1273011, 1, "6b30a5312fb138e62dd9cc6a5ddd6f639a155a3855b7f8c5bee9da1007adfae4")
