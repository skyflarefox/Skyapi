-- Lua provided by SkyAPI 
-- Game: Labyrinth Escape
addappid(654950)
addappid(654951, 1, "6bc35c4fe96a56645cc6abad3be8434115cc534f2467c747139103c8cee690c6")
