-- Lua provided by SkyAPI 
-- Game: Death By Chatter
addappid(3318380)
addappid(3318381, 1, "02823b3500b97e53fd4f3a22e12c32a50cffed659cf3b8b913c2a36812f3c38e")
