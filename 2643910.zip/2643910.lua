-- Lua provided by SkyAPI 
-- Game: The Final Countdown
addappid(2643910)
addappid(2643911, 1, "241ca61315c28923ba92332c98baee3fb7d0806b5979862c0ab7a6ba6345b6b4")
