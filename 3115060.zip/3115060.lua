-- Lua provided by SkyAPI 
-- Game: AppID 3115060
addappid(3115060)
addappid(3115061, 1, "6199195d827ba8221fea9e5991489ec2b0f4ce8c7e4f8ca315e62c3adca2f8dd")
