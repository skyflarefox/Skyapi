-- Lua provided by SkyAPI 
-- Game: Magic Click
addappid(2084090)
addappid(2084091, 1, "a7fb9947ec938aa01783842bf78141cb96baaed9d701c3fe4b63af11c2cb98e7")
