-- Lua provided by SkyAPI 
-- Game: The Detail
addappid(319970)
addappid(319971, 1, "09d28fcb4ee9f92222bacdd6fc483ae069d71583e0717cef403bcb8d32f90957")
addappid(319972, 1, "da9e5af0c2f8ca6fe90bcd0edfc4051e6342a2d26ab03662431edad1a0c856f3")
addappid(319973, 1, "2e6ff81fdd4ab881bb7eb28de878853918bb8f579775e33402197a4c678858ce")
addappid(319974, 1, "6d6aaf0c8c2d60354145c507d24a5df3c2e915738fff405e0708b5000299afd2")
