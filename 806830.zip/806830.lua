-- Lua provided by SkyAPI 
-- Game: Horse World
addappid(806830)
addappid(806831, 1, "96be472f9867c91bd1d9bc6bc2a1bf71300b7c7fcca760b41ffc464e25167161")
