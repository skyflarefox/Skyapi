-- Lua provided by SkyAPI 
-- Game: Hoofobia
addappid(2467300)
addappid(2467301, 1, "64b35ec4cfc5ea7768f54dbf456613f8b0ccaf4d8482efc2f9f0250eabf2cb9a")
