-- Lua provided by SkyAPI 
-- Game: Legend of Towercraft
addappid(1279800)
addappid(1279801, 1, "35ca74d0300e754b2448e379ea63645a8537a182a4ca897cc0c2d71c7fecf488")
