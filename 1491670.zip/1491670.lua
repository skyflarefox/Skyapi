-- Lua provided by SkyAPI 
-- Game: AppID 1491670
addappid(1491670)
addappid(1491671, 1, "09dc31cd91dfdb17e84c1a025f2cbb38913889fac35ab621a1edb11e6eb66f6d")
