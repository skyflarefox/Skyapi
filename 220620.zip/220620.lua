-- Lua provided by SkyAPI 
-- Game: AppID 220620
addappid(220620)
addappid(220621, 1, "cb533bb90636408e305bf3cb2504a12f82a5a334ad2f6d59be2ea9650cca4ace")
