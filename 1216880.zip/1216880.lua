-- Lua provided by SkyAPI 
-- Game: Risen Kingdom
addappid(1216880)
addappid(1216881, 1, "5ad1d0b318bd2c34282d1cd16630c5f38cf94937e5cd17a7ec8874210fbd8b3e")
