-- Lua provided by SkyAPI 
-- Game: AppID 404620
addappid(404620)
addappid(404621, 1, "9733fc69d6ff7c0058c085ad447b7003261f505f185506bd2194d32fc8e6110e")
