-- Lua provided by SkyAPI 
-- Game: AppID 2326470
addappid(2326470)
addappid(2326471, 1, "99de1fe7e8bcfeae29f79cf510b6c7df54a868144600061a99b46ccaa3c3dae2")
