-- Lua provided by SkyAPI 
-- Game: Alien Slayers
addappid(2218140)
addappid(2218141, 1, "b0d2fe9722bf3c5bb18917cae23224cd37f611c6efe5f5580476c0912d08bc5c")
