-- Lua provided by SkyAPI 
-- Game: AppID 1424270
addappid(1424270)
addappid(1424271, 1, "868d9f23b62d0bfe3e8d29863caf2344905af81631ad7290b07f8ae4bfd3cd25")
