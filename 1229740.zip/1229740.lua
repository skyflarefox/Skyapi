-- Lua provided by SkyAPI 
-- Game: LUX SINE
addappid(1229740)
addappid(1229741, 1, "0d1561d4587c530cefbca92f9b07f8c55ca37ffa720825278847146100c2be70")
