-- Lua provided by SkyAPI 
-- Game: Osman Gazi
addappid(1408700)
addappid(1408701, 1, "21d4025d74bf53f1ad32e88d081f27989541ccfd401620152490b8706ff36fd6")
