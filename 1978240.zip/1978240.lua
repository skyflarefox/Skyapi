-- Lua provided by SkyAPI 
-- Game: AppID 1978240
addappid(1978240)
addappid(1978241, 1, "6a3326af47a63225ee5a9bcaf4f467562e85e1f4d386f7f4c41eb78e857564d0")
