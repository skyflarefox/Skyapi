-- Lua provided by SkyAPI 
-- Game: Welcome to Princeland
addappid(914290)
addappid(914291, 1, "4b0e8280b0a2eceaa16c5707018f87f77c9e88ff9e1c2ea65019830415364e95")
addappid(978150)
