-- Lua provided by SkyAPI 
-- Game: My Secret Pets!
addappid(447180)
addappid(447181, 1, "23b1e07810e4c02fb97b6549315a6e5a18e313af62154cf7d12b62a3ebeb6bdb")
addappid(449910)
