-- Lua provided by SkyAPI 
-- Game: Five Nights at Roner's: Remastered
addappid(3294890)
addappid(3294891, 1, "2342bb9064c365a9000ae6a349c14b74cc489a5f4e5839da683274e0d396534f")
