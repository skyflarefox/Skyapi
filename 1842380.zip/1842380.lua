-- Lua provided by SkyAPI 
-- Game: Milf Toys
addappid(1842380)
addappid(1842381, 1, "0f6b5859eaa8e8ec9148e7e10b6c184e53e9d20287ddb695db3aa09244753a98")
