-- Lua provided by SkyAPI 
-- Game: Trombone Champ: Unflattened
addappid(3151670)
addappid(3151671, 1, "85557c97fe3028cb817410bf7e1aac01f0578ec78cf622a65e53061f04d0cfe4")
