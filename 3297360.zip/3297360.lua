-- Lua provided by SkyAPI 
-- Game: We're Here, Papa
addappid(3297360)
addappid(3297361, 1, "56442f62d5822cca521039634c8284cf33d7851350018a63c95a40b96c7364de")
