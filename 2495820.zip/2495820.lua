-- Lua provided by SkyAPI 
-- Game: CometSoldier
addappid(2495820)
addappid(2495821, 1, "3f82b13bb02c9c8dd7b4be1b4a5ce545125c6ca8e2e0dd86de85577feb6e1a9a")
