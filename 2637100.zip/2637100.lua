-- Lua provided by SkyAPI 
-- Game: Neon Fantasy: Dogs
addappid(2637100)
addappid(2637101, 1, "4d766c1a88c6ee22366b3a1860189badc94b1f990039a54b1562c275e2589c44")
