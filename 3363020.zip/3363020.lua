-- Lua provided by SkyAPI 
-- Game: Hotel 188 Demo
addappid(3363020)
addappid(3363021, 1, "e5e4ebed45f90789d726b7feeb0fa5d0c812ec15788e71d01508f12a2e8b3444")
