-- Lua provided by SkyAPI 
-- Game: AppID 923470
addappid(923470)
addappid(923471, 1, "0ba9e7aec2f61c70bef550761d27cdf016ee1f5893261b7457d87f367d3d5128")
