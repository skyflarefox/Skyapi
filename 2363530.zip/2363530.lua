-- Lua provided by SkyAPI 
-- Game: Kemono Friends Opening Day
addappid(2363530)
addappid(2363531, 1, "02f08d3f5f068481571685e72ace240efc5417a2e456247c7efa2276d975d2c5")
