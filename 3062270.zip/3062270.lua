-- Lua provided by SkyAPI 
-- Game: Empire of the Ants - Demo
addappid(3062270)
addappid(3062271, 1, "51788fffbf5b0c7db2ab47c0f9a2102a54766f15cc6dd15fad0fe66d257feafb")
