-- Lua provided by SkyAPI 
-- Game: Fox Hime Zero
addappid(844930)
addappid(844931, 1, "cc74399edb867c6610289e31c8ca08b564316919ef8ca189b5ea87dbd6f88f65")
addappid(888000, 0, "a4c292f32d2f7b2d1422ab880159eb07efac3814eba22a649dbbc586e0ad8842")
addappid(930100, 0, "e20578598448d0fe550b2275e6a63ca412ccc7259716fbd11f339e78b0065954")
