-- Lua provided by SkyAPI 
-- Game: Fairytale Mosaics Cinderella
addappid(1427930)
addappid(1427931, 1, "98cba22b2f37598e15dac6960d57ac9b02f56365a0588d7695b4a31f5c206c3a")
