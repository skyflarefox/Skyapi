-- Lua provided by SkyAPI 
-- Game: Fairytale Mosaics Cinderella
addappid(1427930)
addappid(1427931, 1, "98cba22b2f37598e15dac6960d57ac9b02f56365a0588d7695b4a31f5c206c3a")
addappid(1427932, 1, "b6c6fcb988fcbff09f194d2f1f1efeb2501d57bd37953b588c495ebbc4a947a7")
addappid(1427933, 1, "17ca4983ca762ab5d610e6207b0f88ac0464fb54065d93154f4ba3df1b5fc764")
addappid(1427934, 1, "4eab1fd04d151721cc91035505cc1f284cf9965d2c2a80d2d47f3ee9e50dc374")
