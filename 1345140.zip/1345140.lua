-- Lua provided by SkyAPI 
-- Game: Claw Crane Company
addappid(1345140)
addappid(1345141, 1, "39e66d3854949e9d839390968e5a767a0bb3ff06e7fa2a10693473a736818832")
