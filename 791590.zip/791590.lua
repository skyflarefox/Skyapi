-- Lua provided by SkyAPI 
-- Game: AppID 791590
addappid(791590)
addappid(791591, 1, "470fe9620e9b6d9706629f9e2ddaf6569a9803285fd5f58c837eb84fee6be052")
