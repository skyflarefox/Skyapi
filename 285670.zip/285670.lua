-- Lua provided by SkyAPI 
-- Game: AppID 285670
addappid(285670)
addappid(285671, 1, "b551b18ff8feb8452c8f9d03e1690b9647c810c8362b975d7d882baa90ff14c7")
