-- Lua provided by SkyAPI 
-- Game: Samurai Chess
addappid(1568330)
addappid(1568331, 1, "963a25cdee0d6cd4f909877b5c7608fb3d229e932220a758b74ed329e3503ecd")
