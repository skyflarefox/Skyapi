-- Lua provided by SkyAPI 
-- Game: 召しませ！レミリアお嬢様！
addappid(3391830)
addappid(3391831, 1, "31f53008bb7f50190291ac6db8280a40db8f99a0354ea52226cc7987acb6e38d")
