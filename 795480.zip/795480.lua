-- Lua provided by SkyAPI 
-- Game: Unknown Pain: Hardcore
addappid(795480)
addappid(795481, 1, "638d3dcd791f2fd68b82aafbd2c0cd6c2a7382071586a556d37eccad4b62d1fa")
