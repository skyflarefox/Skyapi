-- Lua provided by SkyAPI 
-- Game: Puzzle Game: Lee inside TV
addappid(1170110)
addappid(1170111, 1, "2a06e66c267fe47c3f73738e5fcbdb5a76e20b01722af1f2a5f78df69e4fdcd0")
