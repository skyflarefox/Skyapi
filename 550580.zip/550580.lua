-- Lua provided by SkyAPI 
-- Game: Sticker Craft
addappid(550580)
addappid(550581, 1, "e00643c1fdaed7ca56745abd4d086ce20b52e27a26cbf80590712ec968195831")
