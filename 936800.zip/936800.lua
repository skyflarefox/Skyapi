-- Lua provided by SkyAPI 
-- Game: Professor Watts Memory Match: Cats
addappid(936800)
addappid(936801, 1, "ab6fefc1fe2f60b789038c4ce1fa6c53d4ae1cc3b917871cef8229f28c953a14")
