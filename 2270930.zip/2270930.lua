-- Lua provided by SkyAPI 
-- Game: F1 Crazy Stunts
addappid(2270930)
addappid(2270931, 1, "1c1cadbf302a11858061cc0fb35e5a3ad2bb2e4a713c712da473d10410d03aa3")
