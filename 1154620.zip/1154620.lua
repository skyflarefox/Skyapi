-- Lua provided by SkyAPI 
-- Game: Bound By Blades Demo
addappid(1154620)
addappid(1154621, 1, "9e235c8108321dc0cbae3ebeb8f5502d2c15d1ff6c4757ef6ebebe06c03427d5")
