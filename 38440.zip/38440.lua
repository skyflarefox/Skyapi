-- Lua provided by SkyAPI 
-- Game: Sacrifice
addappid(38440)
addappid(38441, 1, "38cec1e17d8fe53476a36599eb482e7fadf6429b6ac953b18ed73e0d260277d1")
addappid(38442, 1, "5f8f110ae75c3b4e568537cb05712eb502d2da2893676fbe21c84d57d45bc507")
