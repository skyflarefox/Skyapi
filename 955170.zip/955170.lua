-- Lua provided by SkyAPI 
-- Game: AppID 955170
addappid(955170)
addappid(955171, 1, "0c11f073090e1a85364dcfb0fb4fb8bfeb930ce4b3259a61d723a090f3082e99")
