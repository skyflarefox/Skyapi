-- Lua provided by SkyAPI 
-- Game: Escape from Terror City
addappid(1524020)
addappid(1524021, 1, "927e16363ad1aab037ddb5bc9f5ed84a511279c09e1913011c3ac9b6a13383ea")
