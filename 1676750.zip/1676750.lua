-- Lua provided by SkyAPI 
-- Game: AppID 1676750
addappid(1676750)
addappid(1676751, 1, "8d092550fa928d974ad55291bf15b440f48f6b6e473c5c7668c5718b901ecdf8")
