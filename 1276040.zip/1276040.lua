-- Lua provided by SkyAPI 
-- Game: Mini Words: Top Movies
addappid(1276040)
addappid(1276041, 1, "3a1fa8c367b59be31c9d1b4f287628d49702dcec40f48284070549d863330e71")
