-- Lua provided by SkyAPI 
-- Game: AppID 1239080
addappid(1239080)
addappid(1239081, 1, "fdc10940105c7507be41605c7c23f22212b60ef06404fe78a42a87827baa704e")
