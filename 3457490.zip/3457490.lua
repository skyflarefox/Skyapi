-- Lua provided by SkyAPI 
-- Game: Senet: Households
addappid(3457490)
addappid(3457491, 1, "05681975fa72b9fd9556c175726a4ec647f233e2e81cf61ccf72965987a6af64")
