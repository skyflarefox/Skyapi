-- Lua provided by SkyAPI 
-- Game: FAP & CUM: Simulator 🔞💦
addappid(2331970)
addappid(2331971, 1, "124ea04791ecc549e38d9075a242a54a5f4ae4171f10a48d9a9a11f0bf1a108b")
