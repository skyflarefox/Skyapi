-- Lua provided by SkyAPI 
-- Game: Shovel Knight Pocket Dungeon
addappid(1184760)
addappid(1184761, 1, "b56b55a34487abef1582fb59076f21be023fe8ee57cf7a4198cf33ab2a742a7a")
addappid(1184762, 1, "1a8af630a226181d500504942c25926928755397f197ea6832117ace6353d6a9")
