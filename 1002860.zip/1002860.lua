-- Lua provided by SkyAPI 
-- Game: Magus Over Fool
addappid(1002860)
addappid(1002861, 1, "a0219d6e3487c7be09672e3e46b05854051df4b28790f1412a8af9912a494ab3")
