-- Lua provided by SkyAPI 
-- Game: Stanga
addappid(1248670)
addappid(1248671, 1, "3c32759282541169fec19b3bba62c96d097ac9e30f807ba3370a71c362b0c087")
