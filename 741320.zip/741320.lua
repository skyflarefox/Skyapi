-- Lua provided by SkyAPI 
-- Game: The Song of Terminus  終焉的迴響:護界者之歌
addappid(741320)
addappid(741321, 1, "d93d20f50ddf991ccf9d2fd1fe2409da8c13b253b17a0a4cda79164333fd334c")
