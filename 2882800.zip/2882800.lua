-- Lua provided by SkyAPI 
-- Game: AppID 2882800
addappid(2882800)
addappid(2882801, 1, "f954dd3c0f65a23d99240b9d7d81343f009a31a789cbffed72621b9f13f344d9")
