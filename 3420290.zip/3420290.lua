-- Lua provided by SkyAPI 
-- Game: Look Down
addappid(3420290)
addappid(3420291, 1, "ef6197cdd426248de72f957f370834ebbcc60c04ac493140468c00cc1a1624cf")
