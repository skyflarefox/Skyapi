-- Lua provided by SkyAPI 
-- Game: Real Zombie War Simulator
addappid(2303300)
addappid(2303301, 1, "22b4bf5cd0bf76e23a7bfb8f227c45b56b6d638c500f9e30cb71e0200ca89f35")
