-- Lua provided by SkyAPI 
-- Game: 3D PUZZLE -  Leafless
addappid(3651720)
addappid(3651721, 1, "c5a9172f147c5ce81def3c58d4f2be06abcf50a7d13b0ebf31b4a4ee959e31e8")
