-- Lua provided by SkyAPI 
-- Game: AppID 886290
addappid(886290)
addappid(886291, 1, "c3c7e7e7ae67d11377f0b1cfde3ffbc43df4c6043a54f6afa1998bbaf6004b0c")
