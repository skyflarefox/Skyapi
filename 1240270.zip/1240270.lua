-- Lua provided by SkyAPI 
-- Game: The Botanist
addappid(1240270)
addappid(1240271, 1, "449306cc6a2e85cd22a4c3ee4b0f5b0d586610924391b758375906c1395a9454")
