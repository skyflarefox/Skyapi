-- Lua provided by SkyAPI 
-- Game: AppID 1102130
addappid(1102130)
addappid(1102131, 1, "3580fa24d501e515b727ed67535107f8c57d43aebb2321c278bb653118528046")
