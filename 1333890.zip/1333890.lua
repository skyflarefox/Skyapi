-- Lua provided by SkyAPI 
-- Game: AppID 1333890
addappid(1333890)
addappid(1333891, 1, "a0b1a43f9df9f85bd97970a8c3e756238ee80fdef263bc88a8f4e5a5636e04e6")
