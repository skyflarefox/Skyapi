-- Lua provided by SkyAPI 
-- Game: Hide Alone
addappid(2024300)
addappid(2024301, 1, "f6a5dddacb217e8e27825be30522992a3a2248e02b39c805c6ace4f4d997e941")
