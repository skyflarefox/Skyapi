-- Lua provided by SkyAPI 
-- Game: Shapeless
addappid(2317110)
addappid(2317111, 1, "27f7b52c0c15bbc1b10b19b0316fa8c6d384ed022b10c5628716c1fae1a10b39")
