-- Lua provided by SkyAPI 
-- Game: Planet
addappid(1044180)
addappid(1044181, 1, "27fe1c9a1fa2639b246318db69abcd8532305e481d38229c067f3525ec622d8c")
