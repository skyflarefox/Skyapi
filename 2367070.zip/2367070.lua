-- Lua provided by SkyAPI 
-- Game: AppID 2367070
addappid(2367070)
addappid(2367071, 1, "44d1d55beafd2b9d5b62fdb286df42c10a4fbf312b81c9130beef306dd876e17")
