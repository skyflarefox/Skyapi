-- Lua provided by SkyAPI 
-- Game: Loskop
addappid(1978290)
addappid(1978291, 1, "6a8b6fed6353eea3e55dcf066022572e7c5911cdca69fb5e7d72ca99085a967d")
