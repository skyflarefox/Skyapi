-- Lua provided by SkyAPI 
-- Game: Kamaitachi no Yoru x3
addappid(2612660)
addappid(2612661, 1, "f78b00b3d1227cb6467095f86c4aa6977b08581f814bfb137bb0f1f2836d93a7")
