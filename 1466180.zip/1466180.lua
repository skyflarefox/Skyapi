-- Lua provided by SkyAPI 
-- Game: Devil Girl
addappid(1466180)
addappid(1466181, 1, "189d07eafba92a639ddb137253dcff1f09775bc34cebb549a96f98d274ae7842")
addappid(1466182, 1, "24bf4bcb8ec179ccc8f1e66f6e00abbb77aa29af58bd9a41e8b066be97f2a21e")
