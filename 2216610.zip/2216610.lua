-- Lua provided by SkyAPI 
-- Game: We Who Are About To Die - Support Pack (Art & Soundtrack)
addappid(2216610)
addappid(2216611, 1, "069404e5290cf2c35b540ad2fc6ad8e29604d5f6d795ccec15006d5cb5d2ee7d")
