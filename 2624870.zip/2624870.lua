-- Lua provided by SkyAPI 
-- Game: Life is Strange: Reunion
addappid(2624870)
addappid(2624871, 1, "b639c25fe08af0a3e5d2f68d6f80972e9bacf8df4910d3f0a3ec734133ce62b6")
addappid(3977740)
