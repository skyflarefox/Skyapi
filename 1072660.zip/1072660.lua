-- Lua provided by SkyAPI 
-- Game: Loco Parentis VR
addappid(1072660)
addappid(1072661, 1, "f0e2a97413d32e7b2173e9de35ed0b38a53dd532af2625ba1a8693c2a68102a7")
