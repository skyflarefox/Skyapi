-- Lua provided by SkyAPI 
-- Game: AppID 536280
addappid(536280)
addappid(536281, 1, "101243addbcfc53aa4080cca64649f9d3beb6407e40b2069e519520a16d0e8ff")
