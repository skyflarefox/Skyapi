-- Lua provided by SkyAPI 
-- Game: Combat Monsters
addappid(336040)
addappid(336041, 1, "8297e9fcfd50457679d2191340e497f3d1d5e80f44624e8b4753a7162f2f291b")
