-- Lua provided by SkyAPI 
-- Game: Antipaint Demo
addappid(1898520)
addappid(1898521, 1, "885b0dfd3bf0ab2572f2c83826607fceb2857cd36d87efd12eb618911d09acd4")
