-- Lua provided by SkyAPI 
-- Game: Kill The Emperor
addappid(1507110)
addappid(1507111, 1, "d9a7672ef0f822658bb23996158137e7ba65b287210ce9c412cd20066cc8462c")
