-- Lua provided by SkyAPI 
-- Game: Zero One / 杀戮世界
addappid(1040610)
addappid(1040611, 1, "7ed381a784fd76bf3258bb84ce922933c41268cd0b964392d4c0509cedaa7445")
