-- Lua provided by SkyAPI 
-- Game: AppID 1069360
addappid(1069360)
addappid(1069361, 1, "59773e0a23268f1061ef470776bc99218337e0b5dd5ed17f06a8789ee0f6b584")
