-- Lua provided by SkyAPI 
-- Game: AppID 1009850
addappid(1009850)
addappid(1009851, 1, "84011b0d64e0221c3a99b1b5bb3225d90c53ae790ac8f4309b25729bdcfccf51")
