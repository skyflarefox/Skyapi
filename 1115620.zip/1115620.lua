-- Lua provided by SkyAPI 
-- Game: AppID 1115620
addappid(1115620)
addappid(1115621, 1, "512892100fe62b5f131a5dcf31389247ff14fd3b50f1587939ad0ed78066d2e6")
