-- Lua provided by SkyAPI 
-- Game: AppID 1104330
addappid(1104330)
addappid(1104331, 1, "8df331e8e4dda34da7b2945eb629fb5b7dceea04da5a994b40c5ae2e139c2a9f")
