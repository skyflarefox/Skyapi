-- Lua provided by SkyAPI 
-- Game: Dirty League Demo
addappid(3174270)
addappid(3174271, 1, "8253b83b7c7949a9dc9fb6d46b1560571a6a34e264c100838607cd1e3c5bd697")
