-- Lua provided by SkyAPI 
-- Game: AppID 816490
addappid(816490)
addappid(816491, 1, "cb76d79c10b3ed1c69cf9d62760751f572af36e166e02f14bb9f13296161a7e8")
addappid(816492, 1, "96bf52a55f2ead30c3d6d57df3dc4bb39e86ae5b5876a8e6ce718f54098aaaae")
