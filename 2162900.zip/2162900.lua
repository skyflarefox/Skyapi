-- Lua provided by SkyAPI 
-- Game: Antrabhara
addappid(2162900)
addappid(2162901, 1, "0877a46aaa6373c422e4132f85f94e083cc16797e9f59ef8aa301a132d9a39da")
