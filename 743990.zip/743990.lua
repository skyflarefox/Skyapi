-- Lua provided by SkyAPI 
-- Game: Private Detective Punch Drunk
addappid(743990)
addappid(743991, 1, "2fa2bd5f9b7c00594e60406b3306eb732cf423a41f13e581bf2af8245649d81b")
