-- Lua provided by SkyAPI 
-- Game: AppID 867420
addappid(867420)
addappid(867421, 1, "04dd1145544cae6cabf32c4dd5c25330ef9ee884a7f7c76a3b3c01f1482b5ed8")
