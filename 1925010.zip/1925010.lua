-- Lua provided by SkyAPI 
-- Game: Rich Lady's Slave Role Play
addappid(1925010)
addappid(1925011, 1, "5bf7f4b1cd0074d1a29eb4db0a15be6e08402d7f8c6197cddf4dc01be9e64099")
