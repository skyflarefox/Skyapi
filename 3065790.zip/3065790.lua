-- Lua provided by SkyAPI 
-- Game: JustFutanari 2 Demo
addappid(3065790)
addappid(3065791, 1, "d2394988a819ec37f57c498a5f0b04c3ffa659f359bdeae45db54b34b0c9c4ac")
