-- Lua provided by SkyAPI 
-- Game: AppID 741430
addappid(741430)
addappid(741431, 1, "b79d1256125799b0023995b24c624af325232358e75b3142eb025fcc20d4879d")
