-- Lua provided by SkyAPI 
-- Game: AppID 406090
addappid(406090)
addappid(406091, 1, "24a943f3fcff61fb045a034ae231385884f22fa7c8228f8d939657e871cef442")
