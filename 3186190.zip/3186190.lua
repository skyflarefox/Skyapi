-- Lua provided by SkyAPI 
-- Game: Tempus Triad DEMO
addappid(3186190)
addappid(3186191, 1, "cc946626bd7ce571ce7b6e8935bb984caae7337acebe397dba464ba7f911bf45")
