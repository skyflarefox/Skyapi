-- Lua provided by SkyAPI 
-- Game: Hello Neighbor 3 Playtest
addappid(2800890)
addappid(2800891, 1, "1e13264ed9b82a1c7454535dba0090c738059264ea87e77560023fbfc4c21c6e")
