-- Lua provided by SkyAPI 
-- Game: Ashes
addappid(654710)
addappid(654711, 1, "97af88454b4937440bdb6392a4623e0697d1aa04ac171b1527203e9cc1727ebb")
