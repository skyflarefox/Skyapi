-- Lua provided by SkyAPI 
-- Game: Cyber Slayer
addappid(2153410)
addappid(2153411, 1, "e789c660202f0ae9e7bf6a0fcff9f82faadf6f803920b9c7a1103fb4a10ddef7")
