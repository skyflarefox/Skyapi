-- Lua provided by SkyAPI 
-- Game: Odd||Even
addappid(455940)
addappid(455941, 1, "94ab8bbf4ee057fee051793ac50b52657edb04357c441fa6015f8ee6b8fc0103")
