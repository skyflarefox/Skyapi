-- Lua provided by SkyAPI 
-- Game: Girlfriend from Hell
addappid(2584650)
addappid(2584651, 1, "724272ea155b938e60455e859b6b1dc0ed567508943b0e047d0e077bcf9fec16")
