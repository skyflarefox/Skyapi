-- Lua provided by SkyAPI 
-- Game: Cozy Space Survivors
addappid(2657850)
addappid(2657851, 1, "2e86ebed4d6f4e41da543d9acf530d7e61f91c9bdbd4e59c194247cb8ed2da0e")
addappid(2966740)
