-- Lua provided by SkyAPI 
-- Game: 希望 Demo
addappid(2390210)
addappid(2390211, 1, "829f15a8cea6171f1819f3f022c9f450b40d24b46f4ca0fbe7dc381dfa91fd53")
