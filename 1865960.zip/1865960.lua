-- Lua provided by SkyAPI 
-- Game: Symphonia
addappid(1865960)
addappid(1865961, 1, "dbc805144c65b0d9d7e0894a0065ec39573d8f77c3e96581a2007755bb9e5b68")
