-- Lua provided by SkyAPI 
-- Game: AppID 3101830
addappid(3101830)
addappid(3101831, 1, "ca868b8476162a974cc57797ac859e05a5c08523996e98d074a0351de7c900e3")
