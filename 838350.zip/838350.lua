-- Lua provided by SkyAPI 
-- Game: The Scroll of Taiwu : Beyond The Dome
addappid(838350)
addappid(838351, 1, "7de3577779d63fd52db715a1898f8353eb0f5f4096ab3391f77b582621e1adb8")
addappid(946970, 0, "6eb479723fd905892e55add18fe531a67b7e3c42595302faa5685e47fd7603c3")
