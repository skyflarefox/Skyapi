-- Lua provided by SkyAPI 
-- Game: Like an Angel
addappid(1671510)
addappid(1671511, 1, "978f25aa58e40068072d3c34ee89eed9835ed958f07edbce254e196e44d51c64")
addappid(1965420, 0, "52f0fc9f930c3cb973760af5362a8fc42c7765ae96670d47ef53cd3a93d2ea16")
addappid(2066910, 0, "8ff87cc3c494c517f80489e57c018b420d152e074c712d94ad77d8d1edce70e4")
