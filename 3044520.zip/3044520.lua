-- Lua provided by SkyAPI 
-- Game: Coffee Express: Barista Simulator
addappid(3044520)
addappid(3044521, 1, "941364f880d94742096177f2aadde439ffa84c8e62f479b3690d397d2d3ac8aa")
