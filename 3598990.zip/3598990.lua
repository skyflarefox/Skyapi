-- Lua provided by SkyAPI 
-- Game: Zonark
addappid(3598990)
addappid(3598991, 1, "fc8f6f66c671d44475ad47909fdf3d1a136dd15da4f05b13528e6a387b871c88")
