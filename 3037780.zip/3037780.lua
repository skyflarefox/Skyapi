-- Lua provided by SkyAPI 
-- Game: AppID 3037780
addappid(3037780)
addappid(3037781, 1, "987c9c5efeccd53a760f2e51e9e5bf60a223d2d0458861ed86e4fae4df18a750")
