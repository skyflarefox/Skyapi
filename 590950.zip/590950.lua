-- Lua provided by SkyAPI 
-- Game: AppID 590950
addappid(590950)
addappid(590951, 1, "3ed968d75cbe5fc8f8e57b12013444739eb40f7cecd93b0ecd1497b9380a0120")
