-- Lua provided by SkyAPI 
-- Game: Recursion Deluxe
addappid(425160)
addappid(425161, 1, "353a91aaabe1a46351ad67044a04ae9a9500bf4dbedbc5f03e9c27a1106f019c")
addappid(425162, 1, "6da235700de2459534b4c473e3597ab289f6481f78e2068d35a67d5e45c4df2d")
addappid(425163, 1, "495efc6c8a152b252e12eec67d249abf3d5c165fa6128b2d1f234ca914ba4da8")
