-- Lua provided by SkyAPI 
-- Game: AppID 687730
addappid(687730)
addappid(687731, 1, "378400317862015fa337980667d7d10dd3619ca0fc31da0ee3884ae66a494c7e")
