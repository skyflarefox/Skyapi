-- Lua provided by SkyAPI 
-- Game: Touhou Chireiden ~ Subterranean Animism.
addappid(1100150)
addappid(1100151, 1, "b048c2a00cf76bf14ce58f855c649cdf79144acabcc068ba7e3eba42a9cdd521")
