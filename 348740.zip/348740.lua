-- Lua provided by SkyAPI 
-- Game: Abyss Cave
addappid(348740)
addappid(348741, 1, "35abb4b74a613dde37af5c8dbf796c23a830fdcf908554d3ab1d72fc824183bf")
