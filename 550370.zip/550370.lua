-- Lua provided by SkyAPI 
-- Game: AppID 550370
addappid(550370)
addappid(550371, 1, "17c682540546304467c01fe6fffe89fc0435ac691f329a8bbfba132136b3d227")
