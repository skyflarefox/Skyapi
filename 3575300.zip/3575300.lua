-- Lua provided by SkyAPI 
-- Game: Climb The Backrooms
addappid(3575300)
addappid(3575301, 1, "a8508e96a50b632f23973925f12fae84e58888a316c10b415ee7225c41530bc4")
