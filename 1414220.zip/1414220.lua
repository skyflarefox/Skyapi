-- Lua provided by SkyAPI 
-- Game: POPPIN' DONUTS
addappid(1414220)
addappid(1414221, 1, "acaea0a6802a0c35b611fe5ba785cc562aff17344548bc2ad533f101edb84f86")
