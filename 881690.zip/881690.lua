-- Lua provided by SkyAPI 
-- Game: The Slater
addappid(881690)
addappid(881691, 1, "4e9b6c88c53adcdc26258732da448fb1472ff02f68db48caf85f74bf58d2eb87")
