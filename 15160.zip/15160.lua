-- Lua provided by SkyAPI 
-- Game: Petz® Horsez® 2
addappid(15160)
addappid(15161, 1, "d32c4c5b73800bc162a3d19440c8b78817b274f0ad8ddb8788aaf9e6df0b4382")
addappid(15162, 1, "d22ac806602e7290cb667ac7d402d3a0a65c1fedbd4087960d23da712b47c473")
addappid(15163, 1, "4d113b80f4535725865003acabf78995f447bea9bb98c08439eafd4af08dcf44")
