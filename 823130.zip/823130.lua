-- Lua provided by SkyAPI 
-- Game: Totally Accurate Battlegrounds
addappid(823130)
addappid(823131, 1, "7e190008c73c1ad83bd9b89becea2318a43d57e0a849b355377323220e91e791")
