-- Lua provided by SkyAPI 
-- Game: We Need Space
addappid(2929180)
addappid(2929181, 1, "323a1e1abfea503c6da82274b5c5b74e73f9e83aa46464a2400611d7a31e31c3")
