-- Lua provided by SkyAPI 
-- Game: X4: Cradle of Humanity Soundtrack
addappid(1288490)
addappid(1288491, 1, "70bffd1e69bc22fa2799082f19aa9842897134e77cb4c638a7d58f9c85d229f5")
