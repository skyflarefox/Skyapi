-- Lua provided by SkyAPI 
-- Game: Forklift Load
addappid(1392490)
addappid(1392491, 1, "b3f990c18b38ca9011f6941e5e0feb21bc1c2030671f6355247c9874c373a21b")
