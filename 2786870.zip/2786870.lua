-- Lua provided by SkyAPI 
-- Game: Ninjurate
addappid(2786870)
addappid(2786871, 1, "5a3c31ae8a1ff49d740b81f3a2de2f5f722e1968aad1be1ba678684514447ce6")
