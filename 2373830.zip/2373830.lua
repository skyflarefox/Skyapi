-- Lua provided by SkyAPI 
-- Game: Hyper Hentai Sister Nun
addappid(2373830)
addappid(2373831, 1, "b4299c05dad3377ae0b03edefcc543fdf68c6f3f9c8e7b9ed0c18b4ae728bd11")
