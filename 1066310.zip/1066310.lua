-- Lua provided by SkyAPI 
-- Game: AppID 1066310
addappid(1066310)
addappid(1066311, 1, "8c355e397a7d76c071cd5776e01a3d96298dd5424c0fa42003a0f408a66dedcc")
