-- Lua provided by SkyAPI 
-- Game: AppID 312540
addappid(312540)
addappid(312541, 1, "dd9c05ef0f0bb0d596e0e5c0313f1b9893cd5529688ac1e26ad5f24938f6c334")
addappid(365010, 0, "0e8a316b2725564fc35ddc0e6d1c6f562bc057471214f232f3f6b4f3d5d79aec")
