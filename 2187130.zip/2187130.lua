-- Lua provided by SkyAPI 
-- Game: Rabat Protocol:Metal Rhapsody
addappid(2187130)
addappid(2187131, 1, "1964502ab68b3514d8ca6b19e10ee30de32f8309c2fc7b157c232d5f29b0ac76")
