-- Lua provided by SkyAPI 
-- Game: AppID 2211850
addappid(2211850)
addappid(2211851, 1, "478648686c4630bf0e57b21aeccbd56961851fbb43b1e10204f9518cda4e54ba")
