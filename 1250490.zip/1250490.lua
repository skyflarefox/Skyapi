-- Lua provided by SkyAPI 
-- Game: AppID 1250490
addappid(1250490)
addappid(1250491, 1, "a54e7957e3d9ad0b4e4fdb0e74997223088812042b8fb59da164980c05af5c5a")
addappid(1250492, 1, "0f4df2f53bb3e9a993741fbf7e2629bdc0d9e47ee12b972c085be7e57050edf2")
