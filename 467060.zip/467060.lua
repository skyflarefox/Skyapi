-- Lua provided by SkyAPI 
-- Game: Dead Army - Radio Frequency
addappid(467060)
addappid(467061, 1, "a013f2408904521656e34dcfba7b998dc43621b90402f4c9de1d0f63f0d46461")
