-- Lua provided by SkyAPI 
-- Game: Shape of Clouds
addappid(2717120)
addappid(2717121, 1, "795d2adfa3e22ace6c92f6f625466d4144d7415aa6f17ee645c4ff273458fce4")
