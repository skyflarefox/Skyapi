-- Lua provided by SkyAPI 
-- Game: AppID 2828890
addappid(2828890)
addappid(2828891, 1, "a788fd3f8c5dd983ea26b754fa21ea0617829a6756bc316b9d36d107d3e0e32a")
