-- Lua provided by SkyAPI 
-- Game: Halfway Home
addappid(950250)
addappid(950251, 1, "933cd49199ad70a20147495e90bd78843b68afb203f017673415121925ddf16c")
