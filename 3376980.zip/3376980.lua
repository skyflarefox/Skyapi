-- Lua provided by SkyAPI 
-- Game: AppID 3376980
addappid(3376980)
addappid(3376981, 1, "260672f2c3670e2b727c57dca9d368ad7dfb33004e034796ead2deecc3eeb7f2")
