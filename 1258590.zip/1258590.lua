-- Lua provided by SkyAPI 
-- Game: Locked Up
addappid(1258590)
addappid(1258591, 1, "fff6c0c36eb6188ae8b8bf36a0017622a398a2e9574f2656f8b7731cfe356cdc")
