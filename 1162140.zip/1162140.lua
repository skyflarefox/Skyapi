-- Lua provided by SkyAPI 
-- Game: Rise Of The Overlords
addappid(1162140)
addappid(1162141, 1, "f6a9a52eb4ee4743ed5f92b1f5b0f4819911eb9ac6daea06cd6e137c82417799")
addappid(1162142, 1, "df7140dc9c8ddd04cf5313fe34d784236123fb8b04760688122acf17791ce545")
