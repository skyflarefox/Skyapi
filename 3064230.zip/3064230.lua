-- Lua provided by SkyAPI 
-- Game: Castle of Vania
addappid(3064230)
addappid(3064231, 1, "b399bf0273bbc62a3a3505045e5d4a7e692e2c3382022da7a7cf89af29b63ca1")
