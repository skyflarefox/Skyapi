-- Lua provided by SkyAPI 
-- Game: Smoots Golf
addappid(1601360)
addappid(1601361, 1, "7a8e3431e763a2c8316a7a2e2f0e88d7b5641edc9534f141fe8bff07e7be4a15")
