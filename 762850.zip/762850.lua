-- Lua provided by SkyAPI 
-- Game: AppID 762850
addappid(762850)
addappid(762851, 1, "cb999d9f22f986e2529497fae26cf51dce335351122c73a89a7313c239c274bf")
