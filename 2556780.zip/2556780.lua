-- Lua provided by SkyAPI 
-- Game: Crow Country Demo
addappid(2556780)
addappid(2556781, 1, "519094aed878c5a394fbeb128e8b54744ff77c54b389032029245edbc2345a99")
