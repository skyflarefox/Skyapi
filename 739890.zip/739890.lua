-- Lua provided by SkyAPI 
-- Game: AppID 739890
addappid(739890)
addappid(739891, 1, "e1e6b86cc6f01d8708e03c2334778eff7dc302b33662e40a46f7b12b81d105cd")
