-- Lua provided by SkyAPI 
-- Game: 7 days with Death
addappid(617820)
addappid(617821, 1, "a15562b94c07f9efe7eb352c212bf97fcb20b57165af49f93de7ab7cedf02027")
addappid(617822, 1, "3291c457f112b5b17e486978d1cbdc6d8ed57997bb0397ea28dbe408d7863135")
addappid(617823, 1, "f567437fd0488751550748215e296fcdb7e07de8ff8e3e3abe41560177aa150d")
