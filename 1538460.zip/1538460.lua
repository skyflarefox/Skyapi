-- Lua provided by SkyAPI 
-- Game: Sword and Fairy 2
addappid(1538460)
addappid(1538461, 1, "9d5ae3fcf793574ed5a5d0e0ee9ffc526c91a0c0b95e77a39100e3fda5fbb054")
