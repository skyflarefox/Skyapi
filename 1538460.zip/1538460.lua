-- Lua provided by SkyAPI 
-- Game: Sword and Fairy 2
addappid(1538460)
addappid(1538461, 1, "9d5ae3fcf793574ed5a5d0e0ee9ffc526c91a0c0b95e77a39100e3fda5fbb054")
addappid(1538462, 1, "ad823a4aacde2e2ee5f3a2b585e73b5dbef963a49af5d6ab1194f4decfbb6b2b")
addappid(1538463, 1, "a501f31f3997b12db64d134135bec6724a34ac9a931af2b9bfec8e706fa9bc92")
