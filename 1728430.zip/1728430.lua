-- Lua provided by SkyAPI 
-- Game: I wanna go home
addappid(1728430)
addappid(1728431, 1, "a42b1558af5ea91e2cff23732593b2d9bb1ff21ae1ec1e5ba9b1ac7a2779fc01")
