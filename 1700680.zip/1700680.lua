-- Lua provided by SkyAPI 
-- Game: Ki11er Clutter
addappid(1700680)
addappid(1700681, 1, "0f7dc3c8cb2bb5bea55e087b29b48a04c8e1d7f1196cbf6de0b53008a1a2a1c5")
