-- Lua provided by SkyAPI 
-- Game: Armored Fist 3
addappid(32710)
addappid(32711, 1, "7404662c3565bd675d9421cfa4abb7be05b818f3c7f8ffeaa4a09f4b1d573fef")
