-- Lua provided by SkyAPI 
-- Game: BEN’S WORLD
addappid(1850020)
addappid(1850021, 1, "28ff1e0636f406dc336819d32340045232eca7d836a78523d57d29d391db82ef")
