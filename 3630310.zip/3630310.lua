-- Lua provided by SkyAPI 
-- Game: Boom Buddy
addappid(3630310)
addappid(3630311, 1, "76077dbe7b37758d8919b7f72ee9f2b51e247bba21f73c1416a63a02a8257eb0")
