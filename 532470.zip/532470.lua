-- Lua provided by SkyAPI 
-- Game: AppID 532470
addappid(532470)
addappid(532471, 1, "6c2009253f00458a155d5f4d7563f1ebe4fcf99212d0ba4a8da0f5762b7fa51e")
