-- Lua provided by SkyAPI 
-- Game: DON'T GET GOT
addappid(3467390)
addappid(3467391, 1, "d769b93bc7b7673f275578e14381fe841526329c8e4847fc45b52b047d577651")
