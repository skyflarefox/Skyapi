-- Lua provided by SkyAPI 
-- Game: AppID 1774800
addappid(1774800)
addappid(1774801, 1, "19e43611a91d466cf75f5bf3b2a362c1f9b0d6114f8bca2de938db867916939d")
