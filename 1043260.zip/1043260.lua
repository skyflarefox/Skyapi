-- Lua provided by SkyAPI 
-- Game: Gladiator Guild Manager
addappid(1043260)
addappid(1043261, 1, "8c865483c01f4bb7399ff967ccfc9a7e110d62a197a7fd9ecf4792f5d9c3fe66")
