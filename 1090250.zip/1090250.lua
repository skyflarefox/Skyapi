-- Lua provided by SkyAPI 
-- Game: Crunch Element
addappid(1090250)
addappid(1090251, 1, "fb2d64153fd2c15477f5180013ccdb688ec4728a362ed33fc7c6bda9b1302f65")
