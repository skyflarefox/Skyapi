-- Lua provided by SkyAPI 
-- Game: Living Cell
addappid(2380310)
addappid(2380311, 1, "cad31d7ee36d89608222e1cb60ac982068a768c93b51a132ffa27b09183d32fa")
