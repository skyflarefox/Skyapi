-- Lua provided by SkyAPI 
-- Game: Brother & Sister
addappid(1041760)
addappid(1041761, 1, "6d4badc705637c0db5cbdc373d28b83a9eee37025a7cb22a6dd2a82bb2d25ef0")
