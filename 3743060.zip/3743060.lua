-- Lua provided by SkyAPI 
-- Game: VrmFrontView
addappid(3743060)
addappid(3743061, 1, "df95bc9c494d747ce41642b9ab3e298db482b274344095b7e8497ba1d6238395")
addappid(3744500)
