-- Lua provided by SkyAPI 
-- Game: MELIGO Creator
addappid(2138250)
addappid(2138251, 1, "3110a1a93b130f3621b19e94bec65a575d5df5e55feb41fd55e131178c3b978a")
