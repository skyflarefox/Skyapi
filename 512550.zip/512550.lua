-- Lua provided by SkyAPI 
-- Game: Cursed West
addappid(512550)
addappid(512551, 1, "d86832fa53846a3128a143e986fa4db1956fec597191a3e648b647c9fcade99f")
