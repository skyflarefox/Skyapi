-- Lua provided by SkyAPI 
-- Game: Paintball
addappid(1836240)
addappid(1836241, 1, "d61ed39099fb6b4473061986e4095fd814e8b193c84e6a492424d7a1faec86d1")
