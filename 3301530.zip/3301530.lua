-- Lua provided by SkyAPI 
-- Game: Boogey Hunters
addappid(3301530)
addappid(3301531, 1, "cf50470295e9097e0642fa7929a96921ddee3f23bb1b09ecb34b4d87a688955c")
