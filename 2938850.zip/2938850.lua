-- Lua provided by SkyAPI 
-- Game: Sakura Hime 5
addappid(2938850)
addappid(2938851, 1, "1970b0626ef95215f32c3baa51f78e1a5e90b91244b9d190abba18e4ba46f230")
addappid(3421600, 0, "e870b19ee706b50ed6a9e679272e16208e3461fd77176457a80a333a847651e0")
