-- Lua provided by SkyAPI 
-- Game: Oboi
addappid(3571700)
addappid(3571701, 1, "1f5b0a96116b5c7bc3423606ef0836ef628b65039241223dc3d43ee0188aee1b")
