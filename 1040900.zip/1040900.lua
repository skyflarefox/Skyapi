-- Lua provided by SkyAPI 
-- Game: AppID 1040900
addappid(1040900)
addappid(1040901, 1, "c827008ed5ad93b0cd37eca13bcdcfa6eba30fd6f9d40157a1b47c83f8461f2d")
addappid(1040902, 1, "758966833388bc9bb31b5b0c039910d01c322d58eef017f64ab116a9edffa676")
