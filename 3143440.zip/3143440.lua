-- Lua provided by SkyAPI 
-- Game: AppID 3143440
addappid(3143440)
addappid(3143441, 1, "f1f9c8285f2d42e6da69e1487ea2eb3a3e8cd0d17691cd2cd700c9a8c2dec051")
