-- Lua provided by SkyAPI 
-- Game: Another_World
addappid(1246390)
addappid(1246391, 1, "cd10ee84512b1080a98ae279aea4eb04f5a6e1561e13e17b5ef4bf496900cb7b")
