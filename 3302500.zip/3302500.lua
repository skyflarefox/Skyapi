-- Lua provided by SkyAPI 
-- Game: Liquidator
addappid(3302500)
addappid(3302501, 1, "fe75d3fe06dd144ed9beb8d98e864e9b0d05029fe4969910d443420af73d0785")
