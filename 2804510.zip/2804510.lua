-- Lua provided by SkyAPI 
-- Game: 重生了还要我谈恋爱？
addappid(2804510)
addappid(2804511, 1, "56f96df0083f4a5df472f862a7d457b0e2a6b295e0c128184caf71f427eb4303")
