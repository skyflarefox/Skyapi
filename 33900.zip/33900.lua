-- Lua provided by SkyAPI 
-- Game: Arma 2
addappid(33900)
addappid(33901, 1, "c07cec672c1aa48a1493532ec6a9e04a5f351ce1d1445f8eb98ba8c93ff5fa27")
addappid(33902, 1, "d38d4094b44356928935645d092118615ea6bdd2d833474c272cc64cd5a4853e")
addappid(33904, 1, "ecdc75cdb4173caa93b8847601363c1ff3a2d65392118acce45aeafe4e45aa61")
addappid(33934)
