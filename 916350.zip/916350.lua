-- Lua provided by SkyAPI 
-- Game: Saturnalia
addappid(916350)
addappid(916351, 1, "29dbd3f9b942a3f2f2e869e14ebe946005d6cc160c536aa8a7a73d4627e0d6b5")
