-- Lua provided by SkyAPI 
-- Game: AppID 1255130
addappid(1255130)
addappid(1255131, 1, "6ee4901042eec350edb962354ec01cbd097963f75c4bc1e98a0797ccc9d00876")
