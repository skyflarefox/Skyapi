-- Lua provided by SkyAPI 
-- Game: Strip 4: Classmate Study
addappid(1221080)
addappid(1221081, 1, "aa4eb5d30ed2e62083c8d732a8dfa4a488d232ecb5886435bfbfdb648b22dff7")
