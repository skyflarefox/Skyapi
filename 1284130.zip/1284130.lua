-- Lua provided by SkyAPI 
-- Game: Sclash
addappid(1284130)
addappid(1284131, 1, "a604d50f75a0675f747be39102eb134964d12c5bb741294aeae199e4cd07acdf")
