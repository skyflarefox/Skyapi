-- Lua provided by SkyAPI 
-- Game: AppID 2215540
addappid(2215540)
addappid(2215541, 1, "03cd94d2ff58a23b74b6d3d6a547211759e1f9ee22185a98a3b5e221909745c3")
