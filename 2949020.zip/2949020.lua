-- Lua provided by SkyAPI 
-- Game: Drifto: Infinite Touge
addappid(2949020)
addappid(2949021, 1, "363287db8d9e0d85db9972e5e7d6d3f1cd88f2f2adef8d52b799c91b8f3896e6")
