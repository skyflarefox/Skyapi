-- Lua provided by SkyAPI 
-- Game: Flushed
addappid(3600040)
addappid(3600041, 1, "762b14f068bb088b1a426ef1914836b53f93d8f56eae56bc64408fef73f5670c")
