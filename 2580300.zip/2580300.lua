-- Lua provided by SkyAPI 
-- Game: SNIPERPUNK Playtest
addappid(2580300)
addappid(2580301, 1, "371137b10dd868723c0680a3888ca9c3370756964b5b805a3791ed08d7121cc7")
