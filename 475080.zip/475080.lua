-- Lua provided by SkyAPI 
-- Game: AppID 475080
addappid(475080)
addappid(475081, 1, "96c4ccb619c4c745c88e50bb5defafb1c1eed2bbbd6df76988d7df0c3e956602")
