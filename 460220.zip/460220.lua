-- Lua provided by SkyAPI 
-- Game: AppID 460220
addappid(460220)
addappid(460221, 1, "728a149205810867f1e60a117d8a30387d89831959d2d49582fc33515ce7413b")
