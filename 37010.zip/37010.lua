-- Lua provided by SkyAPI 
-- Game: Ninja Blade
addappid(37010)
addappid(37011, 1, "a0b4f5506c00db9a03b6c5318d6d10995d2b4459b633be4177ebb4a29a2700a8")
