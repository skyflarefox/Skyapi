-- Lua provided by SkyAPI 
-- Game: Timmy the Tiger's Big Adventure
addappid(1791090)
addappid(1791091, 1, "5eaef1c7c9926500c82ed3f588fca921a685940aad63a90cc06f02492f303cc7")
