-- Lua provided by SkyAPI 
-- Game: FIGHTING GIRL YURI  Demo
addappid(3129890)
addappid(3129891, 1, "d73e833b4fa00e5fd0c801160157ee83e1a9512445436dd713463886744d534a")
