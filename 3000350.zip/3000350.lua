-- Lua provided by SkyAPI 
-- Game: AppID 3000350
addappid(3000350)
addappid(3000351, 1, "ad28e076ea4e90fbdcf46c12fbac899eb29302007a72b2e7649399a81f068cde")
