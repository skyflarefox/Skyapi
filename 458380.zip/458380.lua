-- Lua provided by SkyAPI 
-- Game: AppID 458380
addappid(458380)
addappid(458381, 1, "ec33d646d2cb242a3c7931bf3dc7e8a8682c143f404b577b454eb972b3e66b1e")
