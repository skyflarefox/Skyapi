-- Lua provided by SkyAPI 
-- Game: AppID 2218690
addappid(2218690)
addappid(2218691, 1, "2d167273098375cc53fc16efa1ee1048d91799117cb6b9dfb1e73585fa33a5a6")
