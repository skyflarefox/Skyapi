-- Lua provided by SkyAPI 
-- Game: Farm and Girls
addappid(1782270)
addappid(1782271, 1, "f852edad85280fdc301f2316909477b05ceea44f136ffc85637c3c58a58ce13d")
