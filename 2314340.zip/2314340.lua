-- Lua provided by SkyAPI 
-- Game: HEROIC
addappid(2314340)
addappid(2314341, 1, "f9e8ff30b54a64b83d67ded0cec7ca880c2b0c0eac933fbd68e4b6bce34f6f5c")
