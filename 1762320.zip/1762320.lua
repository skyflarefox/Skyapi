-- Lua provided by SkyAPI 
-- Game: AppID 1762320
addappid(1762320)
addappid(1762321, 1, "e190ef485f4b1dc7e85a032312c4afafdd485e703e33b853c31749d723c9d3c8")
