-- Lua provided by SkyAPI 
-- Game: AppID 3023940
addappid(3023940)
addappid(3023941, 1, "ced5f4563b2417eed94dcd8f33beb8a4571aa048b52502e30671723913576eff")
