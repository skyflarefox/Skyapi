-- Lua provided by SkyAPI 
-- Game: SOLAR CAGE
addappid(1795640)
addappid(1795641, 1, "3f0446fa18f073e697b6592489a9324662d1ca83b0aba487d164f5dd328230c1")
