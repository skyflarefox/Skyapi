-- Lua provided by SkyAPI 
-- Game: Guts and Syringes
addappid(654800)
addappid(654801, 1, "3b3f64b9b3d442bf61ce7be114a04890aecb8d2a4572d1b38393ea0888614863")
