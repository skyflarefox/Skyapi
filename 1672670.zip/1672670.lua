-- Lua provided by SkyAPI 
-- Game: AppID 1672670
addappid(1672670)
addappid(1672671, 1, "c533a45a4e94ed704c34ee330d6f2e5f2969396d60b213688ea5218eb06efcf8")
