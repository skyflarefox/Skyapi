-- Lua provided by SkyAPI 
-- Game: Plague Lords Playtest
addappid(3064220)
addappid(3064221, 1, "93e01c84b0d21576032723c62d85b643b9c8bbcf6b6f38e5db5afe59d11e9c20")
