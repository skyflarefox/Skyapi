-- Lua provided by SkyAPI 
-- Game: AppID 1358540
addappid(1358540)
addappid(1358541, 1, "528a5538360c2a8d0e00d991325075baa5bf2cb197e580286924277b97b79b40")
