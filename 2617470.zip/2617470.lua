-- Lua provided by SkyAPI 
-- Game: AppID 2617470
addappid(2617470)
addappid(2617471, 1, "fdc064333ed4c287e86a5ab2744d14841dd094007c40b333ae38471e98b67597")
