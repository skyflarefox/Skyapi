-- Lua provided by SkyAPI 
-- Game: AppID 2441700
addappid(2441700)
addappid(2441701, 1, "0d9c8c4dd6db3f468e5e8dde720c2d0842f7daf071cba1a5ad84a8ef3b78b701")
