-- Lua provided by SkyAPI 
-- Game: AppID 1785700
addappid(1785700)
addappid(1785701, 1, "936c359ec9a2a7fd7ce9867e12eb57fe95b6e6a3ddd848add5c4accdcff76cb3")
