-- Lua provided by SkyAPI 
-- Game: AppID 1189490
addappid(1189490)
addappid(1189491, 1, "b4468979ad10a0c235601089f984963e8f85ec0305bb91a8968ac7017f9f9e89")
