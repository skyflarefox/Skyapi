-- Lua provided by SkyAPI 
-- Game: AppID 1245980
addappid(1245980)
addappid(1245981, 1, "7ddf03e710ca12f4be300e9eaf6c1c7497cd08ad450d169ebca45b0479eb3d64")
