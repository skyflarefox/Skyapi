-- Lua provided by SkyAPI 
-- Game: Terranny
addappid(2131150)
addappid(2131151, 1, "d012689d59379055228c03576e5f34d1cb840b75a570c7c14d22eccac72287c3")
