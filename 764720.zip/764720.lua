-- Lua provided by SkyAPI 
-- Game: AppID 764720
addappid(764720)
addappid(764721, 1, "a286cd5a5e3a2154228315b29a9dcefc6e711d8561780b106716554500b9105c")
