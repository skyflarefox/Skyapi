-- Lua provided by SkyAPI 
-- Game: AppID 1712650
addappid(1712650)
addappid(1712651, 1, "d229ecda10c60cdd6e9205439508c8a90535fecf5fd5c4a242260c6bc025b2fb")
