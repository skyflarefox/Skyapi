-- Lua provided by SkyAPI 
-- Game: Smoked Gun
addappid(1506720)
addappid(1506721, 1, "80e6fec17a71c07c4ac77688c72dcd80142be3a54059397900c61f6e1fc5d4d4")
