-- Lua provided by SkyAPI 
-- Game: AppID 669320
addappid(669320)
addappid(669321, 1, "fe0c65ee64f065479e6ac4020905e66a33e8b2a9514a009d873e8dda708af249")
addappid(669322, 1, "2046fccc30d6b24d5801c9c91c74ade30e9e43b69fe67fa263d10ce519ccb096")
