-- Lua provided by SkyAPI 
-- Game: Football Pitch Simulator
addappid(3154800)
addappid(3154801, 1, "7f03d2f837b27b236e6df6bce387eba1ae4b46d90c9fe62622775ad7c6b30e6c")
