-- Lua provided by SkyAPI 
-- Game: Spectrubes
addappid(447990)
addappid(447991, 1, "dc7cf18dad16628102a0b851943479af3a90ca921f8dbfe031f0cfa914b39202")
addappid(447992, 1, "a6d3066e42b2e723cf326e5f87ab0509c18cd9cadf33cf048f7dcccd6a38cbd1")
addappid(447993, 1, "1b0ce98c1cb1f551a3f9cf4818d799b115d9a303ac515e590f5d46b9315d1ba2")
