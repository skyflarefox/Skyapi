-- Lua provided by SkyAPI 
-- Game: Split Brain
addappid(3156640)
addappid(3156641, 1, "4d2a736692832b5c26486da735a09dbfa2ada6cf9d549277dcaeb9553017027c")
