-- Lua provided by SkyAPI 
-- Game: BrokenLore: UNFOLLOW
addappid(2133830)
addappid(2133831, 1, "e5d1c8cd2921865aae9a3dff027d32e0cba6b6d61f5c0b3e315a954180c73bb5")
addappid(4114580)
