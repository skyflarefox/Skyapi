-- Lua provided by SkyAPI 
-- Game: VTuber Beats Demo
addappid(2467440)
addappid(2467441, 1, "2ebe44bfae24e9ca43982409265127713b1e2adffcf7b143d10042e4d87c7552")
