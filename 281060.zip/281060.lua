-- Lua provided by SkyAPI 
-- Game: Reversion - The Meeting (2nd Chapter)
addappid(281060)
addappid(281061, 1, "628a10e6f051a0c39b2c3a7cde8f510c684de8925e21b6a41d21db2f290f2ac2")
addappid(281062, 1, "f1ade44f10fcc30f6b310a86b8f46d869510c446662c54492c7f7a8644b1707d")
addappid(281063, 1, "14b50306ce7ea3a202fae409c6b195162897aa500c816fc858b9db7392631b3f")
addappid(970410)
