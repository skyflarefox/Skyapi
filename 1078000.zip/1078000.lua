-- Lua provided by SkyAPI 
-- Game: Gamecraft
addappid(1078000)
addappid(1078001, 1, "218ea3818c0da0a44279fb4cb5782ee6502822ccf9730e9c43fc6b24af8ddc98")
