-- Lua provided by SkyAPI 
-- Game: Scarred
addappid(2447100)
addappid(2447101, 1, "45664cca6484d1396e655d45793115e26c623b3a3c649ee69c21b48817acc834")
