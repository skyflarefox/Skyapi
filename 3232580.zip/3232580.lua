-- Lua provided by SkyAPI 
-- Game: Medieval Legacy
addappid(3232580)
addappid(3232581, 1, "b96990e834aafc7731a6ef24150eecc00337eee048f876c7253ff30f2ddba1da")
