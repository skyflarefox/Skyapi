-- Lua provided by SkyAPI 
-- Game: Space Runaway
addappid(2125250)
addappid(2125251, 1, "a5058c48116c51835eda3c1c022a586b4c60690a98091d83ad02c68b0a973a60")
