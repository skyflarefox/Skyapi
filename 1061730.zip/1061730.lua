-- Lua provided by SkyAPI 
-- Game: Super Monkey Ball: Banana Blitz HD
addappid(1061730)
addappid(1061731, 1, "2c82b4ee2bda3fffea8a8525d3098f4d2c004bdc9fdb8ccd036927753a873249")
