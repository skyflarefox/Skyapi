-- Lua provided by SkyAPI 
-- Game: Escape Gaia
addappid(3103970)
addappid(3103971, 1, "8304648da42e828d06b628c3ee68317171ccfc7861641d085caa9b5e838234b2")
