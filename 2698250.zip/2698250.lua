-- Lua provided by SkyAPI 
-- Game: CRAZY DOG DEMO
addappid(2698250)
addappid(2698251, 1, "5103396ad1f7cf457eb7f78619c4610bc11f08728828b879b7790f521e2b635c")
