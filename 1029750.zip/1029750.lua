-- Lua provided by SkyAPI 
-- Game: Voipas
addappid(1029750)
addappid(1029751, 1, "6933d3b20275b1839b689f33453d944e5d572a582da10a88abcec99bf5fd1e75")
