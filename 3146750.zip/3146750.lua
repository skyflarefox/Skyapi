-- Lua provided by SkyAPI 
-- Game: The Black Labyrinth Demo
addappid(3146750)
addappid(3146751, 1, "5001d2b7f027b73580ab693a086fe88b98357a5be3469a2768cfe5904fc7d0be")
