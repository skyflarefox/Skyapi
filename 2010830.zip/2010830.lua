-- Lua provided by SkyAPI 
-- Game: AppID 2010830
addappid(2010830)
addappid(2010831, 1, "6d19969a3a15e68565b161f41243a10fca5085ee00d6615c356c5f6fc8a7eb83")
