-- Lua provided by SkyAPI 
-- Game: AppID 381590
addappid(381590)
addappid(381591, 1, "d8cdaac5d137736a2ae5a28188619ee7ce4600cb091d1773424ac0694e08212d")
