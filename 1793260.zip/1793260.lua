-- Lua provided by SkyAPI 
-- Game: Delivery INC
addappid(1793260)
addappid(1793261, 1, "b0a5ea220d3ed5f402e74a255ee21ec59d0d293bdf134232a3d5ef49405d7968")
