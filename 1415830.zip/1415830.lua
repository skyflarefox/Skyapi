-- Lua provided by SkyAPI 
-- Game: Necrosis
addappid(1415830)
addappid(1415831, 1, "aa982cc55c498891d9a237c17c395c57e009b5348070397a3f4d3d76debae522")
