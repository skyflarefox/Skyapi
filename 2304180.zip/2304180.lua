-- Lua provided by SkyAPI 
-- Game: Gyno Tales - Season 1
addappid(2304180)
addappid(2304181, 1, "18528a406bf635988afac5a01f61eb19cc3e006afab755645b394689b4c78911")
