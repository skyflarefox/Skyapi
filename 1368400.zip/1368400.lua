-- Lua provided by SkyAPI 
-- Game: AppID 1368400
addappid(1368400)
addappid(1368401, 1, "79337f2bd8044f9292107110a6f4abad130d6512469ba299397d38b4569095f3")
