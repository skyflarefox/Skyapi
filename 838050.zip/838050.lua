-- Lua provided by SkyAPI 
-- Game: AppID 838050
addappid(838050)
addappid(838051, 1, "00a5e4b1e39643264b71a8aeb336990f66c93dad50019ecdd6945361229b7654")
addappid(838250)
addappid(838251)
