-- Lua provided by SkyAPI 
-- Game: CivCity: Rome
addappid(3980)
addappid(3981, 1, "4dc4c0856e36f84127359a63427c2a3a2208f3126ce6134950c47dae948bdee0")
addappid(3982, 1, "5d770065cc0f68357cdbe6da7bd7d7122a8b93a07a9f5cfb447aab155416535a")
addappid(3983, 1, "b43dfb7222b4ed46fe41d883886c3e5eba40fcba66cd9489a590a2b23581a06d")
