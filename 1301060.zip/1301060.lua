-- Lua provided by SkyAPI 
-- Game: AppID 1301060
addappid(1301060)
addappid(1301061, 1, "81715e4a82cae3fe43237e9956d7bc7930e5fb4cdf61155424f612e1f96ce607")
