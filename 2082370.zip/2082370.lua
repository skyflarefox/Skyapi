-- Lua provided by SkyAPI 
-- Game: Fuga: Melodies of Steel 2 - Deluxe Edition Upgrade Pack
addappid(2082370)
addappid(2082371, 1, "caa116bf5bf6128e0001138e2c108b9a360db59eb87edf48ca098387a3903c41")
