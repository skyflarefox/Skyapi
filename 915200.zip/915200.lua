-- Lua provided by SkyAPI 
-- Game: Republique VR
addappid(915200)
addappid(915201, 1, "8c87a9497ca0261a05cc7433eae70b2ed2f5ed8e201db76ff5864dcfaaa4bc0f")
