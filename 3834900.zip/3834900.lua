-- Lua provided by SkyAPI 
-- Game: Ark of Trisolar (三体方舟)
addappid(3834900)
addappid(3834901, 1, "7fc36d4927b98f63d6e6445f15b626d2e19b20841ad760fa1a18a53d5eedc196")
