-- Lua provided by SkyAPI 
-- Game: AppID 997030
addappid(997030)
addappid(997031, 1, "076242024cd5b7fffc41ce3e1ba4b4a6cfa6733ac746df0ac2b7f964328281ce")
