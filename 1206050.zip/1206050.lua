-- Lua provided by SkyAPI 
-- Game: Sea King
addappid(1206050)
addappid(1206051, 1, "6b8b1d0127ba90951b2b6a8a549d4e6e2d023f15e79be5c143140e2722063148")
