-- Lua provided by SkyAPI 
-- Game: AppID 832030
addappid(832030)
addappid(832031, 1, "c351a085765998bd8052a610f6f8e4e1b64f20eb617e99853cc06f9e21710f3c")
