-- Lua provided by SkyAPI 
-- Game: Zorro and Zedd
addappid(2599630)
addappid(2599631, 1, "2adf5805178c791afa5d2a031a71c73cc849b85ca72b42f7c50514865fca9aeb")
