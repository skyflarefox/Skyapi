-- Lua provided by SkyAPI 
-- Game: AppID 615670
addappid(615670)
addappid(615671, 1, "513e68cf11d18ed977b60d86548d1bf6528f0883ea7abdccad73c6853a29e963")
addappid(615672, 1, "953f284fb25dd6ef30839519d2201346daaabecb94a81c7c575f866a5d019fc5")
addappid(615673, 1, "266cc3d31e738cad5fcef13e799b0b6daa2ba49e7351210eaabc1fae23e00fa8")
