-- Lua provided by SkyAPI 
-- Game: The song of Star night
addappid(1509340)
addappid(1509341, 1, "24ab2c3ce26b4036adf1f1ce26ea83600239e111ed3a9f7dc054e10a51c15b72")
