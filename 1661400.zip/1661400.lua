-- Lua provided by SkyAPI 
-- Game: AppID 1661400
addappid(1661400)
addappid(1661401, 1, "2e2cf1760b96066f41d3ea5f928ba77f3a256ebd5e113bf71c1725f312952ab9")
