-- Lua provided by SkyAPI 
-- Game: AppID 1087760
addappid(1087760)
addappid(1087761, 1, "6a138e7b33b8d0fddcc4efc5c3d9fc69a18b80529c80a1d2fb835656233d8530")
