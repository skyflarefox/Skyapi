-- Lua provided by SkyAPI 
-- Game: 25 Cadre of Death
addappid(904860)
addappid(904861, 1, "766e47d920e107c8dc00d1d9f68aac3d3e96e590168426a74fbc2025ad32f38b")
