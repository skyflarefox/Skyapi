-- Lua provided by SkyAPI 
-- Game: ISLAND MIRRORGE VR / TYFFONIUM
addappid(1487610)
addappid(1487611, 1, "61c6336e4b7d6ae755071ee249f1b16fdb2d5358965bf8ba8c64548a818c8b14")
