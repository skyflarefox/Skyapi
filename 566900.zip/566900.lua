-- Lua provided by SkyAPI 
-- Game: Wacky Wings VR
addappid(566900)
addappid(566901, 1, "c8152dbfd66b59b72cd375b1c5bbb1591f82c1ca1b823d5396a8e2d343ac4b0f")
