-- Lua provided by SkyAPI 
-- Game: AppID 1177110
addappid(1177110)
addappid(1177111, 1, "f24fce49995b7881f0b7074219308db73f01917831556c77fc0c3c6c28f840ad")
