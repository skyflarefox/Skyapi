-- Lua provided by SkyAPI 
-- Game: AppID 2423430
addappid(2423430)
addappid(2423431, 1, "1c4bff30ab39e5422c44c6c69408224215d0d2b2d7b75fd4bd64e563d381853e")
