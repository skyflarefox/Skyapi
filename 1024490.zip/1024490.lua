-- Lua provided by SkyAPI 
-- Game: Super Jigsaw Puzzle: Anime Reloaded
addappid(1024490)
addappid(1024491, 1, "c414af4e79088a76d2bbe0c2b9e14dbc3e1d713d93ff920bc39cf4a1a8e2c586")
addappid(1056623, 0, "8308bd6d0f762095b771e51ee8d6832ba667edbe053d3a4ea56360f45f94cba5")
