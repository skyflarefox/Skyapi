-- Lua provided by SkyAPI 
-- Game: Love Chase
addappid(2812850)
addappid(2812851, 1, "9d641b89a332e77c1f8b5e13ecacb7bc9447dfbb1e43a49e55b1e1a00cc8f192")
addappid(2937030, 0, "dc1a475be2de2440a8d20b5591321a291782f700114d8d2f36c7fb63e6fed568")
