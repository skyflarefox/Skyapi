-- Lua provided by SkyAPI 
-- Game: AppID 553440
addappid(553440)
addappid(553441, 1, "6698adbea139edbbc8a95c07f1a48934cd2e9349ea0f92a1095b7fc68cf4f505")
