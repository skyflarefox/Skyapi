-- Lua provided by SkyAPI 
-- Game: Bosorka
addappid(2118370)
addappid(2118371, 1, "0fdfed75d9bc00c57b67739864998b39b1105e0c2d36d47f7900e99092afd182")
addappid(4017630)
