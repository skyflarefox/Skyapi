-- Lua provided by SkyAPI 
-- Game: ATNRPG
addappid(2420690)
addappid(2420691, 1, "90faa1cedebbb68c75608ad680a4722917b1563eef111874ccae2bef6c20fee4")
