-- Lua provided by SkyAPI 
-- Game: Remnant: From the Ashes
addappid(617290)
addappid(617291, 1, "a44b1e94ad062cd59177b19472b97fbf016a18c93db2c7ab52857728012fa6ce")
