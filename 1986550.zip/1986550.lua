-- Lua provided by SkyAPI 
-- Game: LOLLIPOP: SUMMER!
addappid(1986550)
addappid(1986551, 1, "9d1c2027741da4497a87a87d08dc9d49f12e1f4d57754054ec346b59c35a3d18")
