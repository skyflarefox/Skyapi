-- Lua provided by SkyAPI 
-- Game: Archery Showdown
addappid(2644490)
addappid(2644491, 1, "088ea45db6a9ce55aecd4d9a025c6477ff0eba6c6aa5f8e0d8c120fd0922693f")
