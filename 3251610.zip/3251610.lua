-- Lua provided by SkyAPI 
-- Game: Space Memory: Dogs
addappid(3251610)
addappid(3251611, 1, "63eef10e5bf901b887786f9c0dfe302374aa36fdb2e961873c30a98729b6c34c")
