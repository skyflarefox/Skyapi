-- Lua provided by SkyAPI 
-- Game: AppID 961500
addappid(961500)
addappid(961501, 1, "6dcbfbec98b91eca02f26abd3be19aa0b444d6a94da380bac9edb12c217e3795")
