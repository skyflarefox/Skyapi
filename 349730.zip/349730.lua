-- Lua provided by SkyAPI 
-- Game: Popup Dungeon
addappid(349730)
addappid(349731, 1, "8c67103f09df3a202d53cf14c1127e883f06a34f8223fc24c83d04efca7aa1d2")
