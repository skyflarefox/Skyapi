-- Lua provided by SkyAPI 
-- Game: Match it Sexy: FREE
addappid(2567520)
addappid(2567521, 1, "f4253c1577794256320d1c5a84cc04fac28a64f78ca18c7daf8ad875d9711948")
