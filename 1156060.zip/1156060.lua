-- Lua provided by SkyAPI 
-- Game: AppID 1156060
addappid(1156060)
addappid(1156061, 1, "f64bae60cadba4d5f6e70caa3f2ef778172f36908669d3cebf4e10fdfa9e5332")
