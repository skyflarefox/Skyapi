-- Lua provided by SkyAPI 
-- Game: DREAM LOGIC
addappid(2110510)
addappid(2110511, 1, "0478fd19d89cdb28174ef7c01793314982cdce4be034607c02a043e46ff4bd74")
