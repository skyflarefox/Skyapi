-- Lua provided by SkyAPI 
-- Game: Selatria Demo
addappid(1327060)
addappid(1327061, 1, "defb26bea3c7371a0018d16ad288871ac67e2974b0e39737268a45430d7adab9")
