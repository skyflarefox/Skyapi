-- Lua provided by SkyAPI 
-- Game: Airline Manager
addappid(1641650)
addappid(1641651, 1, "58027028b5bfdaf7f01e4b31fca3f7548ff5ca23e8ea1909a5c220fd78666e7b")
