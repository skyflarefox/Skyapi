-- Lua provided by SkyAPI 
-- Game: Tiestru
addappid(317720)
addappid(317721, 1, "fefcb869111382a181cdbba000730494447dbda1dc2a5efcedd2d1e4a512e4d9")
