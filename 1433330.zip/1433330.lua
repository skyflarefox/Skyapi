-- Lua provided by SkyAPI 
-- Game: Happy's Humble Burger Farm Alpha
addappid(1433330)
addappid(1433331, 1, "abf9a15261cc77127d9266c45f75225d2c4cf01a6fd1e0ac4d6386f35f72c3b0")
