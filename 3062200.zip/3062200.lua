-- Lua provided by SkyAPI 
-- Game: AppID 3062200
addappid(3062200)
addappid(3062201, 1, "a8f88c4129167922dfdc892c64f5669bbece006474cef6f6218231c777a515bc")
