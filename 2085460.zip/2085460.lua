-- Lua provided by SkyAPI 
-- Game: The Last Fighter
addappid(2085460)
addappid(2085461, 1, "e5836e2fc99e2f068c01f4cd44e165cf9f4f5ecae2dd90136cc91178c03cb183")
