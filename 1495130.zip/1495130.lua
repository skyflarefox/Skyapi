-- Lua provided by SkyAPI 
-- Game: Fill And Cross Christmas Riddles
addappid(1495130)
addappid(1495131, 1, "cf8740f3a7bcd06b188b46cee26f3aaf7c4edc896a30e3f4b3680cc8815bada2")
addappid(1495132, 1, "517af38f5bdeaf03c19cecc9221fc203b1b8b9fe0c9f13868f296aa6deb36195")
addappid(1495133, 1, "b7ff3742b23861aab3b7b8c975bcbedfa1d6d323d6b694c873ce0ce422c7827e")
addappid(1495134, 1, "150a0a588827c69869ba46e4b7c53d1735a76414affb574a3108150bbf1606d6")
