-- Lua provided by SkyAPI 
-- Game: Edge Of Dead Prologue
addappid(2484450)
addappid(2484451, 1, "5b2b29bdbd0533cb2616b4263c26e37a44d9cc75535a93d5c0f7356dd4553c81")
