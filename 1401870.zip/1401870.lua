-- Lua provided by SkyAPI 
-- Game: Dark Dealings
addappid(1401870)
addappid(1401871, 1, "1e5602c19d8265ed36774c06325783ac5d72101c503bcf1245b32c5b353bcbd7")
