-- Lua provided by SkyAPI 
-- Game: Unbound: Worlds Apart Prologue
addappid(1234810)
addappid(1234811, 1, "b6c8293542d0c44f41ffa88659d13b8ad996346f340dbbfcc3bade4cb19a8e04")
