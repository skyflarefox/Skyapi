-- Lua provided by SkyAPI 
-- Game: Amber City Demo
addappid(2067810)
addappid(2067811, 1, "01bc581f68b3acc0904b132c3fc8f396a20347a17e9ca5ada89f2611d4111bef")
