-- Lua provided by SkyAPI 
-- Game: Pixel Game Engine
addappid(2109340)
addappid(2109341, 1, "aacc45fc5857358445ba12066bd74d2cc28c9a31e23a82b9c69a492f3ca5adbe")
