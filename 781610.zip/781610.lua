-- Lua provided by SkyAPI 
-- Game: AppID 781610
addappid(781610)
addappid(781611, 1, "fb896a9db35d4975ab8c3f05f793a8a3d2e0762f96b074574f2685ae10d10782")
