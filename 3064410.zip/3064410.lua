-- Lua provided by SkyAPI 
-- Game: 10:59
addappid(3064410)
addappid(3064411, 1, "3b77e528c6221d0ef283f34c30e6c2f58857ea0b40d686f9ff8d2f9e88288feb")
