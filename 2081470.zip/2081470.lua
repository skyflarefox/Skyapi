-- Lua provided by SkyAPI 
-- Game: Red Matter 2
addappid(2081470)
addappid(2081471, 1, "dd397f04ae1f67a806724de61145a8d1b5d581eb4db86e5ec8073413c586795a")
