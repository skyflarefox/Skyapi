-- Lua provided by SkyAPI 
-- Game: Rogue Tower
addappid(1843760)
addappid(1843761, 1, "81a3002f1b3e8f69c62e3142cf4ebe0bd387d906c795529aa3747e961f136f72")
