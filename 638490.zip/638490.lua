-- Lua provided by SkyAPI 
-- Game: AppID 638490
addappid(638490)
addappid(638491, 1, "46956d67c1b9b4ed52100b738b84e726e8084002ea8b643c7f5c0f89857055f2")
