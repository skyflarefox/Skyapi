-- Lua provided by SkyAPI 
-- Game: Caveblazers
addappid(452060)
addappid(452061, 1, "e3fe57fa8518c9e1fc98bee89c9fa755633bd25bc0a03be9f3a6688b4fa35cb9")
addappid(641430, 0, "32d5d77d1ef907fa651428da7212e1523d62f0d2d3cdf75633985fa39c0574f3")
