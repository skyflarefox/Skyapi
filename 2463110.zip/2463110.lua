-- Lua provided by SkyAPI 
-- Game: QualityScaler
addappid(2463110)
addappid(2463111, 1, "bea3aa5e7f238edb58939d95d8558515f12fd9603cf401978fb0a2419b7cff79")
