-- Lua provided by SkyAPI 
-- Game: Bomberpet
addappid(1747430)
addappid(1747431, 1, "733ce4f1479b85489e84b52c57d5ff9094dbf3171709648a114726b34c18c9dd")
