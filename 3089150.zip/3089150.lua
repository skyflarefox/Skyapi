-- Lua provided by SkyAPI 
-- Game: Retail Company Simulator: Prologue
addappid(3089150)
addappid(3089151, 1, "a88a5dd8a76100cfb50fd8e403abd25298872362850f49e1e3b05e070179d2db")
