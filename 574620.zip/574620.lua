-- Lua provided by SkyAPI 
-- Game: AppID 574620
addappid(574620)
addappid(574621, 1, "1de46565a0e7d220be53dd04ba39e038f4aef8315535f537c97bf61f090af4f2")
