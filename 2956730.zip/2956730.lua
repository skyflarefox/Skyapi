-- Lua provided by SkyAPI 
-- Game: Desert Kingdoms 2
addappid(2956730)
addappid(2956731, 1, "eff167afe4f9329f9738b41b196cd2b8484ae9fbd83cc8723836e41cccee71af")
