-- Lua provided by SkyAPI 
-- Game: Fate/hollow ataraxia REMASTERED
addappid(2396990)
addappid(2396991, 1, "5100b046f94ce318bd23122f91c9d90b4a0e8c0e873bee7bde1cea354300cc52")
