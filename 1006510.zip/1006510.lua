-- Lua provided by SkyAPI 
-- Game: AppID 1006510
addappid(1006510)
addappid(1006511, 1, "b0515ee5a374e6f06d1e93799d0bbec8efef4f9a2d74b40ffe98a8a07d710489")
