-- Lua provided by SkyAPI 
-- Game: Crystal Control II
addappid(499580)
addappid(499581, 1, "977d50da5023cc322406845a1ffb6d70720cd5c4668240c9969e1bfd7f722d5d")
addappid(499582, 1, "4efb7936a9756f626f70a8bf18f846f782b81527d875772e43c366ae53b4399a")
