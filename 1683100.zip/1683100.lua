-- Lua provided by SkyAPI 
-- Game: Ultra Age
addappid(1683100)
addappid(1683101, 1, "a1273e8098d05cfeb8c601cf42c93dcfec861f42c0f2f3d4472a39fd57ab02c1")
addappid(2064451, 0, "b86929f44f335c92fb905f89b27893e29683f72d994af83371ec72be956365c4")
addappid(2065479)
