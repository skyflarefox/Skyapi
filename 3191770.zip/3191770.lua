-- Lua provided by SkyAPI 
-- Game: Slitherise
addappid(3191770)
addappid(3191771, 1, "23877733f7f89a99364f204898303f23e822bd3ef9131ca217c1c4ea07de00ad")
