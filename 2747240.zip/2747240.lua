-- Lua provided by SkyAPI 
-- Game: Intergalactic Pawn Shop: Prologue
addappid(2747240)
addappid(2747241, 1, "fb36d300c2954098282cb1bfdf7b615564c9d4387b4d88c8d63c6557dcce8613")
