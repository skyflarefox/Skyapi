-- Lua provided by SkyAPI 
-- Game: Into The Flames
addappid(1222300)
addappid(1222301, 1, "21dd651ba7ff6d43543c53112d5dfe96d4e425d31065d714776233eb737aa3b6")
