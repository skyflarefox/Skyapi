-- Lua provided by SkyAPI 
-- Game: Sonic Generations Demo
addappid(202290)
addappid(202291, 1, "736f00df771039fc93d7350480a7c3d70fdcb3d10345b97e0c48e9e742e3a26e")
