-- Lua provided by SkyAPI 
-- Game: Cain × Nica
addappid(3000310)
addappid(3000311, 1, "7a967ded598b767a80e704eb7cc937b0ba9f9bf17aafe82e8fb230e402001f01")
