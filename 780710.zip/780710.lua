-- Lua provided by SkyAPI 
-- Game: AppID 780710
addappid(780710)
addappid(780711, 1, "acb91fe385f643219d4049fb497f568e7b0df0061f636d952bf6cb69ed4dc9bf")
