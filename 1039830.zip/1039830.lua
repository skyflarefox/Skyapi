-- Lua provided by SkyAPI 
-- Game: AppID 1039830
addappid(1039830)
addappid(1039831, 1, "9a99b104ef785f3c30fd0337a09f1f418123c4adee73068a9e6cd1c1991d9782")
