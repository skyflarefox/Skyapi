-- Lua provided by SkyAPI 
-- Game: AppID 897330
addappid(897330)
addappid(897331, 1, "90ef04fccf8444a09f5f878bb865f2ca5c2478baaa3d60bf448153439b8822c6")
addappid(897332, 1, "451a7ba1ec57b3cd2ba995d242abc2673df48066ba0e808935af7f32ab22c065")
addappid(897333, 1, "95c9adc2d58ad3343687b48a02723470f6a441d1e6661c31ffbffacef33a1cf6")
