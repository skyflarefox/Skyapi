-- Lua provided by SkyAPI 
-- Game: SmFly: Gravity Adventure
addappid(1403890)
addappid(1403891, 1, "49ef37afbc7ea10312a21d5d62d3b15fb9a433b128b7b166b0362d0a133de7dc")
