-- Lua provided by SkyAPI 
-- Game: AppID 405710
addappid(405710)
addappid(405711, 1, "cfd7a671e35ff2e375a721a925e7c92d0fa9f60dabc74c172a0b8bacb67c31d1")
addappid(405712, 1, "d683b0b47b0b3a78ef2fd175e1933f76c2fbe41a0a45a222dd002a3062f44349")
addappid(405713, 1, "43b9920e7123ef9216719afdc3edfca086a75ae73a128d30c6948f065c5c0e1c")
