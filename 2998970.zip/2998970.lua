-- Lua provided by SkyAPI 
-- Game: Summon: Joint escape
addappid(2998970)
addappid(2998971, 1, "00db5047f3d2a4415beb02b2afc948c0e8309db0d57098abb58d06b52fd36cd0")
