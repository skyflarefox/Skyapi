-- Lua provided by SkyAPI 
-- Game: Plane Accident
addappid(1682340)
addappid(1682341, 1, "9d8dc6e9b546b33e3a2cd0157851cd96060dab29f61fde00f68a36dbd45bb038")
