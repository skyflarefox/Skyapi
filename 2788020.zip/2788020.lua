-- Lua provided by SkyAPI 
-- Game: AppID 2788020
addappid(2788020)
addappid(2788021, 1, "a6a86f75d1cd4f58ed9f143641710b624176e8cf4377637f1c3a481940f270ab")
