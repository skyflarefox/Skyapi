-- Lua provided by SkyAPI 
-- Game: Solitaire Knights
addappid(820090)
addappid(820091, 1, "c2bf5791bc8d2274bad836f7f1b436cc730647bc7d9bcff8469138441b27fcc9")
