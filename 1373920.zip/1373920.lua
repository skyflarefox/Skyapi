-- Lua provided by SkyAPI 
-- Game: Sword Rogue
addappid(1373920)
addappid(1373921, 1, "892f409c693e8f1f0347c82fc09f72ec3d39d653c90a42fc8ccfc3bac20f0e0b")
