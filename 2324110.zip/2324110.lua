-- Lua provided by SkyAPI 
-- Game: FMTC
addappid(2324110)
addappid(2324111, 1, "6d96db93bd5ff4dfded07572295e0588fccf3674e809b8e34d969aff0477ce99")
