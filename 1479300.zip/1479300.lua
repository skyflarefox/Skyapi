-- Lua provided by SkyAPI 
-- Game: VR Hentai
addappid(1479300)
addappid(1479301, 1, "b5e9cfc7ae6a9cb6600c186d61331ede6bd49036b8cafb65b9f3961846193af5")
addappid(1483210)
