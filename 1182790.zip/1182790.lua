-- Lua provided by SkyAPI 
-- Game: AppID 1182790
addappid(1182790)
addappid(1182791, 1, "01ad37f74e1c9288ae86385584e004f0beb80a056e041c6bfee58952240755fd")
