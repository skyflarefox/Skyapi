-- Lua provided by SkyAPI 
-- Game: Damn Ropes
addappid(1739800)
addappid(1739801, 1, "40c250e47dfd53b618a030048dcef238a9f8a523353f29f209fd9681a1200991")
