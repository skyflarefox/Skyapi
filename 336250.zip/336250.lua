-- Lua provided by SkyAPI 
-- Game: Monster Jam Battlegrounds
addappid(336250)
addappid(336251, 1, "ae79e8e410a2d251fffa63c5c095ed322b4cff7d35f8277b23c6ac5b6c22c217")
