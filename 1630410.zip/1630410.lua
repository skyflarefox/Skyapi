-- Lua provided by SkyAPI 
-- Game: Hentai Boy - Original Soundtrack
addappid(1630410)
addappid(1630411, 1, "2a9fc3f7dbd608c888b6b6d2de53c58a4247b35071f62042efe4f083350f0e7c")
