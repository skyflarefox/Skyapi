-- Lua provided by SkyAPI 
-- Game: Kawaii Hentai Sexy Girls
addappid(2063340)
addappid(2063341, 1, "548e12aebc1fdc807c899da4520935f70c34ebd047446d3aeaeaf176a832c7c0")
