-- Lua provided by SkyAPI 
-- Game: Achievement Killer
addappid(1428320)
addappid(1428321, 1, "0e57055ef200ee6f1ac24404a580e72ecc1dc9c11d5f5e5dcdf2495b5dc8311a")
