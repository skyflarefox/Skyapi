-- Lua provided by SkyAPI 
-- Game: AppID 805880
addappid(805880)
addappid(805881, 1, "b97f523473008180cc0a0ac4fcfcce49618adbf8f85341d64f34252b89ea4fae")
