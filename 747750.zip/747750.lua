-- Lua provided by SkyAPI 
-- Game: D.F.R.: The Light
addappid(747750)
addappid(747751, 1, "630207647e49685084a047c7ad4cdc450bace6b9da855b60072dc93a9e6916de")
