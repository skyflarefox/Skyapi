-- Lua provided by SkyAPI 
-- Game: Ring Stars
addappid(2545020)
addappid(2545021, 1, "96954d6bff981547f057077c4712854a4b797c7b87a025ebe5e25050430a0f14")
