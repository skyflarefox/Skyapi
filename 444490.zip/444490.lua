-- Lua provided by SkyAPI 
-- Game: POLYWAR
addappid(444490)
addappid(444491, 1, "f1f7d75218b75446176dad12f25693909a11b2e48fd8cc21bfae3ab7adb994d5")
