-- Lua provided by SkyAPI 
-- Game: NOVEMS
addappid(3549210)
addappid(3549211, 1, "6b1b3573aee48f5d42ef86f9e409c8fabaf31e69f8eff5cd7a5d2e3a62e72862")
