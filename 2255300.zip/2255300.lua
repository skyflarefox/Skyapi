-- Lua provided by SkyAPI 
-- Game: The Starving Tournament
addappid(2255300)
addappid(2255301, 1, "cb93b8b563b0fdfda6f3550cef7ec4b056ae28c30d2d1db1f154ddce97fddde5")
