-- Lua provided by SkyAPI 
-- Game: AppID 856600
addappid(856600)
addappid(856601, 1, "a1d128b4233a9635d924fcbb22f0136120a05b2eadecc0dfa243dccd0073d43c")
