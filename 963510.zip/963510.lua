-- Lua provided by SkyAPI 
-- Game: Intersolar Overdrive
addappid(963510)
addappid(963511, 1, "65bf66a72196998bf4bbe7df873a741d20aa77f0cce0d8d0740fdd6e2bc3e251")
