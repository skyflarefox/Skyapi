-- Lua provided by SkyAPI 
-- Game: AppID 1420650
addappid(1420650)
addappid(1420651, 1, "832b587061efac0c20695b7f193985c39fe5b66e8df28cc27852b62db91587f1")
