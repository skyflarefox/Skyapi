-- Lua provided by SkyAPI 
-- Game: AppID 935490
addappid(935490)
addappid(935491, 1, "0ea665642d86210e6ecb9f31207cdbfc59060a94cc7c610705d7c5ec65ebf860")
