-- Lua provided by SkyAPI 
-- Game: SPECWAR Tactics
addappid(1785680)
addappid(1785681, 1, "b97b12bedcd8c86ee6b9dd6ed9714fc69d1514883028a8aad3e66d8fa35b1b38")
