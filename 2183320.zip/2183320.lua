-- Lua provided by SkyAPI 
-- Game: For Your Tranquility
addappid(2183320)
addappid(2183321, 1, "360b426795971c25240bb56068593efb5343403a873a68c016b5a7c1a1f7c9e9")
