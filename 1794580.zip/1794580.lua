-- Lua provided by SkyAPI 
-- Game: Enraged
addappid(1794580)
addappid(1794581, 1, "48aedc3a47c9a30f9fc0cdd9745296a01396ad2c6571bd9df9f681664b1164f3")
