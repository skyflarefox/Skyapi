-- Lua provided by SkyAPI 
-- Game: Umamusume: Pretty Derby
addappid(3224770)
addappid(3224771, 1, "22b178efa09d88963c4935d572fc8321b864d821a98762c93e791b28a38af501")
