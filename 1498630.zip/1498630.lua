-- Lua provided by SkyAPI 
-- Game: Click on their Heads
addappid(1498630)
addappid(1498631, 1, "ad47bb83d4f870a781e38ddbd5a5de6e98db50517eafcda833dff47bff0e6240")
