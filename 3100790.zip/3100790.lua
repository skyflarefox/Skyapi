-- Lua provided by SkyAPI 
-- Game: GULLET
addappid(3100790)
addappid(3100791, 1, "5eeda691c138b7721cc0030c1f2dbe9b39eceb0c55a315327eda5ffaa5dac408")
