-- Lua provided by SkyAPI 
-- Game: AppID 1400200
addappid(1400200)
addappid(1400201, 1, "9b91d6899fb3768738f94b7d23456c24baf215518c78cfcc6a60bf362a83cf48")
