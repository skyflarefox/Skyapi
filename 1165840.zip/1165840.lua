-- Lua provided by SkyAPI 
-- Game: AppID 1165840
addappid(1165840)
addappid(1165841, 1, "7c3b76074d505d71b889d7819cef49e7547b6d26585f9e433a2ab6df7a37ab04")
