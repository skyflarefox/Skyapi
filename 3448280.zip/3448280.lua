-- Lua provided by SkyAPI 
-- Game: Gothic 1 Remake - Demo (Nyras Prologue)
addappid(3448280)
addappid(3448281, 1, "613993f0b8166b3e2aa1306217ad55fac964a30e0f505be7239d11829a3390a6")
