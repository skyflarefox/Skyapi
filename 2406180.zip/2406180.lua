-- Lua provided by SkyAPI 
-- Game: Knights Within
addappid(2406180)
addappid(2406181, 1, "cbf06c72ee8bc46136ab7a5c23e3d46af32cbfe555d47996a9cd2c89eb57057e")
