-- Lua provided by SkyAPI 
-- Game: How to Say Goodbye
addappid(1709700)
addappid(1709701, 1, "43373173c8c4d0d299b169ebd91f14e00b63aed0517cd4fa610907ce24dd387e")
