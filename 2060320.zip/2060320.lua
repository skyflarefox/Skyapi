-- Lua provided by SkyAPI 
-- Game: Survive Till Morning
addappid(2060320)
addappid(2060321, 1, "6938f8410e77048df25b65e5c928b499ad6745eba2fc12084dc46d16b2efa9d0")
