-- Lua provided by SkyAPI 
-- Game: SaGa Frontier 2 Remastered
addappid(2452080)
addappid(2452081, 1, "c2d565341531f2032ec2e3340fd71477d019939f2b79db27d6f23898e49e9580")
