-- Lua provided by SkyAPI 
-- Game: BlackJack Math Soundtrack
addappid(1455240)
addappid(1455241, 1, "3b29c77709a34d35e729da782b0fc9f9350f3deb8e0a65b2b1a1814e4aedb088")
