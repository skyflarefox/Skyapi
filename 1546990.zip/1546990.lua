-- Lua provided by SkyAPI 
-- Game: Grand Theft Auto: Vice City – The Definitive Edition
addappid(1546990)
addappid(1546991, 1, "8ffae608bee3a6766651bc7b0b2122f7248955251de38eafb6161ea30434979d")
addappid(1899671, 0, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
