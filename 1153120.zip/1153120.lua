-- Lua provided by SkyAPI 
-- Game: AppID 1153120
addappid(1153120)
addappid(1153121, 1, "538d715975398a8a7f2755fb4dcf050384260aefabbc32b96aff6813aa7982dc")
