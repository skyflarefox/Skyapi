-- Lua provided by SkyAPI 
-- Game: System Goose Overload
addappid(672000)
addappid(672001, 1, "bf3e978b9a49cc53f5543b3773ed1bc3494a0fd29ff6f6e01b4499d2d7d2191f")
