-- Lua provided by SkyAPI 
-- Game: Deadwalker Chronicles
addappid(3357680)
addappid(3357681, 1, "f7c3004994a4963bccc9d3d95b5353aa60859665471c5db56b6336c85b94b30e")
