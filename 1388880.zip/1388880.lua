-- Lua provided by SkyAPI 
-- Game: AppID 1388880
addappid(1388880)
addappid(1388881, 1, "4f1093e270a1c6352d8a8ddc1bf9893a6c5e73e352e1dcdbb30631a12372eb69")
