-- Lua provided by SkyAPI 
-- Game: Crossroad OS
addappid(1783800)
addappid(1783801, 1, "7117280a52b1a71434081523af8a290c7b9ed85af555d1d9687b8764ec4a77ec")
