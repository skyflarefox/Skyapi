-- Lua provided by SkyAPI 
-- Game: PERSEVERA Demo
addappid(2567100)
addappid(2567101, 1, "f08581b35abb6215b3c6fac268c4595ecef74e7a727396f0b8d96b7ec3077c1e")
