-- Lua provided by SkyAPI 
-- Game: 通天魔塔-MagicTower
addappid(1653120)
addappid(1653121, 1, "0f3d9daa36e772ef5bed44554a761671205416f539e8eab46ef1d061cc68bfe2")
