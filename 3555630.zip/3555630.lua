-- Lua provided by SkyAPI 
-- Game: Occupy
addappid(3555630)
addappid(3555631, 1, "c502ca8a426d725911be44b34736726d5657cd3bf451063954c0bdffd9987d96")
