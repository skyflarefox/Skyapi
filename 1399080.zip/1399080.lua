-- Lua provided by SkyAPI 
-- Game: The DioField Chronicle
addappid(1399080)
addappid(1399081, 1, "34ffebca3f2cf35760d220c807c1cc9adf69788c4b80413b640df8f08db09aba")
