-- Lua provided by SkyAPI 
-- Game: AppID 774261
addappid(774261)
addappid(774262, 1, "3d2c7c99711e3b78096dea524f7a69a3c184890590ef0383f0e6cc4c3685487c")
