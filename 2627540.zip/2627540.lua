-- Lua provided by SkyAPI 
-- Game: HenapoLand
addappid(2627540)
addappid(2627541, 1, "35d045c4049bcb8deb58c5a18c7ed8b68b6f9ffc65ffde68f5c11e3b64987a0f")
