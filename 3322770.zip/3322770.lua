-- Lua provided by SkyAPI 
-- Game: 1X1
addappid(3322770)
addappid(3322771, 1, "f7df2194a9b298f4cf506fcd9249fd4fa4d2e430fbfdc42efd792cdd0e9bc794")
