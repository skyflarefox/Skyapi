-- Lua provided by SkyAPI 
-- Game: Yet another tower defence
addappid(923890)
addappid(923891, 1, "b6ab3291233715a23e296ce24e0a3a88171cc2ec0c8f3970ceb92337f525aa4e")
addappid(923892, 1, "4076c4d05e4d59aca703afdcf401951d22264ee786c0a84013da5c50fc22e367")
