-- Lua provided by SkyAPI 
-- Game: AppID 3382820
addappid(3382820)
addappid(3382821, 1, "16fde692455202f44c62f4491544ab88d38ec2653d259424acfe8de8a2c5789d")
