-- Lua provided by SkyAPI 
-- Game: Mullet Mad Jack ARTBOOK
addappid(2902200)
addappid(2902201, 1, "bf83ad69169fe2b6bd9a96ca69e8d4c26d8bf44b29393b3f559e203d3193f77f")
