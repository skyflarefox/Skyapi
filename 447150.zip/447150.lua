-- Lua provided by SkyAPI 
-- Game: APE OUT
addappid(447150)
addappid(447151, 1, "a86790d0815a7ec673c494549a405b802fecec2267a6801a0751a1cc3d3322af")
addappid(447152, 1, "77626435ac7625d7195a5381021f4749b7873c88fffddb480eb9d712769ed7e4")
