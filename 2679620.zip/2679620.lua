-- Lua provided by SkyAPI 
-- Game: CAT SHORT WAY
addappid(2679620)
addappid(2679621, 1, "3a6e5126eb6cfa48be07ff8bf8bc2fc554cc9a9857d8d04783c8764a4916a901")
