-- Lua provided by SkyAPI 
-- Game: Destoria: The Withering
addappid(1953960)
addappid(1953961, 1, "2ac8e6d43457df551289973a1c014c52f1a3c4ac73a8ad83aa92c0380e4df8b2")
