-- Lua provided by SkyAPI 
-- Game: Horror Engine: Tech Demo
addappid(2485950)
addappid(2485951, 1, "4adf38019aeffc1644e050bf17543365f3ed8ed1f72fb19cea4eeb34cea269d7")
