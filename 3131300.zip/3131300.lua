-- Lua provided by SkyAPI 
-- Game: AppID 3131300
addappid(3131300)
addappid(3131301, 1, "a4c5649546f376167542e7013cda2c584abcd9702a17d531870d785ac0835169")
