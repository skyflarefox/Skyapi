-- Lua provided by SkyAPI 
-- Game: Happy's Humble Burger Farm
addappid(1433340)
addappid(1433341, 1, "cad7090cb7ab309ef67a6c60ff49477081f6358673c81715fd1d452507530672")
addappid(1816590, 0, "a3b62744ced0ff8597d66b701fca9ff7828601035e72c48a138c1d84097a90b9")
