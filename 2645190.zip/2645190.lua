-- Lua provided by SkyAPI 
-- Game: Agnostic Requiem
addappid(2645190)
addappid(2645191, 1, "62cb0906743824c136a22186aee3e45096e020f3f0b399106445588833c3fd87")
