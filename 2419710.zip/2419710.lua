-- Lua provided by SkyAPI 
-- Game: Saloon Simulator: Prologue
addappid(2419710)
addappid(2419711, 1, "cd3e6acc07500eaba6b30c27d0dfa8b87b20e94608749d8e175c7d50df31dfdd")
