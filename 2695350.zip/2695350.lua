-- Lua provided by SkyAPI 
-- Game: MULLET MAD JACK DEMO
addappid(2695350)
addappid(2695351, 1, "28cfc1b3b957c52f40a8e55c94f8b27cf78d85ad109f4a9bd4e285a81c8bc8e7")
