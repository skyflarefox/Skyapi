-- Lua provided by SkyAPI 
-- Game: AppID 2755850
addappid(2755850)
addappid(2755851, 1, "a41569b1a4714e50564376f1125ac8cb35cc0ee1d8de2edfb56b2a33c2791697")
