-- Lua provided by SkyAPI 
-- Game: AppID 262960
addappid(262960)
addappid(262961, 1, "e2be6d1d891a934adedb54203cbba93ce99b661057c703797eac776f6fb3c171")
