-- Lua provided by SkyAPI 
-- Game: AppID 202930
addappid(202930)
addappid(202931, 1, "c2a352b502b0b6e3a2ac2ff41d9e4f4228a18021ccd1db2b33a9bfe8c7b38a8c")
