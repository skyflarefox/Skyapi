-- Lua provided by SkyAPI 
-- Game: Phantom Spark Demo
addappid(2927020)
addappid(2927021, 1, "8849ca33bccd2104ce0b552d6ec6c74a29fd63babb91cdbc0c82f520a23c0b32")
