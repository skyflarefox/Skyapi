-- Lua provided by SkyAPI 
-- Game: Yacht Mechanic Simulator
addappid(1263620)
addappid(1263621, 1, "c89edf1b152e3259ab7f152c34aff2dfc14a8b4a89620eb835a2faaff703f399")
