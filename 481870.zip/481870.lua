-- Lua provided by SkyAPI 
-- Game: AppID 481870
addappid(481870)
addappid(481871, 1, "113614cea802cbce9619a63f4faeb90ab2913454f2d9d0a41e29ca2d470b388d")
addappid(481872, 1, "cb0e7e18aa6c404b4eaa6425856e2c748ab1ad1898c5153d7862f6efcc2132e9")
