-- Lua provided by SkyAPI 
-- Game: Galacticare
addappid(494730)
addappid(494731, 1, "7d9789588ba66be2326f70ccb84b168862bb5f68c9ff0b2450cce71b68770f02")
addappid(2859040, 0, "74b280ce43cc5a1076dcfdcd3629a86d2409c4db38a885662705a3a775360f4b")
