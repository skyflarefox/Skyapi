-- Lua provided by SkyAPI 
-- Game: AppID 1197280
addappid(1197280)
addappid(1197281, 1, "ca32a06fbcd9c37b1772f0539ce9b11996b53bdc0f159e376fd98025510301c6")
