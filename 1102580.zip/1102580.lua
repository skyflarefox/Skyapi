-- Lua provided by SkyAPI 
-- Game: Traffix
addappid(1102580)
addappid(1102581, 1, "f199adc9a312e2a34130009e962632584c4f987dac296cbc2d436c10856fd465")
