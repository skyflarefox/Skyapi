-- Lua provided by SkyAPI 
-- Game: Fantasy Survivors
addappid(2220870)
addappid(2220871, 1, "25469231958c51bf8105c223f654e5a34d7f8eb27e6262e0eee6b3750c309bc6")
addappid(3586900)
