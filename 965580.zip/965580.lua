-- Lua provided by SkyAPI 
-- Game: Root
addappid(965580)
addappid(965581, 1, "3369a4492dbd5b23bb12fb1ffddfcadaae9719b6dcf01026327b2321f308ca00")
addappid(965582, 1, "3bba89f33d517589841bde268e67c538ff94436d447ece2b01dd669f9e722431")
