-- Lua provided by SkyAPI 
-- Game: Merchant's Rush
addappid(2110600)
addappid(2110601, 1, "d49c2b252b82188d998f455de5135b35e6752cc9da29afcc051365dc376a5ff5")
