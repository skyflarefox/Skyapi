-- Lua provided by SkyAPI 
-- Game: Zoe the Exhibitionist
addappid(2220110)
addappid(2220111, 1, "0f0eb24bd2cf48bc2cb05660679deb2bc37e3a1e9ebc7c2ed577a60eecee06bd")
