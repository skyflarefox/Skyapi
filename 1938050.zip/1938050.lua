-- Lua provided by SkyAPI 
-- Game: Unbridled: That Horse Game
addappid(1938050)
addappid(1938051, 1, "29ddb0db6b08315d1d9e9574c35349e938d5d50d4d6a65a7c2d50af52c87b99d")
