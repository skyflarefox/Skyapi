-- Lua provided by SkyAPI 
-- Game: AppID 745500
addappid(745500)
addappid(745501, 1, "2c21a5809c8cc0aed78bfdd64ae4ff0ccaee39126452255b846bc83040e90275")
