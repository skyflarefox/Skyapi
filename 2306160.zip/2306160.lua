-- Lua provided by SkyAPI 
-- Game: MULTIPLAYER KNIGHTS
addappid(2306160)
addappid(2306161, 1, "cc93c3173cdf0bf30d061cb7e48d9f59806a635cb934090e9304daf62dee9624")
