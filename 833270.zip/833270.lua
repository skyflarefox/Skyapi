-- Lua provided by SkyAPI 
-- Game: AppID 833270
addappid(833270)
addappid(833271, 1, "331f2915b97a9cd8d170a1a9c0809772b2ad1de76de31ef38ed071ebf58e142b")
