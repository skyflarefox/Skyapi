-- Lua provided by SkyAPI 
-- Game: Onimusha: Warlords
addappid(761600)
addappid(761601, 1, "a9cebe81198dc3bda033a39cb706ee6de1b8e574c0ea442ec1e611e2247764de")
