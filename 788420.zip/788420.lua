-- Lua provided by SkyAPI 
-- Game: Potion Explosion
addappid(788420)
addappid(788421, 1, "61ab64ba3a450d9119c8faa60c50303c42d7a6676a52a000b9f6108d867179af")
addappid(789170)
