-- Lua provided by SkyAPI 
-- Game: Escape First
addappid(850450)
addappid(850451, 1, "2a5d7fa3cd6d3b35cb0f7d6ee20c04478f1be68f93c6da8b81281d049617af3e")
