-- Lua provided by SkyAPI 
-- Game: Mad Streets Demo
addappid(1328260)
addappid(1328261, 1, "2047d508aa17601cb9358c5f8ad22385b2c023fb887d2afec024aa93142057f3")
