-- Lua provided by SkyAPI 
-- Game: Biotope
addappid(549040)
addappid(549041, 1, "27e95c75352bcc589ee2d541377df9297a3dfa9515698a3af29de80e523e7cd7")
