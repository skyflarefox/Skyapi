-- Lua provided by SkyAPI 
-- Game: FPS Game: Dev Test
addappid(1901200)
addappid(1901201, 1, "453541cc90571f403b754bf319e87b3efb02b33c98a23b5c9b6aa44202c3c744")
