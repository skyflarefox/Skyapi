-- Lua provided by SkyAPI 
-- Game: Midnight Prowl
addappid(2556950)
addappid(2556951, 1, "6745e42744f0ea3b34dbf350a3c59ff532510fd655df8e10caa57f13b435dbf8")
