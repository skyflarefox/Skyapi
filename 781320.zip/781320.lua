-- Lua provided by SkyAPI 
-- Game: Guns & Notes
addappid(781320)
addappid(781321, 1, "a6a65eaad14c6160c05b3fff41f7a596c783a718f6d5c4c902ebdf926d02c6ce")
