-- Lua provided by SkyAPI 
-- Game: AppID 1313050
addappid(1313050)
addappid(1313051, 1, "8edca1bff5c88ea710c42ebffecc50d7c025a81e09669bab95758cc141b4388d")
