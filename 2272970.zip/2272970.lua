-- Lua provided by SkyAPI 
-- Game: GeraScopia
addappid(2272970)
addappid(2272971, 1, "310c0f81181190784af540305bcdbc670f99cd0a53bc61c34e648f7ec9c916d8")
