-- Lua provided by SkyAPI 
-- Game: Wave of Darkness
addappid(316370)
addappid(316371, 1, "b092d6bdcbbf8dd5de9e94d8753b3374ecf06d3c01c5db1cc7b310598b58d80c")
