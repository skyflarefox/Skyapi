-- Lua provided by SkyAPI 
-- Game: BACCHANALIA DEMO
addappid(2239920)
addappid(2239921, 1, "a7813edc864edae41264be7a59c8047c55ae18e51a8e4df749b1d9d04670f134")
