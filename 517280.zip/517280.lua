-- Lua provided by SkyAPI 
-- Game: ZEscape
addappid(517280)
addappid(517281, 1, "80342b4454668661d48f57245a12e83cf71ff3341d9cf2678c05f24386a113c7")
