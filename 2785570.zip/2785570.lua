-- Lua provided by SkyAPI 
-- Game: AppID 2785570
addappid(2785570)
addappid(2785571, 1, "b40734ca90a8f782a6a5e2cc532af3740f6e2880f4b31612599b63c00c61d447")
