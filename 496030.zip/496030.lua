-- Lua provided by SkyAPI 
-- Game: AppID 496030
addappid(496030)
addappid(496031, 1, "68130208d7984d7ed4e4dfaf03789161339d44f788434c37464cc06833101640")
