-- Lua provided by SkyAPI 
-- Game: Exodemic
addappid(1928370)
addappid(1928371, 1, "87cb8745e1c00899d1c67f1a265b4cea04b76239a23ccb2bc66c568c0e0e0fc1")
