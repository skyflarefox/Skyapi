-- Lua provided by SkyAPI 
-- Game: One Last Breath
addappid(1835190)
addappid(1835191, 1, "5d664afdff4843874b24dd9f4b52038a7ddddfefad14efd61c2724ea8ef692c1")
