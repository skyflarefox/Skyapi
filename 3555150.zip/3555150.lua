-- Lua provided by SkyAPI 
-- Game: Beauty’s Target
addappid(3555150)
addappid(3555151, 1, "e73a06546f1212f66fc9a7c60442cb95d40b575c5714008aa6587bd440827f29")
