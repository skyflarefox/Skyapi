-- Lua provided by SkyAPI 
-- Game: Negative Nancy
addappid(1276750)
addappid(1276751, 1, "47bd2f88c013b413724fd52f700cefc08b891c572c3fd56244ab474598e580d1")
