-- Lua provided by SkyAPI 
-- Game: Cargo 3
addappid(318690)
addappid(318691, 1, "86060a0c74d1a86245e6c484571d11cfce23f45712696aee134da8ba52e684b3")
addappid(318695, 1, "7811f5b867bdb19eecb5eeff1eb36d144058071a2e56f960592cfae4129c6b99")
