-- Lua provided by SkyAPI 
-- Game: Days With Ollie
addappid(2776750)
addappid(2776751, 1, "1190e10b0effc201371b1f04a21562aed4a0886741c0f93069f7679368b8258f")
