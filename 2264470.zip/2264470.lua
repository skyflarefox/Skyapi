-- Lua provided by SkyAPI 
-- Game: Diesel The Pug Warrior
addappid(2264470)
addappid(2264471, 1, "a99b9c2694a3b5680fe3fd0c217a50f600a14119a926ec4c9d7b38378df21578")
