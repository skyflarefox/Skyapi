-- Lua provided by SkyAPI 
-- Game: Gooning Aim Trainer
addappid(3438040)
addappid(3438041, 1, "f9b2369caa6242168cdb458b1cd0f681804c9463b9cfb531cfadc8b661d8ed10")
