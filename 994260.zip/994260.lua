-- Lua provided by SkyAPI 
-- Game: Accel
addappid(994260)
addappid(994261, 1, "303ee8e081a22eefce010c40e7878ece743c86506e8c6bf5af2fe356bc447772")
