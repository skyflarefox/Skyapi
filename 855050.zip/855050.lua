-- Lua provided by SkyAPI 
-- Game: Thunderbolt 2
addappid(855050)
addappid(855051, 1, "78fb5530a5ae8fdda8be031f145368659bfe9f7446ed0e8ab7909c3002b9c57d")
