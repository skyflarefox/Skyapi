-- Lua provided by SkyAPI 
-- Game: AppID 2318260
addappid(2318260)
addappid(2318261, 1, "803dbcb26f3d46a188e81dd28035771a5f685dceae28a1b0da8882f36df7c684")
