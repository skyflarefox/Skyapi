-- Lua provided by SkyAPI 
-- Game: How Much Items - Plants
addappid(3471100)
addappid(3471101, 1, "b0679bf53d72d63b4fad8977e0aae4b85072491b27d090a4091be7b05048f17b")
