-- Lua provided by SkyAPI 
-- Game: DEEP FOG
addappid(1857650)
addappid(1857651, 1, "94da035a2aa91c76eb295b8c9ac5dd6d0898668ba2af3e5b1a54ef46e9f44880")
