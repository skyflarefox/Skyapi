-- Lua provided by SkyAPI 
-- Game: Citystate II
addappid(1352850)
addappid(1352851, 1, "a9f4aacc2b9293fce5e3c1c38e975aee543b830783c7e09ca6e4c3a7e24c6cf1")
