-- Lua provided by SkyAPI 
-- Game: Halo Wars: Definitive Edition
addappid(459220)
addappid(459221, 1, "d5ac4085e8993db07e41ff025f1a60abf083d790e0452af5900fcb82fce8acf0")
