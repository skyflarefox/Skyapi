-- Lua provided by SkyAPI 
-- Game: AppID 3019880
addappid(3019880)
addappid(3019881, 1, "2799b7b49c996bdbc1251ad843f9349005e2a03b93fb725583f332479f806a67")
