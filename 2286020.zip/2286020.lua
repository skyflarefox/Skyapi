-- Lua provided by SkyAPI 
-- Game: The Pyramid Of Bones
addappid(2286020)
addappid(2286021, 1, "5e3c1921b53ca621bb2dd9fb35aa0172b47ac5eb49968d45f155f776ca531b39")
