-- Lua provided by SkyAPI 
-- Game: Alpha Shark
addappid(1806400)
addappid(1806401, 1, "ddf5e1384b1ec06dbbe4f7eadc57deda91a464f1500fdc89bebba9f2d272cc8f")
