-- Lua provided by SkyAPI 
-- Game: Strong Moon
addappid(2143450)
addappid(2143451, 1, "bf85280963ebe1a636ac9f2205f391b9d294f6b3f0394d3891d4007541387839")
