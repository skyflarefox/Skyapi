-- Lua provided by SkyAPI 
-- Game: Darklands:Awakening
addappid(1423500)
addappid(1423501, 1, "161eb0d7bec41e6244b9478ca07c3d88fa8159c9c69a98943edbe522766f298c")
