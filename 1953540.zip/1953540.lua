-- Lua provided by SkyAPI 
-- Game: Furry Shades of Gay 3: Still Gayer
addappid(1953540)
addappid(1953541, 1, "ef31b1e72044b74697cbaef9e815f5ea7097f86c051b7271c2c7d97ae66df3af")
addappid(2573080, 0, "326b2c34adec870789a2e0a5e51d16ff3b4cf790548657a59c0f1410d53717dc")
addappid(2573090, 0, "2ef434264d01e0e13ca4663dd15b0f6820dacebab95d0a40012317a1547f250b")
