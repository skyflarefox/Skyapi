-- Lua provided by SkyAPI 
-- Game: Formata
addappid(580040)
addappid(580041, 1, "3eeeb214f049bd50af6b81128523257251df0f2ca2d6c0eea03c03ba7880c501")
