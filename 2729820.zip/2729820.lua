-- Lua provided by SkyAPI 
-- Game: Vending Dokan!: Kozy Kiosk
addappid(2729820)
addappid(2729821, 1, "e83b8c23c429c67b8e5ab50445864db481598c87bcc7fd11a875c7bf24a722da")
