-- Lua provided by SkyAPI 
-- Game: Super Jigsaw Puzzle
addappid(792650)
addappid(792651, 1, "8b168ddfca95c29dd2ae8ce9e4001ea0ceda2515deaa398e640d0ad81c7357b7")
addappid(1051520, 0, "54a1aacef02c75a9ea7a6f297899a4917f0b920fceba9b98b7eeb358b800d15c")
