-- Lua provided by SkyAPI 
-- Game: 101 Cats in Las Vegas
addappid(3072060)
addappid(3072061, 1, "5a73caea40ea2d9b7a7ac55c8623fe01778a520337ad16dce31646e67a7c9961")
