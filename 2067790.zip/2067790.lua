-- Lua provided by SkyAPI 
-- Game: Crimson Snow (2023)
addappid(2067790)
addappid(2067791, 1, "29921a70c90074f509873c0a98c12f2f93cd0d32c5bc0d17944a9c83802377fb")
