-- Lua provided by SkyAPI 
-- Game: AppID 743650
addappid(743650)
addappid(743651, 1, "527af2d1792b4ae9dab3157589125765d37b1670dbe436d89ccec29649ca5c7a")
