-- Lua provided by SkyAPI 
-- Game: Blacksad: Under the Skin
addappid(1003890)
addappid(1003891, 1, "08864a449ba7f972995a5ccee45e85056d3feeaf97122380167efe0260631ecb")
addappid(1003892, 1, "267878109be2b1410a1b3ae8a9f22833d3625349fc5bb1f5c505a558567131c8")
