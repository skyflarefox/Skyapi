-- Lua provided by SkyAPI 
-- Game: Little Kingdom RTS
addappid(3711950)
addappid(3711951, 1, "281a6428b253ee6de0eb508c4e241c5236ff6d1665b55a81d46ff80cdd852fb5")
