-- Lua provided by SkyAPI 
-- Game: Horror Royale
addappid(1610370)
addappid(1610371, 1, "d5f13b8b50385a58d8f7d61f9c0d561a8e4d06ed4f93e719fd4167b830054516")
