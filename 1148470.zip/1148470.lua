-- Lua provided by SkyAPI 
-- Game: Killjoy Hunter Yuuko
addappid(1148470)
addappid(1148471, 1, "ea6316a04d7c61dee023c24e892086a41ee6842b6b27bec5f42b830ba2e7fe41")
