-- Lua provided by SkyAPI 
-- Game: Project Werewulf Demo
addappid(2618270)
addappid(2618271, 1, "78069c5d6e67f7967aec6a99fc41bd7ddb25723f7498399a267991589cf692c2")
