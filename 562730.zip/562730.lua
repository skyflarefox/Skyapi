-- Lua provided by SkyAPI 
-- Game: MechDefender - Tower Defense
addappid(562730)
addappid(562731, 1, "38a7603fd5aa70b4f3fdd8147bd643c6c7c93259efe39a770b844ef6f9962e9d")
addappid(562732, 1, "6e88b199b7d95e18c1b39288e54eb431186130bee3fd0e878b94a4d55455d52d")
