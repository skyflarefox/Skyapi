-- Lua provided by SkyAPI 
-- Game: TRAFFIC
addappid(2091510)
addappid(2091511, 1, "a4f7908dba502980322976d3db19035e1b08e0f62ac7e2db94fbf54718900f8e")
