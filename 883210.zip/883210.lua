-- Lua provided by SkyAPI 
-- Game: Immortal: Unchained - Primes Pack
addappid(883210)
addappid(883211, 1, "c3c07687a158e55b4158dc3196b637cc19af94a9a42d63673ec330579a387caf")
