-- Lua provided by SkyAPI 
-- Game: Dungeon Inn
addappid(2552310)
addappid(2552311, 1, "a48d53d95522fbe56c2435f9f17d6b85e7280d997aaeda7da4de01790c56e4ad")
