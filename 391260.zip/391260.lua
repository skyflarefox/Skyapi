-- Lua provided by SkyAPI 
-- Game: AppID 391260
addappid(391260)
addappid(391261, 1, "44a0a3e6b3e2c0fc08d65a7bfedfd9fdb886915f7e57df64da82a969dcb30e4d")
