-- Lua provided by SkyAPI 
-- Game: AppID 2150230
addappid(2150230)
addappid(2150231, 1, "5103ef744acaf46e7b88863ec9f16d96f3cc9aef811a37291884088df21831e9")
