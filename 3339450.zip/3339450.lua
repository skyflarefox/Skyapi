-- Lua provided by SkyAPI 
-- Game: Deliverance
addappid(3339450)
addappid(3339451, 1, "2799bea0abedd628c0701769963ae1b476a5282b7a1d0c567b4ec070c7ec5371")
