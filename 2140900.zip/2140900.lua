-- Lua provided by SkyAPI 
-- Game: The Unluckiest Man
addappid(2140900)
addappid(2140901, 1, "4db766c8b3e05e0d0d2c073caea434cc7728e567adfd63e610955fa9dc4866e7")
