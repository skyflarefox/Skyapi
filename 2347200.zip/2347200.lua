-- Lua provided by SkyAPI 
-- Game: CETERIS Paribus
addappid(2347200)
addappid(2347201, 1, "4556489f8421a45ea65254ab7fdedd70208c81a4f4286df036124778c18eb50c")
