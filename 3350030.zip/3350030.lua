-- Lua provided by SkyAPI 
-- Game: The Permanent Residence : Souls Kept
addappid(3350030)
addappid(3350031, 1, "59c695f77d04989e7e44537c879a020165a99fb228c301bc82f898426824198c")
