-- Lua provided by SkyAPI 
-- Game: The Third Building 三教 Demo
addappid(1072970)
addappid(1072971, 1, "4a2a8523eaec7bd27d097905d37e0c16a75b915956cbcc0f4c0a0331884d2c3b")
