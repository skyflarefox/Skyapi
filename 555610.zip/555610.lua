-- Lua provided by SkyAPI 
-- Game: Gunmetal Arcadia Zero
addappid(555610)
addappid(555611, 1, "53e39b8fdc8cc00f1ab24d4e8d6d7a6fc23d135e6c706909a91f2a2e6a307408")
addappid(555612, 1, "27359dd3ae09b6041e4355538d7ff0ca3f2971b7cc535e54e2da11079222617c")
addappid(555613, 1, "a779fc13656b4f2d7c03043a1c119b14eef7c2d7b78e0b4da5a78dd10887ccdf")
