-- Lua provided by SkyAPI 
-- Game: Cooking Simulator 2: Better Together
addappid(2455360)
addappid(2455361, 1, "246c514beec3f2192841f0ad37f41d13200f24a0b56edf2d21111c6a688e0a09")
