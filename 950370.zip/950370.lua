-- Lua provided by SkyAPI 
-- Game: Tactics & Strategy Master 2:Princess of Holy Light（圣光战姬）
addappid(950370)
addappid(950371, 1, "a59f83a4f699a61d54fa7d260e2ad5737e80648813299c2d8c387e00ef4cd1a5")
addappid(950372, 1, "74c29142c67d7f72faef0b5c8a0e6cfe9da014a6c78b210ef468a5caaccc1e06")
addappid(950373, 1, "4673de6deddcf98255b0471360c695f357e30253d70b7cc9a3c6f84611db593e")
addappid(1002940, 0, "d1580009f926dc5e5209bfa2b712740331ff61711883f8ae6d687ba709a44d62")
addappid(1064500)
addappid(1072360, 0, "e30eea6fd2818692b06f1764a421b3b6c7f6d673281cdbfaf133b9560a5e2b39")
