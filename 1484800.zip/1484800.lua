-- Lua provided by SkyAPI 
-- Game: Zardy's Maze
addappid(1484800)
addappid(1484801, 1, "775ada796c83834f256b77d73d100f1316807711a9a43b1d48f5f55d428f2d5e")
addappid(1484802, 1, "c79def08e13d96545b6580d79e88b6facc667fd201ca6766ca6a2b104cbc0fb9")
