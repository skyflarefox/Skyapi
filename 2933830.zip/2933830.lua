-- Lua provided by SkyAPI 
-- Game: Project: Stellar Girls
addappid(2933830)
addappid(2933831, 1, "f7d5545342d172511ae46ca84228cc757b016972a30bc6b4aa1a2c354feab7cc")
