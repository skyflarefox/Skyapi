-- Lua provided by SkyAPI 
-- Game: Plushie from the Sky
addappid(1679510)
addappid(1679511, 1, "42f67c5679f8552d4ba81b6178652889adbcb6e70e01a4016a4961e2acc17668")
