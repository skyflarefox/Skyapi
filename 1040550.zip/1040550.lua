-- Lua provided by SkyAPI 
-- Game: AppID 1040550
addappid(1040550)
addappid(1040551, 1, "7b5b71e839b06d4f5da17661b5fc359e0af3e223d1352b13c76dc105a48918f3")
addappid(1195750, 0, "1ae13e4d5c413feba6bfec3a530b40b0db02d867c7cc68d1a5cbbc449f7bd681")
