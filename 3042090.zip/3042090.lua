-- Lua provided by SkyAPI 
-- Game: Prison of Nightmare
addappid(3042090)
addappid(3042091, 1, "5745caa06cc6e35068ec395d702f7d86d1f3eccf5613a8d8135ee2e5dee3dc19")
