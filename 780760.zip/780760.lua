-- Lua provided by SkyAPI 
-- Game: Lots of Balls
addappid(780760)
addappid(780761, 1, "05ce236b13dc8347e0396d62cfd988c246d9ecaddf2ce40f02af0467fdfcc125")
