-- Lua provided by SkyAPI 
-- Game: Judgment
addappid(2058180)
addappid(2058181, 1, "2c5b08fe950ac2f5fcfc838f3ebcf0f1863bcb65ffc05bb859d1e3f8cd20fb99")
