-- Lua provided by SkyAPI 
-- Game: Rhino Runner
addappid(2542190)
addappid(2542191, 1, "ce1b7f88e30a773757a981b8611177478a24dbe22238d6f575a2b06e2fa4cf70")
