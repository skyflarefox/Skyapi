-- Lua provided by SkyAPI 
-- Game: AppID 1769830
addappid(1769830)
addappid(1769831, 1, "8c3967335c3e1b93c4524d512a00c44d7f35ea4d64b2e0158b9f852c1d8da9ec")
