-- Lua provided by SkyAPI 
-- Game: My Girlfriend is a Futanari
addappid(2152070)
addappid(2152071, 1, "a577910085edd9f10ba353c5824fc90c2722cd45fb72f60d1d30a3f61c4a5377")
