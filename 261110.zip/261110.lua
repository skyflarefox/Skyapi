-- Lua provided by SkyAPI 
-- Game: Killer is Dead - Nightmare Edition
addappid(261110)
addappid(261111, 1, "ff9740958a5c5a4a40e1bb7c34ebccb7118231fac738cdfb22ad5cfc7daabb3a")
addappid(261112, 1, "9c67bd4ee7cf816411e75721ce8452d8c584f276cad8cc1fdf5b1988314e3c23")
