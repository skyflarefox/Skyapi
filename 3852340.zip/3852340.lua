-- Lua provided by SkyAPI 
-- Game: The Last Ski Trip
addappid(3852340)
addappid(3852341, 1, "2be03621e222414cf61594fc9575d127ed9850c4f66bc1046fbb29f0ecce829f")
