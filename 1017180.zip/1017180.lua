-- Lua provided by SkyAPI 
-- Game: AppID 1017180
addappid(1017180)
addappid(1017181, 1, "244a982ca42ee3d2f9489b8debf008732bea45f9a499101041e26bd0dccfa4ed")
