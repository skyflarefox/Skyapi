-- Lua provided by SkyAPI 
-- Game: SAMURAI WARRIORS 4 DX
addappid(2719200)
addappid(2719201, 1, "fc9bc29b7a3f568c45da0e49f09ac00bfd7f6c4048029d697469d85f756124ab")
