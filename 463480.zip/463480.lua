-- Lua provided by SkyAPI 
-- Game: AppID 463480
addappid(463480)
addappid(463481, 1, "8342119b96ae02668c300a08fc9ae0864394c378c3707e2458a3f372c4dd3fca")
