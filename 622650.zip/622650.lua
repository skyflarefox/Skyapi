-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(622650)
addappid(622651,0,"525bb062dc2acf46744d4fbd02044d28bad4f3266fe3c8e42bd6fdd1d2030e97")
setManifestid(622651,"3839364653133507972")
addappid(622652,0,"ff3dc383c775b96130d7be30d5b3a0b9d28a8a761f48663a342206e48f58ff0c")
setManifestid(622652,"1235752666285185366")
addappid(622653,0,"32f8523448cd804dbdb79f690000a9a39ec66e90f2b4b8db6dee433092a4abf4")
setManifestid(622653,"8875080210494677398")
addappid(622654,0,"b05fea5e1e495e4c071fee38d3d800ab0c2bc123fbfc9609da2bf49f614ac42e")
setManifestid(622654,"779084498159863616")