-- Lua provided by SkyAPI 
-- Game: AppID 1203030
addappid(1203030)
addappid(1203031, 1, "4c0ecaa5f4b7f5ec0eb2c0ab464062cc3e1784c3319450abbfecad9142411dde")
