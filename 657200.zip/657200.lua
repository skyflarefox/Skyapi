-- Lua provided by SkyAPI 
-- Game: AppID 657200
addappid(657200)
addappid(657201, 1, "98696297d19b950f17a54b6507fafdea956f0034d8ba3ab01810a1e7b707aa82")
