-- Lua provided by SkyAPI 
-- Game: Isekai Rondo
addappid(2476490)
addappid(2476491, 1, "5deba1f6179a303b6779809bdbd54aa74622a666cf78e1e8eda9b3e0d5dfca74")
