-- Lua provided by SkyAPI 
-- Game: Amoreon NightClub
addappid(701100)
addappid(701101, 1, "c9506a865e975960991b796d84e254d2c4016d4aa8226697c82976687fe44d81")
