-- Lua provided by SkyAPI 
-- Game: Twist & Turn
addappid(2458540)
addappid(2458541, 1, "51285d4946a0c2f0eb09db4694aa864d62ef15adad81cfa57f679b9332325d45")
