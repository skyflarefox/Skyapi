-- Lua provided by SkyAPI 
-- Game: Lup
addappid(412600)
addappid(412601, 1, "858521850f2d033495760124118b15d04a65dece23e812b000b75a53656020a5")
