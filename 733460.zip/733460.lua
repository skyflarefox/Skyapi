-- Lua provided by SkyAPI 
-- Game: First Feudal
addappid(733460)
addappid(733461, 1, "e856fd9d2e84507c88c02a549fe575b3ff174ea91d83ed4c0aa9d549f606dd30")
