-- Lua provided by SkyAPI 
-- Game: Cat Girl
addappid(686180)
addappid(686181, 1, "78d1ac361ce6fd5f20458edd5cc9ce20a3d360c9533b5dfb51e974f91a03be08")
