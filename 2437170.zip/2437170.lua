-- Lua provided by SkyAPI 
-- Game: SMITE 2
addappid(2437170)
addappid(2437171, 1, "b812d1b17a2a57774d8eaf7f83f550ef62d7233a26b05d5133ad110d489f5600")
