-- Lua provided by SkyAPI 
-- Game: Urbek City Builder
addappid(1411740)
addappid(1411741, 1, "f4f2b530a631136f02801aec57b9156b68cab76e189d36fac3b15b1669cab56d")
