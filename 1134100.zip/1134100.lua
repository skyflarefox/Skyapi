-- Lua provided by SkyAPI 
-- Game: Frozenheim
addappid(1134100)
addappid(1134101, 1, "4c5467587a34d40d8980200a39b4ffcfdeec32c4944bae3e459fb3f5d0c3a7c4")
