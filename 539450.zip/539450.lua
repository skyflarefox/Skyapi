-- Lua provided by SkyAPI 
-- Game: Crab Dub
addappid(539450)
addappid(539451, 1, "820641c317b7eacca62a0f6d3772ef1d29bc619a165710058100f44a184cca9b")
addappid(560400, 0, "aa57689469db8d85d8cdb0e0a3a3ac903178a98f1b24065a53e0db6191c6aaec")
