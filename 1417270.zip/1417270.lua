-- Lua provided by SkyAPI 
-- Game: Mind-Blowing Girls
addappid(1417270)
addappid(1417271, 1, "7ad42f1020d529ae03bcd60faa13f675a80f1223f02a563fafa0e3915c109ead")
addappid(1428510)
