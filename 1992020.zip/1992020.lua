-- Lua provided by SkyAPI 
-- Game: Demons Happened
addappid(1992020)
addappid(1992021, 1, "49ed211cb9629ebb5eb3e69755717ff65377134fe84ab1fd708096c598c8011d")
