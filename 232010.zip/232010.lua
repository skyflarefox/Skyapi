-- Lua provided by SkyAPI 
-- Game: Euro Truck Simulator
addappid(232010)
addappid(232011, 1, "93bc394ef460f199bd0d58d805e3cfd47d3793ad705a9d66fa9a4ea9bc819be3")
addappid(232012, 1, "eee24598d30f66f53b02477b62b46e26866a3a4af6f45b9c9b60f900705ccd9a")
