-- Lua provided by SkyAPI 
-- Game: AppID 801290
addappid(801290)
addappid(801291, 1, "e56db289229de0e078365dafd22618699da05061024e55d3a862e70ea38644d7")
