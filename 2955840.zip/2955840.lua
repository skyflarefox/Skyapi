-- Lua provided by SkyAPI 
-- Game: Kitchen Wars
addappid(2955840)
addappid(2955841, 1, "f3c6a7fcc9e3aefecc0226e9a0f026f6590f6dd6d66c02f07e1a787e4c62fd60")
