-- Lua provided by SkyAPI 
-- Game: CONSORTIUM
addappid(264240)
addappid(264241, 1, "02e4f5e2d6a17857eb13acc5ac9ebca0de56c45a3ccf2cf1c0c58f7ada076df6")
addappid(264242, 1, "5f3606b2c6a0c2fd72c2315f2cf4d44fc1ff5df9b259d53c782bbc3c7374d904")
addappid(298810, 0, "5b1ab6f8eb0ed0849505fae48025c702fa194770637472af83c89acd3a2d83fe")
addappid(395040, 0, "290e0a96aef6912e5ef2b04b8d5550aafec1052437e41ae0b8e6c6ebd4ef9034")
