-- Lua provided by SkyAPI 
-- Game: Cyndy
addappid(1014730)
addappid(1014731, 1, "193799e91e157a55517d63b73f4d83d76ce21fb9d9dd5e5c90cb8c849fd22b61")
addappid(1014733, 1, "592653283c81676a577e5042c97bd250a9b15e16de5772a9cf70d0bd79f07bae")
