-- Lua provided by SkyAPI 
-- Game: Dead Climb
addappid(750080)
addappid(750081, 1, "9c5b61c3e0a63d84aede5a28623e9fb3edf0bb0f0d780a21d81312626346349d")
addappid(750082, 1, "61b29043388f0c73ab54b8cc39651c8812736b27b3aaf8f016335350fcef3457")
