-- Lua provided by SkyAPI 
-- Game: EURGAVA™: Fight for Haaria
addappid(559350)
addappid(559351, 1, "3bde5b73ba98dc4923970bc96cfe774a5e045f15e85cd8af81d0dd950a2c12bd")
