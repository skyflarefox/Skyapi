-- Lua provided by SkyAPI 
-- Game: TEVI
addappid(2230650)
addappid(2230651, 1, "cf4bd9819dcbe55a664cd8774f36ed68fb0bcff0071c1600b939704a3b7df38f")
