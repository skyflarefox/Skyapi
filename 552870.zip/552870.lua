-- Lua provided by SkyAPI 
-- Game: aMAZEing adventures
addappid(552870)
addappid(552871, 1, "349ff73ecc3646d5757ef8222d42b165865b29c3e0943ecf536e484a5cc94577")
