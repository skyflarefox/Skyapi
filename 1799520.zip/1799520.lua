-- Lua provided by SkyAPI 
-- Game: The Legend of Pomodoro
addappid(1799520)
addappid(1799521, 1, "0f464c8b240e3a30347f9c87c6925bdcd476f46cc3b3e4664fd17a5857dc7a67")
