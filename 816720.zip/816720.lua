-- Lua provided by SkyAPI 
-- Game: AppID 816720
addappid(816720)
addappid(816721, 1, "2eb1a115e48221707e642a5b7c11bbe219d1aca2563768eb5ed38812cfbe8957")
addappid(1103680, 0, "a6ee29a77ae1f0dd0e56c0d34a7c2f656581a63962111c484db2d79c8c904f8f")
