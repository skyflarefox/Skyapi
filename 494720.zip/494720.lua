-- Lua provided by SkyAPI 
-- Game: Morphblade
addappid(494720)
addappid(494721, 1, "786ccca32e36d65937176e58abcc39577025c7f139424d710b5bb8c0b4df8a49")
